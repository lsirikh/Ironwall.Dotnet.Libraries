---
name: python-patterns
description: Python 3.11+ 핵심 패턴 — type hints, dataclass, async, pattern matching
languages: ["Python"]
frameworks: ["Python 3.11+"]
phases: ["dev", "test"]
---

# Python Patterns

## When to Activate

- Python 프로젝트에서 코드 작성 시
- CLAUDE.md language가 Python일 때

## Core Patterns

### Type Hints (3.10+)

```python
# Union → X | Y (3.10+)
def process(value: int | str) -> str: ...

# Optional → X | None
def find_user(id: int) -> User | None: ...

# TypeVar + Protocol for duck typing
from typing import Protocol

class Readable(Protocol):
    def read(self) -> bytes: ...

def load(source: Readable) -> str:
    return source.read().decode()
```

### Dataclasses

```python
from dataclasses import dataclass, field

@dataclass(frozen=True, slots=True)
class Config:
    host: str
    port: int = 8000
    tags: list[str] = field(default_factory=list)

    def __post_init__(self):
        if self.port < 0:
            raise ValueError(f"Invalid port: {self.port}")
```

### Async/Await

```python
import asyncio

# TaskGroup (3.11+) — gather 대체
async def fetch_all(urls: list[str]) -> list[str]:
    async with asyncio.TaskGroup() as tg:
        tasks = [tg.create_task(fetch(url)) for url in urls]
    return [t.result() for t in tasks]

# Blocking I/O in async context
result = await asyncio.to_thread(blocking_function, arg1)
```

### Structural Pattern Matching (3.10+)

```python
match command:
    case {"action": "create", "name": str(name)}:
        create_item(name)
    case {"action": "delete", "id": int(id_)}:
        delete_item(id_)
    case _:
        raise ValueError(f"Unknown command: {command}")
```

### Context Managers

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def managed_connection(url: str):
    conn = await connect(url)
    try:
        yield conn
    finally:
        await conn.close()
```

### Path Operations

```python
from pathlib import Path

# pathlib over os.path
config_path = Path.home() / ".config" / "app" / "settings.json"
config_path.parent.mkdir(parents=True, exist_ok=True)
config_path.write_text(json.dumps(data))

for py_file in Path("src").rglob("*.py"):
    print(py_file.stem)
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| `from typing import Optional, Union` | `X \| None`, `X \| Y` | 3.10+ syntax is cleaner |
| `os.path.join(a, b)` | `Path(a) / b` | pathlib is more expressive |
| `asyncio.gather(*tasks)` | `async with TaskGroup()` | TaskGroup cancels on error |
| Bare `except:` | `except ValueError:` | Catch specific exceptions |
| `print()` for debugging | `logging.debug()` | Structured, configurable |
| Nested list comprehension | For loop | Readability |
| `dict.keys()` check | `key in dict` | Simpler, faster |
| Mutable default `def f(x=[])` | `def f(x=None)` | Shared mutable state bug |
