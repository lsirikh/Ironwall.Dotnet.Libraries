// .claude/hooks/_learning.js
// Learning Loop 모듈 — FR-01, FR-04, FR-05, FR-08
//
// observations.jsonl 분석, instinct CRUD, feedback-rule 변환을 제공.
// learn 스킬과 session-gate.js가 사용한다.
//
// 설계 원칙:
//   - instinct→rule 변환 시 action은 항상 "remind" (block 금지, NFR-03)
//   - 파일 손상 시 빈 배열 반환 (NFR-04)
//   - 외부 의존성 없음 (순수 Node.js)

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const OBS_FILE = path.join(ROOT, 'docs', 'memory', 'observations.jsonl');
const INST_FILE = path.join(ROOT, 'docs', 'memory', 'instincts.jsonl');
const FB_FILE = path.join(ROOT, 'docs', 'memory', 'feedback-rules.json');
const ARCHIVE_DIR = path.join(ROOT, 'docs', 'memory', 'observations-archive');

// ── Observations ────────────────────────────────────────────────────

/**
 * observations.jsonl에서 최근 N개 로드
 * @param {number} limit
 * @returns {Array<Object>}
 */
function loadObservations(limit = 200) {
  try {
    if (!fs.existsSync(OBS_FILE)) return [];
    const lines = fs.readFileSync(OBS_FILE, 'utf8').trim().split('\n').filter(Boolean);
    const recent = lines.slice(-limit);
    const results = [];
    for (const line of recent) {
      try { results.push(JSON.parse(line)); }
      catch { /* skip malformed */ }
    }
    return results;
  } catch { return []; }
}

/**
 * observation 분석 — 파일 유형별/tool별/phase별 통계
 * @param {Array<Object>} observations
 * @returns {{fileTypeStats, toolPreferences, phasePatterns, total}}
 */
function analyzeObservations(observations) {
  const fileTypeStats = {};  // { ".cs": { count, tools: { Edit: N, Write: N } } }
  const toolPreferences = {}; // { "Edit": N, "Write": N }
  const phasePatterns = {};   // { "dev": { count, fileTypes: {} } }

  for (const obs of observations) {
    const ft = obs.file_type || 'unknown';
    const tool = obs.tool || 'unknown';
    const phase = obs.phase || 'unknown';

    // file type stats
    if (!fileTypeStats[ft]) fileTypeStats[ft] = { count: 0, tools: {} };
    fileTypeStats[ft].count++;
    fileTypeStats[ft].tools[tool] = (fileTypeStats[ft].tools[tool] || 0) + 1;

    // tool preferences
    toolPreferences[tool] = (toolPreferences[tool] || 0) + 1;

    // phase patterns
    if (!phasePatterns[phase]) phasePatterns[phase] = { count: 0, fileTypes: {} };
    phasePatterns[phase].count++;
    phasePatterns[phase].fileTypes[ft] = (phasePatterns[phase].fileTypes[ft] || 0) + 1;
  }

  return { fileTypeStats, toolPreferences, phasePatterns, total: observations.length };
}

// ── Instincts ───────────────────────────────────────────────────────

/**
 * instincts.jsonl 로드
 * @returns {Array<Object>}
 */
function loadInstincts() {
  try {
    if (!fs.existsSync(INST_FILE)) return [];
    const lines = fs.readFileSync(INST_FILE, 'utf8').trim().split('\n').filter(Boolean);
    const results = [];
    for (const line of lines) {
      try { results.push(JSON.parse(line)); }
      catch { /* skip */ }
    }
    return results;
  } catch { return []; }
}

/**
 * instinct 저장 (append)
 * @param {Object} instinct
 */
function saveInstinct(instinct) {
  try {
    const dir = path.dirname(INST_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(INST_FILE, JSON.stringify(instinct) + '\n');
    return true;
  } catch { return false; }
}

/**
 * instinct 업데이트 (id로 찾아서 갱신)
 * @param {string} id
 * @param {Object} updates
 */
function updateInstinct(id, updates) {
  try {
    const instincts = loadInstincts();
    const idx = instincts.findIndex(i => i.id === id);
    if (idx === -1) return false;
    Object.assign(instincts[idx], updates);
    instincts[idx].last_seen = new Date().toISOString().slice(0, 10);
    // 전체 재작성
    const content = instincts.map(i => JSON.stringify(i)).join('\n') + '\n';
    fs.writeFileSync(INST_FILE, content);
    return true;
  } catch { return false; }
}

/**
 * 다음 instinct ID 생성
 */
function nextInstinctId() {
  const instincts = loadInstincts();
  const maxNum = instincts.reduce((max, i) => {
    const m = (i.id || '').match(/INST-(\d+)/);
    return m ? Math.max(max, parseInt(m[1], 10)) : max;
  }, 0);
  return `INST-${String(maxNum + 1).padStart(3, '0')}`;
}

/**
 * 분석 결과에서 instinct 후보 추출
 * 3회+ 반복 패턴만 추출. 기존 instinct과 중복 검사.
 * @param {Object} analysis - analyzeObservations() 결과
 * @returns {Array<Object>} instinct 후보 목록
 */
function extractInstincts(analysis) {
  const candidates = [];
  const existing = loadInstincts();
  const existingPatterns = existing.map(i => i.pattern.toLowerCase());

  // 파일 유형별 도구 선호
  for (const [ft, stats] of Object.entries(analysis.fileTypeStats)) {
    if (ft === 'unknown' || stats.count < 3) continue;
    const topTool = Object.entries(stats.tools)
      .sort((a, b) => b[1] - a[1])[0];
    if (topTool && topTool[1] >= 3) {
      const pattern = `${ft} 파일은 주로 ${topTool[0]} 도구로 작업 (${topTool[1]}회/${stats.count}회)`;
      if (!existingPatterns.includes(pattern.toLowerCase())) {
        const confidence = topTool[1] / stats.count;
        candidates.push({
          pattern,
          category: 'tool-preference',
          confidence: Math.round(confidence * 100) / 100,
          occurrences: topTool[1],
          evidence_count: stats.count,
          file_type: ft,
          tool: topTool[0]
        });
      }
    }
  }

  // phase별 파일 유형 선호
  for (const [phase, stats] of Object.entries(analysis.phasePatterns)) {
    if (phase === 'unknown' || stats.count < 3) continue;
    const topFt = Object.entries(stats.fileTypes)
      .sort((a, b) => b[1] - a[1])[0];
    if (topFt && topFt[1] >= 3) {
      const pattern = `${phase} phase에서 ${topFt[0]} 파일을 주로 편집 (${topFt[1]}회)`;
      if (!existingPatterns.includes(pattern.toLowerCase())) {
        candidates.push({
          pattern,
          category: 'workflow',
          confidence: Math.round((topFt[1] / stats.count) * 100) / 100,
          occurrences: topFt[1],
          phase,
          file_type: topFt[0]
        });
      }
    }
  }

  return candidates;
}

// ── Instinct → Feedback Rule 변환 ───────────────────────────────────

/**
 * instinct를 feedback-rule로 변환
 * action은 항상 "remind" (block 금지, NFR-03)
 * @param {Object} instinct
 * @returns {Object|null} feedback rule 또는 null (변환 불가)
 */
function instinctToRule(instinct) {
  if (!instinct || !instinct.confidence || instinct.confidence < 0.8) return null;

  const rule = {
    id: `FB-AUTO-${instinct.id.replace('INST-', '')}`,
    type: 'auto-learned',
    trigger: { phase: '*', tool: '*', target: null },
    action: 'remind',  // 항상 remind — NFR-03
    severity: 'low',
    message: instinct.pattern,
    source: `instinct:${instinct.id}`,
    created: new Date().toISOString().slice(0, 10),
    active: true
  };

  // category별 trigger 설정
  if (instinct.category === 'tool-preference' && instinct.file_type) {
    const ext = instinct.file_type.replace('.', '\\.');
    rule.trigger.target = `${ext}$`;
    rule.trigger.tool = instinct.tool || '*';
  } else if (instinct.category === 'workflow' && instinct.phase) {
    rule.trigger.phase = instinct.phase;
  }

  return rule;
}

/**
 * feedback-rules.json에 규칙 추가
 * @param {Object} rule
 */
function appendFeedbackRule(rule) {
  try {
    let rules = [];
    if (fs.existsSync(FB_FILE)) {
      rules = JSON.parse(fs.readFileSync(FB_FILE, 'utf8'));
    }
    // 중복 검사
    if (rules.some(r => r.source === rule.source)) return false;
    rules.push(rule);
    fs.writeFileSync(FB_FILE, JSON.stringify(rules, null, 2) + '\n');
    return true;
  } catch { return false; }
}

// ── Observation GC ──────────────────────────────────────────────────

/**
 * observations.jsonl GC — maxLines 초과 시 오래된 절반을 아카이브
 * @param {number} maxLines
 */
function gcObservations(maxLines = 1000) {
  try {
    if (!fs.existsSync(OBS_FILE)) return { archived: 0 };
    const lines = fs.readFileSync(OBS_FILE, 'utf8').trim().split('\n').filter(Boolean);
    if (lines.length <= maxLines) return { archived: 0 };

    const archiveCount = Math.floor(lines.length / 2);
    const toArchive = lines.slice(0, archiveCount);
    const toKeep = lines.slice(archiveCount);

    // 월별 아카이브 파일명
    const now = new Date();
    const archiveFile = path.join(ARCHIVE_DIR, `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}.jsonl`);

    if (!fs.existsSync(ARCHIVE_DIR)) fs.mkdirSync(ARCHIVE_DIR, { recursive: true });
    fs.appendFileSync(archiveFile, toArchive.join('\n') + '\n');
    fs.writeFileSync(OBS_FILE, toKeep.join('\n') + '\n');

    return { archived: archiveCount, remaining: toKeep.length, archiveFile };
  } catch { return { archived: 0 }; }
}

// ── Global Instincts ────────────────────────────────────────────────

// 글로벌 저장소: ~/.claude/global-instincts.jsonl
function getGlobalInstinctsPath() {
  const home = process.env.HOME || process.env.USERPROFILE || '';
  return path.join(home, '.claude', 'global-instincts.jsonl');
}

/**
 * 글로벌 instincts 로드
 * @returns {Array<Object>}
 */
function loadGlobalInstincts() {
  try {
    const gPath = getGlobalInstinctsPath();
    if (!fs.existsSync(gPath)) return [];
    const lines = fs.readFileSync(gPath, 'utf8').trim().split('\n').filter(Boolean);
    const results = [];
    for (const line of lines) {
      try { results.push(JSON.parse(line)); }
      catch { /* skip */ }
    }
    return results;
  } catch { return []; }
}

/**
 * instinct를 글로벌로 승격
 * confidence >= 0.9만 승격 가능
 * @param {Object} instinct - 승격할 instinct
 * @returns {{ok: boolean, reason?: string}}
 */
function promoteToGlobal(instinct) {
  if (!instinct || !instinct.id) return { ok: false, reason: 'invalid instinct' };
  if ((instinct.confidence || 0) < 0.9) {
    return { ok: false, reason: `confidence ${instinct.confidence} < 0.9 minimum` };
  }

  const gPath = getGlobalInstinctsPath();
  const gDir = path.dirname(gPath);

  try {
    // 디렉토리 생성
    if (!fs.existsSync(gDir)) fs.mkdirSync(gDir, { recursive: true });

    // 중복 검사
    const existing = loadGlobalInstincts();
    if (existing.some(g => g.pattern === instinct.pattern)) {
      return { ok: false, reason: 'already exists in global' };
    }

    // 글로벌 전용 필드 추가
    const globalInstinct = {
      ...instinct,
      scope: 'global',
      promoted_at: new Date().toISOString().slice(0, 10),
      promoted_from: ROOT.replace(/\\/g, '/')
    };

    fs.appendFileSync(gPath, JSON.stringify(globalInstinct) + '\n');

    // 프로젝트 instinct의 scope도 업데이트
    updateInstinct(instinct.id, { scope: 'global' });

    return { ok: true };
  } catch (e) { return { ok: false, reason: e.message }; }
}

/**
 * 모든 instincts (프로젝트 + 글로벌) 병합 로드
 * 중복 제거 (pattern 기준)
 * @returns {Array<Object>}
 */
function loadAllInstincts() {
  const project = loadInstincts();
  const global = loadGlobalInstincts();

  // 프로젝트 instinct 우선, 글로벌은 중복 아닌 것만 추가
  const patterns = new Set(project.map(i => i.pattern.toLowerCase()));
  const merged = [...project];
  for (const g of global) {
    if (!patterns.has(g.pattern.toLowerCase())) {
      merged.push(g);
    }
  }
  return merged;
}

module.exports = {
  loadObservations,
  analyzeObservations,
  loadInstincts,
  saveInstinct,
  updateInstinct,
  nextInstinctId,
  extractInstincts,
  instinctToRule,
  appendFeedbackRule,
  gcObservations,
  loadGlobalInstincts,
  promoteToGlobal,
  loadAllInstincts
};
