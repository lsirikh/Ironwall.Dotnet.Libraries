---
name: "Security Common"
description: "OWASP Top 10, secret management, authentication/authorization best practices, input validation, and security logging"
languages: ["*"]
frameworks: ["*"]
phases: ["test"]
---

# Security Common

## When to Activate

- 보안 취약점 리뷰 또는 코드 보안 검토
- 인증/인가 시스템 설계 또는 변경
- 시크릿 관리 방식 결정
- 입력 검증, XSS/SQL Injection 방어
- 보안 헤더, 의존성 스캐닝, 보안 로깅 설정

---

## Core Patterns

### 1. OWASP Top 10 (2021) Summary

| 순위 | 취약점 | 핵심 |
|------|--------|------|
| A01 | Broken Access Control | 인가 검증 누락으로 다른 사용자 데이터 접근 |
| A02 | Cryptographic Failures | 약한 암호화, 평문 전송/저장 |
| A03 | Injection | SQL/NoSQL/OS 명령어 삽입 |
| A04 | Insecure Design | 설계 단계에서 보안 고려 없음 |
| A05 | Security Misconfiguration | 기본 설정, 불필요한 기능 활성화 |
| A06 | Vulnerable Components | 취약한 라이브러리/프레임워크 사용 |
| A07 | Auth Failures | 약한 비밀번호, 세션 관리 미흡 |
| A08 | Data Integrity Failures | 무결성 검증 없는 역직렬화/업데이트 |
| A09 | Logging Failures | 보안 이벤트 미기록, 모니터링 부재 |
| A10 | SSRF | 서버가 악의적 URL을 요청하도록 유도 |

### 2. Injection Prevention

**SQL Injection:**
```python
# 나쁜 예 — 문자열 포맷팅 (SQL Injection 취약)
query = f"SELECT * FROM users WHERE email = '{email}'"
cursor.execute(query)

# 좋은 예 — 파라미터 바인딩
cursor.execute("SELECT * FROM users WHERE email = %s", (email,))

# ORM 사용 (SQLAlchemy)
user = session.query(User).filter(User.email == email).first()
```

```csharp
// C# — 파라미터 바인딩
// 나쁜 예
var query = $"SELECT * FROM Users WHERE Email = '{email}'";

// 좋은 예 — 파라미터화 쿼리
var cmd = new NpgsqlCommand("SELECT * FROM Users WHERE Email = @email", conn);
cmd.Parameters.AddWithValue("email", email);

// EF Core (기본적으로 파라미터화)
var user = context.Users.FirstOrDefault(u => u.Email == email);
```

```typescript
// TypeScript — Prisma (기본적으로 파라미터화)
const user = await prisma.user.findUnique({ where: { email } });

// Raw query — 반드시 파라미터 바인딩
const users = await prisma.$queryRaw`SELECT * FROM users WHERE email = ${email}`;
```

**Command Injection:**
```python
# 나쁜 예
import os
os.system(f"ping {user_input}")  # ; rm -rf / 주입 가능

# 좋은 예
import subprocess
subprocess.run(["ping", "-c", "4", user_input], check=True)  # 인자 분리
```

### 3. Secret Management

**절대 하지 말 것:**
```python
# 소스 코드에 시크릿 하드코딩
API_KEY = "sk-abc123def456"           # NEVER
DATABASE_URL = "postgres://admin:password@localhost/db"  # NEVER
```

**환경 변수 사용:**
```python
import os
API_KEY = os.environ["API_KEY"]       # 필수값 — 없으면 KeyError
DEBUG = os.environ.get("DEBUG", "false") == "true"  # 선택값

# .env 파일 (개발용, .gitignore에 반드시 포함)
# python-dotenv
from dotenv import load_dotenv
load_dotenv()
```

```csharp
// C# — Configuration
var apiKey = builder.Configuration["ApiKey"]
    ?? throw new InvalidOperationException("ApiKey not configured");

// appsettings.json에 시크릿 넣지 않기
// 대신: dotnet user-secrets set "ApiKey" "sk-abc123"
// 프로덕션: 환경 변수 또는 Azure Key Vault
```

**시크릿 관리 계층:**
```
개발: .env 파일 (gitignored) / dotnet user-secrets
스테이징: CI/CD 시크릿 변수 (GitHub Secrets, GitLab CI Variables)
프로덕션: 전용 Vault (HashiCorp Vault, AWS Secrets Manager, Azure Key Vault)
```

**시크릿 스캐닝:**
```bash
# pre-commit hook으로 시크릿 탐지
# gitleaks (https://github.com/gitleaks/gitleaks)
gitleaks detect --source . --verbose

# .gitleaks.toml — 커스텀 규칙
[[rules]]
  id = "custom-api-key"
  description = "Custom API Key"
  regex = '''(?i)(api[_-]?key|apikey)\s*[=:]\s*['"][a-zA-Z0-9]{20,}['"]'''
  tags = ["key", "api"]
```

### 4. Authentication Best Practices

**비밀번호 해싱:**
```python
# Python — bcrypt
import bcrypt

# 해싱 (가입 시)
password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12))

# 검증 (로그인 시)
is_valid = bcrypt.checkpw(input_password.encode(), stored_hash)

# 절대 하지 말 것
# hashlib.md5(password.encode()).hexdigest()  # MD5는 비밀번호용이 아님
# hashlib.sha256(password.encode()).hexdigest()  # salt 없는 SHA도 부적절
```

```csharp
// C# — BCrypt.Net
using BCrypt.Net;

// 해싱
var hash = BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);

// 검증
var isValid = BCrypt.Net.BCrypt.Verify(inputPassword, storedHash);
```

**JWT 토큰:**
```python
# Python — PyJWT
import jwt
from datetime import datetime, timedelta

SECRET_KEY = os.environ["JWT_SECRET"]

def create_token(user_id: int) -> str:
    payload = {
        "sub": str(user_id),
        "iat": datetime.utcnow(),
        "exp": datetime.utcnow() + timedelta(hours=1),  # 짧은 만료 시간
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise AuthError("Token expired")
    except jwt.InvalidTokenError:
        raise AuthError("Invalid token")
```

**세션 관리 규칙:**
- 세션 ID는 충분히 긴 랜덤 문자열 (128비트 이상)
- 로그인 시 세션 ID 재발급 (session fixation 방지)
- 비활동 타임아웃 설정 (15-30분)
- 절대 만료 시간 설정 (8-24시간)
- 로그아웃 시 서버 측 세션 무효화

**MFA (Multi-Factor Authentication):**
- 관리자 계정에는 필수
- TOTP (Time-based One-Time Password) 기반 — Google Authenticator 등
- SMS 기반 MFA는 SIM Swap 공격에 취약하므로 TOTP 선호

### 5. Authorization Patterns

**RBAC (Role-Based Access Control):**
```python
# 역할 기반 권한 체크
from enum import Enum
from functools import wraps

class Role(Enum):
    VIEWER = "viewer"
    EDITOR = "editor"
    ADMIN = "admin"

ROLE_PERMISSIONS = {
    Role.VIEWER: {"read"},
    Role.EDITOR: {"read", "write"},
    Role.ADMIN: {"read", "write", "delete", "manage_users"},
}

def require_permission(permission: str):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user, **kwargs):
            user_permissions = ROLE_PERMISSIONS.get(current_user.role, set())
            if permission not in user_permissions:
                raise HTTPException(status_code=403, detail="Forbidden")
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator

@app.delete("/users/{user_id}")
@require_permission("manage_users")
async def delete_user(user_id: int, current_user: User = Depends(get_current_user)):
    ...
```

**ABAC (Attribute-Based Access Control):**
```python
# 속성 기반 — 리소스 소유자만 수정 가능
@app.put("/orders/{order_id}")
async def update_order(order_id: int, current_user: User = Depends(get_current_user)):
    order = get_order(order_id)
    if order.user_id != current_user.id and current_user.role != Role.ADMIN:
        raise HTTPException(status_code=403, detail="Not your order")
    ...
```

### 6. Input Validation

```python
# Python — Pydantic 모델로 입력 검증
from pydantic import BaseModel, EmailStr, Field, validator
import re

class CreateUserRequest(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=100)
    age: int = Field(ge=0, le=150)

    @validator("name")
    def sanitize_name(cls, v):
        if re.search(r"[<>\"';]", v):
            raise ValueError("Invalid characters in name")
        return v.strip()
```

```csharp
// C# — Data Annotations + FluentValidation
public class CreateUserRequest
{
    [Required]
    [EmailAddress]
    [MaxLength(255)]
    public string Email { get; set; } = null!;

    [Required]
    [StringLength(100, MinimumLength = 1)]
    [RegularExpression(@"^[a-zA-Z\s\-]+$")]
    public string Name { get; set; } = null!;

    [Range(0, 150)]
    public int Age { get; set; }
}
```

**원칙:**
- 화이트리스트 검증 (허용 패턴 정의) > 블랙리스트 (금지 패턴 차단)
- 서버 측 검증은 필수 (클라이언트 측은 부가)
- 길이 제한, 타입 검증, 범위 검증을 항상 적용

### 7. XSS Prevention

```python
# Python — HTML 이스케이프
from markupsafe import escape

# 사용자 입력을 HTML에 렌더링할 때
safe_name = escape(user_input)  # <script> → &lt;script&gt;
```

```typescript
// TypeScript — DOMPurify (프론트엔드)
import DOMPurify from "dompurify";

const cleanHTML = DOMPurify.sanitize(userInput);
// <script>alert('xss')</script> → ""
```

**CSP (Content Security Policy):**
```
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'
```

### 8. Secure Headers

```python
# FastAPI — 보안 헤더 미들웨어
from starlette.middleware import Middleware
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware

@app.middleware("http")
async def add_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response
```

```csharp
// ASP.NET — 보안 헤더
app.Use(async (context, next) =>
{
    context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
    context.Response.Headers.Append("X-Frame-Options", "DENY");
    context.Response.Headers.Append("X-XSS-Protection", "1; mode=block");
    context.Response.Headers.Append("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    context.Response.Headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");
    await next();
});
```

### 9. Dependency Scanning

```bash
# Python — pip-audit, safety
pip-audit                              # 설치된 패키지 취약점 검사
safety check --file requirements.txt   # requirements.txt 기준 검사

# Node.js — npm audit
npm audit                              # 취약점 검사
npm audit fix                          # 자동 수정 (패치 버전)

# C# — dotnet list package --vulnerable
dotnet list package --vulnerable       # 취약한 NuGet 패키지 확인

# GitHub Dependabot — .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
```

### 10. Security Logging

```python
# 보안 이벤트 로깅 — 반드시 기록해야 할 이벤트
import logging

security_logger = logging.getLogger("security")

# 반드시 로깅
security_logger.warning("LOGIN_FAILED", extra={
    "ip": request.client.host,
    "email": email,
    "user_agent": request.headers.get("user-agent"),
    "timestamp": datetime.utcnow().isoformat(),
})

security_logger.info("LOGIN_SUCCESS", extra={"user_id": user.id, "ip": request.client.host})
security_logger.warning("ACCESS_DENIED", extra={"user_id": user.id, "resource": path, "action": method})
security_logger.critical("PRIVILEGE_ESCALATION_ATTEMPT", extra={"user_id": user.id, "target_role": "admin"})
```

**로깅 필수 이벤트:**
| 이벤트 | Level | 설명 |
|--------|-------|------|
| 로그인 실패 | WARNING | 브루트포스 탐지 |
| 로그인 성공 | INFO | 감사 추적 |
| 접근 거부 | WARNING | 권한 문제 추적 |
| 권한 변경 | WARNING | 권한 에스컬레이션 탐지 |
| 데이터 삭제 | INFO | 감사 추적 |
| 설정 변경 | WARNING | 보안 설정 변경 추적 |
| 비정상 입력 | WARNING | 공격 시도 탐지 |

**절대 로깅하면 안 되는 것:**
- 비밀번호 (해시 포함)
- 신용카드 번호
- 세션 토큰, API 키
- 주민등록번호 등 개인식별정보

### 11. SSRF Prevention

```python
# SSRF — 서버가 내부 네트워크로 요청하도록 유도
# 나쁜 예
@app.get("/fetch")
async def fetch_url(url: str):
    response = httpx.get(url)  # 사용자가 http://169.254.169.254/ 요청 가능
    return response.text

# 좋은 예 — URL 화이트리스트 + 내부 IP 차단
import ipaddress, urllib.parse

ALLOWED_HOSTS = {"api.example.com", "cdn.example.com"}

def validate_url(url: str) -> bool:
    parsed = urllib.parse.urlparse(url)
    if parsed.hostname not in ALLOWED_HOSTS:
        return False
    try:
        ip = ipaddress.ip_address(parsed.hostname)
        if ip.is_private or ip.is_loopback or ip.is_link_local:
            return False
    except ValueError:
        pass  # hostname은 IP가 아님 — 화이트리스트로 검증 완료
    return True
```

---

## Anti-Patterns

### 1. Security by Obscurity
- URL을 복잡하게 만들어 보안이라고 생각 (`/admin_x7k2m`)
- **해결:** 적절한 인증/인가 적용. URL은 공개된 것으로 간주

### 2. Client-Side Only Validation
- 프론트엔드에서만 검증하고 서버는 무조건 신뢰
- **해결:** 서버 측 검증 필수. 클라이언트 검증은 UX 향상용

### 3. Storing Passwords in Plain Text
- 데이터베이스에 비밀번호를 평문 또는 MD5/SHA256으로 저장
- **해결:** bcrypt, argon2, scrypt 등 전용 해싱 알고리즘 사용

### 4. Overly Permissive CORS
- `Access-Control-Allow-Origin: *` + `Allow-Credentials: true`
- **해결:** 필요한 도메인만 명시, 와일드카드와 credentials 동시 사용 금지

### 5. No Rate Limiting on Auth Endpoints
- 로그인, 비밀번호 재설정 등에 제한 없이 브루트포스 공격 가능
- **해결:** Rate limiting + 계정 잠금 정책 (5회 실패 → 15분 잠금)

### 6. Logging Sensitive Data
- 로그에 비밀번호, 토큰, 카드 번호가 평문으로 기록됨
- **해결:** 민감 정보 마스킹 또는 제외 규칙 적용

### 7. Ignoring Dependency Updates
- 2년 전 버전의 라이브러리에 알려진 CVE가 있어도 업데이트하지 않음
- **해결:** Dependabot/Renovate 설정, 정기적 `npm audit` / `pip-audit` 실행
