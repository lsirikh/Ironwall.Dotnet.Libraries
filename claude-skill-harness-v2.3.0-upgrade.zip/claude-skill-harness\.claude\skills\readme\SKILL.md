---
name: readme
description: |
  README.md를 사용자 요청 시 전체 재작성하는 스킬.
  명시적 요청: "README 갱신해줘", "README 만들어줘", "프로젝트 소개해줘",
  "오픈소스로 공개하자", "팀원이 볼 수 있게 정리해줘"
  암묵적 요청: "이 프로젝트 어떻게 생겼어?" → README 확인/갱신 필요
  중요: 이 스킬은 자동으로 트리거되지 않는다.
  변경 이력(CHANGELOG.md)은 changelog 스킬이 자동으로 관리한다.
  README는 "프로젝트가 무엇인가"를 답하고, CHANGELOG는 "언제 무엇이 바뀌었나"를 답한다.
---

# README 스킬 — 프로젝트 얼굴 관리

## 역할

`README.md`는 프로젝트의 **현재 상태와 구조**를 한눈에 보여준다.
"이 프로젝트가 뭐야? 어떻게 쓰는 거야?"에 답하는 게 목적이다.

이 스킬은 사용자가 명시적으로 요청할 때만 호출된다.
**자동 갱신되지 않는다** — 자동 갱신은 `changelog` 스킬이 CHANGELOG.md에 대해서만 수행한다.

---

## README vs CHANGELOG 책임 분리

| 항목 | README.md | CHANGELOG.md |
|------|---------|------------|
| 갱신 시점 | 사용자 요청 시만 | Track C complete 자동 |
| 갱신 방식 | 전체 재작성 | 추가만 (append-only) |
| 답하는 질문 | "이 프로젝트가 뭐야?" | "언제 무엇이 바뀌었나?" |
| 형식 | 개요 + 구조 + 사용법 | 시간 역순 로그 |
| 주된 독자 | 신규 합류자, 외부 | 유지보수자, 배포자 |
| 관리 스킬 | **readme** (이 스킬) | **changelog** |

이 스킬은 CHANGELOG에 손대지 않는다. 두 파일은 완전히 독립적으로 관리된다.

---

## 사용 시점

이 스킬은 **사용자 요청 시에만** 호출된다.

| 사용자 요청 | 동작 |
|-----------|------|
| "README 만들어줘" | README.md가 없으면 신규 생성 |
| "README 갱신해줘" | 기존 README.md 전체 재작성 |
| "프로젝트 소개해줘" | README.md 신규 생성 또는 갱신 |
| "팀원에게 공유할 README 정리해줘" | README.md 갱신 |

`process`, `prd`, `report` 스킬은 더 이상 readme를 자동 트리거하지 않는다.

---

## 실행 절차 — 자동 수집 + 전체 재작성

### Step 1 — 정보 수집

다음 5개 출처에서 정보를 자동 수집한다:

| 출처 | 추출 항목 |
|------|---------|
| `CLAUDE.md` | project_name, language, framework, test_framework, package_manager, version |
| `docs/INDEX.md` | PRD/Plan/Test/Report 통계 (각 섹션 행 수) |
| `docs/reports/*.md` | 각 리포트의 첫 ## 섹션 (주요 기능 목록) |
| `CHANGELOG.md` | 최신 버전 + 마지막 변경 날짜 |
| `src/` 직접 하위 1단계 | 디렉토리 구조 트리 |

### Step 2 — README.md 전체 재작성

수집한 정보를 다음 템플릿에 채워 **기존 README.md를 완전히 덮어쓴다**:

```markdown
# {project_name}

{한 줄 소개 — 프로젝트가 무엇인지}

## 개요

- **언어/프레임워크**: {language} / {framework}
- **테스트**: {test_framework}
- **패키지**: {package_manager}
- **현재 버전**: {version}
- **변경 이력**: [CHANGELOG.md](CHANGELOG.md)

## 주요 기능

(docs/reports/ 의 각 리포트 첫 단락에서 추출한 핵심 기능 목록)

- {기능 1} — {짧은 설명} ([Report]({리포트 경로}))
- {기능 2} — {짧은 설명} ({리포트 경로})
- ...

## 설치

(language/framework에 따라 자동 생성)

```bash
# Python 예시
pip install -r requirements.txt

# Node.js 예시
npm install

# .NET 예시
dotnet restore
```

## 사용법

(framework에 따라 자동 생성 또는 placeholder)

## 디렉토리 구조

(src/ 직접 하위 1단계)

```
src/
├── {dir1}/
├── {dir2}/
└── {dir3}/
```

## 통계

- PRD: {N}개
- Plan: {N}개
- Test 결과: {N}개
- Report: {N}개

## 변경 이력

상세 변경 이력은 [CHANGELOG.md](CHANGELOG.md)를 참조하세요.
최신 버전: **{version}** ({last_changelog_date})
```

### Step 3 — 결과 안내

```
README.md가 갱신되었습니다.

수집 항목:
  - CLAUDE.md: project={name}, version={version}
  - INDEX: PRD {N}, Plan {N}, Report {N}
  - 기능: {N}개 추출 (docs/reports/)
  - 디렉토리: src/ 하위 {N}개

CHANGELOG.md는 자동 관리되므로 변경하지 않았습니다.
```

---

## 자동 수집 세부 규칙

### CLAUDE.md 파싱

```javascript
yaml 블록에서:
  project_name: "..."
  language: "..."
  framework: "..."
  test_framework: "..."
  package_manager: "..."
  version: "..."
```

빈 값이면 placeholder `(미설정)`로 대체.

### docs/reports/ 스캔

각 `*-report.md` 파일에서:
1. 첫 `# 헤더` → 기능 제목
2. 첫 `## 1. 개요` 또는 첫 단락 → 한 줄 설명 (최대 80자)

### src/ 트리

`fs.readdirSync('src/')` 결과 중 디렉토리만, 1단계 깊이로.
4개 초과 시 "..." 처리.

### 폴백

- `src/` 없음 → 디렉토리 구조 섹션 생략
- `docs/reports/` 없음 → 주요 기능 섹션에 placeholder
- `CHANGELOG.md` 없음 → 변경 이력 링크 비활성화

---

## 완료 후 처리

1. README.md 저장 확인
2. session-context.md "마지막으로 수정한 파일"에 자동 추가됨 (post-write-sync.js Hook)
3. 사용자에게 갱신 결과 안내

CHANGELOG와 달리 README 갱신은 audit-log에 별도 이벤트를 남기지 않는다 (사용자 요청 기반이므로).

---

## process 스킬 연동

### 연동 변경 사항 (이전 vs 현재)

| 시점 | 이전 동작 | 현재 동작 |
|------|---------|---------|
| 프로젝트 시작 시 | README 자동 생성 시도 | ❌ 더 이상 자동 트리거 없음 |
| PRD Approved 시 | Unreleased 갱신 시도 | ❌ 자동 트리거 없음 (CHANGELOG가 처리) |
| report 완료 시 | Changelog 갱신 시도 | ❌ changelog 스킬이 처리 |
| **사용자 명시 요청 시** | 갱신 | ✅ **유일한 트리거** |

이 분리로 readme 스킬은 단일 책임 원칙(SRP)을 만족한다.

---

## 트러블슈팅

### README이 갱신되지 않는다

이 스킬은 자동 갱신되지 않는다. "README 갱신해줘"라고 명시적으로 요청해야 한다.

### CHANGELOG가 README에 포함되어야 하나?

아니다. README는 CHANGELOG.md를 **링크로만** 참조한다. 두 파일의 책임을 명확히 분리한다.

### 신규 기능이 README에 자동 반영되지 않는다

의도된 동작이다. 사용자가 적절한 시점에 "README 갱신해줘"를 요청하면 그때 최신 reports/를 스캔해서 반영한다.
