---
name: "Microservices Patterns"
description: "Service decomposition, inter-service communication, resilience patterns, and distributed system design guidance"
languages: ["Python", "C#", "TypeScript"]
frameworks: ["FastAPI", ".NET", "Docker"]
phases: ["analysis", "dev"]
---

# Microservices Patterns

## When to Activate

- 모놀리스를 마이크로서비스로 분해하는 설계 논의
- 새 서비스를 추가하거나 기존 서비스 간 통신 방식을 결정할 때
- 분산 트랜잭션, 장애 전파, 서비스 디스커버리 관련 문제
- API Gateway 도입 또는 변경
- 이벤트 소싱, CQRS 패턴 적용 검토

---

## Core Patterns

### 1. Service Decomposition — Bounded Context

서비스 경계는 도메인 경계(Bounded Context)와 일치시킨다.

**원칙:**
- 하나의 서비스 = 하나의 비즈니스 도메인
- 서비스 간 데이터 공유는 API를 통해서만
- 각 서비스는 자체 데이터 저장소를 소유한다 (Database per Service)

```
# 잘못된 분해 — 기술 계층 기준
UserController → UserService → UserRepository
OrderController → OrderService → OrderRepository (User 테이블 직접 참조)

# 올바른 분해 — 도메인 기준
[User Service] ←API→ [Order Service] ←API→ [Payment Service]
  └─ user_db         └─ order_db           └─ payment_db
```

**DDD Tactical Patterns:**
- **Entity**: 고유 ID로 식별되는 도메인 객체
- **Value Object**: ID 없이 속성으로만 비교되는 불변 객체
- **Aggregate**: 트랜잭션 일관성의 최소 단위
- **Domain Event**: Aggregate 상태 변경을 알리는 메시지

### 2. API Gateway Pattern

모든 클라이언트 요청의 단일 진입점.

```python
# FastAPI — 간단한 Gateway 라우팅 예시
from fastapi import FastAPI, Request
import httpx

app = FastAPI()
SERVICE_MAP = {
    "users": "http://user-service:8001",
    "orders": "http://order-service:8002",
    "payments": "http://payment-service:8003",
}

@app.api_route("/{service}/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def gateway(service: str, path: str, request: Request):
    base_url = SERVICE_MAP.get(service)
    if not base_url:
        return {"error": "Unknown service"}, 404
    async with httpx.AsyncClient() as client:
        resp = await client.request(
            method=request.method,
            url=f"{base_url}/{path}",
            headers=dict(request.headers),
            content=await request.body(),
        )
        return resp.json()
```

**Gateway 책임:** 라우팅, 인증/인가, Rate Limiting, 로깅, 응답 캐싱, 요청 집계(BFF).

### 3. Inter-Service Communication

| 방식 | 용도 | 장점 | 단점 |
|------|------|------|------|
| **REST (sync)** | 단순 CRUD, 즉시 응답 필요 | 단순, 디버깅 쉬움 | 강한 결합, 장애 전파 |
| **gRPC (sync)** | 내부 서비스 간 고성능 통신 | 빠름, 타입 안전 | 브라우저 직접 호출 어려움 |
| **Message Queue (async)** | 이벤트 기반, 최종 일관성 | 느슨한 결합, 복원력 | 복잡도 증가 |

```python
# Python — RabbitMQ 비동기 메시지 발행
import pika, json

def publish_event(exchange: str, event_type: str, payload: dict):
    connection = pika.BlockingConnection(pika.ConnectionParameters("rabbitmq"))
    channel = connection.channel()
    channel.exchange_declare(exchange=exchange, exchange_type="topic")
    channel.basic_publish(
        exchange=exchange,
        routing_key=event_type,
        body=json.dumps(payload),
        properties=pika.BasicProperties(content_type="application/json"),
    )
    connection.close()

# 사용
publish_event("orders", "order.created", {"order_id": "123", "user_id": "456"})
```

```csharp
// C# .NET — MassTransit + RabbitMQ 이벤트 발행
public record OrderCreatedEvent(string OrderId, string UserId, decimal Amount);

public class OrderService
{
    private readonly IPublishEndpoint _publisher;

    public OrderService(IPublishEndpoint publisher) => _publisher = publisher;

    public async Task CreateOrder(CreateOrderRequest req)
    {
        // ... 주문 생성 로직
        await _publisher.Publish(new OrderCreatedEvent(order.Id, req.UserId, req.Amount));
    }
}
```

### 4. SAGA Pattern

분산 트랜잭션을 로컬 트랜잭션의 시퀀스로 관리한다.

**Choreography (이벤트 기반):**
```
OrderService → [OrderCreated] → PaymentService → [PaymentCompleted] → InventoryService
                                 ↓ 실패 시
                                [PaymentFailed] → OrderService → 주문 취소
```
- 장점: 단순, 느슨한 결합
- 단점: 플로우 추적 어려움, 순환 의존 위험

**Orchestration (중앙 조정자):**
```
OrderSaga (Orchestrator)
  1. CreateOrder → OrderService
  2. ProcessPayment → PaymentService
  3. ReserveInventory → InventoryService
  4. 실패 시 → 역순으로 보상 트랜잭션 실행
```
- 장점: 플로우 명확, 디버깅 쉬움
- 단점: 오케스트레이터가 단일 장애점이 될 수 있음

### 5. Circuit Breaker

장애가 전파되지 않도록 실패하는 호출을 차단한다.

```python
# Python — tenacity를 이용한 Circuit Breaker
from tenacity import retry, stop_after_attempt, wait_exponential, CircuitBreaker

circuit = CircuitBreaker(fail_max=5, reset_timeout=30)

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, max=10))
def call_payment_service(order_id: str):
    if circuit.current_state == "open":
        raise Exception("Circuit is open — payment service unavailable")
    try:
        response = httpx.post(f"http://payment-service/pay/{order_id}")
        response.raise_for_status()
        circuit.success()
        return response.json()
    except Exception as e:
        circuit.failure()
        raise
```

```csharp
// C# .NET — Polly Circuit Breaker
services.AddHttpClient("PaymentService")
    .AddPolicyHandler(Policy<HttpResponseMessage>
        .Handle<HttpRequestException>()
        .OrResult(r => !r.IsSuccessStatusCode)
        .CircuitBreakerAsync(
            handledEventsAllowedBeforeBreaking: 5,
            durationOfBreak: TimeSpan.FromSeconds(30),
            onBreak: (result, duration) =>
                logger.LogWarning("Circuit opened for {Duration}s", duration.TotalSeconds),
            onReset: () => logger.LogInformation("Circuit closed")
        ));
```

### 6. Health Checks

```python
# FastAPI — Health Check 엔드포인트
@app.get("/health")
async def health():
    checks = {
        "database": await check_db(),
        "redis": await check_redis(),
        "downstream_api": await check_downstream(),
    }
    status = "healthy" if all(checks.values()) else "unhealthy"
    return {"status": status, "checks": checks}
```

```csharp
// ASP.NET — Built-in Health Checks
builder.Services.AddHealthChecks()
    .AddNpgSql(connectionString, name: "database")
    .AddRedis(redisConnection, name: "redis")
    .AddUrlGroup(new Uri("http://payment-service/health"), name: "payment-service");

app.MapHealthChecks("/health", new HealthCheckOptions
{
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});
```

### 7. Distributed Tracing (OpenTelemetry)

요청이 여러 서비스를 거치는 경로를 추적한다.

```python
# Python — OpenTelemetry 기본 설정
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

provider = TracerProvider()
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://jaeger:4317")))
trace.set_tracer_provider(provider)

tracer = trace.get_tracer(__name__)

async def process_order(order_id: str):
    with tracer.start_as_current_span("process_order", attributes={"order.id": order_id}):
        with tracer.start_as_current_span("validate_order"):
            validate(order_id)
        with tracer.start_as_current_span("charge_payment"):
            await call_payment_service(order_id)
```

### 8. Event Sourcing & CQRS

**Event Sourcing:** 상태 대신 이벤트를 저장한다.
```
OrderCreated → ItemAdded → ItemAdded → ItemRemoved → OrderConfirmed
현재 상태 = 이벤트 리플레이 결과
```

**CQRS (Command Query Responsibility Segregation):**
```
[Command Side]                    [Query Side]
  Write Model                      Read Model (Materialized View)
  ↓ Event Store ──publish──→       ↓ Projection
  정규화된 스키마                    비정규화된 조회 최적화 스키마
```

- Event Sourcing + CQRS 조합은 복잡도가 높으므로 감사 로그, 금융 트랜잭션 등 이력 추적이 핵심인 도메인에만 적용한다.

### 9. Service Discovery

```yaml
# Docker Compose — 내장 DNS 기반 서비스 디스커버리
services:
  user-service:
    build: ./user-service
    networks: [backend]
  order-service:
    build: ./order-service
    environment:
      USER_SERVICE_URL: http://user-service:8001  # Docker DNS 자동 해석
    networks: [backend]

networks:
  backend:
    driver: bridge
```

Kubernetes 환경에서는 CoreDNS가 `service-name.namespace.svc.cluster.local`로 자동 해석한다.

---

## Anti-Patterns

### 1. Distributed Monolith
- 서비스를 나눴지만 동기 호출 체인이 길어 하나가 죽으면 전체가 죽는 구조
- **해결:** 비동기 이벤트 기반으로 결합도를 줄인다

### 2. Shared Database
- 여러 서비스가 하나의 DB를 직접 참조하면 스키마 변경 시 전부 깨진다
- **해결:** Database per Service 원칙을 지킨다

### 3. Chatty Communication
- 하나의 비즈니스 동작에 서비스 간 호출이 10회 이상 발생
- **해결:** 서비스 경계를 재검토하고, 필요하면 서비스를 합친다

### 4. No Fallback Strategy
- Circuit Breaker 없이 장애 서비스를 무한 재시도
- **해결:** 타임아웃, 재시도 한도, Circuit Breaker, 기본값 반환을 조합한다

### 5. Synchronous SAGA
- 분산 트랜잭션을 2PC(Two-Phase Commit)로 구현하여 성능 저하
- **해결:** SAGA 패턴(Choreography 또는 Orchestration)을 사용한다

### 6. Over-decomposition
- 처음부터 10개 이상의 마이크로서비스로 시작하면 운영 부담이 급증
- **해결:** 모놀리스로 시작하여 도메인 경계가 명확해진 후 분리한다 (Monolith First)
