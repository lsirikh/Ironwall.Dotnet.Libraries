---
name: swagger-openapi-patterns
description: OpenAPI 3.0/3.1 스펙 설계 — 스키마, 버전 관리, FastAPI 자동 생성
languages: ["Python", "TypeScript"]
frameworks: ["OpenAPI", "Swagger", "FastAPI"]
phases: ["dev"]
---

# Swagger / OpenAPI Patterns

## When to Activate

- API 스펙 설계 또는 리뷰 시
- FastAPI의 OpenAPI 자동 생성 커스터마이징 시

## Core Patterns

### Schema Design

```yaml
components:
  schemas:
    User:
      type: object
      required: [id, name, email]
      properties:
        id: { type: integer, format: int64 }
        name: { type: string, minLength: 1, maxLength: 100 }
        email: { type: string, format: email }

    UserCreate:
      allOf:
        - $ref: '#/components/schemas/User'
        - type: object
          required: [password]
          properties:
            password: { type: string, minLength: 8 }
```

### Versioning (URL Path)

```
/api/v1/users     -- current
/api/v2/users     -- breaking changes only
```

```python
# FastAPI
v1 = APIRouter(prefix="/api/v1")
v2 = APIRouter(prefix="/api/v2")
app.include_router(v1)
app.include_router(v2)
```

### Pagination (Cursor-based)

```yaml
paths:
  /users:
    get:
      parameters:
        - name: cursor
          in: query
          schema: { type: string }
        - name: limit
          in: query
          schema: { type: integer, default: 20, maximum: 100 }
      responses:
        200:
          content:
            application/json:
              schema:
                type: object
                properties:
                  data: { type: array, items: { $ref: '#/components/schemas/User' } }
                  next_cursor: { type: string, nullable: true }
```

### Error Format (RFC 7807)

```json
{
  "type": "https://api.example.com/errors/not-found",
  "title": "Resource not found",
  "status": 404,
  "detail": "User with id 42 not found",
  "instance": "/users/42"
}
```

### Security Schemes

```yaml
components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
    ApiKeyAuth:
      type: apiKey
      in: header
      name: X-API-Key
```

### FastAPI Auto-Generation Tips

```python
app = FastAPI(
    title="My API",
    version="1.0.0",
    openapi_tags=[
        {"name": "users", "description": "User management"},
    ],
)

# Exclude from OpenAPI
@router.get("/health", include_in_schema=False)
async def health(): return {"ok": True}
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| Versioning by header | URL path `/v1/` | Simpler, cacheable |
| Offset pagination for large sets | Cursor-based | Consistent, scalable |
| Generic error messages | RFC 7807 format | Structured, actionable |
| No `required` fields | Explicit required array | Prevents silent bugs |
| `additionalProperties: true` | `false` or explicit | Type safety |
