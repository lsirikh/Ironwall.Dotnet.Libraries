---
name: java-security
description: Java security patterns — Spring Security, JWT authentication, password encoding, CORS, CSRF, input validation, SQL injection prevention, secret management
languages: ["Java"]
frameworks: ["Spring Security", "Spring Boot"]
phases: ["test"]
---

# Java Security Patterns

## When to Activate

- Configuring authentication or authorization in Spring Boot
- Implementing JWT-based stateless authentication
- Setting up CORS, CSRF, password encoding, or input validation
- Preventing SQL injection or managing secrets

---

## Core Patterns

### 1. SecurityFilterChain

```java
@Configuration @EnableWebSecurity @EnableMethodSecurity
public class SecurityConfig {
    private final JwtAuthenticationFilter jwtFilter;
    private final AuthenticationProvider authProvider;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable()) // stateless API
                .cors(cors -> cors.configurationSource(corsSource()))
                .sessionManagement(s -> s.sessionCreationPolicy(STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**", "/actuator/health").permitAll()
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .anyRequest().authenticated())
                .authenticationProvider(authProvider)
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
}
```

### 2. Method-Level Authorization

```java
@PreAuthorize("hasRole('ADMIN')")
public List<UserResponse> getAllUsers() { ... }

@PreAuthorize("#userId == authentication.principal.id or hasRole('ADMIN')")
public UserResponse getUserById(Long userId) { ... }

@Secured("ROLE_ADMIN")
public void deleteUser(Long userId) { ... }
```

### 3. JWT Authentication

```java
@Service
public class JwtService {
    @Value("${app.jwt.secret}") private String secretKey;
    @Value("${app.jwt.expiration-ms}") private long expirationMs;

    public String generateToken(UserDetails user) {
        return Jwts.builder().subject(user.getUsername())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(getSigningKey(), Jwts.SIG.HS256).compact();
    }

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public boolean isTokenValid(String token, UserDetails user) {
        return extractUsername(token).equals(user.getUsername()) && !isExpired(token);
    }

    private boolean isExpired(String token) {
        return extractClaim(token, Claims::getExpiration).before(new Date());
    }

    private <T> T extractClaim(String token, Function<Claims, T> resolver) {
        Claims claims = Jwts.parser().verifyWith(getSigningKey())
                .build().parseSignedClaims(token).getPayload();
        return resolver.apply(claims);
    }

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(secretKey));
    }
}
```

#### JWT Filter (OncePerRequestFilter)

```java
@Component @RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                                     FilterChain chain) throws ServletException, IOException {
        String header = req.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            chain.doFilter(req, res); return;
        }
        String jwt = header.substring(7);
        String username = jwtService.extractUsername(jwt);
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            UserDetails user = userDetailsService.loadUserByUsername(username);
            if (jwtService.isTokenValid(jwt, user)) {
                var authToken = new UsernamePasswordAuthenticationToken(
                        user, null, user.getAuthorities());
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }
        chain.doFilter(req, res);
    }
}
```

### 4. Password Encoding

```java
@Bean public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder(12);
}

// Registration — always encode
user.setPassword(passwordEncoder.encode(request.password()));

// Login — use matches()
if (!passwordEncoder.matches(request.password(), user.getPassword()))
    throw new BadCredentialsException("Invalid credentials");
```

### 5. CORS Configuration

```java
@Bean
public CorsConfigurationSource corsSource() {
    CorsConfiguration config = new CorsConfiguration();
    config.setAllowedOrigins(List.of("https://app.example.com"));
    config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
    config.setAllowedHeaders(List.of("Authorization", "Content-Type"));
    config.setAllowCredentials(true);
    config.setMaxAge(3600L);
    UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
    src.registerCorsConfiguration("/api/**", config);
    return src;
}
```

### 6. CSRF Protection

```java
// Stateless API: disable CSRF (see pattern 1)
// Session-based app: keep CSRF enabled
.csrf(csrf -> csrf
        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
        .csrfTokenRequestHandler(new CsrfTokenRequestAttributeHandler()))
```

### 7. Input Validation

```java
public record CreateUserRequest(
        @NotBlank @Size(min = 2, max = 100) String name,
        @NotBlank @Email String email,
        @NotBlank @Size(min = 8, max = 128)
        @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$",
                 message = "Must contain upper, lower, and digit") String password) {}

// Custom validator
@Constraint(validatedBy = NoProfanityValidator.class)
public @interface NoProfanity { String message() default "Prohibited content"; ... }

public class NoProfanityValidator implements ConstraintValidator<NoProfanity, String> {
    private static final Set<String> BLOCKED = Set.of("badword1", "badword2");
    @Override public boolean isValid(String val, ConstraintValidatorContext ctx) {
        return val == null || BLOCKED.stream().noneMatch(val.toLowerCase()::contains);
    }
}

// Controller: @Valid triggers validation
@PostMapping public ResponseEntity<UserResponse> create(@Valid @RequestBody CreateUserRequest req) { ... }
```

### 8. SQL Injection Prevention

```java
// GOOD — Spring Data (parameterized automatically)
List<User> findByNameContaining(String keyword);
@Query("SELECT u FROM User u WHERE u.email = :email")
Optional<User> findByEmail(@Param("email") String email);

// GOOD — JdbcTemplate parameterized
jdbcTemplate.query("SELECT * FROM users WHERE name LIKE ?",
        new Object[]{"%" + keyword + "%"}, rowMapper);

// BAD — string concatenation = SQL injection!
String sql = "SELECT * FROM users WHERE name LIKE '%" + keyword + "%'"; // NEVER
```

### 9. Secret Management

```yaml
# Environment variables (minimum)
spring:
  datasource:
    url: ${DB_URL}
    password: ${DB_PASSWORD}
app.jwt.secret: ${JWT_SECRET}

# Jasypt encrypted values
spring.datasource.password: ENC(encrypted-value-here)
# Run: JASYPT_ENCRYPTOR_PASSWORD=key java -jar app.jar
```

```yaml
# HashiCorp Vault (bootstrap.yml)
spring.cloud.vault:
  uri: https://vault.example.com
  token: ${VAULT_TOKEN}
  kv.backend: secret
```

### 10. Dependency Vulnerability Scanning

```xml
<!-- OWASP dependency-check (Maven) -->
<plugin>
    <groupId>org.owasp</groupId>
    <artifactId>dependency-check-maven</artifactId>
    <version>9.0.9</version>
    <configuration><failBuildOnCVSS>7</failBuildOnCVSS></configuration>
</plugin>
<!-- Run: mvn dependency-check:check -->
```

```bash
# Snyk CLI
snyk test --all-projects
snyk monitor --all-projects
```

---

## Anti-Patterns

### Never Plain-Text Passwords

```java
user.setPassword(request.password());                    // BAD
user.setPassword(passwordEncoder.encode(request.password())); // GOOD
```

### Never Hardcode Secrets

```java
private static final String SECRET = "my-key-123";      // BAD
@Value("${app.jwt.secret}") private String secret;       // GOOD
```

### Never Trust Client Input for Authorization

```java
// BAD — no access check
@GetMapping("/{id}") public UserResponse get(@PathVariable Long id) { return svc.get(id); }
// GOOD
@PreAuthorize("#id == authentication.principal.id or hasRole('ADMIN')")
@GetMapping("/{id}") public UserResponse get(@PathVariable Long id) { return svc.get(id); }
```

### Never Expose Stack Traces / Log Secrets / Wildcard CORS

```java
return ResponseEntity.status(500).body(ex.toString());          // BAD — stack trace
return ProblemDetail.forStatusAndDetail(INTERNAL_SERVER_ERROR, "Unexpected error"); // GOOD

config.setAllowedOrigins(List.of("*"));                         // BAD — wildcard
config.setAllowedOrigins(List.of("https://app.example.com"));   // GOOD

log.info("Login: email={}, password={}", email, pw);             // BAD — secrets in log
log.info("Login attempt: email={}", email);                       // GOOD
```
