# Upgrade Guide

## 업그레이드 패키지 사용법

```bash
# 1. 업그레이드 zip 다운로드
# claude-skill-harness-v2.3.0-upgrade.zip

# 2. 프로젝트 루트에서 압축 해제
# Windows PowerShell:
Expand-Archive -Path claude-skill-harness-v2.3.0-upgrade.zip -DestinationPath . -Force

# macOS/Linux:
unzip -o claude-skill-harness-v2.3.0-upgrade.zip -d .

# 3. 설치 실행
cd claude-skill-harness
node install.js --upgrade

# 4. 검증
node .claude/hooks/advance-phase.js status
```

## 보존/덮어쓰기 정책

| 파일 | 업그레이드 시 | 이유 |
|------|------------|------|
| `CLAUDE.md` | **보존** (yaml 보존 + 구조 마이그레이션) | 프로젝트 설정 |
| `.claude/settings.json` | **보존** (Hook 병합) | 사용자 Hook 보존 |
| `docs/memory/*` | **보존** | 상태, 세션, 학습 데이터 |
| `.claude/hooks/*.js` | **덮어쓰기** | Hook 코드 최신화 |
| `.claude/skills/*/SKILL.md` | **덮어쓰기** | 프로세스 스킬 최신화 |
| `.claude/agents/*.md` | **덮어쓰기** | Agent 정의 최신화 |
| `.claude/domain-skills/*.md` | **덮어쓰기** | 도메인 지식 최신화 |
| `.claude/rules/**/*.md` | **덮어쓰기** | 코딩 규칙 최신화 |

---

## settings.json 병합

업그레이드 시 install.js가 자동으로 Hook을 병합합니다.
기존 사용자 Hook은 보존됩니다.

```json
{
  "hooks": {
    "UserPromptSubmit": [
      { "hooks": [{ "type": "command", "command": "node .claude/hooks/session-gate.js", "timeout": 5 }] }
    ],
    "PreToolUse": [
      {
        "matcher": "Write|Edit|Bash|mcp__filesystem__write_file|mcp__filesystem__edit_file|mcp__filesystem__move_file",
        "hooks": [{ "type": "command", "command": "node .claude/hooks/pre-tool-gate.js", "timeout": 8 }]
      }
    ],
    "PreCompact": [
      { "hooks": [{ "type": "command", "command": "node .claude/hooks/pre-compact.js", "timeout": 5 }] }
    ],
    "Stop": [
      { "hooks": [{ "type": "command", "command": "node .claude/hooks/stop-observation.js", "timeout": 10 }] }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [{ "type": "command", "command": "node .claude/hooks/post-write-sync.js", "timeout": 10 }]
      }
    ]
  }
}
```
