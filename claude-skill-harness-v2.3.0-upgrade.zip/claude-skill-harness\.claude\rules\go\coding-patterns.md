# Go Coding Patterns

## Must Always
- Handle errors explicitly: `if err != nil { return fmt.Errorf("context: %w", err) }`
- Use `context.Context` as first parameter in functions that do I/O or may be cancelled
- Use `defer` for cleanup (file close, mutex unlock, connection release)
- Accept interfaces, return structs
- Use `errors.Is()` and `errors.As()` for error checking (not `==`)
- Close channels from sender side, never receiver
- Use `sync.WaitGroup` or `errgroup.Group` for goroutine coordination
- Prefer `strings.Builder` over `+` concatenation in loops
- Use `go vet`, `staticcheck`, `golangci-lint` in CI
- Graceful shutdown with `os.Signal` and `context.WithCancel`

## Must Never
- Ignore errors with `_`: always handle or explicitly document why ignored
- Use `panic()` for expected error conditions (only for programmer errors)
- Use `init()` for complex logic (keep simple, prefer explicit initialization)
- Share memory by communicating — don't communicate by sharing memory (use channels)
- Use `interface{}` / `any` without type assertion safety
- Launch goroutines without a way to stop them (always pass context or done channel)
