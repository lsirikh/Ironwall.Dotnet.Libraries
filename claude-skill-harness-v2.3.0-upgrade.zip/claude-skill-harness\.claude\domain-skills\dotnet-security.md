---
name: dotnet-security
description: .NET security patterns — Identity, JWT, Data Protection, CORS, validation, authorization, secret management
languages: ["C#"]
frameworks: [".NET", "ASP.NET"]
phases: ["test"]
---

# .NET Security Patterns

## When to Activate

- Configuring authentication (Identity, JWT Bearer)
- Implementing authorization policies and roles
- Setting up CORS policies for APIs
- Validating user input (DataAnnotations, FluentValidation)
- Managing secrets (user-secrets, Azure Key Vault)
- Implementing anti-forgery protection or Data Protection API

---

## Core Patterns

### 1. ASP.NET Identity Configuration

```csharp
// Program.cs
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    // Password policy
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 12;
    options.Password.RequireNonAlphanumeric = true;
    options.Password.RequireUppercase = true;

    // Lockout
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
    options.Lockout.MaxFailedAccessAttempts = 5;
    options.Lockout.AllowedForNewUsers = true;

    // User
    options.User.RequireUniqueEmail = true;
    options.SignIn.RequireConfirmedEmail = true;
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();
```

#### Custom ApplicationUser

```csharp
public class ApplicationUser : IdentityUser
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsActive { get; set; } = true;

    public ICollection<RefreshToken> RefreshTokens { get; set; }
        = new List<RefreshToken>();
}
```

---

### 2. JWT Bearer Authentication

#### Token Service

```csharp
public class JwtTokenService : ITokenService
{
    private readonly JwtSettings _settings;
    private readonly UserManager<ApplicationUser> _userManager;

    public JwtTokenService(
        IOptions<JwtSettings> settings,
        UserManager<ApplicationUser> userManager)
    {
        _settings = settings.Value;
        _userManager = userManager;
    }

    public async Task<TokenResponse> GenerateTokenAsync(ApplicationUser user)
    {
        var roles = await _userManager.GetRolesAsync(user);
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Email, user.Email!),
            new(ClaimTypes.Name, user.UserName!),
            new("firstName", user.FirstName),
        };
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_settings.Secret));
        var credentials = new SigningCredentials(
            key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _settings.Issuer,
            audience: _settings.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(_settings.ExpirationMinutes),
            signingCredentials: credentials);

        var refreshToken = GenerateRefreshToken();
        user.RefreshTokens.Add(new RefreshToken
        {
            Token = refreshToken,
            ExpiresAt = DateTime.UtcNow.AddDays(_settings.RefreshTokenExpirationDays),
            CreatedAt = DateTime.UtcNow
        });
        await _userManager.UpdateAsync(user);

        return new TokenResponse
        {
            AccessToken = new JwtSecurityTokenHandler().WriteToken(token),
            RefreshToken = refreshToken,
            ExpiresAt = token.ValidTo
        };
    }

    private static string GenerateRefreshToken()
    {
        var bytes = new byte[64];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(bytes);
        return Convert.ToBase64String(bytes);
    }
}
```

#### Registration in Program.cs

```csharp
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"]!)),
        ClockSkew = TimeSpan.FromSeconds(30)  // Reduce from default 5 min
    };

    // For SignalR JWT support
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            var token = context.Request.Query["access_token"];
            if (!string.IsNullOrEmpty(token) &&
                context.HttpContext.Request.Path.StartsWithSegments("/hubs"))
            {
                context.Token = token;
            }
            return Task.CompletedTask;
        }
    };
});
```

---

### 3. Data Protection API

For encrypting sensitive data at rest (cookies, tokens, local secrets).

```csharp
// Registration
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(@"/var/keys"))
    .SetApplicationName("MyApp")
    .SetDefaultKeyLifetime(TimeSpan.FromDays(90))
    .ProtectKeysWithCertificate(certificate);

// Usage
public class SensitiveDataService
{
    private readonly IDataProtector _protector;

    public SensitiveDataService(IDataProtectionProvider provider)
    {
        _protector = provider.CreateProtector("SensitiveData.v1");
    }

    public string Encrypt(string plainText) => _protector.Protect(plainText);

    public string Decrypt(string cipherText) => _protector.Unprotect(cipherText);

    // Time-limited protection
    public string EncryptWithExpiry(string plainText, TimeSpan lifetime)
    {
        var timeLimited = _protector.ToTimeLimitedDataProtector();
        return timeLimited.Protect(plainText, lifetime);
    }
}
```

---

### 4. Anti-Forgery Tokens

#### Razor Pages / MVC (Automatic)

```csharp
// Program.cs — enabled by default in Razor Pages
builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "X-XSRF-TOKEN";
    options.Cookie.Name = "XSRF-TOKEN";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Strict;
});
```

```html
<!-- In Razor view — automatic with form tag helper -->
<form asp-action="Create" method="post">
    <!-- Anti-forgery token is automatically included -->
    <input type="text" asp-for="Name" />
    <button type="submit">Create</button>
</form>
```

#### Minimal API with SPA

```csharp
app.MapGet("/antiforgery/token", (IAntiforgery antiforgery, HttpContext context) =>
{
    var tokens = antiforgery.GetAndStoreTokens(context);
    return Results.Ok(new { token = tokens.RequestToken });
}).RequireAuthorization();

// Validate on mutations
app.MapPost("/api/orders", async (
    HttpContext context,
    IAntiforgery antiforgery,
    CreateOrderRequest request) =>
{
    await antiforgery.ValidateRequestAsync(context);
    // Process order...
});
```

---

### 5. CORS Policy

```csharp
builder.Services.AddCors(options =>
{
    // Named policy for production
    options.AddPolicy("Production", policy =>
    {
        policy.WithOrigins(
                "https://app.example.com",
                "https://admin.example.com")
            .WithMethods("GET", "POST", "PUT", "DELETE")
            .WithHeaders("Authorization", "Content-Type", "X-XSRF-TOKEN")
            .AllowCredentials()
            .SetPreflightMaxAge(TimeSpan.FromMinutes(10));
    });

    // Development policy — more permissive
    options.AddPolicy("Development", policy =>
    {
        policy.WithOrigins("http://localhost:3000", "http://localhost:5173")
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials();
    });
});

// Apply in pipeline
app.UseCors(app.Environment.IsDevelopment() ? "Development" : "Production");

// Or per-endpoint
app.MapGet("/api/public", () => "Hello")
    .RequireCors("Production");
```

---

### 6. Input Validation

#### DataAnnotations

```csharp
public class CreateUserRequest
{
    [Required(ErrorMessage = "Name is required")]
    [StringLength(100, MinimumLength = 2)]
    public string Name { get; set; }

    [Required]
    [EmailAddress(ErrorMessage = "Invalid email format")]
    public string Email { get; set; }

    [Required]
    [RegularExpression(
        @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{12,}$",
        ErrorMessage = "Password must be 12+ chars with upper, lower, digit, special")]
    public string Password { get; set; }

    [Range(18, 120)]
    public int Age { get; set; }

    [Url]
    public string? WebsiteUrl { get; set; }
}
```

#### FluentValidation

```csharp
public class CreateOrderValidator : AbstractValidator<CreateOrderRequest>
{
    public CreateOrderValidator(IProductRepository productRepo)
    {
        RuleFor(x => x.CustomerId)
            .GreaterThan(0)
            .WithMessage("Valid customer ID is required");

        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("Order must contain at least one item");

        RuleForEach(x => x.Items).ChildRules(item =>
        {
            item.RuleFor(i => i.ProductId)
                .GreaterThan(0);
            item.RuleFor(i => i.Quantity)
                .InclusiveBetween(1, 1000)
                .WithMessage("Quantity must be between 1 and 1000");
            item.RuleFor(i => i.UnitPrice)
                .GreaterThan(0)
                .ScalePrecision(2, 10);
        });

        // Async validation with DB lookup
        RuleFor(x => x.CustomerId)
            .MustAsync(async (id, ct) =>
            {
                return await productRepo.ExistsAsync(id, ct);
            })
            .WithMessage("Customer does not exist");
    }
}

// Registration
builder.Services.AddValidatorsFromAssemblyContaining<CreateOrderValidator>();
```

---

### 7. Authorization Policies

```csharp
builder.Services.AddAuthorization(options =>
{
    // Role-based
    options.AddPolicy("AdminOnly", policy =>
        policy.RequireRole("Admin"));

    // Claim-based
    options.AddPolicy("PremiumUser", policy =>
        policy.RequireClaim("subscription", "premium", "enterprise"));

    // Custom requirement
    options.AddPolicy("MinimumAge", policy =>
        policy.Requirements.Add(new MinimumAgeRequirement(18)));

    // Combined
    options.AddPolicy("CanManageOrders", policy =>
        policy.RequireRole("Admin", "OrderManager")
              .RequireClaim("department", "sales", "operations")
              .RequireAuthenticatedUser());

    // Fallback — require authentication for all endpoints by default
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});
```

#### Custom Authorization Handler

```csharp
public class MinimumAgeRequirement : IAuthorizationRequirement
{
    public int MinimumAge { get; }
    public MinimumAgeRequirement(int minimumAge) => MinimumAge = minimumAge;
}

public class MinimumAgeHandler : AuthorizationHandler<MinimumAgeRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        MinimumAgeRequirement requirement)
    {
        var birthDateClaim = context.User.FindFirst("birthdate");
        if (birthDateClaim is null) return Task.CompletedTask;

        var birthDate = DateOnly.Parse(birthDateClaim.Value);
        var age = DateOnly.FromDateTime(DateTime.Today).Year - birthDate.Year;

        if (age >= requirement.MinimumAge)
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

// Register handler
builder.Services.AddSingleton<IAuthorizationHandler, MinimumAgeHandler>();
```

#### Resource-Based Authorization

```csharp
public class OrderAuthorizationHandler
    : AuthorizationHandler<OperationAuthorizationRequirement, Order>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        OperationAuthorizationRequirement requirement,
        Order resource)
    {
        var userId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (requirement.Name == "Delete" &&
            (context.User.IsInRole("Admin") || resource.CreatedByUserId == userId))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}

// Usage in endpoint
app.MapDelete("/api/orders/{id}", async (
    int id,
    IAuthorizationService auth,
    IOrderRepository repo,
    ClaimsPrincipal user) =>
{
    var order = await repo.GetByIdAsync(id);
    if (order is null) return Results.NotFound();

    var result = await auth.AuthorizeAsync(user, order, Operations.Delete);
    if (!result.Succeeded) return Results.Forbid();

    await repo.DeleteAsync(id);
    return Results.NoContent();
});
```

---

### 8. Secret Management

#### Development — User Secrets

```bash
# Initialize (creates secrets.json outside project directory)
dotnet user-secrets init

# Set secrets
dotnet user-secrets set "Jwt:Secret" "my-super-secret-key-for-dev-only"
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Server=localhost;..."
dotnet user-secrets set "ExternalApi:ApiKey" "dev-api-key-12345"

# List secrets
dotnet user-secrets list
```

```csharp
// Automatically loaded in Development environment
var builder = WebApplication.CreateBuilder(args);
// builder.Configuration already includes user-secrets in Development
```

#### Production — Azure Key Vault

```csharp
builder.Configuration.AddAzureKeyVault(
    new Uri($"https://{builder.Configuration["KeyVault:Name"]}.vault.azure.net/"),
    new DefaultAzureCredential());

// Access secrets as normal configuration
var jwtSecret = builder.Configuration["Jwt:Secret"];
```

#### Environment Variables (All Environments)

```csharp
// Naming convention: double underscore for nesting
// Jwt__Secret maps to Jwt:Secret in IConfiguration
// ConnectionStrings__DefaultConnection maps to ConnectionStrings:DefaultConnection

var secret = builder.Configuration["Jwt:Secret"]; // Reads from env var Jwt__Secret
```

> **Rule**: Never commit secrets to source control. Use `.gitignore` for
> `appsettings.Development.json`. Use user-secrets for development,
> environment variables or Key Vault for production.

---

## Anti-Patterns

### Authentication

- Storing JWT secret in `appsettings.json` committed to source control
- Using long-lived access tokens without refresh token rotation
- Not validating `Issuer`, `Audience`, or `Lifetime` in JWT configuration
- Setting `ClockSkew` to `TimeSpan.Zero` — causes intermittent auth failures

### Authorization

- Using role checks in controllers instead of policy-based authorization — hard to maintain
- Checking `User.IsInRole()` scattered throughout business logic — not testable
- Forgetting `FallbackPolicy` — unauthenticated access to unattributed endpoints

### CORS

- Using `AllowAnyOrigin()` with `AllowCredentials()` — browsers block this combination
- Wildcard CORS in production — allows any site to make authenticated requests
- Not restricting HTTP methods — allows unexpected mutations

### Validation

- Trusting client-side validation alone — always validate server-side
- Not sanitizing HTML output — XSS vulnerability
- Using `[RegularExpression]` for complex rules — unreadable, use FluentValidation
- Not validating file uploads (type, size, content) — malware upload risk

### Secrets

- Hardcoding connection strings or API keys in source code
- Logging sensitive data (tokens, passwords, PII) — leaks to log aggregators
- Using the same secret/key across environments — production breach from dev leak
