---
name: index
description: |
  docs/ 폴더의 모든 산출 문서를 INDEX.md에 즉시 인덱싱하는 스킬.
  명시적 요청: "인덱스 갱신해줘", "문서 목록 보여줘", "어떤 문서가 있어?",
  "docs 정리해줘", "인덱스 재빌드해줘"
  자동 실행: CLAUDE.md의 "응답 후 필수 처리 Rule 2"에 따라
  docs/에 파일이 생성·수정될 때마다 이 파일을 읽어 INDEX.md를 즉시 갱신한다.
  PRD 상태가 변경(Draft→Approved→Completed)될 때도 INDEX.md를 갱신한다.
  Plan 진행률이 변경될 때도 INDEX.md의 해당 행을 갱신한다.
  문서가 생성되고 INDEX.md 갱신이 지연되는 상황은 허용되지 않는다.
---

# Index 스킬 — 문서 즉시 인덱싱

## 역할

docs/ 하위에 파일이 생기는 순간, 또는 문서 상태가 바뀌는 순간 INDEX.md를 갱신한다.
새 세션에서 INDEX.md 하나만 보면 어떤 문서가 있고 각 작업이 어느 단계인지 파악할 수 있어야 한다.

---

## 3가지 사용 방식

**방식 1 — 신규 문서 생성 시 즉시 추가 (주된 사용)**
문서 생성 직후 해당 유형의 테이블에 새 행을 추가한다.

**방식 2 — 문서 상태 변경 시 행 업데이트**
PRD 상태 변경, Plan 진행률 변경, 기존 문서 재작성 시 기존 행을 찾아 해당 컬럼만 교체한다.

**방식 3 — 전체 재빌드 (사용자 명시 요청)**
docs/ 전체를 순회해 INDEX.md를 전면 재작성한다.

---

## 방식 1 — 신규 문서 행 추가 절차

1. `docs/INDEX.md`를 연다 (없으면 아래 전체 템플릿으로 생성)
2. 문서 유형에 맞는 테이블을 찾아 마지막 데이터 행 뒤에 추가한다
3. "마지막 갱신" 날짜를 오늘로 교체한다
4. "총 문서 수"를 +1 한다
5. session-context.md의 "세션 통계 > 생성된 문서" 수도 +1 갱신한다

### 동일 topic 문서가 이미 있는 경우

재분석, PRD 재작성, 재테스트 등으로 같은 topic 파일이 다시 생성된 경우:
- 기존 행을 찾아 날짜 컬럼과 내용을 업데이트한다 (행 추가 X, 행 교체 O)
- "총 문서 수"는 변경하지 않는다

---

## 방식 2 — 상태·진행률 변경 시 행 업데이트 절차

**PRD 상태 변경 시**
1. PRD 테이블에서 해당 topic 행을 찾는다
2. "상태" 컬럼을 새 상태로 교체한다 (`Draft` → `Review` → `Approved` → `Completed`)

**Plan 진행률 변경 시** (monitoring 스킬에서 위임)
1. Plan 테이블에서 해당 topic 행을 찾는다
2. "진행률" 컬럼을 `{완료}/{전체}` 형식으로 교체한다
3. 전체 완료 시 `{N}/{N} ✅`로 표시한다

---

## 문서 유형별 신규 행 형식

**분석 문서 (docs/analysis/)**
```
| [{topic}-analysis.md](analysis/{topic}-analysis.md) | {분석 범위 한 줄} | {YYYY-MM-DD} |
```

**PRD (docs/prds/)**
```
| [{topic}-prd.md](prds/{topic}-prd.md) | {기능/모듈 설명 한 줄} | Draft | {YYYY-MM-DD} |
```

**구현 플랜 (docs/plans/)**
```
| [{topic}-prd-plan.md](plans/{topic}-prd-plan.md) | [PRD](prds/{topic}-prd.md) | 0/{전체태스크수} | {YYYY-MM-DD} |
```

**테스트 결과 (docs/tests/)**
```
| [{topic}-test-result.md](tests/{topic}-test-result.md) | {통과율}% | {커버리지}% | {YYYY-MM-DD} |
```

**완료 리포트 (docs/reports/)**
```
| [{topic}-report.md](reports/{topic}-report.md) | [PRD](prds/{topic}-prd.md) → [Plan](plans/{topic}-prd-plan.md) | {YYYY-MM-DD} |
```

리포트 행에 문서 연결 체인을 표시해서 INDEX에서 바로 흐름을 파악할 수 있게 한다.

---

## 전체 재빌드 절차 (방식 3)

1. `docs/` 폴더 전체를 순회한다
2. 각 .md 파일의 H1 제목, 날짜, 상태(있는 경우)를 읽는다
3. `docs/INDEX.md`를 아래 전체 템플릿으로 재작성한다
4. "총 문서 수"를 실제 파일 수로 계산해서 기입한다

### 재빌드 자동 트리거 조건

아래 조건 중 하나라도 감지되면 전체 재빌드를 **제안**한다:

| 조건 | 감지 방법 | 행동 |
|------|---------|------|
| INDEX.md 총 문서 수 ≠ 실제 파일 수 | 무결성 검사에서 감지 | "문서 수 불일치 감지. 재빌드할까요?" |
| INDEX.md가 존재하지 않음 | 파일 존재 확인 | 즉시 전체 재빌드 실행 |
| 새 세션 시작 + INDEX.md 7일 이상 미갱신 | 마지막 갱신 날짜 비교 | "INDEX.md가 {N}일 동안 갱신되지 않았습니다. 재빌드할까요?" |
| 사용자 명시 요청 | "인덱스 재빌드해줘" | 즉시 전체 재빌드 실행 |

---

## docs/INDEX.md 전체 템플릿

```markdown
# 프로젝트 문서 인덱스

- **마지막 갱신**: {YYYY-MM-DD}
- **총 문서 수**: {N}개

---

## 분석 (docs/analysis/)

| 파일 | 분석 대상 | 날짜 |
|------|---------|------|

## 요구사항 정의서 (docs/prds/)

| 파일 | 내용 | 상태 | 날짜 |
|------|------|------|------|

## 구현 플랜 (docs/plans/)

| 파일 | 연관 PRD | 진행률 | 날짜 |
|------|---------|--------|------|

## 테스트 결과 (docs/tests/)

| 파일 | 통과율 | 커버리지 | 날짜 |
|------|--------|---------|------|

## 완료 리포트 (docs/reports/)

| 파일 | 문서 연결 체인 | 날짜 |
|------|------------|------|

---

## 세션 메모리

| 파일 | 마지막 업데이트 |
|------|--------------|
| [session-context.md](memory/session-context.md) | {날짜} |
```

---

## 무결성 검사 (INDEX 건강 체크)

INDEX.md를 갱신하거나 읽을 때마다 아래 검사를 수행한다:

### 링크 검증

INDEX.md의 모든 파일 링크 `[파일명](경로)` 를 순회한다:

```
검증 절차:
1. docs/ 하위 상대 경로를 절대 경로로 변환
2. 해당 파일이 실제로 존재하는지 확인
3. 존재하지 않는 링크 → ⚠️ 깨진 링크 목록에 추가
4. 깨진 링크 발견 시:
   "INDEX.md에 깨진 링크 {N}건이 있습니다: {목록}. 제거할까요?"
```

### 문서 수 드리프트 방지

```
검증 절차:
1. INDEX.md 상단의 "총 문서 수: {N}개"를 읽는다
2. docs/ 하위 .md 파일을 실제로 카운트한다 (INDEX.md, session-context.md, dev-journal.md, pipeline-state.json 제외)
3. 불일치 시:
   - 실제 > 기재: "미등록 문서 {N}건 발견: {목록}. INDEX에 추가할까요?"
   - 기재 > 실제: "삭제된 문서 {N}건 발견: {목록}. INDEX에서 제거할까요?"
4. 수정 후 총 문서 수를 실제 값으로 갱신
```

### 상태 일관성 검사

```
검증 절차:
1. INDEX.md PRD 테이블의 "상태" 컬럼 vs 실제 PRD 파일 상단 "상태:" 필드 비교
2. INDEX.md Plan 테이블의 "진행률" vs 실제 Plan 파일의 체크박스 집계 비교
3. 불일치 시 실제 파일 값으로 INDEX.md를 갱신
```

---

## Hook 자동 처리 vs Claude 수동 처리

### Hook이 자동 처리하는 항목

`post-write-sync.js`가 처리하는 것:
- pipeline-state.json의 activePrd/activePlan 갱신 (docs/prds/, docs/plans/ 쓰기 시)
- session-context.md의 "마지막으로 수정한 파일" 자동 추가
- INDEX.md의 "마지막 갱신" 날짜 자동 업데이트 (docs/ 하위 파일 쓰기 시)

### Claude가 수동으로 처리해야 하는 항목

INDEX.md의 **테이블 행 추가/수정**은 Claude가 직접 처리해야 한다. 이유:
- 테이블 행 형식이 문서 유형마다 다름 (분석/PRD/Plan/Test/Report)
- 상태 변경 (Draft→Approved), 진행률 갱신 등 의미적 판단 필요
- 총 문서 수 재계산 필요

따라서 INDEX.md 테이블은 여전히 Claude가 직접 갱신해야 한다.
CLAUDE.md "응답 후 필수 처리 Rule 2"는 그대로 유효하다.

### 갱신 누락 방지 체크리스트

docs/ 하위에 .md 파일을 생성하는 모든 스킬은 완료 후 처리에서 INDEX.md 갱신을 포함해야 한다.
아래 체크리스트로 누락 여부를 확인한다:

```
□ analysis 완료 → INDEX 분석 테이블에 행 추가?
□ prd 완료 → INDEX PRD 테이블에 행 추가?
□ prd 상태 변경 → INDEX PRD 테이블 상태 컬럼 갱신?
□ plan 완료 → INDEX Plan 테이블에 행 추가?
□ 태스크 완료 → INDEX Plan 진행률 컬럼 갱신?
□ test 완료 → INDEX 테스트 테이블에 행 추가?
□ report 완료 → INDEX 리포트 테이블에 행 추가 + PRD 상태 Completed?
```

---

## 완료 후 처리

INDEX.md 갱신 후:
1. `docs/memory/session-context.md`의 "세션 통계 > 생성된 문서" 수를 갱신한다
2. "마지막으로 수정한 파일"은 Hook이 자동 처리하므로 생략 가능
