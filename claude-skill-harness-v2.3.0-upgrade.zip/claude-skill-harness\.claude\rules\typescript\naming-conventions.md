# TypeScript Naming Conventions

> Always-on naming rules for TypeScript codebases.
> Applies to both Node.js and React/Next.js projects.

---

## Casing Rules

### camelCase
- Variables: `userName`, `itemCount`
- Functions: `getUserById`, `calculateTotal`
- Methods: `processPayment`, `validateInput`
- Parameters: `userId`, `orderData`

### PascalCase
- Classes: `UserService`, `OrderProcessor`
- Interfaces: `UserProps`, `ApiConfig` (no `I` prefix)
- Types: `OrderStatus`, `ApiResponse`
- Enums: `HttpMethod`, `UserRole`
- React components: `UserProfile`, `OrderList`

### UPPER_CASE
- Constants: `MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`
- Enum values: `HttpMethod.GET`, `UserRole.ADMIN`

---

## Must Always

### Naming Patterns
- Prefix booleans with `is`, `has`, `can`, `should`: `isActive`, `hasPermission`
- Use verb-first for functions: `fetchUsers`, `createOrder`, `handleSubmit`
- Name event handlers with `handle` prefix: `handleClick`, `handleSubmit`
- Name callbacks/props with `on` prefix: `onClick`, `onSubmit`
- Use descriptive names for generics: `TResponse`, `TData` (not just `T` unless obvious)

### File Naming
- Use kebab-case for files: `user-service.ts`, `api-client.ts`
- Use PascalCase for React components: `UserProfile.tsx`, `OrderList.tsx`
- Use `.ts` for logic, `.tsx` only when JSX is present
- Test files: `user-service.test.ts` or `user-service.spec.ts`
- Type definition files: `user.types.ts` or inline in module

### Exports
- Use named exports (not default exports, except Next.js pages/layouts)
- Export name must match the primary purpose of the module
- Barrel exports (`index.ts`) only for package public API

---

## Must Never

- Prefix interfaces with `I`: ~~`IUserService`~~ -> `UserService`
- Use `any` in type names: ~~`AnyData`~~ (use `unknown` semantics)
- Use abbreviations unless universally known: `id`, `url`, `api` are OK
- Use single-character names except in short lambdas: `(x) => x.id`
- Use Hungarian notation: ~~`strName`~~, ~~`arrItems`~~
- Mix casing conventions: ~~`get_user_by_id`~~ (use `getUserById`)
- Use `default export` for utility modules (makes refactoring harder)
- Name files with spaces or special characters

---

## Quick Reference

| Element           | Convention     | Example                       |
|-------------------|----------------|-------------------------------|
| Variable          | camelCase      | `userName`                    |
| Function          | camelCase      | `getUserById`                 |
| Class             | PascalCase     | `OrderProcessor`              |
| Interface         | PascalCase     | `UserConfig` (no I prefix)    |
| Type              | PascalCase     | `ApiResponse`                 |
| Enum              | PascalCase     | `HttpMethod`                  |
| Enum value        | UPPER_CASE     | `HttpMethod.GET`              |
| Constant          | UPPER_CASE     | `MAX_CONNECTIONS`             |
| React component   | PascalCase     | `UserProfile.tsx`             |
| File (logic)      | kebab-case     | `user-service.ts`             |
| File (component)  | PascalCase     | `UserProfile.tsx`             |
| Boolean           | is/has/can     | `isValid`, `hasAccess`        |
| Event handler     | handle + Event | `handleClick`                 |
| Callback prop     | on + Event     | `onClick`                     |
| Generic           | T + PascalCase | `TResponse`, `TKey`           |
