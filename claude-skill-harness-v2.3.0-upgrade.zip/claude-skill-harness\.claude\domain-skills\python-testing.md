---
name: python-testing
description: pytest 패턴 — fixtures, parametrize, asyncio, mocking, coverage
languages: ["Python"]
frameworks: ["pytest", "Python"]
phases: ["test"]
---

# Python Testing

## When to Activate

- Python 테스트 코드 작성 시
- pytest 설정 및 실행 시

## Core Patterns

### Fixtures

```python
import pytest

@pytest.fixture
def db_session():
    session = create_session()
    yield session
    session.rollback()
    session.close()

@pytest.fixture(scope="module")
def app_client():
    app = create_app(testing=True)
    with TestClient(app) as client:
        yield client
```

### Parametrize

```python
@pytest.mark.parametrize("input,expected", [
    ("hello", 5),
    ("", 0),
    ("  ", 2),
])
def test_string_length(input: str, expected: int):
    assert len(input) == expected
```

### Async Tests (pytest-asyncio)

```python
import pytest

@pytest.mark.asyncio
async def test_fetch_user(db_session):
    user = await create_user(db_session, name="test")
    result = await get_user(db_session, user.id)
    assert result.name == "test"

@pytest.fixture
async def async_client():
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
```

### Mocking

```python
from unittest.mock import patch, MagicMock, AsyncMock

def test_send_email():
    with patch("app.services.smtp.send") as mock_send:
        mock_send.return_value = True
        result = notify_user("test@example.com")
        mock_send.assert_called_once_with("test@example.com", subject=ANY)
        assert result is True

@pytest.mark.asyncio
async def test_async_service():
    mock_repo = AsyncMock()
    mock_repo.find.return_value = User(id=1, name="test")
    service = UserService(repo=mock_repo)
    user = await service.get(1)
    assert user.name == "test"
```

### Coverage

```ini
# pyproject.toml
[tool.coverage.run]
source = ["src"]
branch = true

[tool.coverage.report]
fail_under = 80
exclude_lines = ["pragma: no cover", "if TYPE_CHECKING:"]
```

```bash
pytest --cov=src --cov-report=term-missing
```

### FastAPI TestClient

```python
from fastapi.testclient import TestClient

def test_create_user(app_client: TestClient):
    response = app_client.post("/users", json={"name": "test", "email": "t@t.com"})
    assert response.status_code == 201
    assert response.json()["name"] == "test"
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| `time.sleep()` in tests | Mock time or use `freezegun` | Slow, flaky |
| Shared mutable fixtures | `scope="function"` default | Test isolation |
| `assert True` | Specific assertion | Meaningless test |
| Testing private methods | Test public interface | Implementation coupling |
| No `conftest.py` | Shared fixtures in conftest | DRY |
| `mock.patch` everywhere | Dependency injection | Easier to test |
