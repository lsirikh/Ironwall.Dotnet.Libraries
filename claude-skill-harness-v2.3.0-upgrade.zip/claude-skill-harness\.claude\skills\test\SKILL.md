---
name: test
description: |
  테스트 코드 작성 및 실행을 담당하는 스킬.
  명시적 요청: "테스트 작성해줘", "단위 테스트 만들어줘", "테스트 실행해줘",
  "커버리지 확인해줘", "이 함수 테스트 케이스 만들어줘",
  "TDD로 개발해줘", "테스트 코드가 없어서 추가하고 싶어"
  암묵적 요청: "안심하고 리팩토링하고 싶어", "배포 전 검증해줘",
  "버그 재발 방지하고 싶어", "이 코드 믿을 수 있어?",
  "코드 변경이 기존 기능에 영향 줄 것 같아" → 회귀 테스트 필요
  자동 제안: 코드 구현 완료 후 TEST 태스크가 있으면 test 스킬 실행을 제안한다.
  plan에 TEST- 태스크가 있을 때 해당 단계에서 자동으로 이어진다.
  CLAUDE.md의 test_framework를 따르며, 없으면 언어에 맞는 기본값을 사용한다.
---

# Test 스킬 — 테스트 코드 작성·실행

## 역할

코드의 핵심 동작을 문서화하고 리팩토링 시 안전망을 제공한다.
단순 "통과"가 목적이 아니라 PRD의 FR과 NFR을 실제로 검증하는 것이 목적이다.
테스트가 충분하면 나중에 대담하게 리팩토링하고 자신 있게 배포할 수 있다.

## TDD 사이클 (Kent Beck — Red → Green → Refactor)

Track C에서는 **TDD 패턴이 기본**이다 (plan/SKILL.md "TDD 분해 패턴" 참조).

```
🔴 Red    → 실패하는 테스트 작성 (TEST-XX)
            ↓ 백워드 reason: "[Red] TEST-XX 작성"
🟢 Green  → 최소 구현 (IMPL-XX)
            ↓ 백워드 reason: "[Green] TEST-XX 통과"
🔵 Refactor → (선택) 정리 (REFAC-XX) — 동작 변경 금지 (Tidy First)
            ↓ 백워드 reason: "[Refactor] IMPL-XX 정리"
```

dev↔test 백워드 전환의 `--reason`에 마커 포함 시 dev-journal과 session-gate가 자동으로 TDD 단계를 표시한다.

## 시나리오 회귀 테스트 러너 — tests/manual/run-all.sh

Hook 시스템처럼 단위 테스트 프레임워크가 없는 경우, Bash 시나리오 테스트로 대체:

```bash
# 모든 시나리오 일괄 실행
bash tests/manual/run-all.sh

# 단일 시나리오
bash tests/manual/approve-prd.sh
```

각 시나리오는 `tests/manual/_helpers.sh`의 `assert_block`, `assert_allow`, `assert_contains`, `assert_not_contains` 헬퍼를 사용한다.

새 시나리오 추가:
1. `tests/manual/{topic}.sh` 작성 (chmod +x)
2. `source "$(dirname "$0")/_helpers.sh"` 로 시작
3. 마지막에 `print_summary` 호출
4. run-all.sh가 자동으로 picking up

---

## 실행 전 확인

1. CLAUDE.md를 읽어 `test_framework` 값을 확인한다
   - 비어있으면: "어떤 테스트 프레임워크를 사용하시나요?" 물어보고 CLAUDE.md에 기록
2. 진입 경로를 확인한다:
   **경로 A — analysis에서 직접 연결**
   - analysis의 "테스트 강화 필요" 섹션에서 커버리지 수치와 미테스트 영역을 받는다
   **경로 B — plan의 TEST 태스크에서 연결 (일반 경로)**
   - plan 파일에서 TEST- 태스크 목록과 `관련 NFR` 필드를 확인한다
   - PRD의 NFR 테이블 "검증 방법" 컬럼을 읽어 테스트 유형 결정에 사용한다
3. 기존 테스트 파일이 있으면 먼저 읽는다 — 중복 작성 방지, 패턴 파악

---

## 테스트 유형 분류 및 NFR 매핑

요청과 PRD NFR에 따라 적합한 테스트 유형을 선택한다.

| 테스트 유형 | 목적 | NFR 연결 |
|-----------|------|---------|
| **단위 테스트** | 함수·메서드 단독 동작 검증 | FR 구현 확인 |
| **통합 테스트** | 모듈 간 협력 동작 검증 | 의존성·데이터 흐름 |
| **성능 테스트** | 응답 시간·처리량 측정 | NFR 성능 항목 |
| **보안 테스트** | 인증·권한·입력 검증 | NFR 보안 항목 |
| **회귀 테스트** | 기존 기능 영향 없음 확인 | 변경 후 안전성 |
| **E2E 테스트** | 전체 사용자 시나리오 | 주요 사용자 흐름 |

### NFR → 테스트 유형 자동 매핑

PRD에 NFR이 있으면 아래 표에 따라 테스트 케이스를 추가로 설계한다:

| NFR 항목 | 생성할 테스트 유형 | 케이스 예시 |
|---------|--------------|---------|
| 성능 (응답 시간) | 성능 테스트 | N개 동시 요청 시 X초 이내 응답 |
| 성능 (처리량) | 부하 테스트 | 초당 N건 처리 가능 |
| 보안 (인증) | 보안 테스트 | 미인증 요청 차단 확인 |
| 보안 (입력 검증) | 보안 테스트 | SQL 인젝션·XSS 방지 확인 |
| 가용성 | 회복력 테스트 | 장애 후 정상 복구 |

---

## 프레임워크 자동 감지 로직

CLAUDE.md의 `test_framework`가 비어있을 때 아래 순서로 자동 감지한다:

```
감지 절차 (첫 번째 매칭에서 중단):

1. 프로젝트 파일 기반 감지:
   *.csproj에 "xunit" 포함 → xUnit
   *.csproj에 "nunit" 포함 → NUnit
   pyproject.toml에 [tool.pytest] 섹션 → pytest
   package.json에 "jest" 의존성 → Jest
   package.json에 "vitest" 의존성 → Vitest
   CMakeLists.txt에 "gtest" 포함 → Google Test

2. 설정 파일 기반 감지:
   jest.config.* 존재 → Jest
   vitest.config.* 존재 → Vitest
   pytest.ini / setup.cfg [tool:pytest] 존재 → pytest
   .nunitrc 존재 → NUnit

3. 기존 테스트 파일 패턴 감지:
   tests/*_test.py 또는 tests/test_*.py 존재 → pytest
   *.Tests/ 디렉토리 존재 → dotnet test (xUnit/NUnit)
   __tests__/ 또는 *.test.ts 존재 → Jest 또는 Vitest
   *_test.cpp 존재 → Google Test

4. 감지 실패 시:
   "테스트 프레임워크를 자동 감지하지 못했습니다. 어떤 프레임워크를 사용하시나요?"
   답변 후 CLAUDE.md test_framework에 기록
```

## 언어별 프레임워크 기본 설정

| 언어 | 프레임워크 | 파일 위치 | 실행 명령 | 커버리지 도구 |
|------|---------|---------|---------|-----------|
| C# | xUnit | `tests/{Project}.Tests/` | `dotnet test --collect:"XPlat Code Coverage"` | coverlet |
| C# | NUnit | `tests/{Project}.Tests/` | `dotnet test --collect:"XPlat Code Coverage"` | coverlet |
| Python | pytest | `tests/` | `pytest tests/ -v --tb=short --cov=src --cov-report=term` | pytest-cov |
| TypeScript | Jest | `src/__tests__/` | `npm test -- --coverage` | jest 내장 |
| TypeScript | Vitest | `src/__tests__/` | `npx vitest run --coverage` | v8/istanbul |
| C++ | Google Test | `tests/` | `ctest --output-on-failure` | gcov/lcov |
| Go | testing | `*_test.go` | `go test ./... -coverprofile=coverage.out` | go test 내장 |
| Rust | cargo test | `tests/` | `cargo test` | cargo-tarpaulin |

---

## 커버리지 기준

| 코드 유형 | 권장 커버리지 | 미달 시 조치 |
|---------|------------|---------|
| 핵심 비즈니스 로직 | 90% 이상 | 즉시 보강 필수 |
| 일반 기능 구현 | 80% 이상 | 주요 경로 추가 |
| 유틸리티·헬퍼 | 70% 이상 | 핵심 케이스 추가 |
| 프레임워크 boilerplate | 제외 가능 | — |

커버리지 미달 시 어떤 파일·함수가 미테스트인지 확인해서 우선순위를 제안한다.

### 커버리지 미달 시 보강 우선순위

```
1순위: 핵심 비즈니스 로직 중 미테스트 함수 (90% 목표)
2순위: 에러 처리 경로 (예외, 타임아웃, 경계값)
3순위: 공개 API/인터페이스 함수 (80% 목표)
4순위: 유틸리티·헬퍼 함수 (70% 목표)
```

커버리지 보고서에서 미테스트 파일/함수를 추출하고 위 우선순위로 정렬하여 제안한다.

### 언어별 커버리지 측정 명령

커버리지 도구가 미설치인 경우 자동 설치를 제안한다:

| 언어 | 미설치 감지 | 설치 명령 |
|------|----------|---------|
| Python | `ModuleNotFoundError: pytest-cov` | `pip install pytest-cov` |
| C# | coverlet 어댑터 누락 | `dotnet add package coverlet.collector` |
| TypeScript | coverage 설정 없음 | package.json scripts에 `--coverage` 추가 |

---

## 테스트 작성 절차

### 1. 대상 코드 분석

구현된 코드를 읽고:
- Public 인터페이스/함수 목록 파악
- 핵심 비즈니스 로직 식별
- 경계값과 예외 상황 도출
- NFR 검증 항목 확인 (PRD에서 수신한 경우)

### 2. 테스트 케이스 설계

각 함수/메서드에 대해 3관점 + NFR 케이스:

```
Happy path : 정상 입력 → 예상 출력 확인
Edge case  : 경계값 (빈 값, 최대값, null, 음수 등)
Error case : 잘못된 입력 → 예외/에러 처리 확인
NFR case   : 성능 측정, 보안 검증 (해당 시)
```

### 3. 코드 작성 후 실행

파일 작성 후 실제로 실행해서 통과 여부 확인.

### 4. 실패 시 분류 및 수정

실패한 테스트를 먼저 아래 유형으로 분류한 뒤 접근한다:

| 실패 유형 | 판단 기준 | 수정 대상 |
|---------|---------|---------|
| 구현 버그 | 테스트 로직은 맞지만 실제 코드가 잘못된 경우 | 구현 코드 수정 |
| 테스트 버그 | 테스트 기대값 자체가 잘못 설정된 경우 | 테스트 코드 수정 |
| 환경 문제 | 의존성·설정·경로 오류 | 설정/환경 수정 |
| 플레이키 테스트 | 실행 때마다 결과가 다를 경우 | 테스트 독립성 확보 |

수정 후 `실패한 테스트만` 재실행해서 통과 확인, 이후 전체 재실행.

### 5. 재시도 및 플레이키 테스트 대응

**재시도 절차:**
```
1차 실행 → 실패 발생
  ↓
실패 유형 분류 (위 표 참조)
  ↓
수정 적용
  ↓
2차 실행 (실패한 테스트만)
  ↓ 통과 시
3차 실행 (전체 테스트 스위트)
  ↓ 실패 시
원인 재분석 → 최대 3회 반복
  ↓ 3회 초과 실패 시
사용자에게 보고: "테스트가 3회 연속 실패했습니다. 수동 확인이 필요합니다."
[!] 상태로 전환, dev-journal에 기록
```

**플레이키 테스트 감지 및 대응:**
```
감지 기준: 동일 테스트가 동일 코드에서 통과/실패가 교차하는 경우
  - 1차 실패 → 코드 변경 없이 2차 통과 → 플레이키 의심

대응 절차:
1. 해당 테스트를 @flaky/@unstable 마킹 권고
2. 플레이키 원인 분류:
   - 타이밍 의존 (sleep, 타임아웃) → 명시적 대기로 교체
   - 순서 의존 (다른 테스트 결과에 의존) → 테스트 독립성 확보
   - 외부 의존 (네트워크, DB) → 모킹 또는 테스트 환경 격리
   - 리소스 경합 (파일, 포트) → 고유 리소스 할당
3. test-result.md의 "실패한 테스트" 섹션에 "플레이키 의심" 컬럼 추가
```

---

## 결과 기록

**경로**: `docs/tests/{topic}-test-result.md`

```markdown
# {topic} 테스트 결과

- **실행일**: {날짜}
- **프레임워크**: {framework}
- **연관 Plan**: docs/plans/{topic}-prd-plan.md
- **연관 PRD**: docs/prds/{topic}-prd.md

## 결과 요약

| 항목 | 수치 | 기준 | 평가 |
|------|------|------|------|
| 전체 테스트 | {N}개 | — | — |
| 통과율 | {%}% | 100% | ✅/❌ |
| 커버리지 | {%}% | 80%+ | ✅/⚠️/❌ |

## NFR 검증 결과

| NFR ID | 항목 | 요구사항 | 실제 측정값 | 결과 |
|--------|------|---------|----------|------|
| NFR-01 | 성능 | X초 이내 | {N}초 | ✅/❌ |

## 실패한 테스트

| 테스트명 | 실패 유형 | 원인 | 처리 상태 |
|---------|---------|------|---------|

## 전체 테스트 목록

| ID | 테스트명 | 대상 | 유형 | 결과 |
|----|---------|------|------|------|
```

---

## 완료 후 처리

**테스트 전체 통과 시:**

1. `docs/tests/{topic}-test-result.md` 저장
2. **plan 파일 갱신**
   `.claude/skills/monitoring/SKILL.md`를 읽고 TEST- 태스크를 `[x]`로 변경
3. **INDEX.md 갱신**
   `.claude/skills/index/SKILL.md`를 읽고 테스트 결과 섹션에 한 줄 추가
4. **session-context.md 갱신**
   `.claude/skills/memory/SKILL.md`를 읽고 갱신:
   - "완료된 작업 이력"에 `{날짜} | {topic} 테스트 완료 (커버리지: {%}%)` 추가
   - NFR 검증 실패 항목이 있으면 "미해결 이슈"에 추가
5. 사용자에게 결과 안내 (NFR 달성 여부 포함)

**테스트 실패 시:**

1. 실패 유형을 분류하고 수정 방향을 제안한다
2. 코드 수정 후 재실행한다
3. `.claude/skills/monitoring/SKILL.md`를 읽고 해당 태스크를 `[!]`로 표시

---

## process 연동

- 전체 통과 → `.claude/skills/process/SKILL.md`의 "test 전체 통과" 처리에 따라 report 즉시 실행
- 실패 있음 → "test 실패" 예외 복구 라우팅에 따라 실패 TEST-ID와 연관 IMPL-ID를 process에 전달
- NFR 미달 → process에 NFR 항목별 미달 내용을 전달하여 report의 "알려진 이슈"에 포함
