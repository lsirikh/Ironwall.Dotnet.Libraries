// .claude/hooks/advance-phase-heal.js
// Self-Healing + INDEX 재구축

const fs = require('fs');
const path = require('path');
const { scanDocsDir } = require('./_common');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

function extractPrdStatus(prdAbsPath) {
  try {
    const c = fs.readFileSync(prdAbsPath, 'utf8');
    const m = c.match(/^- \*\*상태\*\*:\s*(\w+)/im);
    return m ? m[1] : 'Draft';
  } catch { return 'Draft'; }
}

function calcPlanProgress(planAbsPath) {
  try {
    const c = fs.readFileSync(planAbsPath, 'utf8');
    const done = (c.match(/^- \[x\]/gm) || []).length;
    const total = done +
      (c.match(/^- \[ \]/gm) || []).length +
      (c.match(/^- \[~\]/gm) || []).length +
      (c.match(/^- \[!\]/gm) || []).length;
    return `${done}/${total}`;
  } catch { return '0/0'; }
}

function rebuildIndexAuto() {
  const indexFile = path.join(PROJECT_ROOT, 'docs', 'INDEX.md');
  const today = new Date().toISOString().slice(0, 10);

  const analyses = scanDocsDir('analysis');
  const prds = scanDocsDir('prds');
  const plans = scanDocsDir('plans');
  const tests = scanDocsDir('tests');
  const reports = scanDocsDir('reports');
  const totalDocs = analyses.length + prds.length + plans.length + tests.length + reports.length;

  let auto = `<!-- auto-section-start -->\n# 프로젝트 문서 인덱스\n\n`;
  auto += `- **마지막 갱신**: ${today} (advance-phase 자동)\n- **총 문서 수**: ${totalDocs}개\n\n---\n\n`;

  auto += `## 분석 (docs/analysis/)\n\n| 파일 | 분석 대상 | 날짜 |\n|------|---------|------|\n`;
  for (const f of analyses) {
    auto += `| [${f.name}](analysis/${f.name}) | ${f.name.replace(/-analysis\.md$/, '')} | ${new Date(f.mtime).toISOString().slice(0, 10)} |\n`;
  }

  auto += `\n## 요구사항 정의서 (docs/prds/)\n\n| 파일 | 내용 | 상태 | 날짜 |\n|------|------|------|------|\n`;
  for (const f of prds) {
    auto += `| [${f.name}](prds/${f.name}) | ${f.name.replace(/-prd\.md$/, '')} | ${extractPrdStatus(path.join(PROJECT_ROOT, f.path))} | ${new Date(f.mtime).toISOString().slice(0, 10)} |\n`;
  }

  auto += `\n## 구현 플랜 (docs/plans/)\n\n| 파일 | 연관 PRD | 진행률 | 날짜 |\n|------|---------|--------|------|\n`;
  for (const f of plans) {
    const topic = f.name.replace(/-prd-plan\.md$/, '').replace(/-plan\.md$/, '');
    auto += `| [${f.name}](plans/${f.name}) | [PRD](prds/${topic}-prd.md) | ${calcPlanProgress(path.join(PROJECT_ROOT, f.path))} | ${new Date(f.mtime).toISOString().slice(0, 10)} |\n`;
  }

  auto += `\n## 테스트 결과 (docs/tests/)\n\n| 파일 | 통과율 | 커버리지 | 날짜 |\n|------|--------|---------|------|\n`;
  for (const f of tests) {
    auto += `| [${f.name}](tests/${f.name}) | -% | -% | ${new Date(f.mtime).toISOString().slice(0, 10)} |\n`;
  }

  auto += `\n## 완료 리포트 (docs/reports/)\n\n| 파일 | 문서 연결 체인 | 날짜 |\n|------|------------|------|\n`;
  for (const f of reports) {
    const topic = f.name.replace(/-report\.md$/, '');
    auto += `| [${f.name}](reports/${f.name}) | [PRD](prds/${topic}-prd.md) → [Plan](plans/${topic}-prd-plan.md) | ${new Date(f.mtime).toISOString().slice(0, 10)} |\n`;
  }
  auto += `\n<!-- auto-section-end -->\n`;

  let content = '';
  if (fs.existsSync(indexFile)) {
    content = fs.readFileSync(indexFile, 'utf8');
    if (content.includes('<!-- auto-section-start -->') && content.includes('<!-- auto-section-end -->')) {
      content = content.replace(/<!-- auto-section-start -->[\s\S]*?<!-- auto-section-end -->/, auto.trim());
    } else {
      try { const bk = path.join(PROJECT_ROOT, 'docs', 'INDEX.md.user-backup'); if (!fs.existsSync(bk)) fs.writeFileSync(bk, content); } catch {}
      content = auto;
    }
  } else { content = auto; }

  try { fs.writeFileSync(indexFile, content); return { ok: true, totalDocs }; }
  catch (err) { return { ok: false, error: err.message }; }
}

function healArtifacts(state) {
  if (!state.artifacts) state.artifacts = {};
  for (const type of ['prd', 'plan']) {
    const dirName = type === 'prd' ? 'prds' : 'plans';
    if (state.artifacts[type]) {
      const p = path.join(PROJECT_ROOT, state.artifacts[type].path);
      if (!fs.existsSync(p)) {
        const recent = scanDocsDir(dirName)[0];
        if (recent) {
          state.artifacts[type] = { path: recent.path, recorded_at: new Date().toISOString() };
          state[type === 'prd' ? 'activePrd' : 'activePlan'] = recent.path;
        } else {
          delete state.artifacts[type];
          state[type === 'prd' ? 'activePrd' : 'activePlan'] = null;
        }
      }
    }
  }
  return state;
}

module.exports = { extractPrdStatus, calcPlanProgress, rebuildIndexAuto, healArtifacts };
