---
name: rust-patterns
description: Rust core patterns — ownership, borrowing, error handling, traits, enums, iterators, smart pointers, async, closures, modules
languages: ["Rust"]
frameworks: ["Rust"]
phases: ["dev", "test"]
---

# Rust Patterns

## When to Activate

- Rust 프로젝트에서 코드 작성 또는 리뷰 시
- CLAUDE.md language가 Rust일 때
- `.rs` 파일을 편집하거나 `Cargo.toml`이 존재할 때

## Core Patterns

### Ownership and Borrowing

```rust
fn main() {
    let s1 = String::from("hello");
    let s2 = s1;           // s1 MOVED into s2, s1 is invalid
    let s3 = s2.clone();   // explicit clone to keep both

    // Immutable reference: &T — multiple allowed
    let len = calculate_length(&s3);
    // Mutable reference: &mut T — only one at a time
    let mut s = String::from("hi");
    append_world(&mut s);
}
fn calculate_length(s: &String) -> usize { s.len() }
fn append_world(s: &mut String) { s.push_str(", world"); }
```

### Lifetime Annotations

```rust
// Explicit lifetime ties return reference to inputs
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() > y.len() { x } else { y }
}

struct Excerpt<'a> { text: &'a str }
impl<'a> Excerpt<'a> {
    fn announce(&self, msg: &str) -> &str { // lifetime elision on &self
        println!("{msg}");
        self.text
    }
}
```

### Error Handling — Result, ?, thiserror, anyhow

```rust
use std::fs;
use thiserror::Error;
use anyhow::Context;

// ? operator propagates errors
fn read_username() -> Result<String, std::io::Error> {
    let mut s = fs::read_to_string("username.txt")?;
    s.truncate(s.trim_end().len());
    Ok(s)
}

// Custom error enum with thiserror (for libraries)
#[derive(Error, Debug)]
enum AppError {
    #[error("database error: {0}")]
    Database(#[from] sqlx::Error),
    #[error("not found: {entity} id={id}")]
    NotFound { entity: &'static str, id: i64 },
}

// anyhow for application code — adds context to any error
fn load_config(path: &str) -> anyhow::Result<Config> {
    let text = fs::read_to_string(path)
        .with_context(|| format!("failed to read {path}"))?;
    Ok(toml::from_str(&text).context("bad TOML")?)
}
```

### Traits — impl Trait, dyn Trait, From/Into

```rust
trait Summary {
    fn summarize(&self) -> String;
    fn preview(&self) -> String { format!("{}...", &self.summarize()[..20]) }
}
struct Article { title: String, body: String }
impl Summary for Article {
    fn summarize(&self) -> String { format!("{}: {}", self.title, &self.body[..50]) }
}

// Static dispatch (monomorphized, zero cost)
fn notify(item: &impl Summary) { println!("{}", item.summarize()); }

// Dynamic dispatch (trait object, runtime vtable)
fn get_summarizer(kind: &str) -> Box<dyn Summary> {
    match kind {
        "article" => Box::new(Article { title: "t".into(), body: "b".repeat(60) }),
        _ => panic!("unknown"),
    }
}

// Associated types
trait Iterator { type Item; fn next(&mut self) -> Option<Self::Item>; }

// From/Into conversion
impl From<AppError> for HttpResponse {
    fn from(e: AppError) -> Self { /* ... */ }
}
```

### Enums and Pattern Matching

```rust
enum Command { Quit, Echo(String), Move { x: i32, y: i32 } }

fn execute(cmd: Command) {
    match cmd { // exhaustive — compiler enforces all variants
        Command::Quit => println!("quit"),
        Command::Echo(msg) => println!("{msg}"),
        Command::Move { x, y } => println!("({x},{y})"),
    }
}

// if let / while let for single-variant
if let Some(s) = optional_val { println!("{s}"); }
while let Ok(msg) = rx.try_recv() { println!("{msg}"); }

// Nested match with guard
match result {
    Ok(Some(v)) if v > 0 => println!("positive: {v}"),
    Ok(None) => println!("empty"),
    Err(e) => eprintln!("{e}"),
    _ => {}
}
```

### Iterators

```rust
let nums = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

let evens_doubled: Vec<i32> = nums.iter()
    .filter(|&&n| n % 2 == 0).map(|&n| n * 2).collect();

let combined: Vec<i32> = (1..=3).chain(7..=9).collect();             // chain
for (i, v) in nums.iter().enumerate() { println!("[{i}]={v}"); }     // enumerate
let sum: i32 = nums.iter().fold(0, |acc, &x| acc + x);               // fold
let words: Vec<&str> = vec!["hello world", "foo bar"]
    .iter().flat_map(|s| s.split_whitespace()).collect();              // flat_map
let (even, odd): (Vec<i32>, Vec<i32>) = nums.iter().partition(|&&n| n % 2 == 0);
```

### Smart Pointers

```rust
use std::sync::{Arc, Mutex};
use std::rc::Rc;
use std::cell::RefCell;

// Box<T> — heap allocation, single owner
let large = Box::new([0u8; 1_000_000]);

// Rc<T> — reference-counted, single-thread
let data = Rc::new(vec![1, 2, 3]);
let c1 = Rc::clone(&data); // ref count = 2

// Arc<Mutex<T>> — thread-safe shared mutable state
let counter = Arc::new(Mutex::new(0));
for _ in 0..10 {
    let c = Arc::clone(&counter);
    std::thread::spawn(move || { *c.lock().unwrap() += 1; });
}

// RefCell<T> — interior mutability, runtime borrow checks
let cell = RefCell::new(vec![1, 2]);
cell.borrow_mut().push(3);
```

### Async / Await (Tokio)

```rust
use tokio::sync::mpsc;
use tokio::time::{sleep, Duration};

#[tokio::main]
async fn main() {
    let (tx, mut rx) = mpsc::channel(32);
    tokio::spawn(async move { for i in 0..5 { tx.send(i).await.unwrap(); } });
    while let Some(v) = rx.recv().await { println!("{v}"); }
}

// select! races multiple futures
async fn with_timeout() {
    tokio::select! {
        data = fetch_data() => println!("{data:?}"),
        _ = sleep(Duration::from_secs(5)) => println!("timeout"),
    }
}
```

### Closures

```rust
// Fn — borrows immutably, callable many times
let greeting = String::from("hi");
let greet = |name: &str| println!("{greeting}, {name}!");

// FnMut — borrows mutably
let mut count = 0;
let mut inc = || { count += 1; };

// FnOnce — takes ownership via move, callable once
let data = vec![1, 2, 3];
let consume = move || { drop(data); };

// Returning closures
fn make_adder(x: i32) -> impl Fn(i32) -> i32 { move |y| x + y }
```

### Modules and Visibility

```rust
pub mod network {
    pub mod server {
        pub struct Config {
            pub host: String,
            pub(crate) port: u16,  // crate-visible
            timeout_ms: u32,        // private
        }
        impl Config {
            pub fn new(host: &str, port: u16) -> Self {
                Self { host: host.into(), port, timeout_ms: 5000 }
            }
        }
    }
    pub mod client {
        pub use super::server::Config as ServerConfig; // re-export
    }
}
use crate::network::client::ServerConfig;
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| `.unwrap()` in library code | `?` with proper error type | Libraries must not panic on recoverable errors |
| `clone()` to silence borrow checker | Restructure lifetimes / references | Unnecessary allocation, hides design issues |
| `Arc<Mutex<T>>` everywhere | Channel-based message passing | Reduces lock contention, clearer data flow |
| Stringly-typed errors `Err("fail")` | Custom error enums with `thiserror` | Type-safe, pattern matchable |
| `unsafe` without justification | Safe abstractions or `// SAFETY:` doc | Unsafe must be audited and documented |
| Wildcard `match _ =>` first | Handle all variants explicitly | Compiler can't catch missing new variants |
| `Box<dyn Trait>` by default | `impl Trait` (static dispatch) | Dynamic dispatch has runtime cost |
| Recursive types without `Box` | `Box<Node>` for recursive enums | Compiler can't determine size |
| `pub` on all struct fields | Expose via methods, keep fields private | Encapsulation, internal flexibility |
| Ignoring `#[must_use]` warnings | Handle or `let _ =` to discard | Result/Option must be checked |
