---
name: frontend-testing
description: Frontend testing strategies — unit tests (Vitest/Jest), component tests (Testing Library), E2E tests (Playwright/Cypress)
languages: ["TypeScript", "JavaScript"]
frameworks: ["Jest", "Vitest", "Playwright", "Cypress"]
phases: ["test"]
---

# Frontend Testing

## When to Activate

- Writing or reviewing unit tests for frontend utilities and hooks
- Testing React or Vue components with Testing Library
- Setting up or maintaining E2E test suites with Playwright or Cypress
- Configuring CI pipelines for headless browser testing
- Debugging flaky tests or improving test reliability

---

## Core Patterns

### 1. Unit Testing with Vitest / Jest

Vitest and Jest share nearly identical APIs. Vitest is faster for Vite-based projects.

```ts
// utils/format.ts
export function formatCurrency(amount: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(
    amount
  );
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
```

```ts
// utils/format.test.ts
import { describe, it, expect } from "vitest"; // or from "@jest/globals"
import { formatCurrency, slugify } from "./format";

describe("formatCurrency", () => {
  it("formats USD by default", () => {
    expect(formatCurrency(1234.5)).toBe("$1,234.50");
  });

  it("formats EUR when specified", () => {
    expect(formatCurrency(1000, "EUR")).toBe("€1,000.00");
  });

  it("handles zero", () => {
    expect(formatCurrency(0)).toBe("$0.00");
  });
});

describe("slugify", () => {
  it("converts spaces to hyphens", () => {
    expect(slugify("Hello World")).toBe("hello-world");
  });

  it("removes special characters", () => {
    expect(slugify("Hello, World!")).toBe("hello-world");
  });

  it("trims leading/trailing hyphens", () => {
    expect(slugify("  Hello  ")).toBe("hello");
  });
});
```

**Mocking modules:**

```ts
// services/api.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";
import { fetchUsers } from "./api";

// Mock the global fetch
const mockFetch = vi.fn();
vi.stubGlobal("fetch", mockFetch);

describe("fetchUsers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns parsed user data", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [{ id: 1, name: "Alice" }],
    });

    const users = await fetchUsers();
    expect(users).toEqual([{ id: 1, name: "Alice" }]);
    expect(mockFetch).toHaveBeenCalledWith("/api/users");
  });

  it("throws on HTTP error", async () => {
    mockFetch.mockResolvedValueOnce({ ok: false, status: 500 });

    await expect(fetchUsers()).rejects.toThrow("HTTP 500");
  });
});
```

**Mocking modules (vi.mock / jest.mock):**

```ts
import { vi } from "vitest";

// Auto-mock entire module
vi.mock("@/lib/analytics", () => ({
  trackEvent: vi.fn(),
  identify: vi.fn(),
}));

// Partial mock — keep real implementations, override specific exports
vi.mock("@/lib/auth", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/auth")>();
  return {
    ...actual,
    isAuthenticated: vi.fn(() => true),
  };
});
```

**Snapshot testing:**

```ts
import { describe, it, expect } from "vitest";
import { generateConfig } from "./config";

describe("generateConfig", () => {
  it("matches snapshot for default config", () => {
    const config = generateConfig({ env: "production" });
    expect(config).toMatchSnapshot();
  });

  it("matches inline snapshot", () => {
    const config = generateConfig({ env: "test" });
    expect(config).toMatchInlineSnapshot(`
      {
        "debug": true,
        "env": "test",
        "logLevel": "verbose",
      }
    `);
  });
});
```

### 2. Component Testing with Testing Library

**React component test:**

```tsx
// components/Counter.tsx
"use client";
import { useState } from "react";

export function Counter({ initial = 0 }: { initial?: number }) {
  const [count, setCount] = useState(initial);
  return (
    <div>
      <p data-testid="count">Count: {count}</p>
      <button onClick={() => setCount((c) => c + 1)}>Increment</button>
      <button onClick={() => setCount(0)}>Reset</button>
    </div>
  );
}
```

```tsx
// components/Counter.test.tsx
import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { Counter } from "./Counter";

describe("Counter", () => {
  it("renders initial count", () => {
    render(<Counter initial={5} />);
    expect(screen.getByTestId("count")).toHaveTextContent("Count: 5");
  });

  it("increments on button click", () => {
    render(<Counter />);
    fireEvent.click(screen.getByText("Increment"));
    expect(screen.getByTestId("count")).toHaveTextContent("Count: 1");
  });

  it("resets to zero", () => {
    render(<Counter initial={10} />);
    fireEvent.click(screen.getByText("Reset"));
    expect(screen.getByTestId("count")).toHaveTextContent("Count: 0");
  });
});
```

**Vue component test:**

```vue
<!-- components/TodoItem.vue -->
<script setup lang="ts">
defineProps<{ title: string; done: boolean }>();
const emit = defineEmits<{ toggle: [] }>();
</script>

<template>
  <li :class="{ 'line-through': done }" @click="emit('toggle')">
    {{ title }}
  </li>
</template>
```

```ts
// components/TodoItem.test.ts
import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/vue";
import TodoItem from "./TodoItem.vue";

describe("TodoItem", () => {
  it("renders the title", () => {
    render(TodoItem, { props: { title: "Buy milk", done: false } });
    expect(screen.getByText("Buy milk")).toBeTruthy();
  });

  it("applies line-through when done", () => {
    render(TodoItem, { props: { title: "Buy milk", done: true } });
    const item = screen.getByText("Buy milk");
    expect(item.classList.contains("line-through")).toBe(true);
  });

  it("emits toggle event on click", async () => {
    const { emitted } = render(TodoItem, {
      props: { title: "Buy milk", done: false },
    });
    await fireEvent.click(screen.getByText("Buy milk"));
    expect(emitted().toggle).toHaveLength(1);
  });
});
```

**Key queries (priority order):**

| Query | Use When |
|-------|----------|
| `getByRole` | Accessible elements (buttons, headings, inputs) |
| `getByLabelText` | Form fields with labels |
| `getByPlaceholderText` | Inputs with placeholder |
| `getByText` | Visible text content |
| `getByTestId` | Last resort — no semantic query available |

### 3. E2E Testing with Playwright

```ts
// e2e/login.spec.ts
import { test, expect } from "@playwright/test";

test.describe("Login flow", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/login");
  });

  test("successful login redirects to dashboard", async ({ page }) => {
    await page.getByLabel("Email").fill("user@example.com");
    await page.getByLabel("Password").fill("password123");
    await page.getByRole("button", { name: "Sign in" }).click();

    await expect(page).toHaveURL("/dashboard");
    await expect(page.getByRole("heading", { name: "Dashboard" })).toBeVisible();
  });

  test("shows error for invalid credentials", async ({ page }) => {
    await page.getByLabel("Email").fill("user@example.com");
    await page.getByLabel("Password").fill("wrong");
    await page.getByRole("button", { name: "Sign in" }).click();

    await expect(page.getByText("Invalid credentials")).toBeVisible();
    await expect(page).toHaveURL("/login");
  });
});
```

**API mocking (route interception):**

```ts
test("displays users from API", async ({ page }) => {
  // Intercept API call and return mock data
  await page.route("/api/users", (route) =>
    route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify([
        { id: 1, name: "Alice" },
        { id: 2, name: "Bob" },
      ]),
    })
  );

  await page.goto("/users");
  await expect(page.getByText("Alice")).toBeVisible();
  await expect(page.getByText("Bob")).toBeVisible();
});
```

**Visual comparison:**

```ts
test("homepage matches screenshot", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveScreenshot("homepage.png", {
    maxDiffPixelRatio: 0.01,
  });
});
```

**Playwright config essentials:**

```ts
// playwright.config.ts
import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: "html",
  use: {
    baseURL: "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
  },
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    { name: "firefox", use: { ...devices["Desktop Firefox"] } },
    { name: "mobile", use: { ...devices["Pixel 5"] } },
  ],
  webServer: {
    command: "npm run dev",
    port: 3000,
    reuseExistingServer: !process.env.CI,
  },
});
```

### 4. E2E Testing with Cypress

```ts
// cypress/e2e/search.cy.ts
describe("Search feature", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("filters results as user types", () => {
    cy.get('[data-testid="search-input"]').type("react");
    cy.get('[data-testid="result-item"]').should("have.length.greaterThan", 0);
    cy.get('[data-testid="result-item"]')
      .first()
      .should("contain.text", "React");
  });

  it("shows empty state when no results", () => {
    cy.get('[data-testid="search-input"]').type("xyznonexistent");
    cy.get('[data-testid="empty-state"]').should("be.visible");
  });
});
```

**API interception:**

```ts
it("handles API errors gracefully", () => {
  cy.intercept("GET", "/api/search*", {
    statusCode: 500,
    body: { error: "Internal Server Error" },
  }).as("searchRequest");

  cy.get('[data-testid="search-input"]').type("test");
  cy.wait("@searchRequest");
  cy.get('[data-testid="error-message"]').should("be.visible");
});
```

### 5. Test Organization

```
src/
├── components/
│   ├── Button.tsx
│   └── Button.test.tsx          # Co-located unit/component test
├── utils/
│   ├── format.ts
│   └── format.test.ts           # Co-located unit test
e2e/                              # E2E tests separated from source
├── login.spec.ts
├── search.spec.ts
└── fixtures/
    └── users.json                # Shared test data
```

**Test naming conventions:**

```ts
// Describe the unit under test, then the scenario
describe("formatCurrency", () => {
  it("formats positive amounts with two decimals", () => { /* ... */ });
  it("handles negative amounts", () => { /* ... */ });
  it("throws for NaN input", () => { /* ... */ });
});
```

### 6. CI Integration

```yaml
# .github/workflows/test.yml
name: Tests
on: [push, pull_request]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npx vitest run --coverage

  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npx playwright install --with-deps
      - run: npx playwright test
      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 7
```

---

## Anti-Patterns

1. **Testing implementation details** — querying by CSS class names or internal state. Use accessible queries (`getByRole`, `getByLabelText`) that reflect how users interact with the UI.

2. **Not waiting for async operations** — using `sleep` or fixed timeouts instead of Playwright's auto-waiting locators or Cypress's built-in retry. Let the framework wait for elements.

3. **Shared mutable state between tests** — tests should be independent. Use `beforeEach` to set up fresh state. Never rely on test execution order.

4. **Over-mocking** — mocking everything creates tests that pass even when the real code is broken. Mock external dependencies (APIs, databases), not internal modules.

5. **Skipping error-path tests** — only testing the happy path. Always test error states, empty states, loading states, and edge cases.

6. **Giant E2E tests** — a single test that covers the entire user journey. Break into focused scenarios. If one assertion fails, the rest of the test is skipped.

7. **Not running tests in CI** — tests that only run locally get ignored. Configure CI to run the full suite on every push/PR.

8. **Snapshot overuse** — large snapshots that change frequently become rubber-stamp updates. Use inline snapshots for small outputs and structural assertions for complex UI.
