---
name: java-patterns
description: Modern Java development patterns — records, sealed classes, pattern matching, Optional, Streams, CompletableFuture, virtual threads
languages: ["Java"]
frameworks: ["Java 17+"]
phases: ["dev", "test"]
---

# Java Modern Patterns

## When to Activate

- Writing or reviewing Java code targeting Java 17+
- Designing immutable data carriers (records) or restricted type hierarchies (sealed classes)
- Using pattern matching, Optional, Streams, or CompletableFuture
- Adopting virtual threads (Java 21+) or functional interfaces

---

## Core Patterns

### 1. Records

```java
// Compact constructor with validation + normalization
public record Email(String value) {
    public Email {
        if (value == null || !value.contains("@"))
            throw new IllegalArgumentException("Invalid email: " + value);
        value = value.trim().toLowerCase();
    }
}

// Defensive copy for immutability
public record Order(String id, List<LineItem> items) {
    public Order {
        Objects.requireNonNull(id);
        items = List.copyOf(items);
    }
}

// Record as DTO with factory method
public record UserResponse(Long id, String name, String email) {
    public static UserResponse from(User e) {
        return new UserResponse(e.getId(), e.getName(), e.getEmail());
    }
}
```

### 2. Sealed Classes / Interfaces

```java
public sealed interface Shape permits Circle, Rectangle, Triangle {}
public record Circle(double radius) implements Shape {}
public record Rectangle(double w, double h) implements Shape {}
public record Triangle(double base, double h) implements Shape {}

// Exhaustive switch — no default needed
public double area(Shape shape) {
    return switch (shape) {
        case Circle c    -> Math.PI * c.radius() * c.radius();
        case Rectangle r -> r.w() * r.h();
        case Triangle t  -> 0.5 * t.base() * t.h();
    };
}
```

### 3. Pattern Matching

```java
// instanceof pattern matching
if (obj instanceof String s && !s.isBlank()) {
    return "String length " + s.length();
}

// Switch with guarded patterns
public String format(Object obj) {
    return switch (obj) {
        case Integer i when i < 0  -> "Negative: " + i;
        case Integer i             -> "Non-negative: " + i;
        case String s when s.isBlank() -> "(blank)";
        case String s              -> "\"" + s + "\"";
        case null                  -> "null";
        default                    -> obj.toString();
    };
}
```

### 4. Optional (Never call `.get()`)

```java
// map + orElse
String name = userRepo.findById(id).map(User::getName).orElse("Anonymous");

// flatMap for nested Optional
String city = userRepo.findById(id)
        .flatMap(User::getAddress).map(Address::getCity).orElse("Unknown");

// ifPresent for side effects
userRepo.findById(id).ifPresent(u -> emailService.send(u.getEmail(), "Hi"));

// orElseThrow with meaningful exception
User user = userRepo.findById(id)
        .orElseThrow(() -> new UserNotFoundException(id));
```

### 5. Streams

```java
// filter + map + toList (Java 16+)
List<String> emails = users.stream()
        .filter(User::isActive).map(User::getEmail).toList();

// groupingBy with downstream
Map<Dept, Double> avgSalary = emps.stream().collect(
        Collectors.groupingBy(Emp::getDept, Collectors.averagingDouble(Emp::getSalary)));

// flatMap
List<String> allTags = articles.stream()
        .flatMap(a -> a.getTags().stream()).distinct().sorted().toList();

// reduce
int total = items.stream().map(Item::getQty).reduce(0, Integer::sum);
```

### 6. var (Local Variable Type Inference)

```java
var users = new ArrayList<User>();          // GOOD — type obvious
var resp = client.send(req, ofString());    // GOOD — type obvious
var result = service.process(data);         // BAD  — type unclear
```

### 7. Text Blocks

```java
String json = """
        { "name": "%s", "email": "%s", "active": true }
        """.formatted(name, email);

String sql = """
        SELECT id, name FROM users
        WHERE active = true AND dept_id = ?
        ORDER BY name
        """;
```

### 8. CompletableFuture

```java
// thenApply — synchronous transform
CompletableFuture.supplyAsync(() -> repo.findById(id))
        .thenApply(this::enrich).thenApply(Summary::from);

// thenCompose — when step returns CF
createOrderAsync(req).thenCompose(this::shipAsync).thenCompose(this::trackAsync);

// exceptionally — fallback on error
primaryService.fetchAsync(key).exceptionally(ex -> fallback.fetchSync(key));

// allOf — combine independent tasks
var a = loadProfile(id); var b = loadOrders(id);
CompletableFuture.allOf(a, b)
        .thenApply(v -> new Dashboard(a.join(), b.join()));
```

### 9. Virtual Threads (Java 21)

```java
Thread.ofVirtual().name("worker").start(() -> processBlocking());

try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
    var futures = urls.stream().map(u -> exec.submit(() -> fetch(u))).toList();
    var results = futures.stream().map(f -> {
        try { return f.get(); }
        catch (Exception e) { throw new RuntimeException(e); }
    }).toList();
}
```

### 10. Functional Interfaces

```java
Function<String, Integer> len = String::length;
Function<String, Integer> upperLen = ((Function<String,String>) String::toUpperCase).andThen(len);

Predicate<User> activeAdmin = User::isActive;
activeAdmin = activeAdmin.and(u -> u.getRole() == Role.ADMIN);

Consumer<User> onRegister = u -> emailService.welcome(u.getEmail());
onRegister = onRegister.andThen(u -> log.info("Created {}", u.getId()));

Supplier<LocalDateTime> now = LocalDateTime::now;
```

---

## Anti-Patterns

### Never `Optional.get()`

```java
String name = opt.get();                                          // BAD
String name = opt.orElse("default");                              // GOOD
String name = opt.orElseThrow(() -> new NotFoundException(id));   // GOOD
```

### Never Raw Types

```java
List items = new ArrayList();       // BAD — loses type safety
List<Item> items = new ArrayList<>(); // GOOD
```

### Mutable Records

```java
public record Team(String name, List<String> members) {}                  // BAD
public record Team(String name, List<String> members) {
    public Team { members = List.copyOf(members); }                       // GOOD
}
```

### Blocking the Common ForkJoinPool

```java
CompletableFuture.supplyAsync(() -> blockingDbCall());              // BAD
CompletableFuture.supplyAsync(() -> blockingDbCall(), ioExecutor);  // GOOD
```

### Collecting Just to Iterate

```java
users.stream().collect(toList()).forEach(this::process);  // BAD
users.forEach(this::process);                              // GOOD
```
