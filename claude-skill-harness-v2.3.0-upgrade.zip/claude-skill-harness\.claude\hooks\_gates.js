// .claude/hooks/_gates.js
// 순수 검증 함수 — FR-08
//
// 모든 게이트 로직을 부작용 없는 순수 함수로 추출.
// pre-tool-gate, advance-phase에서 호출.
// 단위 테스트 95%+ 목표.

const path = require('path');
const fs = require('fs');

// ── Track 경로 정의 ─────────────────────────────────────────────────

const TRACK_ROUTES = {
  A: ['setup', 'analysis', 'complete'],
  B: ['setup', 'analysis', 'dev', 'test', 'complete'],
  C: ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete']
};

const ALLOWED_BACKWARDS = {
  'test→dev': '테스트 실패로 코드 수정',
  'test→plan': '테스트 결과로 태스크 추가/변경',
  'dev→plan': '개발 중 계획 수정',
  'plan→prd': '계획 중 요구사항 변경',
  'report→dev': '리포트 중 추가 수정',
  'report→test': '추가 테스트 필요',
  'complete→analysis': '새 사이클 시작'
};

const PHASES = ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete'];

// ── Phase 전환 검증 ─────────────────────────────────────────────────

/**
 * Phase 전환 가능 여부 확인
 * @param {string} from - 현재 Phase
 * @param {string} to - 목표 Phase
 * @param {string} track - 현재 Track (A/B/C)
 * @param {Object} opts - { reason, force }
 * @returns {{allowed: boolean, message?: string, isBackward?: boolean}}
 */
function canTransitionTo(from, to, track, opts = {}) {
  if (!PHASES.includes(from)) return { allowed: false, message: `invalid from phase: ${from}` };
  if (!PHASES.includes(to)) return { allowed: false, message: `invalid to phase: ${to}` };
  if (!track || !TRACK_ROUTES[track]) return { allowed: false, message: `invalid track: ${track}` };

  const route = TRACK_ROUTES[track];
  const fromIdx = route.indexOf(from);
  const toIdx = route.indexOf(to);

  // Track 경로에 없는 Phase
  if (fromIdx === -1) return { allowed: false, message: `phase "${from}" is not in Track ${track} route` };
  if (toIdx === -1) return { allowed: false, message: `phase "${to}" is not in Track ${track} route` };

  // 정방향 (다음 Phase로)
  if (toIdx === fromIdx + 1) {
    return { allowed: true, isBackward: false };
  }

  // 동일 Phase
  if (toIdx === fromIdx) {
    return { allowed: false, message: `already in phase "${from}"` };
  }

  // 역방향
  if (toIdx < fromIdx) {
    const edge = `${from}→${to}`;
    if (ALLOWED_BACKWARDS[edge]) {
      if (!opts.reason && !opts.force) {
        return { allowed: false, message: `backward "${edge}" requires --reason`, isBackward: true };
      }
      return { allowed: true, isBackward: true };
    }
    return { allowed: false, message: `backward "${edge}" is not allowed`, isBackward: true };
  }

  // 건너뛰기 (2칸 이상 정방향)
  if (opts.force) return { allowed: true, isBackward: false };
  return { allowed: false, message: `cannot skip from "${from}" to "${to}" (next: "${route[fromIdx + 1]}")` };
}

// ── 파일 접근 검증 ──────────────────────────────────────────────────

/**
 * Track/Phase 조합에서 파일 쓰기 허용 여부
 * @param {string} track
 * @param {string} phase
 * @param {string} normalizedPath - POSIX 정규화 경로
 * @param {Object} opts - { isSourceFile, hasDevJournal, hasPrdApproved, hasPlan }
 * @returns {{allowed: boolean, message?: string}}
 */
function trackAllowsWrite(track, phase, normalizedPath, opts = {}) {
  // docs/, .claude/, config 파일은 항상 허용
  const alwaysAllow = [
    /\/docs\//i, /\/\.claude\//i, /\/config\//i, /\/docker/i,
    /\/tests?\//i, /\/alembic\//i, /CLAUDE\.md$/i, /README\.md$/i,
    /CHANGELOG\.md$/i, /\.gitignore$/i, /package\.json$/i,
    /requirements\.txt$/i, /go\.(mod|sum)$/i, /Cargo\.toml$/i
  ];
  if (alwaysAllow.some(p => p.test(normalizedPath))) {
    return { allowed: true };
  }

  // 소스 파일 여부
  if (!opts.isSourceFile) return { allowed: true }; // 소스가 아니면 허용

  // 소스 파일에 대한 Phase 검증
  const blockedPhases = ['setup', 'analysis', 'prd', 'plan', 'complete'];
  if (blockedPhases.includes(phase)) {
    return {
      allowed: false,
      message: `[HARD GATE] 소스 코드 작성 차단\n현재 phase: ${phase}, track: ${track}\n` +
               `이유: ${phase === 'setup' ? 'CLAUDE.md 프로젝트 설정이 완료되지 않음' : `${phase} 단계 산출물이 먼저 필요`}\n` +
               `해결: 먼저 해당 단계 산출물을 완성하세요.\nPhase 전환: node .claude/hooks/advance-phase.js dev`
    };
  }

  // dev Phase Track별 검증
  if (phase === 'dev') {
    if (track === 'A') {
      return { allowed: false, message: '[HARD GATE] Track A는 코드 수정 불가 (분석/질문 전용)' };
    }
    if (track === 'B' && !opts.hasDevJournal) {
      return {
        allowed: false,
        message: '[HARD GATE] Track B dev — dev-journal 엔트리 필수\n' +
                 '먼저 docs/memory/dev-journal.md에 ### [YYYY-MM-DD] 엔트리를 작성하세요.'
      };
    }
    if (track === 'C') {
      if (!opts.hasPrdApproved) {
        return { allowed: false, message: '[HARD GATE] Track C dev — Approved PRD 필요' };
      }
      if (!opts.hasPlan) {
        return { allowed: false, message: '[HARD GATE] Track C dev — Plan 필요' };
      }
    }
  }

  return { allowed: true };
}

// ── Bash 명령 검증 ──────────────────────────────────────────────────

/**
 * Bash 명령이 현재 Phase에서 안전한지 확인
 * @param {string} command
 * @param {string} phase
 * @param {Array<string>} sourceDirs - ['src/', 'cmd/', 'app/']
 * @returns {{blocked: boolean, reason?: string}}
 */
function isBlockingBashCommand(command, phase, sourceDirs = ['src/']) {
  if (!command) return { blocked: false };

  const blockedPhases = ['setup', 'analysis', 'prd', 'plan', 'complete'];
  if (!blockedPhases.includes(phase)) return { blocked: false };

  // 위험한 시스템 명령
  if (/rm\s+-rf\s+\/|rm\s+-rf\s+\.\s*$|format\s+[a-z]:/i.test(command)) {
    return { blocked: true, reason: '[SAFETY] 위험한 시스템 명령 차단' };
  }

  // 소스 디렉토리 패턴 생성
  const srcPatterns = sourceDirs.map(d => d.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const srcRegex = new RegExp('\\b(' + srcPatterns.join('|') + ')', 'i');

  if (!srcRegex.test(command)) return { blocked: false }; // src 관련 없음

  // sed/awk/perl in-place 편집
  if (/(?:sed|awk|perl)\s+(?:-[a-z]*i[a-z]*\b|--in-place\b)/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] sed/awk/perl in-place 편집 차단 (비dev Phase)' };
  }

  // 리다이렉트로 소스 쓰기
  if (/(?:echo|printf|cat|tee|jq|yq|curl|wget)[^|;&\n]*[>]+/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] 리다이렉트 소스 파일 쓰기 차단' };
  }

  // cp/mv/install
  if (/(?:cp|mv|install)\s+/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] cp/mv/install 소스 복사 차단' };
  }

  // dd 명령
  if (/\bdd\s+.*\bof=/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] dd 명령으로 소스 쓰기 차단' };
  }

  // Python/Node 원라이너
  if (/(?:python|node|ruby|perl)\s+-[ce].*(?:open|write|fs\.write)/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] 스크립트 원라이너로 소스 쓰기 차단' };
  }

  // 컴파일/빌드
  if (/(?:gcc|g\+\+|clang|rustc|cargo\s+build|javac|go\s+build|swiftc|dotnet\s+build)/i.test(command)) {
    return { blocked: true, reason: '[HARD GATE] 컴파일/빌드 차단 (비dev Phase)' };
  }

  // 변수 확장으로 소스 경로 은닉
  if (/\$\{.*\b(?:src|cmd|app)\b|\$\(.*>.*(?:src|cmd|app)/.test(command)) {
    return { blocked: true, reason: '[HARD GATE] 변수 확장으로 소스 경로 은닉 감지' };
  }

  return { blocked: false };
}

// ── Feedback Rules 검증 ─────────────────────────────────────────────

/**
 * 행동 피드백 규칙 매칭
 * @param {Object} rule - feedback-rules.json의 규칙
 * @param {Object} context - { phase, tool, path }
 * @returns {boolean}
 */
function matchesFeedbackTrigger(rule, context) {
  if (!rule.active || !rule.trigger) return false;
  const t = rule.trigger;

  // Phase 매칭
  if (t.phase && t.phase !== '*') {
    const phases = t.phase.split('|');
    if (!phases.includes(context.phase)) return false;
  }

  // Tool 매칭
  if (t.tool && t.tool !== '*') {
    if (t.tool !== context.tool) return false;
  }

  // Target 매칭 (regex)
  if (t.target) {
    try {
      if (!new RegExp(t.target, 'i').test(context.path || '')) return false;
    } catch { return false; }
  }

  return true;
}

module.exports = {
  TRACK_ROUTES,
  ALLOWED_BACKWARDS,
  PHASES,
  canTransitionTo,
  trackAllowsWrite,
  isBlockingBashCommand,
  matchesFeedbackTrigger
};
