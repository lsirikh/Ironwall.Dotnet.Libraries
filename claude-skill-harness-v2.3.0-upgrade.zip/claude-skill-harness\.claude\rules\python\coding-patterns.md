# Python Coding Patterns

> Always-on coding pattern rules for Python codebases.
> Covers type hints, dataclasses, async, error handling, and imports.

---

## Type Hints

### Do
- Always annotate function signatures (parameters and return type)
- Use `X | Y` over `Union[X, Y]` (Python 3.10+)
- Use `X | None` over `Optional[X]`
- Use `from __future__ import annotations` for forward references
- Annotate class attributes and instance variables
- Use `TypeVar`, `Protocol`, `Generic` for reusable abstractions

### Don't
- Omit return type annotations (use `-> None` explicitly)
- Use `Any` as an escape hatch without justification
- Ignore type checker warnings -- fix or explicitly suppress with comment

```python
# Do
def get_user(user_id: int) -> User | None:
    ...

# Don't
def get_user(user_id):  # no annotations
    ...
```

---

## Dataclasses & Data Containers

### Do
- Prefer `@dataclass` over plain classes for data containers
- Use `frozen=True` for immutable value objects
- Use `slots=True` for memory efficiency (Python 3.10+)
- Use `field(default_factory=list)` for mutable defaults
- Consider Pydantic `BaseModel` when validation is needed

### Don't
- Use plain dicts for structured data that has a defined schema
- Use mutable default arguments: ~~`def f(items=[])`~~
- Create dataclasses with business logic -- keep them as data holders

---

## Async

### Do
- Use `asyncio.TaskGroup` over `asyncio.gather` (Python 3.11+)
- Use `asyncio.to_thread` for blocking I/O in async contexts
- Use `async with` for async context managers (DB connections, HTTP sessions)
- Propagate async through the call chain -- don't mix sync wrappers

### Don't
- Call blocking I/O directly in async functions (use `to_thread`)
- Use `asyncio.gather` with `return_exceptions=True` without checking errors
- Create event loops manually when one is already running

---

## Context Managers

### Do
- Use `contextlib.contextmanager` for simple resource management
- Use `contextlib.asynccontextmanager` for async resources
- Use `contextlib.suppress` instead of empty `except` blocks
- Chain context managers with `contextlib.ExitStack` when needed

### Don't
- Forget to close files, connections, or sessions
- Write `try/finally` when a context manager is cleaner

---

## Comprehensions & Iteration

### Do
- Prefer list/dict/set comprehensions over `map`/`filter` for simple cases
- Use generator expressions for large datasets: `sum(x for x in items)`
- Use `enumerate` for index access, `zip` for parallel iteration
- Use `itertools` for complex iteration patterns

### Don't
- Nest more than one level of comprehension (extract to function instead)
- Use comprehension for side effects: ~~`[print(x) for x in items]`~~
- Mutate the iterable during iteration

---

## Imports

### Do
- Use absolute imports: `from mypackage.module import MyClass`
- Group imports in order: stdlib -> third-party -> local (blank line between)
- One import per line (or grouped from same module)
- Sort imports with `isort` or `ruff`

### Don't
- Use wildcard imports: ~~`from module import *`~~
- Use relative imports except within packages: ~~`from . import utils`~~ at top level
- Import inside functions unless avoiding circular imports

---

## Error Handling

### Do
- Catch specific exceptions: `except ValueError as e:`
- Create custom exception hierarchies for domain errors
- Use `logging` module, not `print`, for diagnostics
- Use `raise ... from e` to chain exceptions and preserve context
- Provide actionable error messages

### Don't
- Use bare `except:` -- always specify the exception type
- Catch `Exception` and silently pass
- Use exceptions for normal flow control (use return values, sentinel objects)
- Log and re-raise the same exception (do one or the other)

```python
# Do
except FileNotFoundError as e:
    logger.error("Config file missing: %s", path)
    raise ConfigError(f"Cannot load {path}") from e

# Don't
except:          # bare except
    pass         # silent swallow
```

---

## Quick Reference

| Pattern            | Do                                  | Don't                             |
|--------------------|-------------------------------------|-----------------------------------|
| Type hints         | `X | None`, annotate all signatures | `Any`, omit return types          |
| Data containers    | `@dataclass(frozen=True)`           | Plain dicts for structured data   |
| Async              | `TaskGroup`, `to_thread`            | Blocking I/O in async functions   |
| Comprehensions     | Single-level, readable              | Nested or side-effect-only        |
| Imports            | Absolute, grouped, sorted           | `from x import *`                 |
| Errors             | Specific exceptions + `from e`      | Bare `except:` / silent `pass`    |
| Logging            | `logging` module                    | `print()` for diagnostics         |
