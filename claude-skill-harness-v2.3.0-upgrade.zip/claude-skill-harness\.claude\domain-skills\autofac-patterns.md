---
name: autofac-patterns
description: Autofac DI container patterns — modules, lifetimes, decorators, keyed services, Caliburn.Micro integration
languages: ["C#"]
frameworks: ["Autofac", "WPF"]
phases: ["dev"]
---

# Autofac Patterns

## When to Activate

- Configuring Autofac dependency injection in any .NET application
- Building modular registration with Autofac Modules
- Choosing correct lifetime scopes (Transient, Scoped, Singleton)
- Applying the Decorator pattern via Autofac
- Integrating Autofac with Caliburn.Micro for WPF applications
- Using advanced resolution (Keyed, Owned, Func, Lazy)

---

## Core Patterns

### 1. Module-Based Registration

Modules organize related registrations into cohesive units.

```csharp
public class DataAccessModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<SqlConnectionFactory>()
            .As<IConnectionFactory>()
            .SingleInstance();

        builder.RegisterType<OrderRepository>()
            .As<IOrderRepository>()
            .InstancePerLifetimeScope();

        builder.RegisterType<ProductRepository>()
            .As<IProductRepository>()
            .InstancePerLifetimeScope();

        builder.RegisterType<UnitOfWork>()
            .As<IUnitOfWork>()
            .InstancePerLifetimeScope();
    }
}

public class ServiceModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<OrderService>()
            .As<IOrderService>()
            .InstancePerLifetimeScope();

        builder.RegisterType<NotificationService>()
            .As<INotificationService>()
            .SingleInstance();

        builder.RegisterType<PricingEngine>()
            .As<IPricingEngine>()
            .InstancePerDependency();
    }
}

// Composing modules
var builder = new ContainerBuilder();
builder.RegisterModule<DataAccessModule>();
builder.RegisterModule<ServiceModule>();
builder.RegisterModule(new LoggingModule { Level = LogLevel.Debug });
var container = builder.Build();
```

#### Parameterized Modules

```csharp
public class LoggingModule : Module
{
    public LogLevel Level { get; set; } = LogLevel.Information;

    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterGeneric(typeof(Logger<>))
            .As(typeof(ILogger<>))
            .SingleInstance()
            .WithParameter("minLevel", Level);
    }
}
```

---

### 2. Lifetime Scopes

#### Lifetime Comparison

| Lifetime | Method | Behavior |
|----------|--------|----------|
| Transient | `InstancePerDependency()` | New instance every resolve (default) |
| Scoped | `InstancePerLifetimeScope()` | One per scope (per-request, per-dialog) |
| Singleton | `SingleInstance()` | One for entire container lifetime |
| Matching Scope | `InstancePerMatchingLifetimeScope("name")` | One per named scope |

#### Scoped Lifetime in Practice

```csharp
// Create a child scope for a unit of work
using (var scope = container.BeginLifetimeScope())
{
    var repo = scope.Resolve<IOrderRepository>();   // instance A
    var repo2 = scope.Resolve<IOrderRepository>();  // same instance A
    var uow = scope.Resolve<IUnitOfWork>();
    // All scoped services in this scope share the same lifetime
}
// scope disposed — all InstancePerLifetimeScope services disposed

// Named scopes for WPF dialogs
using (var dialogScope = container.BeginLifetimeScope("dialog"))
{
    var vm = dialogScope.Resolve<EditOrderViewModel>();
    // Scoped services are isolated to this dialog
}
```

#### Avoiding Captive Dependencies

```csharp
// BAD — scoped service captured in singleton
builder.RegisterType<CacheService>()
    .As<ICacheService>()
    .SingleInstance();
builder.RegisterType<OrderRepository>()
    .As<IOrderRepository>()
    .InstancePerLifetimeScope();

public class CacheService : ICacheService
{
    // OrderRepository is scoped, but CacheService is singleton.
    // The repo instance will live as long as the singleton — too long!
    public CacheService(IOrderRepository repo) { }  // Captive dependency!
}

// GOOD — use Func<T> for lazy resolution
public class CacheService : ICacheService
{
    private readonly Func<IOrderRepository> _repoFactory;

    public CacheService(Func<IOrderRepository> repoFactory)
    {
        _repoFactory = repoFactory;
    }

    public void RefreshCache()
    {
        var repo = _repoFactory();  // Resolves from current scope each time
    }
}
```

---

### 3. Constructor vs Property Injection

#### Constructor Injection (Preferred)

```csharp
// Dependencies are explicit and required
public class OrderService
{
    private readonly IOrderRepository _repo;
    private readonly ILogger<OrderService> _logger;

    public OrderService(IOrderRepository repo, ILogger<OrderService> logger)
    {
        _repo = repo ?? throw new ArgumentNullException(nameof(repo));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
}
```

#### Property Injection (Optional Dependencies Only)

```csharp
builder.RegisterType<ReportGenerator>()
    .As<IReportGenerator>()
    .PropertiesAutowired(PropertyWiringOptions.AllowCircularDependencies);

public class ReportGenerator : IReportGenerator
{
    // Optional — gets injected if available, null otherwise
    public ILogger<ReportGenerator> Logger { get; set; }

    public void Generate()
    {
        Logger?.LogInformation("Generating report...");
    }
}
```

> **Rule**: Use constructor injection for required dependencies.
> Use property injection only for truly optional cross-cutting concerns.

---

### 4. Decorator Pattern

Wrap existing service implementations transparently.

```csharp
// Base registration
builder.RegisterType<OrderRepository>()
    .As<IOrderRepository>()
    .InstancePerLifetimeScope();

// Decorator wraps the base implementation
builder.RegisterDecorator<CachingOrderRepository, IOrderRepository>();

// Multiple decorators — applied bottom-to-top (last registered wraps outermost)
builder.RegisterDecorator<LoggingOrderRepository, IOrderRepository>();

// Resolution order: Logging -> Caching -> OrderRepository
```

```csharp
public class CachingOrderRepository : IOrderRepository
{
    private readonly IOrderRepository _inner;
    private readonly IMemoryCache _cache;

    public CachingOrderRepository(IOrderRepository inner, IMemoryCache cache)
    {
        _inner = inner;  // Autofac injects the original implementation
        _cache = cache;
    }

    public async Task<Order> GetByIdAsync(int id, CancellationToken ct)
    {
        var key = $"order:{id}";
        if (_cache.TryGetValue(key, out Order cached))
            return cached;

        var order = await _inner.GetByIdAsync(id, ct);
        _cache.Set(key, order, TimeSpan.FromMinutes(5));
        return order;
    }
}

public class LoggingOrderRepository : IOrderRepository
{
    private readonly IOrderRepository _inner;
    private readonly ILogger _logger;

    public LoggingOrderRepository(IOrderRepository inner, ILogger logger)
    {
        _inner = inner;
        _logger = logger;
    }

    public async Task<Order> GetByIdAsync(int id, CancellationToken ct)
    {
        _logger.LogDebug("Getting order {Id}", id);
        var result = await _inner.GetByIdAsync(id, ct);
        _logger.LogDebug("Got order {Id}: {Status}", id, result?.Status);
        return result;
    }
}
```

#### Conditional Decorators

```csharp
builder.RegisterDecorator<CachingOrderRepository, IOrderRepository>(
    context => context.AppliedDecorators.Count == 0  // Only first decorator
);
```

---

### 5. Keyed and Named Services

#### Registration

```csharp
// Keyed by enum
builder.RegisterType<SqlServerProvider>()
    .Keyed<IDatabaseProvider>(DatabaseType.SqlServer);
builder.RegisterType<PostgresProvider>()
    .Keyed<IDatabaseProvider>(DatabaseType.Postgres);
builder.RegisterType<SqliteProvider>()
    .Keyed<IDatabaseProvider>(DatabaseType.Sqlite);

// Named by string
builder.RegisterType<SmtpEmailSender>()
    .Named<IEmailSender>("smtp");
builder.RegisterType<SendGridEmailSender>()
    .Named<IEmailSender>("sendgrid");
```

#### Resolution with IIndex&lt;TKey, TValue&gt;

```csharp
public class DatabaseMigrator
{
    private readonly IIndex<DatabaseType, IDatabaseProvider> _providers;

    public DatabaseMigrator(IIndex<DatabaseType, IDatabaseProvider> providers)
    {
        _providers = providers;
    }

    public async Task MigrateAsync(DatabaseType targetType)
    {
        if (_providers.TryGetValue(targetType, out var provider))
        {
            await provider.MigrateAsync();
        }
        else
        {
            throw new NotSupportedException($"No provider for {targetType}");
        }
    }
}
```

---

### 6. Owned&lt;T&gt; and Func&lt;T&gt; Lazy Resolution

#### Func&lt;T&gt; — Factory Pattern

```csharp
// Autofac automatically provides Func<T> for any registered service
public class BatchProcessor
{
    private readonly Func<IUnitOfWork> _uowFactory;

    public BatchProcessor(Func<IUnitOfWork> uowFactory)
    {
        _uowFactory = uowFactory;
    }

    public async Task ProcessBatchAsync(IReadOnlyList<Item> items)
    {
        foreach (var chunk in items.Chunk(100))
        {
            using var uow = _uowFactory();  // New instance each iteration
            await uow.ProcessAsync(chunk);
            await uow.CommitAsync();
        }
    }
}
```

#### Owned&lt;T&gt; — Controlled Lifetime

```csharp
// Owned<T> gives you ownership of the component lifetime scope
public class ReportEngine
{
    private readonly Func<Owned<IReportGenerator>> _generatorFactory;

    public ReportEngine(Func<Owned<IReportGenerator>> generatorFactory)
    {
        _generatorFactory = generatorFactory;
    }

    public async Task<byte[]> GenerateAsync(ReportRequest request)
    {
        // Owned<T> creates a new lifetime scope — you control disposal
        using var owned = _generatorFactory();
        var generator = owned.Value;
        return await generator.RenderAsync(request);
        // Disposing Owned<T> disposes the generator AND its scoped dependencies
    }
}
```

#### Lazy&lt;T&gt; — Deferred Resolution

```csharp
public class DashboardViewModel
{
    private readonly Lazy<IExpensiveService> _service;

    public DashboardViewModel(Lazy<IExpensiveService> service)
    {
        _service = service;  // Not resolved yet
    }

    public void LoadWhenNeeded()
    {
        var svc = _service.Value;  // Resolved on first access
    }
}
```

---

### 7. Caliburn.Micro Bootstrapper Integration

```csharp
public class AppBootstrapper : BootstrapperBase
{
    private IContainer _container;

    protected override void Configure()
    {
        var builder = new ContainerBuilder();

        // Core Caliburn.Micro services
        builder.RegisterType<WindowManager>()
            .As<IWindowManager>()
            .SingleInstance();
        builder.RegisterType<EventAggregator>()
            .As<IEventAggregator>()
            .SingleInstance();

        // Application modules
        builder.RegisterModule<DataAccessModule>();
        builder.RegisterModule<ServiceModule>();
        builder.RegisterModule<ViewModelModule>();

        _container = builder.Build();
    }

    protected override object GetInstance(Type service, string key)
    {
        return key == null
            ? _container.Resolve(service)
            : _container.ResolveKeyed(key, service);
    }

    protected override IEnumerable<object> GetAllInstances(Type service)
    {
        return (IEnumerable<object>)_container
            .Resolve(typeof(IEnumerable<>).MakeGenericType(service));
    }

    protected override void BuildUp(object instance)
    {
        _container.InjectProperties(instance);
    }
}
```

---

### 8. ViewModel Auto-Registration

```csharp
public class ViewModelModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        var assembly = typeof(ViewModelModule).Assembly;

        // All ViewModels as themselves (for conductor navigation)
        builder.RegisterAssemblyTypes(assembly)
            .Where(t => t.Name.EndsWith("ViewModel"))
            .AsSelf()
            .InstancePerDependency();

        // Services as their interfaces
        builder.RegisterAssemblyTypes(assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerLifetimeScope();

        // Specific overrides
        builder.RegisterType<ShellViewModel>()
            .AsSelf()
            .SingleInstance();
    }
}
```

---

## Anti-Patterns

### Registration

- Registering everything as `SingleInstance` — prevents proper scope isolation
- Using `container.Resolve<T>()` directly in application code — service locator
- Not disposing `IContainer` on application exit — resource leak
- Registering the same service in multiple modules without `PreserveExistingDefaults()`

### Lifetime

- Scoped dependency injected into singleton — captive dependency, stale data
- Creating `InstancePerDependency` for `DbContext` — should be scoped per unit of work
- Not using `Owned<T>` when you need to control a component disposal

### Decorators

- Applying decorators in wrong order — outermost should be logging/caching
- Forgetting to delegate calls to `_inner` for methods you did not intend to intercept
- Using decorators for completely different behavior — use a different registration instead

### Keyed Services

- Overusing keyed services when polymorphism or strategy pattern is cleaner
- Using magic strings for keys — prefer enums or constants
- Not providing a fallback/default registration alongside keyed ones
