---
name: "Database Patterns"
description: "Schema design, indexing, migration, query optimization, and ORM patterns for PostgreSQL/SQLite with EF Core, SQLAlchemy, and Prisma"
languages: ["Python", "C#", "TypeScript"]
frameworks: ["PostgreSQL", "SQLite", "EF Core", "SQLAlchemy", "Prisma"]
phases: ["dev"]
---

# Database Patterns

## When to Activate

- 데이터베이스 스키마 설계 또는 리뷰
- 인덱스 전략 결정, 쿼리 성능 최적화
- ORM 사용 패턴, N+1 문제 해결
- 마이그레이션 관리, 트랜잭션 처리
- 커넥션 풀링, 데드락 방지

---

## Core Patterns

### 1. Schema Design — Normalization

**1NF (First Normal Form):**
- 각 컬럼은 원자값만 (배열, 쉼표 구분 금지)

```sql
-- 나쁜 예: 1NF 위반
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name TEXT,
    phone_numbers TEXT  -- "010-1234, 010-5678"
);

-- 좋은 예: 1NF 준수
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name TEXT
);
CREATE TABLE user_phones (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    phone TEXT NOT NULL
);
```

**2NF (Second Normal Form):**
- 1NF + 부분 함수 종속 제거 (복합키의 일부에만 종속되는 컬럼 분리)

**3NF (Third Normal Form):**
- 2NF + 이행 함수 종속 제거 (A→B→C에서 C를 별도 테이블로)

```sql
-- 나쁜 예: 3NF 위반 (city→country 이행 종속)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name TEXT,
    city TEXT,
    country TEXT  -- city가 결정하는 값
);

-- 좋은 예: 3NF 준수
CREATE TABLE cities (
    id SERIAL PRIMARY KEY,
    name TEXT,
    country TEXT
);
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name TEXT,
    city_id INTEGER REFERENCES cities(id)
);
```

**비정규화 (Denormalization) 기준:**
- 읽기 성능이 쓰기보다 압도적으로 중요할 때
- JOIN이 5개 이상 필요한 조회가 빈번할 때
- 데이터 불일치 위험을 감수할 수 있을 때 (캐시, 리포트용 뷰)

### 2. Indexing Strategy

**B-tree Index (기본):**
```sql
-- 단일 컬럼 인덱스
CREATE INDEX idx_users_email ON users (email);

-- 복합 인덱스 (순서 중요! 왼쪽부터 매칭)
CREATE INDEX idx_orders_user_status ON orders (user_id, status);
-- WHERE user_id = 1 → 사용됨
-- WHERE user_id = 1 AND status = 'pending' → 사용됨
-- WHERE status = 'pending' → 사용 안 됨 (첫 컬럼 누락)
```

**Partial Index:**
```sql
-- 활성 사용자만 인덱싱 (인덱스 크기 절약)
CREATE INDEX idx_users_active_email ON users (email)
    WHERE is_active = true;
```

**Covering Index:**
```sql
-- 인덱스만으로 쿼리 응답 (테이블 접근 불필요)
CREATE INDEX idx_orders_cover ON orders (user_id, status)
    INCLUDE (total_amount, created_at);

-- 이 쿼리는 인덱스만으로 응답 가능
SELECT status, total_amount, created_at
FROM orders WHERE user_id = 123;
```

**인덱스 판단 기준:**
| 상황 | 인덱스 추가 |
|------|-----------|
| WHERE 절에 자주 등장 | O |
| JOIN 조건 컬럼 | O |
| ORDER BY / GROUP BY 컬럼 | 검토 |
| 카디널리티 낮음 (성별 등) | X |
| 자주 UPDATE되는 컬럼 | 신중히 |
| 작은 테이블 (1000행 이하) | 불필요 |

### 3. Migration Management

**원칙:**
- 마이그레이션은 버전 관리에 포함한다
- 항상 롤백 가능하도록 down 마이그레이션을 작성한다
- 프로덕션에서는 파괴적 변경을 단계적으로 수행한다

```python
# SQLAlchemy + Alembic
# alembic revision --autogenerate -m "add_user_email_index"

def upgrade():
    op.create_index("idx_users_email", "users", ["email"], unique=True)

def downgrade():
    op.drop_index("idx_users_email", "users")
```

```csharp
// EF Core Migration
// dotnet ef migrations add AddUserEmailIndex

public partial class AddUserEmailIndex : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateIndex(
            name: "IX_Users_Email",
            table: "Users",
            column: "Email",
            unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(name: "IX_Users_Email", table: "Users");
    }
}
```

```typescript
// Prisma Migration
// npx prisma migrate dev --name add_user_email_index

// schema.prisma
model User {
  id    Int    @id @default(autoincrement())
  email String @unique
  name  String

  @@index([email])
}
```

**파괴적 변경 안전 절차 (컬럼 삭제 예시):**
```
1. 새 코드 배포: 해당 컬럼 읽기/쓰기 중단
2. 마이그레이션 1: 컬럼 nullable로 변경
3. 일정 기간 모니터링
4. 마이그레이션 2: 컬럼 삭제
```

### 4. Query Optimization

**EXPLAIN ANALYZE:**
```sql
EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 123 AND status = 'pending';

-- 결과 해석
-- Seq Scan → 풀 테이블 스캔 (인덱스 없거나 미사용)
-- Index Scan → 인덱스 사용 (좋음)
-- Bitmap Index Scan → 여러 인덱스 조합
-- Nested Loop → 작은 결과셋 JOIN (좋음)
-- Hash Join → 큰 테이블 JOIN (보통)
-- Sort → ORDER BY 처리 (인덱스 없으면 비용 높음)
```

**N+1 Problem:**
```python
# 나쁜 예 — N+1 쿼리 (users 1회 + 각 user의 orders N회)
users = session.query(User).all()          # 쿼리 1
for user in users:
    print(user.orders)                      # 쿼리 N (lazy loading)

# 좋은 예 — Eager Loading (joinedload)
from sqlalchemy.orm import joinedload
users = session.query(User).options(joinedload(User.orders)).all()  # 쿼리 1-2
```

```csharp
// EF Core — N+1 해결
// 나쁜 예
var users = context.Users.ToList();
foreach (var user in users)
    Console.WriteLine(user.Orders.Count);  // 각 user마다 쿼리

// 좋은 예 — Include (Eager Loading)
var users = context.Users
    .Include(u => u.Orders)
    .ToList();  // JOIN 또는 2번 쿼리

// 좋은 예 — Projection (필요한 데이터만)
var result = context.Users
    .Select(u => new { u.Name, OrderCount = u.Orders.Count })
    .ToList();
```

```typescript
// Prisma — N+1 해결
// 나쁜 예
const users = await prisma.user.findMany();
for (const user of users) {
  const orders = await prisma.order.findMany({ where: { userId: user.id } });
}

// 좋은 예 — include
const users = await prisma.user.findMany({
  include: { orders: true },
});

// 좋은 예 — select (필요한 필드만)
const users = await prisma.user.findMany({
  select: {
    name: true,
    _count: { select: { orders: true } },
  },
});
```

### 5. Connection Pooling

```python
# SQLAlchemy — Connection Pool 설정
from sqlalchemy import create_engine

engine = create_engine(
    "postgresql://user:pass@localhost/mydb",
    pool_size=10,           # 기본 풀 크기
    max_overflow=20,        # 초과 허용 연결 수
    pool_timeout=30,        # 연결 대기 타임아웃(초)
    pool_recycle=3600,      # 연결 재활용 주기(초)
    pool_pre_ping=True,     # 사용 전 연결 유효성 체크
)
```

```csharp
// EF Core / ADO.NET — Connection Pool (기본 활성화)
// connection string에서 설정
"Server=localhost;Database=mydb;User Id=user;Password=pass;"
+ "Min Pool Size=5;Max Pool Size=100;Connection Lifetime=300;"
```

```typescript
// Prisma — Connection Pool
// DATABASE_URL="postgresql://user:pass@localhost/mydb?connection_limit=10&pool_timeout=30"
```

### 6. Transactions & Isolation Levels

```python
# SQLAlchemy — 트랜잭션
from sqlalchemy.orm import Session

with Session(engine) as session:
    try:
        order = Order(user_id=1, total=100)
        session.add(order)
        payment = Payment(order_id=order.id, amount=100)
        session.add(payment)
        session.commit()
    except Exception:
        session.rollback()
        raise
```

```csharp
// EF Core — 트랜잭션
using var transaction = await context.Database.BeginTransactionAsync();
try
{
    context.Orders.Add(new Order { UserId = 1, Total = 100 });
    await context.SaveChangesAsync();

    context.Payments.Add(new Payment { OrderId = order.Id, Amount = 100 });
    await context.SaveChangesAsync();

    await transaction.CommitAsync();
}
catch
{
    await transaction.RollbackAsync();
    throw;
}
```

**Isolation Levels:**
| Level | Dirty Read | Non-repeatable Read | Phantom Read | 성능 |
|-------|-----------|-------------------|-------------|------|
| Read Uncommitted | O | O | O | 최고 |
| Read Committed (기본) | X | O | O | 좋음 |
| Repeatable Read | X | X | O | 보통 |
| Serializable | X | X | X | 최저 |

```sql
-- PostgreSQL — Isolation Level 설정
BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;
UPDATE accounts SET balance = balance - 100 WHERE id = 1;
UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT;
```

**Deadlock Prevention:**
- 테이블/행 접근 순서를 통일한다 (항상 A→B 순서)
- 트랜잭션을 최소 범위로 유지한다
- 타임아웃을 설정한다 (`SET lock_timeout = '5s'`)

### 7. ORM Patterns by Language

**SQLAlchemy (Python):**
```python
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import DeclarativeBase, relationship
from datetime import datetime

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    orders = relationship("Order", back_populates="user", lazy="selectin")

class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    status = Column(String(20), default="pending", index=True)
    total = Column(Integer, nullable=False)

    user = relationship("User", back_populates="orders")
```

**EF Core (C#):**
```csharp
public class User
{
    public int Id { get; set; }
    public string Email { get; set; } = null!;
    public string Name { get; set; } = null!;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public List<Order> Orders { get; set; } = new();
}

public class Order
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Status { get; set; } = "pending";
    public decimal Total { get; set; }
    public User User { get; set; } = null!;
}

public class AppDbContext : DbContext
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Order> Orders => Set<Order>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(e =>
        {
            e.HasIndex(u => u.Email).IsUnique();
            e.HasMany(u => u.Orders).WithOne(o => o.User).HasForeignKey(o => o.UserId);
        });

        modelBuilder.Entity<Order>(e =>
        {
            e.HasIndex(o => o.UserId);
            e.HasIndex(o => o.Status);
        });
    }
}
```

**Prisma (TypeScript):**
```prisma
// schema.prisma
model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  name      String
  createdAt DateTime @default(now()) @map("created_at")
  orders    Order[]

  @@map("users")
}

model Order {
  id     Int    @id @default(autoincrement())
  userId Int    @map("user_id")
  status String @default("pending")
  total  Int

  user User @relation(fields: [userId], references: [id])

  @@index([userId])
  @@index([status])
  @@map("orders")
}
```

---

## Anti-Patterns

### 1. No Indexes on Foreign Keys
- JOIN, WHERE 절에 사용되는 FK에 인덱스가 없으면 풀 스캔
- **해결:** FK 컬럼에는 반드시 인덱스 생성

### 2. SELECT *
- 불필요한 컬럼까지 가져와 메모리 낭비, 네트워크 부하
- **해결:** 필요한 컬럼만 SELECT, ORM에서는 Projection 사용

### 3. N+1 Queries
- 리스트 조회 후 각 항목의 연관 데이터를 개별 쿼리로 조회
- **해결:** Eager Loading (Include, joinedload, include)

### 4. No Migration Rollback Plan
- down 마이그레이션 없이 배포하면 롤백 불가
- **해결:** 모든 마이그레이션에 up/down 양방향 작성

### 5. Long-Running Transactions
- 트랜잭션 안에서 외부 API 호출, 파일 I/O 등 긴 작업 수행
- **해결:** 트랜잭션은 DB 작업만, 최소 범위로 유지

### 6. Over-Indexing
- 모든 컬럼에 인덱스를 걸면 INSERT/UPDATE 성능 저하, 저장 공간 낭비
- **해결:** 실제 쿼리 패턴 분석 후 필요한 인덱스만 생성

### 7. Storing Sensitive Data in Plain Text
- 비밀번호, 개인정보를 평문 저장
- **해결:** 비밀번호는 bcrypt/argon2로 해싱, 개인정보는 암호화
