---
name: fastapi-patterns
description: FastAPI + Pydantic 패턴 — 라우터, DI, 비동기 엔드포인트, 미들웨어
languages: ["Python"]
frameworks: ["FastAPI", "Pydantic"]
phases: ["dev", "test"]
---

# FastAPI Patterns

## When to Activate

- FastAPI 프로젝트에서 API 엔드포인트 작성 시
- Pydantic 모델 설계 시

## Core Patterns

### Router Organization

```python
from fastapi import APIRouter

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/{user_id}")
async def get_user(user_id: int) -> UserResponse:
    ...

# main.py
app.include_router(router)
```

### Pydantic v2 Models

```python
from pydantic import BaseModel, ConfigDict, field_validator

class UserCreate(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    name: str
    email: str

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        if "@" not in v:
            raise ValueError("Invalid email")
        return v.lower()
```

### Dependency Injection

```python
from fastapi import Depends

async def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/users")
async def list_users(db: Session = Depends(get_db)):
    return db.query(User).all()
```

### Error Handling

```python
from fastapi import HTTPException
from fastapi.responses import JSONResponse

@app.exception_handler(ValueError)
async def value_error_handler(request, exc):
    return JSONResponse(status_code=422, content={"detail": str(exc)})

# In endpoints
raise HTTPException(status_code=404, detail="User not found")
```

### Lifespan Events

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    pool = await create_pool()
    app.state.pool = pool
    yield
    # shutdown
    await pool.close()

app = FastAPI(lifespan=lifespan)
```

### Background Tasks

```python
from fastapi import BackgroundTasks

@router.post("/notify")
async def send_notification(bg: BackgroundTasks):
    bg.add_task(send_email, "user@example.com", "Hello")
    return {"status": "queued"}
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| Sync def for I/O endpoints | `async def` | Blocks event loop |
| Global DB session | `Depends(get_db)` | Not request-scoped |
| `dict` response | Pydantic `response_model` | No validation |
| Catching `Exception` in endpoint | Specific exceptions + handler | Hides bugs |
| Business logic in endpoint | Service layer | Untestable |
| Hardcoded CORS origins | Config/env variable | Security risk |
