// .claude/hooks/_state.js
// 원자적 상태 관리 — FR-06
//
// pipeline-state.json에 대한 안전한 CRUD:
//   - wx 플래그 기반 advisory file locking
//   - 스키마 검증
//   - 자동 백업 (최근 10개)
//   - 손상 복구 (백업에서 복원)

const fs = require('fs');
const path = require('path');

const { execSync } = require('child_process');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

// FR-20: 브랜치 기반 세션 격리 — git 브랜치별 pipeline-state 분리
function detectGitBranch() {
  try {
    const branch = execSync('git rev-parse --abbrev-ref HEAD', {
      cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 3000, stdio: ['pipe', 'pipe', 'pipe']
    }).trim();
    // main/master는 기본 경로 사용
    if (branch === 'main' || branch === 'master' || branch === 'HEAD') return null;
    return branch.replace(/[^a-zA-Z0-9_-]/g, '-');
  } catch { return null; } // git 미설치 또는 git repo 아님
}

const GIT_BRANCH = detectGitBranch();
const BRANCH_STATE_DIR = GIT_BRANCH
  ? path.join(PROJECT_ROOT, '.claude', '.branch-' + GIT_BRANCH)
  : null;

// 브랜치별 state 파일 경로 (없으면 기본 경로)
const STATE_FILE = BRANCH_STATE_DIR
  ? path.join(BRANCH_STATE_DIR, 'pipeline-state.json')
  : path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');
const LOCK_FILE = STATE_FILE + '.lock';
const BACKUP_DIR = path.join(PROJECT_ROOT, 'docs', 'memory', 'state-backups');

// 브랜치 state 디렉토리 보장
if (BRANCH_STATE_DIR && !fs.existsSync(BRANCH_STATE_DIR)) {
  try { fs.mkdirSync(BRANCH_STATE_DIR, { recursive: true }); } catch {}
}

// 브랜치 state 파일이 없으면 기본 state에서 복사
if (BRANCH_STATE_DIR && !fs.existsSync(STATE_FILE)) {
  const defaultState = path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');
  try {
    if (fs.existsSync(defaultState)) fs.copyFileSync(defaultState, STATE_FILE);
  } catch {}
}

const VALID_PHASES = ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete'];
const VALID_TRACKS = ['A', 'B', 'C', null];

const DEFAULT_STATE = {
  phase: 'setup',
  track: null,
  activePrd: null,
  activePlan: null,
  artifacts: {},
  updated_at: new Date().toISOString(),
  iterations: { total_backwards: 0 },
  lastFailure: null,
  autoFixCount: 0,
  lastLintResult: null
};

// ── 스키마 검증 ─────────────────────────────────────────────────────

function validateState(state) {
  const errors = [];
  if (!state || typeof state !== 'object') {
    return { valid: false, errors: ['state is not an object'] };
  }
  if (!VALID_PHASES.includes(state.phase)) {
    errors.push(`invalid phase: "${state.phase}"`);
  }
  if (!VALID_TRACKS.includes(state.track)) {
    errors.push(`invalid track: "${state.track}"`);
  }
  if (state.autoFixCount !== undefined && (typeof state.autoFixCount !== 'number' || state.autoFixCount < 0)) {
    errors.push(`invalid autoFixCount: ${state.autoFixCount}`);
  }
  return { valid: errors.length === 0, errors };
}

// ── 파일 잠금 ───────────────────────────────────────────────────────

function acquireLock(timeoutMs = 5000) {
  const start = Date.now();
  while (true) {
    try {
      // wx = write + exclusive — 파일이 이미 존재하면 실패
      fs.writeFileSync(LOCK_FILE, JSON.stringify({
        pid: process.pid,
        time: Date.now()
      }), { flag: 'wx' });
      return true;
    } catch (e) {
      // 잠금 파일이 이미 존재
      if (Date.now() - start > timeoutMs) {
        // 타임아웃: 오래된 잠금이면 강제 해제
        try {
          const lockData = JSON.parse(fs.readFileSync(LOCK_FILE, 'utf8'));
          if (Date.now() - lockData.time > 10000) {
            // 10초 이상 된 잠금 → 고아 잠금으로 판단, 강제 해제
            fs.unlinkSync(LOCK_FILE);
            continue;
          }
        } catch { /* 잠금 파일 읽기 실패 → 삭제 시도 */
          try { fs.unlinkSync(LOCK_FILE); continue; } catch {}
        }
        return false; // 진짜 타임아웃
      }
      // 짧은 대기 후 재시도 (busy-wait, 10ms 간격)
      const waitUntil = Date.now() + 10;
      while (Date.now() < waitUntil) { /* spin */ }
    }
  }
}

function releaseLock() {
  try { fs.unlinkSync(LOCK_FILE); } catch { /* silent */ }
}

// ── 백업 ────────────────────────────────────────────────────────────

function createBackup(state, reason) {
  try {
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const safeReason = (reason || 'auto').replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
    const backupFile = path.join(BACKUP_DIR, `${timestamp}_${safeReason}.json`);
    fs.writeFileSync(backupFile, JSON.stringify(state, null, 2) + '\n');
    purgeOldBackups();
    return backupFile;
  } catch { return null; }
}

function purgeOldBackups(keepCount = 10) {
  try {
    if (!fs.existsSync(BACKUP_DIR)) return;
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith('.json'))
      .sort()
      .reverse();
    for (let i = keepCount; i < files.length; i++) {
      try { fs.unlinkSync(path.join(BACKUP_DIR, files[i])); } catch {}
    }
  } catch { /* silent */ }
}

// ── 핵심 API ────────────────────────────────────────────────────────

/**
 * 상태 로드 — 안전한 폴백
 * 파일 미존재/손상 시 DEFAULT_STATE 반환
 */
function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return { ...DEFAULT_STATE };
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    const { valid } = validateState(parsed);
    if (!valid) {
      // 스키마 위반 → 복구 시도
      const recovered = recoverFromBackup();
      if (recovered) return recovered;
      return { ...DEFAULT_STATE };
    }
    // 필수 필드 보장
    if (!parsed.phase) parsed.phase = 'setup';
    if (!VALID_TRACKS.includes(parsed.track)) parsed.track = 'C';
    if (!parsed.iterations) parsed.iterations = { total_backwards: 0 };
    if (parsed.autoFixCount === undefined) parsed.autoFixCount = 0;
    return parsed;
  } catch {
    // JSON 파싱 실패 → 손상
    const recovered = recoverFromBackup();
    if (recovered) return recovered;
    return { ...DEFAULT_STATE };
  }
}

/**
 * 상태 저장 — 검증 + 백업 + 원자적 쓰기
 */
function saveState(state, backupReason) {
  const { valid, errors } = validateState(state);
  if (!valid) {
    throw new Error('State validation failed: ' + errors.join(', '));
  }
  state.updated_at = new Date().toISOString();

  // 기존 상태 백업
  if (backupReason && fs.existsSync(STATE_FILE)) {
    try {
      const current = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      createBackup(current, backupReason);
    } catch { /* 백업 실패해도 저장은 진행 */ }
  }

  // 원자적 쓰기: temp → rename
  const tempFile = STATE_FILE + '.tmp.' + process.pid;
  try {
    fs.writeFileSync(tempFile, JSON.stringify(state, null, 2) + '\n');
    fs.renameSync(tempFile, STATE_FILE);
    return true;
  } catch (err) {
    try { fs.unlinkSync(tempFile); } catch {}
    throw err;
  }
}

/**
 * 원자적 상태 업데이트 — 잠금 + 읽기 + 수정 + 저장
 * @param {Function} updateFn - (state) => modifiedState
 * @param {string} [backupReason] - 백업 태그
 * @returns {Object} 업데이트된 상태
 */
function atomicStateUpdate(updateFn, backupReason) {
  const locked = acquireLock(5000);
  // 잠금 실패 시 graceful degradation — 잠금 없이 진행
  try {
    const state = loadState();
    const newState = updateFn(state);
    saveState(newState, backupReason);
    return newState;
  } finally {
    if (locked) releaseLock();
  }
}

/**
 * 백업에서 복구
 */
function recoverFromBackup() {
  try {
    if (!fs.existsSync(BACKUP_DIR)) return null;
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith('.json'))
      .sort()
      .reverse();
    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(BACKUP_DIR, file), 'utf8');
        const state = JSON.parse(content);
        const { valid } = validateState(state);
        if (valid) return state;
      } catch { continue; }
    }
    return null;
  } catch { return null; }
}

/**
 * 백업 목록 조회
 */
function listBackups() {
  try {
    if (!fs.existsSync(BACKUP_DIR)) return [];
    return fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith('.json'))
      .sort()
      .reverse()
      .map(f => ({
        file: f,
        path: path.join(BACKUP_DIR, f),
        timestamp: f.substring(0, 19).replace(/-/g, (m, i) => i < 10 ? '-' : i === 10 ? 'T' : ':')
      }));
  } catch { return []; }
}

module.exports = {
  STATE_FILE,
  LOCK_FILE,
  BACKUP_DIR,
  VALID_PHASES,
  VALID_TRACKS,
  DEFAULT_STATE,
  validateState,
  acquireLock,
  releaseLock,
  loadState,
  saveState,
  atomicStateUpdate,
  createBackup,
  purgeOldBackups,
  recoverFromBackup,
  listBackups
};
