// .claude/hooks/_config.js
// 설정 계층 관리 — FR-07
//
// 우선순위: CLAUDE.md yaml → 환경변수 (CLAUDE_*) → 기본값
// 모든 매직넘버를 이 모듈에서 관리

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const CLAUDE_MD_PATH = path.join(PROJECT_ROOT, 'CLAUDE.md');

// ── 기본값 정의 ─────────────────────────────────────────────────────

const CONFIG_DEFAULTS = {
  project: {
    name: '',
    language: '',
    framework: '',
    version: '0.1.0'
  },
  commands: {
    test_command: '',
    lint_command: ''
  },
  source_dirs: ['src/'],
  thresholds: {
    max_auto_fix: 3,
    test_timeout_ms: 60000,
    lint_timeout_ms: 10000,
    iteration_warn: 5,
    prd_review_expiry_hours: 72,
    dev_journal_archive_lines: 200,
    audit_log_gc_lines: 1000,
    hook_perf_warn_ms: 100
  },
  directories: {
    agents_dir: '.claude/agents',
    domain_skills_dir: '.claude/domain-skills',
    rules_dir: '.claude/rules'
  },
  features: {
    auto_prd_marker: true,
    auto_lint: true,
    auto_index_rebuild: true,
    audit_log: true,
    agent_recommendations: true,
    domain_skill_injection: true,
    observations: true
  }
};

// ── CLAUDE.md 파싱 ──────────────────────────────────────────────────

function readClaudeMdConfig() {
  try {
    if (!fs.existsSync(CLAUDE_MD_PATH)) return {};
    const content = fs.readFileSync(CLAUDE_MD_PATH, 'utf8');

    // yaml 블록 추출 (```yaml ... ```)
    const yamlMatch = content.match(/```yaml\n([\s\S]*?)```/);
    if (!yamlMatch) return {};
    const yaml = yamlMatch[1];

    const result = { project: {}, commands: {}, thresholds: {} };

    // 문자열 필드
    const strFields = {
      'project_name': 'project.name',
      'language': 'project.language',
      'framework': 'project.framework',
      'version': 'project.version',
      'test_command': 'commands.test_command',
      'lint_command': 'commands.lint_command'
    };

    for (const [field, target] of Object.entries(strFields)) {
      const m = yaml.match(new RegExp(field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*"([^"]*)"'));
      if (m && m[1]) {
        const [ns, key] = target.split('.');
        if (!result[ns]) result[ns] = {};
        result[ns][key] = m[1];
      }
    }

    // 숫자 필드
    const numFields = {
      'max_auto_fix': 'thresholds.max_auto_fix',
      'test_timeout_ms': 'thresholds.test_timeout_ms',
      'lint_timeout_ms': 'thresholds.lint_timeout_ms'
    };

    for (const [field, target] of Object.entries(numFields)) {
      const m = yaml.match(new RegExp(field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*(\\d+)'));
      if (m) {
        const [ns, key] = target.split('.');
        if (!result[ns]) result[ns] = {};
        result[ns][key] = parseInt(m[1], 10);
      }
    }

    // source_dirs (배열 필드)
    const sdMatch = yaml.match(/source_dirs:\s*\n((?:\s+-\s+"[^"]+"\n?)+)/);
    if (sdMatch) {
      const dirs = [];
      const lineRe = /^\s+-\s+"([^"]+)"/gm;
      let lm;
      while ((lm = lineRe.exec(sdMatch[1])) !== null) {
        dirs.push(lm[1]);
      }
      if (dirs.length > 0) result.source_dirs = dirs;
    }

    return result;
  } catch { return {}; }
}

// ── 환경변수 오버레이 ───────────────────────────────────────────────

function readEnvConfig() {
  const result = { thresholds: {} };
  const envMap = {
    'CLAUDE_MAX_AUTO_FIX': 'thresholds.max_auto_fix',
    'CLAUDE_TEST_TIMEOUT': 'thresholds.test_timeout_ms',
    'CLAUDE_LINT_TIMEOUT': 'thresholds.lint_timeout_ms',
    'CLAUDE_ITERATION_WARN': 'thresholds.iteration_warn',
    'CLAUDE_PRD_EXPIRY_HOURS': 'thresholds.prd_review_expiry_hours',
    'CLAUDE_JOURNAL_ARCHIVE': 'thresholds.dev_journal_archive_lines',
    'CLAUDE_AUDIT_GC': 'thresholds.audit_log_gc_lines'
  };

  for (const [env, target] of Object.entries(envMap)) {
    if (process.env[env]) {
      const val = parseInt(process.env[env], 10);
      if (!isNaN(val)) {
        const [ns, key] = target.split('.');
        if (!result[ns]) result[ns] = {};
        result[ns][key] = val;
      }
    }
  }

  // source_dirs 환경변수 (쉼표 구분)
  if (process.env.CLAUDE_SOURCE_DIRS) {
    result.source_dirs = process.env.CLAUDE_SOURCE_DIRS.split(',').map(s => s.trim());
  }

  return result;
}

// ── Deep Merge ──────────────────────────────────────────────────────

function deepMerge(target, source) {
  const result = { ...target };
  for (const key of Object.keys(source)) {
    if (source[key] === undefined || source[key] === null) continue;
    if (typeof source[key] === 'object' && !Array.isArray(source[key]) &&
        typeof target[key] === 'object' && !Array.isArray(target[key])) {
      result[key] = deepMerge(target[key], source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}

// ── 메인 API ────────────────────────────────────────────────────────

let _configCache = null;
let _configCacheTime = 0;
const CONFIG_CACHE_TTL = 60000; // 60초

/**
 * 설정 로드 (계층 병합 + 캐시)
 * 우선순위: 기본값 < CLAUDE.md < 환경변수
 */
function loadConfig(fresh = false) {
  const now = Date.now();
  if (!fresh && _configCache && (now - _configCacheTime) < CONFIG_CACHE_TTL) {
    return _configCache;
  }

  let config = { ...CONFIG_DEFAULTS };
  const claudeConfig = readClaudeMdConfig();
  config = deepMerge(config, claudeConfig);
  const envConfig = readEnvConfig();
  config = deepMerge(config, envConfig);

  _configCache = config;
  _configCacheTime = now;
  return config;
}

/**
 * 설정값 안전 조회
 * @param {string} dotPath - 'thresholds.max_auto_fix'
 * @param {*} defaultValue - 폴백 값
 */
function getConfigValue(dotPath, defaultValue) {
  const config = loadConfig();
  const parts = dotPath.split('.');
  let current = config;
  for (const part of parts) {
    if (current === null || current === undefined || typeof current !== 'object') {
      return defaultValue;
    }
    current = current[part];
  }
  return current !== undefined && current !== null ? current : defaultValue;
}

/**
 * source_dirs 목록 반환 (기본값: ['src/'])
 */
function getSourceDirs() {
  return getConfigValue('source_dirs', ['src/']);
}

/**
 * 파일 경로가 소스 디렉토리에 해당하는지 확인
 * @param {string} normalizedPath - POSIX 정규화된 경로
 */
function isSourcePath(normalizedPath) {
  const dirs = getSourceDirs();
  const lowerPath = normalizedPath.toLowerCase();
  return dirs.some(dir => {
    const normalDir = '/' + dir.replace(/\\/g, '/').replace(/^\//, '');
    return lowerPath.includes(normalDir);
  });
}

/**
 * 파일 확장자가 소스 코드인지 확인
 */
function isSourceExtension(filePath) {
  return /\.(py|js|ts|jsx|tsx|cs|cpp|java|go|rs|rb|php|kt|swift|scala|zig)$/i.test(filePath);
}

module.exports = {
  CONFIG_DEFAULTS,
  loadConfig,
  getConfigValue,
  getSourceDirs,
  isSourcePath,
  isSourceExtension,
  readClaudeMdConfig,
  readEnvConfig,
  deepMerge
};
