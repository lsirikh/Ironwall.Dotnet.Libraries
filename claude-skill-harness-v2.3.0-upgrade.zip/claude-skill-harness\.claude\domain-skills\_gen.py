#!/usr/bin/env python3
"""Generate domain skill files."""
import os

BASE = "C:/workspace_python/skill-set/.claude/domain-skills"

# =============================================================================
# 1. python-patterns.md
# =============================================================================
PYTHON_PATTERNS = r'''---
name: "Python Modern Patterns"
description: "Python 3.11+ 모던 패턴 가이드 — 타입 힌트, dataclass, async, 패턴 매칭, 실전 관용구"
languages: ["Python"]
frameworks: ["Python 3.11+"]
phases: ["dev", "test"]
---

# Python Modern Patterns

## When to Activate

- Python 3.11+ 코드를 작성하거나 리뷰할 때
- 타입 힌트, dataclass, async/await 패턴이 필요할 때
- 레거시 Python 코드를 모던 스타일로 리팩토링할 때
- `os.path` → `pathlib`, `format()` → f-string 전환 시

---

## Core Patterns

### 1. Type Hints — Modern Syntax (3.10+)

```python
# OLD — 사용하지 않는다
from typing import Union, Optional, List, Dict, Tuple

def old_style(x: Optional[int], items: List[str]) -> Union[str, None]:
    ...

# NEW — 내장 타입 + | 연산자
def new_style(x: int | None, items: list[str]) -> str | None:
    ...

# 컬렉션 타입도 내장 사용
def process(
    mapping: dict[str, list[int]],
    coords: tuple[float, float],
    unique: set[str],
) -> None:
    ...
```

#### TypeVar & Protocol

```python
from typing import TypeVar, Protocol

# TypeVar — 제네릭 함수
T = TypeVar("T")

def first(items: list[T]) -> T | None:
    return items[0] if items else None

# Protocol — 구조적 서브타이핑 (덕 타이핑의 정적 버전)
class Renderable(Protocol):
    def render(self) -> str: ...

def display(obj: Renderable) -> None:
    print(obj.render())

# 어떤 클래스든 render() 메서드만 있으면 Renderable로 인정
class Button:
    def render(self) -> str:
        return "<button>Click</button>"

display(Button())  # OK — Protocol 만족
```

#### TypeAlias & NewType

```python
from typing import NewType, TypeAlias

# TypeAlias — 복잡한 타입에 이름 부여
JSON: TypeAlias = dict[str, "JSON"] | list["JSON"] | str | int | float | bool | None

# NewType — 타입 수준에서 구분 (런타임 비용 없음)
UserId = NewType("UserId", int)
OrderId = NewType("OrderId", int)

def get_user(user_id: UserId) -> dict:
    ...

uid = UserId(42)
oid = OrderId(42)
get_user(uid)  # OK
get_user(oid)  # mypy 에러 — OrderId ≠ UserId
```

---

### 2. Dataclasses

```python
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class User:
    name: str
    email: str
    age: int
    tags: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self) -> None:
        """생성 직후 검증/변환 로직"""
        if self.age < 0:
            raise ValueError(f"age must be non-negative, got {self.age}")
        self.email = self.email.lower().strip()

# Frozen (불변) dataclass
@dataclass(frozen=True)
class Point:
    x: float
    y: float

    def distance_to(self, other: "Point") -> float:
        return ((self.x - other.x) ** 2 + (self.y - other.y) ** 2) ** 0.5

p = Point(1.0, 2.0)
# p.x = 3.0  # FrozenInstanceError

# slots=True (3.10+) — 메모리 절약 + 속성 접근 속도 향상
@dataclass(slots=True)
class Sensor:
    id: str
    value: float
    unit: str = "celsius"
```

#### dataclass vs NamedTuple vs dict

```python
# dict — 스키마 없음, 빠른 프로토타이핑만
# NamedTuple — 불변, 언패킹 필요 시
# dataclass — 가변/불변 선택 가능, 메서드 추가 가능 → 기본 선택
```

---

### 3. Async/Await

```python
import asyncio
from asyncio import TaskGroup

# 기본 패턴 — asyncio.gather
async def fetch_all(urls: list[str]) -> list[str]:
    async with asyncio.TaskGroup() as tg:
        tasks = [tg.create_task(fetch(url)) for url in urls]
    return [t.result() for t in tasks]

# TaskGroup (3.11+) — gather보다 안전한 예외 처리
async def process_batch(items: list[dict]) -> None:
    async with TaskGroup() as tg:
        for item in items:
            tg.create_task(process_item(item))
    # 하나라도 실패하면 ExceptionGroup 발생 → 나머지 자동 취소

# 블로킹 I/O를 비동기로 래핑
import httpx

async def fetch(url: str) -> str:
    async with httpx.AsyncClient() as client:
        resp = await client.get(url)
        return resp.text

# CPU-bound 작업을 스레드로 위임
def heavy_compute(data: bytes) -> bytes:
    # CPU 작업
    return data

async def handle_request(data: bytes) -> bytes:
    result = await asyncio.to_thread(heavy_compute, data)
    return result
```

#### Async Iteration

```python
async def read_lines(path: str):
    """비동기 제너레이터"""
    import aiofiles
    async with aiofiles.open(path) as f:
        async for line in f:
            yield line.strip()

async def main():
    async for line in read_lines("data.txt"):
        print(line)
```

---

### 4. Context Managers

```python
from contextlib import contextmanager, asynccontextmanager
import time

# 동기 컨텍스트 매니저
@contextmanager
def timer(label: str):
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"{label}: {elapsed:.3f}s")

with timer("DB query"):
    results = db.execute(query)

# 비동기 컨텍스트 매니저
@asynccontextmanager
async def db_transaction(conn):
    tx = await conn.begin()
    try:
        yield tx
        await tx.commit()
    except Exception:
        await tx.rollback()
        raise

async def save_user(conn, user):
    async with db_transaction(conn) as tx:
        await tx.execute("INSERT INTO users ...")
```

---

### 5. Structural Pattern Matching (3.10+)

```python
# 기본 match/case
def handle_command(command: dict) -> str:
    match command:
        case {"action": "create", "name": str(name)}:
            return f"Creating {name}"
        case {"action": "delete", "id": int(item_id)}:
            return f"Deleting #{item_id}"
        case {"action": str(action)}:
            return f"Unknown action: {action}"
        case _:
            return "Invalid command"

# 클래스 패턴
@dataclass
class Response:
    status: int
    body: str

def handle_response(resp: Response) -> None:
    match resp:
        case Response(status=200, body=body):
            print(f"OK: {body}")
        case Response(status=404):
            print("Not found")
        case Response(status=s) if s >= 500:
            print(f"Server error: {s}")

# 시퀀스 패턴
def process_args(args: list[str]) -> None:
    match args:
        case []:
            print("No arguments")
        case [single]:
            print(f"One arg: {single}")
        case [first, *rest]:
            print(f"First: {first}, rest: {rest}")
```

---

### 6. Walrus Operator (:=)

```python
# 패턴 1: while 루프에서 할당 + 조건
while chunk := file.read(8192):
    process(chunk)

# 패턴 2: 리스트 컴프리헨션에서 중복 계산 방지
results = [
    cleaned
    for raw in data
    if (cleaned := raw.strip()) and len(cleaned) > 5
]

# 패턴 3: 정규식 매칭
import re
if m := re.match(r"(\d+)-(\d+)", text):
    start, end = m.groups()
```

---

### 7. Pathlib over os.path

```python
from pathlib import Path

# os.path → pathlib 대응
base = Path("/app/data")
config = base / "config" / "settings.json"  # 경로 결합

# 파일 읽기/쓰기
content = config.read_text(encoding="utf-8")
config.write_text('{"key": "value"}', encoding="utf-8")

# 디렉토리 탐색
for py_file in base.rglob("*.py"):
    print(py_file.stem)  # 확장자 없는 이름

# 존재 확인 + 생성
output = base / "output"
output.mkdir(parents=True, exist_ok=True)

# 확장자 변경
source = Path("report.md")
html = source.with_suffix(".html")
```

---

### 8. enumerate & zip Best Practices

```python
# enumerate — 인덱스 + 값
for i, item in enumerate(items):
    print(f"{i}: {item}")

# enumerate — start 파라미터
for line_no, line in enumerate(lines, start=1):
    print(f"Line {line_no}: {line}")

# zip — 여러 이터러블 병렬 순회
for name, score in zip(names, scores):
    print(f"{name}: {score}")

# zip strict=True (3.10+) — 길이 불일치 시 에러
for name, score in zip(names, scores, strict=True):
    ...  # 길이 다르면 ValueError

# 딕셔너리 생성
mapping = dict(zip(keys, values))
```

---

## Anti-Patterns

### 1. 타입 힌트

```python
# BAD — 구버전 임포트 (3.10+ 프로젝트에서)
from typing import Optional, List, Union

# GOOD — 내장 타입 + | 연산자
x: int | None = None
items: list[str] = []
```

### 2. Mutable Default Arguments

```python
# BAD — 뮤터블 기본값
def append_to(item, target=[]):  # 모든 호출이 같은 리스트 공유
    target.append(item)
    return target

# GOOD — None 센티널
def append_to(item, target: list | None = None) -> list:
    if target is None:
        target = []
    target.append(item)
    return target
```

### 3. bare except

```python
# BAD
try:
    do_something()
except:  # KeyboardInterrupt, SystemExit도 잡음
    pass

# GOOD
try:
    do_something()
except Exception as e:
    logger.error("Failed: %s", e)
    raise
```

### 4. String Concatenation in Loops

```python
# BAD — O(n^2)
result = ""
for item in items:
    result += str(item) + ", "

# GOOD — join
result = ", ".join(str(item) for item in items)
```

### 5. os.path in New Code

```python
# BAD
import os
path = os.path.join(base_dir, "config", "app.yaml")
if os.path.exists(path):
    with open(path) as f:
        content = f.read()

# GOOD
from pathlib import Path
path = Path(base_dir) / "config" / "app.yaml"
if path.exists():
    content = path.read_text()
```

### 6. Async Anti-Patterns

```python
# BAD — 순차 실행 (async의 의미 없음)
for url in urls:
    result = await fetch(url)

# GOOD — 병렬 실행
async with TaskGroup() as tg:
    tasks = [tg.create_task(fetch(url)) for url in urls]

# BAD — asyncio.run() 중첩
async def handler():
    asyncio.run(other_coroutine())  # RuntimeError

# GOOD
async def handler():
    await other_coroutine()
```
'''

# =============================================================================
# 2. fastapi-patterns.md
# =============================================================================
FASTAPI_PATTERNS = r'''---
name: "FastAPI Patterns"
description: "FastAPI + Pydantic v2 실전 패턴 — 라우터 구조, DI, 미들웨어, 에러 처리, 비동기 엔드포인트"
languages: ["Python"]
frameworks: ["FastAPI", "Pydantic"]
phases: ["dev", "test"]
---

# FastAPI Patterns

## When to Activate

- FastAPI 앱을 설계하거나 엔드포인트를 추가할 때
- Pydantic v2 모델을 작성하거나 마이그레이션할 때
- 의존성 주입, 미들웨어, 에러 핸들러를 구현할 때
- 비동기 엔드포인트 또는 백그라운드 태스크를 다룰 때

---

## Core Patterns

### 1. Router Organization

```python
# app/routers/users.py
from fastapi import APIRouter, Depends, HTTPException, status

router = APIRouter(
    prefix="/users",
    tags=["users"],
    responses={404: {"description": "User not found"}},
)

@router.get("/", response_model=list[UserOut])
async def list_users(skip: int = 0, limit: int = 20):
    return await user_service.list(skip=skip, limit=limit)

@router.get("/{user_id}", response_model=UserOut)
async def get_user(user_id: int):
    user = await user_service.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

```python
# app/main.py
from fastapi import FastAPI
from app.routers import users, items, auth

app = FastAPI(title="My API", version="1.0.0")

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(items.router, prefix="/api/v1")
```

#### 프로젝트 구조 (권장)

```
app/
├── main.py              # FastAPI 인스턴스 + 라우터 등록
├── config.py            # pydantic-settings 설정
├── dependencies.py      # 공통 의존성
├── models/              # SQLAlchemy / ORM 모델
│   └── user.py
├── schemas/             # Pydantic 스키마
│   └── user.py
├── routers/             # 엔드포인트
│   ├── auth.py
│   └── users.py
├── services/            # 비즈니스 로직
│   └── user_service.py
└── tests/
    ├── conftest.py
    └── test_users.py
```

---

### 2. Pydantic v2 Models

```python
from pydantic import BaseModel, ConfigDict, field_validator, model_validator
from datetime import datetime

class UserCreate(BaseModel):
    """생성 요청 스키마"""
    model_config = ConfigDict(str_strip_whitespace=True)

    username: str
    email: str
    password: str
    age: int | None = None

    @field_validator("username")
    @classmethod
    def username_alphanumeric(cls, v: str) -> str:
        if not v.isalnum():
            raise ValueError("must be alphanumeric")
        return v.lower()

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        if "@" not in v:
            raise ValueError("invalid email format")
        return v.lower()

class UserOut(BaseModel):
    """응답 스키마 — password 제외"""
    model_config = ConfigDict(from_attributes=True)  # ORM 모드

    id: int
    username: str
    email: str
    created_at: datetime

class DateRange(BaseModel):
    """model_validator — 필드 간 교차 검증"""
    start: datetime
    end: datetime

    @model_validator(mode="after")
    def check_date_order(self) -> "DateRange":
        if self.start >= self.end:
            raise ValueError("start must be before end")
        return self
```

#### 중첩 모델 & 제네릭 응답

```python
from pydantic import BaseModel
from typing import Generic, TypeVar

T = TypeVar("T")

class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
    has_next: bool

# 사용
@router.get("/users", response_model=PaginatedResponse[UserOut])
async def list_users(page: int = 1, size: int = 20):
    ...
```

---

### 3. Dependency Injection

```python
from fastapi import Depends, Header, HTTPException
from typing import Annotated

# 간단한 의존성
async def get_db():
    db = SessionLocal()
    try:
        yield db  # yield 의존성 — finally 보장
    finally:
        db.close()

# 타입 앨리어스로 DI 간소화
DB = Annotated[AsyncSession, Depends(get_db)]

@router.get("/users")
async def list_users(db: DB):
    return await db.execute(select(User))

# 인증 의존성 체이닝
async def get_current_user(
    token: Annotated[str, Depends(oauth2_scheme)],
    db: DB,
) -> User:
    payload = decode_token(token)
    user = await db.get(User, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="Invalid token")
    return user

CurrentUser = Annotated[User, Depends(get_current_user)]

# 권한 검사 의존성
def require_role(role: str):
    async def check(user: CurrentUser):
        if role not in user.roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return check

@router.delete("/{user_id}")
async def delete_user(
    user_id: int,
    admin: Annotated[User, Depends(require_role("admin"))],
    db: DB,
):
    ...
```

---

### 4. Async Endpoint Patterns

```python
import httpx
from asyncio import TaskGroup

# 외부 API 병렬 호출
@router.get("/dashboard")
async def dashboard(user: CurrentUser):
    async with TaskGroup() as tg:
        orders_task = tg.create_task(order_service.get_recent(user.id))
        notifications_task = tg.create_task(notification_service.unread(user.id))

    return {
        "orders": orders_task.result(),
        "notifications": notifications_task.result(),
    }

# def 엔드포인트 — FastAPI가 자동으로 스레드 풀에서 실행
@router.get("/sync-heavy")
def sync_heavy_computation():
    """CPU-bound 작업은 def로 선언하면 threadpool에서 실행됨"""
    return compute_report()
```

---

### 5. Middleware

```python
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import time

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://frontend.example.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 커스텀 미들웨어 — 요청 시간 로깅
@app.middleware("http")
async def log_request_time(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    elapsed = time.perf_counter() - start
    response.headers["X-Process-Time"] = f"{elapsed:.4f}"
    return response
```

---

### 6. Background Tasks

```python
from fastapi import BackgroundTasks

async def send_email(to: str, subject: str, body: str):
    """실제 이메일 전송 로직"""
    ...

@router.post("/register", status_code=201)
async def register(
    user_in: UserCreate,
    background_tasks: BackgroundTasks,
    db: DB,
):
    user = await user_service.create(db, user_in)
    background_tasks.add_task(
        send_email,
        to=user.email,
        subject="Welcome!",
        body=f"Hello {user.username}",
    )
    return user
```

---

### 7. Lifespan Events

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    app.state.db_pool = await create_pool()
    app.state.redis = await aioredis.from_url("redis://localhost")
    print("Started")
    yield
    # Shutdown
    await app.state.db_pool.close()
    await app.state.redis.close()
    print("Shutdown complete")

app = FastAPI(lifespan=lifespan)
```

---

### 8. Error Handling

```python
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

# 커스텀 예외
class NotFoundError(Exception):
    def __init__(self, resource: str, id: int | str):
        self.resource = resource
        self.id = id

class BusinessRuleError(Exception):
    def __init__(self, message: str, code: str):
        self.message = message
        self.code = code

# 예외 핸들러 등록
@app.exception_handler(NotFoundError)
async def not_found_handler(request: Request, exc: NotFoundError):
    return JSONResponse(
        status_code=404,
        content={
            "error": "not_found",
            "detail": f"{exc.resource} #{exc.id} not found",
        },
    )

@app.exception_handler(BusinessRuleError)
async def business_rule_handler(request: Request, exc: BusinessRuleError):
    return JSONResponse(
        status_code=422,
        content={"error": exc.code, "detail": exc.message},
    )

# 사용
@router.post("/orders")
async def create_order(order_in: OrderCreate, user: CurrentUser, db: DB):
    if user.balance < order_in.total:
        raise BusinessRuleError(
            message="Insufficient balance",
            code="insufficient_funds",
        )
    ...
```

---

### 9. Response Models & Path/Query Validation

```python
from fastapi import Path, Query
from typing import Annotated

@router.get(
    "/items/{item_id}",
    response_model=ItemOut,
    response_model_exclude_none=True,
    summary="Get item by ID",
    responses={
        404: {"description": "Item not found"},
        422: {"description": "Validation error"},
    },
)
async def get_item(
    item_id: Annotated[int, Path(ge=1, description="Item ID (positive integer)")],
    fields: Annotated[
        list[str] | None,
        Query(description="Fields to include in response"),
    ] = None,
):
    ...
```

---

## Anti-Patterns

### 1. 동기 I/O in async endpoint

```python
# BAD — 이벤트 루프 블로킹
@router.get("/data")
async def get_data():
    with open("large_file.csv") as f:  # 동기 파일 I/O
        return f.read()

# GOOD — aiofiles 또는 def 엔드포인트
@router.get("/data")
def get_data():  # def → 자동 스레드 풀
    with open("large_file.csv") as f:
        return f.read()
```

### 2. 과도한 중첩 의존성

```python
# BAD — 5단계 이상 체이닝 → 디버깅 불가
# Depends(a) → Depends(b) → Depends(c) → Depends(d) → Depends(e)

# GOOD — 최대 3단계, 복잡하면 서비스 계층으로 분리
```

### 3. 요청 핸들러에 비즈니스 로직 직접 작성

```python
# BAD — 엔드포인트에 모든 로직
@router.post("/orders")
async def create_order(order_in: OrderCreate, db: DB):
    # 50줄의 비즈니스 로직...
    ...

# GOOD — 서비스 계층 분리
@router.post("/orders", response_model=OrderOut, status_code=201)
async def create_order(order_in: OrderCreate, db: DB, user: CurrentUser):
    return await order_service.create(db, user, order_in)
```

### 4. Pydantic v1 문법 사용 (v2 프로젝트에서)

```python
# BAD — v1 스타일
class Config:
    orm_mode = True

@validator("name")
def check_name(cls, v):
    ...

# GOOD — v2 스타일
model_config = ConfigDict(from_attributes=True)

@field_validator("name")
@classmethod
def check_name(cls, v: str) -> str:
    ...
```

### 5. HTTPException 남용

```python
# BAD — 모든 에러를 HTTPException으로
raise HTTPException(status_code=400, detail="insufficient funds")

# GOOD — 도메인 예외 + exception_handler
raise InsufficientFundsError(user_id=user.id, required=100, available=50)
```
'''

# =============================================================================
# 3. swagger-openapi-patterns.md
# =============================================================================
SWAGGER_PATTERNS = r'''---
name: "Swagger & OpenAPI Patterns"
description: "OpenAPI 3.0/3.1 스펙 설계, 스키마 정의, 버전 관리, FastAPI 자동 생성, 보안 스킴"
languages: ["Python", "TypeScript"]
frameworks: ["OpenAPI", "Swagger", "FastAPI"]
phases: ["dev"]
---

# Swagger & OpenAPI Patterns

## When to Activate

- REST API 스펙을 설계하거나 OpenAPI 문서를 작성할 때
- FastAPI의 자동 생성 OpenAPI를 커스터마이징할 때
- API 버전 관리 전략을 결정할 때
- Swagger UI를 커스터마이징하거나 보안 스킴을 설정할 때

---

## Core Patterns

### 1. OpenAPI 3.1 Spec Structure

```yaml
openapi: "3.1.0"
info:
  title: "Order Management API"
  version: "2.1.0"
  description: "주문 관리 시스템 API"
  contact:
    name: "API Support"
    email: "api@example.com"

servers:
  - url: "https://api.example.com/v2"
    description: "Production"
  - url: "https://staging-api.example.com/v2"
    description: "Staging"

tags:
  - name: orders
    description: "주문 관련 엔드포인트"
  - name: users
    description: "사용자 관련 엔드포인트"

paths:
  /orders:
    get:
      tags: [orders]
      summary: "주문 목록 조회"
      operationId: listOrders
      parameters:
        - $ref: "#/components/parameters/PageParam"
        - $ref: "#/components/parameters/SizeParam"
      responses:
        "200":
          description: "성공"
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/OrderListResponse"
        "401":
          $ref: "#/components/responses/Unauthorized"
```

---

### 2. Schema Definitions

#### $ref — 재사용 스키마

```yaml
components:
  schemas:
    Order:
      type: object
      required: [id, status, items, total]
      properties:
        id:
          type: integer
          format: int64
          example: 12345
        status:
          $ref: "#/components/schemas/OrderStatus"
        items:
          type: array
          items:
            $ref: "#/components/schemas/OrderItem"
        total:
          type: number
          format: double
          minimum: 0
        created_at:
          type: string
          format: date-time

    OrderStatus:
      type: string
      enum: [pending, confirmed, shipped, delivered, cancelled]

    OrderItem:
      type: object
      required: [product_id, quantity, price]
      properties:
        product_id:
          type: integer
        quantity:
          type: integer
          minimum: 1
        price:
          type: number
          minimum: 0
```

#### allOf — 상속 / 확장

```yaml
components:
  schemas:
    UserBase:
      type: object
      required: [username, email]
      properties:
        username:
          type: string
          minLength: 3
          maxLength: 50
        email:
          type: string
          format: email

    UserCreate:
      allOf:
        - $ref: "#/components/schemas/UserBase"
        - type: object
          required: [password]
          properties:
            password:
              type: string
              minLength: 8

    UserResponse:
      allOf:
        - $ref: "#/components/schemas/UserBase"
        - type: object
          required: [id, created_at]
          properties:
            id:
              type: integer
            created_at:
              type: string
              format: date-time
```

#### oneOf + discriminator — 다형성

```yaml
components:
  schemas:
    Notification:
      oneOf:
        - $ref: "#/components/schemas/EmailNotification"
        - $ref: "#/components/schemas/SmsNotification"
        - $ref: "#/components/schemas/PushNotification"
      discriminator:
        propertyName: type
        mapping:
          email: "#/components/schemas/EmailNotification"
          sms: "#/components/schemas/SmsNotification"
          push: "#/components/schemas/PushNotification"

    EmailNotification:
      type: object
      required: [type, to, subject, body]
      properties:
        type:
          type: string
          const: email
        to:
          type: string
          format: email
        subject:
          type: string
        body:
          type: string

    SmsNotification:
      type: object
      required: [type, phone, message]
      properties:
        type:
          type: string
          const: sms
        phone:
          type: string
        message:
          type: string
          maxLength: 160
```

---

### 3. Path / Query / Body Design

```yaml
paths:
  /users/{user_id}/orders:
    get:
      summary: "사용자의 주문 목록"
      parameters:
        - name: user_id
          in: path
          required: true
          schema:
            type: integer
            minimum: 1
        - name: status
          in: query
          required: false
          schema:
            $ref: "#/components/schemas/OrderStatus"
        - name: sort
          in: query
          schema:
            type: string
            enum: [created_at, total, status]
            default: created_at
        - name: order
          in: query
          schema:
            type: string
            enum: [asc, desc]
            default: desc
      responses:
        "200":
          description: "성공"

  /orders:
    post:
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/OrderCreate"
            examples:
              basic:
                summary: "기본 주문"
                value:
                  items:
                    - product_id: 1
                      quantity: 2
                  shipping_address: "서울시 강남구"
      responses:
        "201":
          description: "주문 생성 완료"
          headers:
            Location:
              schema:
                type: string
              description: "생성된 리소스 URL"
```

#### 재사용 가능한 파라미터

```yaml
components:
  parameters:
    PageParam:
      name: page
      in: query
      schema:
        type: integer
        minimum: 1
        default: 1
    SizeParam:
      name: size
      in: query
      schema:
        type: integer
        minimum: 1
        maximum: 100
        default: 20
```

---

### 4. Response Codes Convention

| Code | 용도 | Body |
|------|------|------|
| 200 | 조회/수정 성공 | 리소스 또는 리스트 |
| 201 | 생성 성공 | 생성된 리소스 + Location 헤더 |
| 204 | 삭제 성공 | 없음 |
| 400 | 잘못된 요청 | 에러 상세 |
| 401 | 인증 실패 | 에러 메시지 |
| 403 | 권한 부족 | 에러 메시지 |
| 404 | 리소스 없음 | 에러 메시지 |
| 409 | 충돌 (중복 등) | 충돌 상세 |
| 422 | 유효성 검증 실패 | 필드별 에러 |
| 429 | Rate limit 초과 | Retry-After 헤더 |
| 500 | 서버 에러 | 일반 에러 (상세 노출 금지) |

```yaml
components:
  responses:
    Unauthorized:
      description: "인증 실패"
      content:
        application/json:
          schema:
            $ref: "#/components/schemas/ErrorResponse"
  schemas:
    ErrorResponse:
      type: object
      required: [error, detail]
      properties:
        error:
          type: string
          example: "unauthorized"
        detail:
          type: string
          example: "Invalid or expired token"
```

---

### 5. Versioning Strategies

```python
# 전략 1: URL Path (권장 — 가장 명시적)
# /api/v1/users, /api/v2/users
from fastapi import FastAPI

app = FastAPI()
app.include_router(users_v1.router, prefix="/api/v1")
app.include_router(users_v2.router, prefix="/api/v2")

# 전략 2: Header
# Accept: application/vnd.myapi.v2+json
from fastapi import Header

@router.get("/users")
async def list_users(
    accept: str = Header(default="application/vnd.myapi.v1+json"),
):
    version = parse_version(accept)
    ...

# 전략 3: Query Parameter
# /users?version=2
@router.get("/users")
async def list_users(version: int = 1):
    ...
```

---

### 6. FastAPI Auto-Generation Tips

```python
from fastapi import FastAPI

# OpenAPI 메타데이터 커스터마이징
app = FastAPI(
    title="Order API",
    version="2.1.0",
    description="주문 관리 시스템",
    openapi_tags=[
        {"name": "orders", "description": "주문 CRUD"},
        {"name": "auth", "description": "인증/인가"},
    ],
    openapi_url="/api/v1/openapi.json",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# 엔드포인트별 상세 문서
@router.post(
    "/orders",
    response_model=OrderOut,
    status_code=201,
    summary="Create a new order",
    description="새 주문을 생성합니다. 재고 확인 후 결제를 진행합니다.",
    response_description="생성된 주문 정보",
    responses={
        409: {
            "description": "재고 부족",
            "content": {
                "application/json": {
                    "example": {"error": "out_of_stock", "detail": "Item #42 out of stock"}
                }
            },
        },
    },
    openapi_extra={
        "x-rate-limit": "100/hour",
    },
)
async def create_order(order_in: OrderCreate):
    ...
```

#### 특정 엔드포인트 OpenAPI에서 숨기기

```python
@router.get("/internal/health", include_in_schema=False)
async def health_check():
    return {"status": "ok"}
```

---

### 7. Swagger UI Customization

```python
from fastapi import FastAPI
from fastapi.openapi.docs import get_swagger_ui_html

app = FastAPI(docs_url=None)  # 기본 docs 비활성화

@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - Docs",
        swagger_ui_parameters={
            "defaultModelsExpandDepth": -1,
            "docExpansion": "none",
            "filter": True,
            "persistAuthorization": True,
            "tryItOutEnabled": True,
        },
    )
```

---

### 8. Security Schemes

```yaml
components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

    OAuth2:
      type: oauth2
      flows:
        authorizationCode:
          authorizationUrl: "https://auth.example.com/authorize"
          tokenUrl: "https://auth.example.com/token"
          scopes:
            read:orders: "주문 조회"
            write:orders: "주문 생성/수정"
            admin: "관리자 권한"

    ApiKeyAuth:
      type: apiKey
      in: header
      name: X-API-Key

security:
  - BearerAuth: []
```

```python
# FastAPI에서 보안 스킴 구현
from fastapi.security import OAuth2PasswordBearer, APIKeyHeader

oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="/auth/token",
    scopes={
        "read:orders": "주문 조회",
        "write:orders": "주문 생성/수정",
    },
)

api_key_header = APIKeyHeader(name="X-API-Key")

# 스코프 기반 권한 검사
from fastapi import Security

@router.get("/orders")
async def list_orders(
    token: str = Security(oauth2_scheme, scopes=["read:orders"]),
):
    ...
```

---

## Anti-Patterns

### 1. 모호한 응답 타입

```yaml
# BAD — any 타입
responses:
  "200":
    content:
      application/json:
        schema:
          type: object  # 필드 정의 없음

# GOOD — 명확한 스키마
responses:
  "200":
    content:
      application/json:
        schema:
          $ref: "#/components/schemas/OrderListResponse"
```

### 2. 동사 기반 URL

```
# BAD
POST /api/createUser
GET  /api/getOrders
POST /api/deleteItem/42

# GOOD — 명사 + HTTP 메서드
POST   /api/users
GET    /api/orders
DELETE /api/items/42
```

### 3. 버전 없는 API

```
# BAD — 버전 없이 배포
GET /api/users

# GOOD — 최초 릴리스부터 버전 포함
GET /api/v1/users
```

### 4. 보안 스킴 미정의

```python
# BAD — 인증 필요하지만 OpenAPI에 정의 없음
@router.get("/orders")
async def list_orders(token: str = Header()):
    ...

# GOOD — 보안 스킴 명시
@router.get("/orders")
async def list_orders(
    token: str = Security(oauth2_scheme, scopes=["read:orders"]),
):
    ...
```

### 5. 과도한 중첩 경로

```
# BAD — 4단계 이상 중첩
/api/v1/companies/{cid}/departments/{did}/teams/{tid}/members/{mid}

# GOOD — 2단계까지, 필요하면 쿼리 파라미터 활용
/api/v1/members?company_id=1&department_id=2&team_id=3
/api/v1/teams/{tid}/members
```
'''

# =============================================================================
# 4. python-testing.md
# =============================================================================
PYTHON_TESTING = r'''---
name: "Python Testing Patterns"
description: "pytest 중심 테스트 패턴 — fixture, parametrize, mocking, async 테스트, 커버리지, FastAPI TestClient"
languages: ["Python"]
frameworks: ["pytest", "Python"]
phases: ["test"]
---

# Python Testing Patterns

## When to Activate

- pytest 기반 테스트 코드를 작성하거나 리뷰할 때
- 비동기 코드(async/await) 테스트를 구성할 때
- mock, patch 전략을 결정할 때
- 테스트 커버리지를 측정하거나 개선할 때
- FastAPI 엔드포인트를 테스트할 때

---

## Core Patterns

### 1. pytest Fixtures

```python
# conftest.py — 프로젝트/디렉토리 전역 fixture
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

@pytest.fixture
def sample_user() -> dict:
    """단순 데이터 fixture"""
    return {"username": "testuser", "email": "test@example.com", "age": 25}

# scope 옵션: function(기본), class, module, session
@pytest.fixture(scope="session")
def db_engine():
    """세션 전체에서 하나의 엔진 공유"""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    yield engine
    # teardown
    engine.dispose()

@pytest.fixture
async def db_session(db_engine) -> AsyncSession:
    """각 테스트마다 새 세션 + 롤백"""
    async with AsyncSession(db_engine) as session:
        async with session.begin():
            yield session
            await session.rollback()

# autouse — 명시적 선언 없이 자동 적용
@pytest.fixture(autouse=True)
def reset_caches():
    """모든 테스트 전에 캐시 초기화"""
    cache.clear()
    yield
    cache.clear()
```

#### Fixture 계층 구조

```
tests/
├── conftest.py           # 전역 fixture (DB, 앱 인스턴스)
├── unit/
│   ├── conftest.py       # 유닛 테스트 전용 fixture
│   └── test_services.py
├── integration/
│   ├── conftest.py       # 통합 테스트 전용 fixture
│   └── test_api.py
└── factories.py          # 팩토리 함수
```

---

### 2. Parametrize

```python
import pytest

# 기본 파라미터화
@pytest.mark.parametrize("input,expected", [
    ("hello", "HELLO"),
    ("world", "WORLD"),
    ("", ""),
    ("MiXeD", "MIXED"),
])
def test_uppercase(input: str, expected: str):
    assert input.upper() == expected

# 여러 축 결합
@pytest.mark.parametrize("x", [1, 2, 3])
@pytest.mark.parametrize("y", [10, 20])
def test_multiply(x: int, y: int):
    assert x * y == x * y  # 3 x 2 = 6개 테스트 케이스

# ID 지정 — 테스트 결과에서 식별 용이
@pytest.mark.parametrize("status_code,expected_error", [
    pytest.param(400, "bad_request", id="bad-request"),
    pytest.param(401, "unauthorized", id="unauthorized"),
    pytest.param(403, "forbidden", id="forbidden"),
    pytest.param(404, "not_found", id="not-found"),
    pytest.param(500, "server_error", id="server-error"),
])
def test_error_mapping(status_code: int, expected_error: str):
    assert map_error(status_code) == expected_error

# 특정 케이스 스킵 / 실패 예상
@pytest.mark.parametrize("value,expected", [
    (1, 1),
    pytest.param(-1, 1, marks=pytest.mark.xfail(reason="negative not supported")),
    pytest.param(None, 0, marks=pytest.mark.skip(reason="TODO: handle None")),
])
def test_absolute(value, expected):
    assert abs_value(value) == expected
```

---

### 3. pytest-asyncio

```python
import pytest
import pytest_asyncio

# pyproject.toml에서 모드 설정
# [tool.pytest.ini_options]
# asyncio_mode = "auto"  # 모든 async test 자동 인식

# async fixture
@pytest_asyncio.fixture
async def async_client():
    async with httpx.AsyncClient(base_url="http://test") as client:
        yield client

# async test
@pytest.mark.asyncio
async def test_fetch_data(async_client):
    response = await async_client.get("/api/data")
    assert response.status_code == 200

# async parametrize
@pytest.mark.asyncio
@pytest.mark.parametrize("endpoint,expected_status", [
    ("/health", 200),
    ("/nonexistent", 404),
])
async def test_endpoints(async_client, endpoint: str, expected_status: int):
    response = await async_client.get(endpoint)
    assert response.status_code == expected_status
```

---

### 4. Mocking

```python
from unittest.mock import patch, MagicMock, AsyncMock, PropertyMock

# patch — 외부 의존성 대체
class TestUserService:
    @patch("app.services.user_service.db_repository")
    def test_create_user(self, mock_repo):
        mock_repo.save.return_value = User(id=1, name="test")

        result = user_service.create({"name": "test"})

        mock_repo.save.assert_called_once()
        assert result.id == 1

    # 컨텍스트 매니저로 patch
    def test_with_context(self):
        with patch("app.services.email.send") as mock_send:
            mock_send.return_value = True
            result = notify_user(user_id=1)
            mock_send.assert_called_once_with(
                to="user@example.com",
                subject="Notification",
            )

# AsyncMock — 비동기 함수 모킹
@pytest.mark.asyncio
async def test_async_service():
    mock_client = AsyncMock()
    mock_client.get.return_value = MagicMock(
        status_code=200,
        json=MagicMock(return_value={"data": "value"}),
    )

    service = ExternalService(client=mock_client)
    result = await service.fetch_data()

    mock_client.get.assert_awaited_once_with("/api/data")
    assert result == {"data": "value"}

# side_effect — 예외 또는 동적 반환
def test_retry_on_failure():
    mock_api = MagicMock()
    mock_api.call.side_effect = [
        ConnectionError("timeout"),    # 1차 실패
        ConnectionError("timeout"),    # 2차 실패
        {"status": "ok"},              # 3차 성공
    ]

    result = resilient_call(mock_api)
    assert result == {"status": "ok"}
    assert mock_api.call.call_count == 3

# spec — 원본 인터페이스 준수 강제
mock_user = MagicMock(spec=User)
mock_user.name = "test"
mock_user.nonexistent_field  # AttributeError (spec 덕분)
```

#### patch 대상 지정 규칙

```python
# BAD — 정의된 곳을 patch
@patch("app.utils.datetime")  # utils.py에서 import한 datetime

# GOOD — 사용되는 곳을 patch
@patch("app.services.user_service.datetime")  # user_service.py에서 사용

# 규칙: patch("사용하는_모듈.이름")
# from X import Y → patch("사용모듈.Y")
# import X       → patch("사용모듈.X")
```

---

### 5. Coverage

```ini
# pyproject.toml
[tool.pytest.ini_options]
addopts = "--cov=app --cov-report=term-missing --cov-branch"
testpaths = ["tests"]

[tool.coverage.run]
source = ["app"]
branch = true
omit = [
    "app/migrations/*",
    "app/config.py",
    "app/__main__.py",
]

[tool.coverage.report]
fail_under = 80
show_missing = true
exclude_lines = [
    "pragma: no cover",
    "if TYPE_CHECKING:",
    "if __name__ == .__main__.",
    "@(abc\\.)?abstractmethod",
]
```

```bash
# 실행
pytest --cov=app --cov-report=html
# htmlcov/index.html 에서 시각적 확인
```

---

### 6. Test Organization — Arrange-Act-Assert

```python
def test_order_total_with_discount():
    # Arrange — 테스트 데이터 준비
    items = [
        OrderItem(product_id=1, quantity=2, price=100),
        OrderItem(product_id=2, quantity=1, price=200),
    ]
    discount = Discount(type="percentage", value=10)

    # Act — 테스트 대상 실행
    order = Order(items=items, discount=discount)
    total = order.calculate_total()

    # Assert — 결과 검증
    assert total == 360.0  # (200 + 200) * 0.9
    assert order.discount_applied is True
```

#### 하나의 테스트 = 하나의 행위 검증

```python
# BAD — 여러 행위를 하나의 테스트에서 검증
def test_user_lifecycle():
    user = create_user(...)
    assert user.id is not None
    update_user(user.id, name="new")
    assert get_user(user.id).name == "new"
    delete_user(user.id)
    assert get_user(user.id) is None

# GOOD — 분리
def test_create_user():
    user = create_user(...)
    assert user.id is not None

def test_update_user_name(existing_user):
    update_user(existing_user.id, name="new")
    assert get_user(existing_user.id).name == "new"

def test_delete_user(existing_user):
    delete_user(existing_user.id)
    assert get_user(existing_user.id) is None
```

---

### 7. Factory Pattern for Test Data

```python
# tests/factories.py
from dataclasses import dataclass, field
from typing import Any

class UserFactory:
    """테스트용 User 인스턴스 생성 팩토리"""
    _counter = 0

    @classmethod
    def create(cls, **overrides: Any) -> User:
        cls._counter += 1
        defaults = {
            "username": f"user_{cls._counter}",
            "email": f"user_{cls._counter}@test.com",
            "age": 25,
            "is_active": True,
        }
        defaults.update(overrides)
        return User(**defaults)

    @classmethod
    def create_batch(cls, count: int, **overrides: Any) -> list[User]:
        return [cls.create(**overrides) for _ in range(count)]

# 사용
def test_list_active_users(db_session):
    active_users = UserFactory.create_batch(3, is_active=True)
    inactive_user = UserFactory.create(is_active=False)
    for u in [*active_users, inactive_user]:
        db_session.add(u)
    db_session.flush()

    result = user_service.list_active(db_session)
    assert len(result) == 3
```

#### pytest-factoryboy 활용

```python
import factory
from factory import Faker, SubFactory

class UserFactory(factory.Factory):
    class Meta:
        model = User

    username = Faker("user_name")
    email = Faker("email")
    age = Faker("random_int", min=18, max=80)

class OrderFactory(factory.Factory):
    class Meta:
        model = Order

    user = SubFactory(UserFactory)
    total = Faker("pydecimal", left_digits=4, right_digits=2, positive=True)
```

---

### 8. FastAPI TestClient

```python
import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app
from app.dependencies import get_db, get_current_user

# 의존성 오버라이드
@pytest.fixture
def override_deps():
    mock_db = MagicMock()

    async def mock_get_db():
        yield mock_db

    async def mock_get_current_user():
        return User(id=1, username="testuser", roles=["user"])

    app.dependency_overrides[get_db] = mock_get_db
    app.dependency_overrides[get_current_user] = mock_get_current_user
    yield mock_db
    app.dependency_overrides.clear()

# 동기 TestClient (간단한 테스트)
from fastapi.testclient import TestClient

def test_health():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

# 비동기 TestClient (httpx)
@pytest_asyncio.fixture
async def client(override_deps):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

@pytest.mark.asyncio
async def test_create_order(client: AsyncClient):
    payload = {
        "items": [{"product_id": 1, "quantity": 2}],
        "shipping_address": "서울시 강남구",
    }

    response = await client.post("/api/v1/orders", json=payload)

    assert response.status_code == 201
    data = response.json()
    assert data["id"] is not None
    assert len(data["items"]) == 1

@pytest.mark.asyncio
async def test_unauthorized_access():
    """의존성 오버라이드 없이 — 401 확인"""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/api/v1/orders")
        assert response.status_code == 401
```

---

## Anti-Patterns

### 1. 외부 서비스 직접 호출

```python
# BAD — 실제 API 호출 (느림, 불안정, 비용)
def test_send_notification():
    result = notification_service.send("user@real.com", "Hello")
    assert result.success

# GOOD — mock 사용
@patch("app.services.notification_service.smtp_client")
def test_send_notification(mock_smtp):
    mock_smtp.send.return_value = True
    result = notification_service.send("test@example.com", "Hello")
    assert result.success
```

### 2. 테스트 간 상태 공유

```python
# BAD — 테스트 실행 순서에 의존
shared_list = []

def test_add():
    shared_list.append(1)
    assert len(shared_list) == 1

def test_check():  # test_add가 먼저 실행되어야 통과
    assert 1 in shared_list

# GOOD — fixture로 독립적 상태 관리
@pytest.fixture
def items():
    return [1]

def test_add(items):
    items.append(2)
    assert len(items) == 2

def test_check(items):
    assert 1 in items  # 항상 새로운 [1]
```

### 3. 과도한 mock (테스트가 구현을 반복)

```python
# BAD — 내부 구현 전부 mock → 리팩토링하면 테스트 전부 깨짐
@patch("app.services.user.validate")
@patch("app.services.user.transform")
@patch("app.services.user.save")
@patch("app.services.user.notify")
def test_create_user(mock_notify, mock_save, mock_transform, mock_validate):
    ...

# GOOD — 경계(외부 I/O)만 mock, 내부 로직은 실제 실행
@patch("app.services.user.db_repository")
@patch("app.services.user.email_client")
def test_create_user(mock_email, mock_repo):
    mock_repo.save.return_value = User(id=1, name="test")
    result = user_service.create({"name": "test"})
    assert result.id == 1
```

### 4. assert 메시지 없는 복잡한 조건

```python
# BAD
assert result

# GOOD — 실패 시 디버깅 가능
assert result is not None, f"Expected result but got None for input={input_data}"
assert len(items) == 3, f"Expected 3 items, got {len(items)}: {items}"
```
'''

# =============================================================================
# 5. python-security.md
# =============================================================================
PYTHON_SECURITY = r'''---
name: "Python Security Patterns"
description: "Python/FastAPI 보안 패턴 — 입력 검증, SQL 인젝션 방지, JWT 인증, 비밀번호 해싱, CORS, 비밀 관리"
languages: ["Python"]
frameworks: ["Python", "FastAPI"]
phases: ["test"]
---

# Python Security Patterns

## When to Activate

- API 인증/인가 로직을 구현할 때
- 사용자 입력을 검증하거나 DB 쿼리를 작성할 때
- 비밀번호 저장, 토큰 발급, 보안 헤더를 다룰 때
- 의존성 취약점을 스캔하거나 보안 설정을 점검할 때
- 코드 리뷰에서 보안 관련 체크포인트를 확인할 때

---

## Core Patterns

### 1. Input Validation — Pydantic

```python
from pydantic import BaseModel, field_validator, ConfigDict
import re
import bleach

class UserInput(BaseModel):
    """모든 사용자 입력은 Pydantic 모델을 통과해야 한다"""
    model_config = ConfigDict(str_strip_whitespace=True, str_max_length=500)

    username: str
    email: str
    bio: str | None = None

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9_]{3,30}$", v):
            raise ValueError("username must be 3-30 alphanumeric characters")
        return v.lower()

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if not re.match(pattern, v):
            raise ValueError("invalid email format")
        return v.lower()

    @field_validator("bio")
    @classmethod
    def sanitize_bio(cls, v: str | None) -> str | None:
        if v is None:
            return v
        # HTML 태그 제거 (XSS 방지)
        return bleach.clean(v, tags=[], strip=True)
```

#### Path Traversal 방지

```python
from pathlib import Path

UPLOAD_DIR = Path("/app/uploads").resolve()

def safe_file_path(filename: str) -> Path:
    """경로 조작 공격 방지"""
    safe_name = Path(filename).name  # 디렉토리 부분 제거
    if not safe_name or safe_name.startswith("."):
        raise ValueError("Invalid filename")

    full_path = (UPLOAD_DIR / safe_name).resolve()

    # resolve() 후 여전히 UPLOAD_DIR 하위인지 확인
    if not full_path.is_relative_to(UPLOAD_DIR):
        raise ValueError("Path traversal detected")

    return full_path
```

---

### 2. SQL Injection Prevention

```python
# BAD — 문자열 포매팅 (SQL 인젝션 취약)
async def get_user_bad(username: str):
    query = f"SELECT * FROM users WHERE username = '{username}'"
    return await db.execute(query)

# GOOD — 파라미터화된 쿼리
async def get_user_safe(username: str):
    query = "SELECT * FROM users WHERE username = :username"
    return await db.execute(query, {"username": username})

# GOOD — SQLAlchemy ORM (자동 파라미터화)
from sqlalchemy import select
from app.models import User

async def get_user_orm(db: AsyncSession, username: str) -> User | None:
    stmt = select(User).where(User.username == username)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()

# GOOD — SQLAlchemy Core (동적 조건도 안전)
from sqlalchemy import and_, or_

async def search_users(
    db: AsyncSession,
    name: str | None = None,
    email: str | None = None,
) -> list[User]:
    stmt = select(User)
    conditions = []
    if name:
        conditions.append(User.name.ilike(f"%{name}%"))
    if email:
        conditions.append(User.email == email)
    if conditions:
        stmt = stmt.where(and_(*conditions))
    result = await db.execute(stmt)
    return list(result.scalars().all())
```

#### 위험 감지 체크리스트

```python
# 코드 리뷰에서 다음 패턴이 보이면 즉시 경고:
# 1. f"SELECT ... {variable}" 또는 "SELECT ... " + variable
# 2. f"INSERT ... VALUES ('{variable}')"
# 3. cursor.execute(f"... {variable} ...")
# 4. .format() 또는 % 포매팅으로 SQL 작성
```

---

### 3. Authentication — JWT

```python
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

SECRET_KEY = "load-from-environment"  # 환경변수에서 로드
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

def create_access_token(
    data: dict,
    expires_delta: timedelta | None = None,
) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": "access",
    })
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def create_refresh_token(user_id: int) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    return jwt.encode(
        {"sub": str(user_id), "exp": expire, "type": "refresh"},
        SECRET_KEY,
        algorithm=ALGORITHM,
    )

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        if user_id is None or token_type != "access":
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = await db.get(User, int(user_id))
    if user is None:
        raise credentials_exception
    return user
```

#### Token Refresh Flow

```python
@router.post("/auth/refresh")
async def refresh_token(
    refresh_token: str,
    db: AsyncSession = Depends(get_db),
):
    try:
        payload = jwt.decode(refresh_token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user_id = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    user = await db.get(User, int(user_id))
    if not user:
        raise HTTPException(status_code=401, detail="User not found")

    return {
        "access_token": create_access_token({"sub": str(user.id)}),
        "token_type": "bearer",
    }
```

---

### 4. Password Hashing

```python
from passlib.context import CryptContext

pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=12,
)

def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

# 비밀번호 정책 검증
import re

def validate_password_strength(password: str) -> None:
    errors = []
    if len(password) < 8:
        errors.append("최소 8자 이상")
    if not re.search(r"[A-Z]", password):
        errors.append("대문자 1개 이상 포함")
    if not re.search(r"[a-z]", password):
        errors.append("소문자 1개 이상 포함")
    if not re.search(r"\d", password):
        errors.append("숫자 1개 이상 포함")
    if not re.search(r"[!@#$%^&*(),.?:{}|<>]", password):
        errors.append("특수문자 1개 이상 포함")
    if errors:
        raise ValueError(f"Password requirements: {', '.join(errors)}")
```

---

### 5. CORS Configuration

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

if settings.ENV == "development":
    origins = ["http://localhost:3000", "http://localhost:5173"]
else:
    origins = ["https://app.example.com", "https://admin.example.com"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,          # ["*"] 절대 금지 (프로덕션)
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Authorization", "Content-Type"],
    expose_headers=["X-Total-Count", "X-Request-Id"],
    max_age=600,
)
```

---

### 6. Rate Limiting

```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import FastAPI, Request

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@router.post("/auth/login")
@limiter.limit("5/minute")
async def login(request: Request, credentials: LoginRequest):
    ...

@router.get("/api/data")
@limiter.limit("100/minute")
async def get_data(request: Request):
    ...

# 사용자별 제한 (인증 후)
def get_user_key(request: Request) -> str:
    user = request.state.user
    return f"user:{user.id}" if user else get_remote_address(request)

@router.post("/api/upload")
@limiter.limit("10/hour", key_func=get_user_key)
async def upload(request: Request):
    ...
```

---

### 7. Environment Variable Management — pydantic-settings

```python
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr

class Settings(BaseSettings):
    """환경변수를 타입-안전하게 로드"""
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # 앱 설정
    app_name: str = "MyApp"
    debug: bool = False
    env: str = "production"

    # 보안 — SecretStr로 로그 노출 방지
    secret_key: SecretStr
    database_url: SecretStr
    redis_url: str = "redis://localhost:6379"

    # JWT
    jwt_secret: SecretStr
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30

    # 외부 서비스
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_password: SecretStr | None = None

settings = Settings()

# SecretStr 사용법
secret = settings.secret_key.get_secret_value()  # 실제 값 접근
print(settings.secret_key)  # 출력: **********  (노출 방지)
```

#### .env 파일 (git에 커밋하지 않는다)

```env
SECRET_KEY=your-very-secret-key-here
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/dbname
JWT_SECRET=jwt-signing-secret
```

```gitignore
# .gitignore
.env
.env.*
!.env.example
```

---

### 8. Secrets Management

```python
import secrets
import hashlib

# 안전한 랜덤 토큰 생성
def generate_api_key() -> str:
    """URL-safe 32바이트 토큰"""
    return secrets.token_urlsafe(32)

def generate_verification_code() -> str:
    """6자리 숫자 코드"""
    return f"{secrets.randbelow(1_000_000):06d}"

# 타이밍 공격 방지 비교
def safe_compare(a: str, b: str) -> bool:
    """일정 시간 비교 — 타이밍 사이드 채널 방지"""
    return secrets.compare_digest(a.encode(), b.encode())

# API 키 해싱 (저장 시)
def hash_api_key(key: str) -> str:
    """API 키는 해시로 저장, 원문 비교 불가"""
    return hashlib.sha256(key.encode()).hexdigest()
```

---

### 9. Dependency Vulnerability Scanning

```bash
# pip-audit — PyPI 취약점 DB 기반
pip install pip-audit
pip-audit                          # 설치된 패키지 스캔
pip-audit -r requirements.txt      # requirements 파일 스캔
pip-audit --fix                    # 자동 수정

# safety — 오프라인 DB 지원
pip install safety
safety check
safety check -r requirements.txt
```

#### 보안 헤더 추가

```python
from fastapi import FastAPI, Request
from starlette.middleware.base import BaseHTTPMiddleware

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = (
            "max-age=31536000; includeSubDomains"
        )
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return response

app = FastAPI()
app.add_middleware(SecurityHeadersMiddleware)
```

---

## Anti-Patterns

### 1. 하드코딩된 시크릿

```python
# BAD
SECRET_KEY = "my-super-secret-key-12345"
DB_PASSWORD = "admin123"

# GOOD
from app.config import settings
SECRET_KEY = settings.secret_key.get_secret_value()
```

### 2. allow_origins=["*"] in Production

```python
# BAD — 모든 도메인 허용
app.add_middleware(CORSMiddleware, allow_origins=["*"])

# GOOD — 명시적 도메인
app.add_middleware(CORSMiddleware, allow_origins=["https://app.example.com"])
```

### 3. 평문 비밀번호 저장

```python
# BAD
user.password = plain_password  # DB에 평문 저장

# GOOD
user.password_hash = pwd_context.hash(plain_password)
```

### 4. JWT에 민감 정보 포함

```python
# BAD — JWT payload에 비밀번호, 카드번호 등
token = jwt.encode({"sub": user.id, "password": user.password, "ssn": "..."})

# GOOD — 최소한의 식별 정보만
token = jwt.encode({"sub": str(user.id), "roles": user.roles})
```

### 5. 에러 메시지에 내부 정보 노출

```python
# BAD — 스택 트레이스, DB 스키마 노출
except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))

# GOOD — 일반적인 메시지 + 내부 로깅
except Exception as e:
    logger.error("Order creation failed", exc_info=True)
    raise HTTPException(status_code=500, detail="Internal server error")
```

### 6. 인증 없는 엔드포인트

```python
# BAD — 민감한 데이터에 인증 없이 접근
@router.get("/users/{user_id}/orders")
async def get_user_orders(user_id: int, db: DB):
    return await db.execute(select(Order).where(Order.user_id == user_id))

# GOOD — 인증 + 소유권 확인
@router.get("/users/{user_id}/orders")
async def get_user_orders(
    user_id: int,
    current_user: CurrentUser,
    db: DB,
):
    if current_user.id != user_id and "admin" not in current_user.roles:
        raise HTTPException(status_code=403, detail="Forbidden")
    return await db.execute(select(Order).where(Order.user_id == user_id))
```
'''

# Write all files
files = {
    "python-patterns.md": PYTHON_PATTERNS,
    "fastapi-patterns.md": FASTAPI_PATTERNS,
    "swagger-openapi-patterns.md": SWAGGER_PATTERNS,
    "python-testing.md": PYTHON_TESTING,
    "python-security.md": PYTHON_SECURITY,
}

for name, content in files.items():
    path = os.path.join(BASE, name)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.lstrip('\n'))
    size = os.path.getsize(path)
    lines = content.count('\n')
    print(f"  {name}: {size:,} bytes, ~{lines} lines")

print(f"\nAll {len(files)} files written successfully.")
