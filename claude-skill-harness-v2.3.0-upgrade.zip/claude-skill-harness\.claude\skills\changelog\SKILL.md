---
name: changelog
description: |
  CHANGELOG.md 자동 갱신 정책을 정의하는 스킬.
  이 스킬은 직접 호출되지 않는다 — advance-phase.js complete 트리거가 자동 실행한다.
  사용자가 "변경 이력 보여줘", "이번에 뭐 바뀌었어?" 등을 물으면 이 파일을 읽고
  CHANGELOG.md의 최신 항목을 안내한다.
  버전 체계, 엔트리 형식, 멱등성 규칙을 정의한다.
---

# Changelog 스킬 — CHANGELOG.md 자동 갱신 정책

## 역할

`CHANGELOG.md`는 **시간/이벤트 중심**으로 프로젝트의 모든 주요 변경을 누적 기록한다.
README.md가 "이 프로젝트가 뭐야?"를 답한다면, CHANGELOG.md는 "언제 무엇이 바뀌었나?"를 답한다.

이 스킬은 **Claude가 직접 호출하지 않는다**. `advance-phase.js`의 complete 전환 로직이 자동으로 실행한다.

---

## 자동 갱신 트리거

| 시점 | 동작 |
|------|------|
| `advance-phase.js complete` (Track C) | 새 사이클 엔트리 자동 추가 |
| `advance-phase.js bump-major` | 메이저 마커 추가 + 버전 X+1 |

Track A/B는 CHANGELOG에 기록하지 않는다.

---

## 버전 체계 — 작업 로그형 X.Y.Z

```
X . Y . Z
│   │   │
│   │   └── 작업 단위 (Track C 사이클 완료마다 +1)
│   └────── 날짜 (날이 바뀌면 +1, Z=0으로 리셋)
└────────── 사람 (수동 bump-major, 큰 이정표)
```

### 증가 규칙

1. **Z 증가**: Track C `complete` 전환 시 자동
   - 같은 날 사이클: `0.2.0` → `0.2.1` → `0.2.2` ...
2. **Y 증가**: 사이클 종료 시 "오늘 날짜 ≠ pipeline-state.last_changelog_date"
   - 새 날 첫 사이클: `0.2.5` → `0.3.0`
3. **X 증가**: `advance-phase.js bump-major` 명시 호출
   - 큰 이정표: `0.5.7` → `1.0.0`

### 시나리오 예시

| 시점 | 이벤트 | 버전 |
|------|------|------|
| 2026-04-09 시작 | 사람이 0.1.0 설정 | 0.1.0 |
| 2026-04-09 사이클 1 | Z+1 | 0.1.1 |
| 2026-04-09 사이클 2 | Z+1 | 0.1.2 |
| 2026-04-10 첫 사이클 | Y+1, Z=0 | 0.2.0 |
| 2026-04-10 두 번째 사이클 | Z+1 | 0.2.1 |
| 2026-05-01 수동 bump | X+1, Y=0, Z=0 | 1.0.0 |
| 2026-05-01 사이클 | Z+1 | 1.0.1 |

---

## CHANGELOG.md 형식 — Keep a Changelog 변형

```markdown
# Changelog

이 프로젝트의 모든 주요 변경사항은 이 파일에 기록됩니다.
형식: Keep a Changelog + 작업 로그형 X.Y.Z 버전

<!-- changelog-entries-start -->

## [0.2.1] - 2026-04-10

### Added
- **Changelog/README 분리 + 자동화** ([PRD](docs/prds/changelog-readme-separation-prd.md) · [Plan](docs/plans/changelog-readme-separation-prd-plan.md) · [Report](docs/reports/changelog-readme-separation-report.md))

## [0.2.0] - 2026-04-10

### Added
- **Hook 시스템 Hard Gate 강화** ([Report](docs/reports/hook-hardening-report.md))
```

### 엔트리 구성 요소

1. **버전 헤더**: `## [X.Y.Z] - YYYY-MM-DD`
2. **카테고리**: `### Added` / `### Changed` / `### Fixed` / `### Major` 등
3. **사이클 제목**: report.md의 첫 `# 헤더` 또는 PRD 폴백
4. **링크**: PRD/Plan/Report 파일 경로 (존재하는 것만)

---

## 멱등성 보장

같은 사이클이 두 번 complete으로 진입할 수 있다 (예: --force 재실행, 사용자 실수).
이를 방지하기 위해 `updateChangelog` 함수는:

1. report 파일 경로(`docs/reports/{topic}-report.md`)를 키로 사용
2. CHANGELOG.md에 이미 해당 경로가 포함되어 있으면 **silent skip**
3. 스킵 시 stdout에 `CHANGELOG: 이미 기록됨, 스킵` 출력

---

## 안정성 — 격리된 try-catch

CHANGELOG 갱신이 실패해도 complete 자체는 정상 진행된다 (NFR-03).

```
실패 시:
  1. stderr에 경고 출력
  2. audit-log.jsonl에 changelog-update-failed 이벤트 기록
  3. complete 전환은 정상 완료
```

---

## CLAUDE.md 동기화

CHANGELOG 갱신 시 함께 업데이트되는 항목:

| 파일 | 필드 | 갱신 내용 |
|------|------|---------|
| `CLAUDE.md` | `version` | 새 X.Y.Z |
| `CLAUDE.md` | `last_updated` | 오늘 날짜 |
| `pipeline-state.json` | `last_changelog_date` | 오늘 날짜 |

---

## 사용자 질문 응답

사용자가 다음과 같이 물으면 이 스킬을 읽고 답한다:

| 질문 | 응답 방법 |
|------|---------|
| "이번에 뭐 바뀌었어?" | CHANGELOG.md 첫 블록 요약 |
| "전체 변경 이력 보여줘" | CHANGELOG.md 전체 표시 |
| "지금 버전이 뭐야?" | CLAUDE.md의 version 필드 |
| "메이저 버전 올려줘" | `advance-phase.js bump-major` 실행 안내 |

---

## 다른 스킬과의 연동

| 스킬 | 연동 방식 |
|------|---------|
| **report** | report 작성 후 complete 전환 시 changelog 자동 트리거 |
| **readme** | README가 CHANGELOG의 최신 버전 정보를 참조 |
| **memory** | 사이클 완료 이력을 session-context.md에도 기록 |

---

## 트러블슈팅

### 같은 사이클이 두 번 기록되었다

`advance-phase.js complete --force`를 두 번 실행했을 가능성. 멱등성 검사가 활성화된 상태라면 발생하지 않는다.

### CHANGELOG.md가 비어 있다

첫 complete 전환이 아직 발생하지 않았거나, 모두 Track A/B 사이클이었음. Track C complete 한 번 후 확인.

### 버전이 예상과 다르다

`pipeline-state.json`의 `last_changelog_date` 필드 확인. 이 값을 기준으로 Y vs Z 증가가 결정된다.
