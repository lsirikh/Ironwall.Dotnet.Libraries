# Python Naming Conventions

> Always-on naming rules for Python codebases.
> Follows PEP 8 with project-specific refinements.

---

## Casing Rules

### snake_case
- Functions: `get_user_by_id`, `calculate_total`
- Methods: `process_payment`, `validate_input`
- Variables: `user_count`, `total_price`
- Modules: `user_service.py`, `data_processor.py`
- Packages: `utils`, `models`, `services`

### PascalCase
- Classes: `UserService`, `OrderProcessor`
- Type aliases: `UserId = int`, `JsonDict = dict[str, Any]`
- Exceptions: `ValidationError`, `ResourceNotFoundError`

### UPPER_CASE
- Constants: `MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`
- Module-level configuration: `BASE_URL`, `API_VERSION`

---

## Must Always

### Access Modifiers (by convention)
- Single underscore `_prefix` for internal/private: `_validate`, `_cache`
- Double underscore `__prefix` for name mangling (rare, inheritance conflicts only)
- Dunder methods for protocols: `__init__`, `__repr__`, `__str__`, `__len__`

### Boolean Naming
- Use verb prefixes: `is_active`, `has_permission`, `can_edit`, `should_retry`
- Return type should be obvious from the name

### Clarity
- Use meaningful, self-documenting names
- Prefer full words: `customer` not `cust`, `repository` not `repo`
- Use domain-specific terminology consistently
- Name collections as plurals: `users`, `order_items`
- Name mappings descriptively: `user_by_id`, `price_per_item`

### File Organization
- Module names are short, lowercase, snake_case
- Package `__init__.py` exports the public API
- Test files: `test_{module}.py` or `{module}_test.py`

---

## Must Never

- Use single-character names `l` (ell), `O` (oh), `I` (eye) -- ambiguous with digits
- Use abbreviations unless universally known: `id`, `url`, `http` are OK
- Use camelCase for functions/variables: ~~`getUserById`~~
- Use PascalCase for functions: ~~`GetUser`~~
- Start names with double underscore unless name mangling is intentional
- Use trailing underscore except to avoid keyword collision: `class_`, `type_`
- Prefix with type: ~~`str_name`~~, ~~`list_items`~~ (not Pythonic)

---

## Quick Reference

| Element           | Convention     | Example                       |
|-------------------|----------------|-------------------------------|
| Function          | snake_case     | `get_user_by_id`              |
| Method            | snake_case     | `calculate_total`             |
| Variable          | snake_case     | `item_count`                  |
| Class             | PascalCase     | `OrderProcessor`              |
| Exception         | PascalCase     | `InvalidInputError`           |
| Constant          | UPPER_CASE     | `MAX_CONNECTIONS`             |
| Module            | snake_case     | `data_loader.py`              |
| Package           | lowercase      | `utils`, `models`             |
| Private           | _snake_case    | `_internal_cache`             |
| Name mangling     | __snake_case   | `__secret` (rare)             |
| Dunder            | __name__       | `__init__`, `__repr__`        |
| Boolean           | is/has/can     | `is_valid`, `has_access`      |
| Type alias        | PascalCase     | `UserId`, `JsonDict`          |
| Test file         | test_ prefix   | `test_user_service.py`        |
