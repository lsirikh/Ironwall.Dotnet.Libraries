// .claude/hooks/stop-observation.js
// Stop Hook — 세션 종료 시 observation 통계 + cost tracking
// async: true, timeout: 10

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const OBS_FILE = path.join(ROOT, 'docs', 'memory', 'observations.jsonl');
const COST_FILE = path.join(ROOT, 'docs', 'memory', 'cost-log.jsonl');
const AUDIT_LOG = path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl');
const STATE_FILE = path.join(ROOT, 'docs', 'memory', 'pipeline-state.json');

try {
  // ── 1. Observation 통계 ──────────────────────────────────────────
  let obsTotal = 0;
  const fileTypes = {};
  const phases = {};

  if (fs.existsSync(OBS_FILE)) {
    const lines = fs.readFileSync(OBS_FILE, 'utf8').trim().split('\n').filter(Boolean);
    obsTotal = lines.length;
    for (const line of lines.slice(-100)) {
      try {
        const obs = JSON.parse(line);
        const ft = obs.file_type || 'unknown';
        const ph = obs.phase || 'unknown';
        fileTypes[ft] = (fileTypes[ft] || 0) + 1;
        phases[ph] = (phases[ph] || 0) + 1;
      } catch { /* skip */ }
    }
  }

  // ── 2. Cost Tracking ─────────────────────────────────────────────
  // Claude Code 환경변수에서 세션 메트릭 수집
  const sessionId = process.env.CLAUDE_SESSION_ID || 'unknown';
  const costEntry = {
    timestamp: new Date().toISOString(),
    session_id: sessionId,
    observations: obsTotal,
    top_file_types: Object.entries(fileTypes).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${k}:${v}`),
    phase_distribution: phases
  };

  // pipeline-state에서 현재 phase/track 읽기
  try {
    if (fs.existsSync(STATE_FILE)) {
      const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      costEntry.phase = state.phase || 'unknown';
      costEntry.track = state.track || 'unknown';
      costEntry.version = state.version || '';
    }
  } catch { /* silent */ }

  // audit-log에서 이 세션의 hook-perf 이벤트 합산
  let totalHookMs = 0;
  let hookCallCount = 0;
  try {
    if (fs.existsSync(AUDIT_LOG)) {
      const auditLines = fs.readFileSync(AUDIT_LOG, 'utf8').trim().split('\n').filter(Boolean);
      // 최근 500줄만 스캔 (성능)
      for (const line of auditLines.slice(-500)) {
        try {
          const entry = JSON.parse(line);
          if (entry.event === 'hook-perf' && entry.elapsed_ms) {
            totalHookMs += entry.elapsed_ms;
            hookCallCount++;
          }
        } catch { /* skip */ }
      }
    }
  } catch { /* silent */ }

  costEntry.hook_total_ms = totalHookMs;
  costEntry.hook_call_count = hookCallCount;
  costEntry.hook_avg_ms = hookCallCount > 0 ? Math.round(totalHookMs / hookCallCount) : 0;

  // cost-log.jsonl에 저장
  const memDir = path.dirname(COST_FILE);
  if (!fs.existsSync(memDir)) fs.mkdirSync(memDir, { recursive: true });
  fs.appendFileSync(COST_FILE, JSON.stringify(costEntry) + '\n');

  // audit-log에 세션 요약
  fs.appendFileSync(AUDIT_LOG, JSON.stringify({
    timestamp: costEntry.timestamp,
    event: 'session-cost-summary',
    observations: obsTotal,
    hook_total_ms: totalHookMs,
    hook_calls: hookCallCount,
    hook_avg_ms: costEntry.hook_avg_ms,
    phase: costEntry.phase,
    track: costEntry.track
  }) + '\n');

} catch { /* silent */ }

process.exit(0);
