---
name: frontend-security
description: Frontend security — XSS, CSRF, auth tokens, CORS, input sanitization, dependency auditing, secure headers
languages: ["TypeScript", "JavaScript"]
frameworks: ["React", "Vue", "Next.js"]
phases: ["test"]
---

# Frontend Security

## When to Activate

- Rendering user-generated content (HTML, Markdown)
- Handling authentication tokens or session cookies
- Configuring CORS or security headers
- Reviewing code for XSS, CSRF, or injection vulnerabilities
- Auditing npm dependencies for known vulnerabilities
- Setting up Content Security Policy

---

## Core Patterns

### 1. XSS (Cross-Site Scripting) Prevention

**React — `dangerouslySetInnerHTML`:**

React escapes JSX expressions by default, but `dangerouslySetInnerHTML` bypasses this.

```tsx
// DANGEROUS — unsanitized user input
function Comment({ html }: { html: string }) {
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
}

// SAFE — sanitize with DOMPurify before rendering
import DOMPurify from "dompurify";

function Comment({ html }: { html: string }) {
  const clean = DOMPurify.sanitize(html, {
    ALLOWED_TAGS: ["b", "i", "em", "strong", "a", "p", "br"],
    ALLOWED_ATTR: ["href", "title"],
  });
  return <div dangerouslySetInnerHTML={{ __html: clean }} />;
}
```

**Vue — `v-html`:**

```vue
<!-- DANGEROUS — raw HTML injection -->
<div v-html="userContent"></div>

<!-- SAFE — sanitize first -->
<script setup lang="ts">
import DOMPurify from "dompurify";
import { computed } from "vue";

const props = defineProps<{ userContent: string }>();
const safeContent = computed(() =>
  DOMPurify.sanitize(props.userContent, {
    ALLOWED_TAGS: ["b", "i", "em", "strong", "a", "p"],
    ALLOWED_ATTR: ["href"],
  })
);
</script>

<template>
  <div v-html="safeContent"></div>
</template>
```

**Content Security Policy (CSP):**

```ts
// next.config.js — Next.js security headers
const securityHeaders = [
  {
    key: "Content-Security-Policy",
    value: [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "font-src 'self'",
      "connect-src 'self' https://api.example.com",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join("; "),
  },
];

module.exports = {
  async headers() {
    return [{ source: "/(.*)", headers: securityHeaders }];
  },
};
```

**Never inject user input into:**
- `eval()`, `new Function()`, `setTimeout(string)`
- `javascript:` URLs in `href`
- Inline event handlers constructed from strings

```tsx
// DANGEROUS
<a href={`javascript:${userInput}`}>Click</a>

// SAFE — validate URL protocol
function isSafeUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ["http:", "https:", "mailto:"].includes(parsed.protocol);
  } catch {
    return false;
  }
}

<a href={isSafeUrl(userUrl) ? userUrl : "#"}>Click</a>
```

### 2. CSRF (Cross-Site Request Forgery) Protection

**SameSite cookies — first line of defense:**

```ts
// Server-side cookie setting (Express example)
res.cookie("session", token, {
  httpOnly: true,       // Not accessible via JavaScript
  secure: true,         // HTTPS only
  sameSite: "lax",      // Blocks cross-site POST, allows top-level GET
  maxAge: 3600000,      // 1 hour
  path: "/",
});
```

| SameSite Value | Cross-site GET | Cross-site POST |
|---------------|---------------|----------------|
| `strict` | Blocked | Blocked |
| `lax` | Allowed | Blocked |
| `none` | Allowed (requires `secure`) | Allowed (requires `secure`) |

**Anti-CSRF tokens — for state-changing operations:**

```tsx
// Next.js Server Action with CSRF protection
// 1. Generate token on server, embed in form
import { cookies } from "next/headers";
import crypto from "crypto";

export async function generateCsrfToken(): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  const cookieStore = await cookies();
  cookieStore.set("csrf-token", token, {
    httpOnly: true,
    sameSite: "strict",
    secure: true,
  });
  return token;
}

// 2. Validate on submission
export async function handleSubmit(formData: FormData) {
  "use server";
  const cookieStore = await cookies();
  const cookieToken = cookieStore.get("csrf-token")?.value;
  const formToken = formData.get("csrf-token");

  if (!cookieToken || cookieToken !== formToken) {
    throw new Error("CSRF validation failed");
  }
  // Process the form...
}
```

### 3. Authentication Patterns

**HTTP-only cookies vs localStorage:**

| | HTTP-only Cookie | localStorage |
|---|-----------------|-------------|
| XSS access | No (not in JS) | Yes (vulnerable) |
| CSRF risk | Yes (auto-sent) | No (manual attach) |
| Server-side access | Yes | No |
| Recommendation | Preferred for session tokens | Acceptable for non-sensitive prefs |

```ts
// RECOMMENDED: HTTP-only cookie approach
// Server sets the cookie; client never touches the token directly.

// NOT RECOMMENDED: Storing JWT in localStorage
// localStorage.setItem("token", jwt); // Accessible to any XSS payload
```

**Token refresh pattern (cookie-based):**

```ts
// API route that refreshes the session
// app/api/auth/refresh/route.ts
import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function POST() {
  const cookieStore = await cookies();
  const refreshToken = cookieStore.get("refresh-token")?.value;

  if (!refreshToken) {
    return NextResponse.json({ error: "No refresh token" }, { status: 401 });
  }

  const newTokens = await authService.refresh(refreshToken);

  const response = NextResponse.json({ success: true });
  response.cookies.set("access-token", newTokens.access, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    maxAge: 900, // 15 minutes
  });
  response.cookies.set("refresh-token", newTokens.refresh, {
    httpOnly: true,
    secure: true,
    sameSite: "strict",
    maxAge: 604800, // 7 days
  });

  return response;
}
```

### 4. CORS Configuration

```ts
// Express CORS setup
import cors from "cors";

app.use(
  cors({
    origin: ["https://app.example.com", "https://admin.example.com"],
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,           // Allow cookies
    allowedHeaders: ["Content-Type", "Authorization"],
    maxAge: 86400,               // Preflight cache: 24 hours
  })
);

// NEVER do this in production:
// cors({ origin: "*", credentials: true })  // Invalid and insecure
```

```ts
// Next.js route handler CORS
import { NextRequest, NextResponse } from "next/server";

const ALLOWED_ORIGINS = ["https://app.example.com"];

export async function GET(request: NextRequest) {
  const origin = request.headers.get("origin") ?? "";
  const data = await fetchData();

  const response = NextResponse.json(data);

  if (ALLOWED_ORIGINS.includes(origin)) {
    response.headers.set("Access-Control-Allow-Origin", origin);
    response.headers.set("Access-Control-Allow-Credentials", "true");
  }

  return response;
}
```

### 5. Input Sanitization

```ts
// Sanitize for different contexts

// HTML context — use DOMPurify (see XSS section above)

// SQL context — use parameterized queries (never string concatenation)
// ORM handles this: prisma.user.findMany({ where: { name: input } })

// URL parameters — encode user input
const safeParam = encodeURIComponent(userInput);
const url = `/search?q=${safeParam}`;

// File names — strip path traversal characters
function sanitizeFilename(name: string): string {
  return name
    .replace(/[/\\]/g, "")        // Remove path separators
    .replace(/\.\./g, "")         // Remove parent directory refs
    .replace(/[<>:"|?*\x00-\x1f]/g, ""); // Remove invalid chars
}

// Validate expected formats
function isValidEmail(email: string): boolean {
  // Simple structural check — full validation happens server-side
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}
```

### 6. Dependency Vulnerability Management

**npm audit:**

```bash
# Check for known vulnerabilities
npm audit

# Fix automatically where possible
npm audit fix

# See full report in JSON
npm audit --json
```

**Automated scanning in CI:**

```yaml
# .github/workflows/security.yml
name: Security Scan
on:
  push:
    branches: [main]
  schedule:
    - cron: "0 9 * * 1"  # Weekly Monday 9 AM

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npm ci
      - run: npm audit --audit-level=high
```

**Lock file hygiene:**
- Always commit `package-lock.json` / `pnpm-lock.yaml`
- Use `npm ci` (not `npm install`) in CI to use exact lock file versions
- Review lock file diffs in PRs for unexpected changes

### 7. Subresource Integrity (SRI)

When loading scripts or styles from CDNs, use SRI to verify file integrity.

```html
<!-- The browser will refuse to execute if the hash doesn't match -->
<script
  src="https://cdn.example.com/lib.min.js"
  integrity="sha384-oqVuAfXRKap7fdgcCY5uykM6+R9GqQ8K/uxAh6VgnSY..."
  crossorigin="anonymous"
></script>

<link
  rel="stylesheet"
  href="https://cdn.example.com/styles.min.css"
  integrity="sha384-BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB..."
  crossorigin="anonymous"
/>
```

```bash
# Generate SRI hash
cat lib.min.js | openssl dgst -sha384 -binary | openssl base64 -A
```

### 8. Secure Headers

**Next.js headers configuration:**

```ts
// next.config.js
const headers = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-XSS-Protection", value: "0" },  // Deprecated; rely on CSP instead
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
  {
    key: "Strict-Transport-Security",
    value: "max-age=63072000; includeSubDomains; preload",
  },
];

module.exports = {
  async headers() {
    return [{ source: "/(.*)", headers }];
  },
};
```

**Helmet.js for Express:**

```ts
import helmet from "helmet";

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "https://api.example.com"],
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    crossOriginEmbedderPolicy: true,
    crossOriginOpenerPolicy: { policy: "same-origin" },
    crossOriginResourcePolicy: { policy: "same-origin" },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: "strict-origin-when-cross-origin" },
  })
);
```

---

## Anti-Patterns

1. **Storing JWTs in localStorage** — any XSS vulnerability exposes the token. Use HTTP-only cookies for authentication tokens. If you must use localStorage (e.g., third-party auth), keep token lifetimes very short.

2. **Using `dangerouslySetInnerHTML` / `v-html` without sanitization** — always sanitize with DOMPurify before rendering user-generated HTML. No exceptions.

3. **`cors({ origin: "*" })` with credentials** — this is both invalid per spec and a security hole. Whitelist specific origins when credentials are needed.

4. **Disabling CSP for convenience** — "it breaks my inline scripts" is not a valid reason. Use nonces or hashes for inline scripts instead of `'unsafe-inline'` for script-src.

5. **Not running `npm audit` regularly** — known vulnerabilities in dependencies are one of the most common attack vectors. Automate this in CI.

6. **Client-side-only input validation** — client validation is for UX, not security. All validation must be duplicated server-side. An attacker can bypass any client-side check.

7. **Exposing sensitive data in client bundles** — API keys, database URLs, and secrets must never appear in frontend code. Use server-side environment variables and API routes as proxies.

8. **Trusting `Referer` or `Origin` headers alone for CSRF protection** — these can be spoofed in some scenarios. Use anti-CSRF tokens for critical state-changing operations in addition to SameSite cookies.
