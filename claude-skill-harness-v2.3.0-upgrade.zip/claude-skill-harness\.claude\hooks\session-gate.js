// .claude/hooks/session-gate.js
// UserPromptSubmit Hook — 매 사용자 메시지마다 파이프라인 상태를 Claude에 강제 주입
//
// 이 Hook이 해결하는 문제:
//   Claude가 CLAUDE.md를 읽지 않고 바로 답변하는 것을 방지
//   현재 Phase, 활성 PRD/Plan, 미해결 이슈를 매번 주입하여
//   Claude가 상태를 "모르겠다"고 할 수 없게 만든다
//
// 동작 원리:
//   stdout에 텍스트 출력 → <user-prompt-submit-hook>으로 Claude에 주입
//   아무것도 출력하지 않고 exit(0) → 주입 없이 통과

const fs = require('fs');
const path = require('path');

// IMPL-10 (FR-10): Hook 실행 시간 자동 측정
const _hookStart = Date.now();
process.on('exit', () => {
  const elapsed = Date.now() - _hookStart;
  if (elapsed > 100) {
    try {
      const al = path.join(path.resolve(__dirname, '..', '..'), 'docs', 'memory', 'audit-log.jsonl');
      fs.appendFileSync(al, JSON.stringify({
        timestamp: new Date().toISOString(),
        event: 'hook-perf',
        hook: 'session-gate.js',
        elapsed_ms: elapsed
      }) + '\n');
    } catch { /* silent */ }
  }
});

const ROOT = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(ROOT, 'docs', 'memory', 'pipeline-state.json');
const SESSION_FILE = path.join(ROOT, 'docs', 'memory', 'session-context.md');
const CLAUDE_MD = path.join(ROOT, 'CLAUDE.md');
const MARKER_FILE = path.join(ROOT, '.claude', '.pending-prd-review');

// IMPL-04 (RISK-01): 사용자 메시지 읽기 — Claude Code UserPromptSubmit hook은 stdin으로 JSON 전달
// 중요: stdin이 TTY면 readFileSync(0)가 block → timeout. isTTY 검사 필수.
function readUserMessage() {
  // TTY (직접 실행)면 stdin 못 읽음 — 폴백
  if (process.stdin.isTTY) {
    return process.env.CLAUDE_USER_MESSAGE || '';
  }
  try {
    const buf = fs.readFileSync(0, 'utf8');
    if (!buf) return '';
    try {
      const j = JSON.parse(buf);
      return j.prompt || j.message || j.user_message || buf;
    } catch {
      return buf;
    }
  } catch {
    return process.env.CLAUDE_USER_MESSAGE || '';
  }
}

try {
  const output = [];

  // ── 1. pipeline-state.json 확인 ──────────────────────────────────────
  let phase = 'unknown';
  let track = null;
  let activePrd = null;
  let activePlan = null;
  let iterations = null;
  let stateExists = false;

  if (fs.existsSync(STATE_FILE)) {
    stateExists = true;
    try {
      const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      phase = state.phase || 'unknown';
      track = state.track || null;
      activePrd = state.activePrd || null;
      activePlan = state.activePlan || null;
      iterations = state.iterations || null;
      // [FR-02/03] Harness Loop: 에러 피드백 읽기
      var lastFailure = state.lastFailure || null;
      var lastLintResult = state.lastLintResult || null;
      var autoFixCount = state.autoFixCount || 0;
    } catch {
      phase = 'corrupted';
    }
  } else {
    // pipeline-state.json이 없으면 자동 생성 (setup Phase)
    try {
      const memDir = path.join(ROOT, 'docs', 'memory');
      if (!fs.existsSync(memDir)) {
        fs.mkdirSync(memDir, { recursive: true });
      }
      const initState = {
        phase: 'setup',
        track: null,
        activePrd: null,
        activePlan: null,
        artifacts: {},
        updated_at: new Date().toISOString()
      };
      fs.writeFileSync(STATE_FILE, JSON.stringify(initState, null, 2) + '\n');
      phase = 'setup';
      stateExists = true;
    } catch { /* ignore */ }
  }

  // ── 2. CLAUDE.md project_name 확인 ──────────────────────────────────
  let projectName = '';
  let projectVersion = '';
  if (fs.existsSync(CLAUDE_MD)) {
    try {
      const content = fs.readFileSync(CLAUDE_MD, 'utf8');
      const nameMatch = content.match(/project_name:\s*"([^"]*)"/);
      const verMatch = content.match(/version:\s*"([^"]*)"/);
      projectName = nameMatch ? nameMatch[1] : '';
      projectVersion = verMatch ? verMatch[1] : '';
    } catch { /* ignore */ }
  }

  // ── 3. session-context.md 확인 ──────────────────────────────────────
  let sessionPhase = '';
  let activeWork = '';
  let nextTodo = '';
  let unresolvedIssues = '';
  let lastUpdate = '';

  if (fs.existsSync(SESSION_FILE)) {
    try {
      const content = fs.readFileSync(SESSION_FILE, 'utf8');
      // FR-13 / IMPL-13: Phase 정규식 견고화 — 공백/별표/콜론 변형 허용
      const phaseMatch = content.match(/현재\s*Phase\s*\*?\*?\s*[::]\s*(.+?)\s*$/m);
      const workMatch = content.match(/## 진행 중인 작업\n\n?([^\n#]+)/);
      const todoMatch = content.match(/## 다음 할 일\n\n?([^\n#]+)/);
      const issueMatch = content.match(/## 미해결 이슈\n\n?([^\n#]+)/);
      const dateMatch = content.match(/마지막 업데이트\*\*:\s*(.+)/);

      sessionPhase = phaseMatch ? phaseMatch[1].trim() : '';
      activeWork = workMatch ? workMatch[1].trim() : '';
      nextTodo = todoMatch ? todoMatch[1].trim() : '';
      unresolvedIssues = issueMatch ? issueMatch[1].trim() : '';
      lastUpdate = dateMatch ? dateMatch[1].trim() : '';
    } catch { /* ignore */ }
  }

  // ── 4. Plan 진행률 (dev Phase일 때) ─────────────────────────────────
  let planProgress = '';
  if (phase === 'dev' && activePlan) {
    try {
      const planPath = path.join(ROOT, activePlan);
      if (fs.existsSync(planPath)) {
        const content = fs.readFileSync(planPath, 'utf8');
        const done = (content.match(/\[x\]/g) || []).length;
        const inProg = (content.match(/\[~\]/g) || []).length;
        const blocking = (content.match(/\[!\]/g) || []).length;
        const todo = (content.match(/\[ \]/g) || []).length;
        const total = done + inProg + blocking + todo;
        const pct = total > 0 ? Math.round(done / total * 100) : 0;
        planProgress = `${done}/${total}(${pct}%) [진행:${inProg} 블로킹:${blocking} 대기:${todo}]`;
      }
    } catch { /* ignore */ }
  }

  // ── 5. Phase 불일치 감지 ─────────────────────────────────────────────
  let phaseDesync = false;
  if (sessionPhase && stateExists && sessionPhase !== phase &&
      sessionPhase !== '완료' && sessionPhase !== 'unknown' && phase !== 'unknown') {
    phaseDesync = true;
  }

  // ── 6. 출력 조립 ────────────────────────────────────────────────────
  const trackLabel = track ? `Track: ${track}` : 'Track: (미설정→C)';
  output.push('╔══════════════════════════════════════════════════════════════╗');
  output.push('║  PIPELINE STATE (Hook 강제 주입 — 무시 불가)                  ║');
  output.push('╠══════════════════════════════════════════════════════════════╣');
  output.push(`║  Phase: ${phase.padEnd(10)} ${trackLabel.padEnd(18)} Project: ${(projectName || '(미설정)').padEnd(15)} v${projectVersion || '0.1.0'}`);

  if (activePrd) output.push(`║  Active PRD:  ${activePrd}`);
  if (activePlan) output.push(`║  Active Plan: ${activePlan}`);
  if (planProgress) output.push(`║  Progress:    ${planProgress}`);

  // [IMPL-06 / FR-15] post-write-sync Hook 우회 — Draft PRD 스캔 후 마커 없으면 자동 생성
  // Hook 자동 트리거가 죽었어도 session-gate가 매 호출 시 docs/prds 스캔하여 보장
  if (!fs.existsSync(MARKER_FILE)) {
    try {
      const prdsDir = path.join(ROOT, 'docs', 'prds');
      if (fs.existsSync(prdsDir)) {
        // 가장 최근 mtime의 Draft PRD 찾기
        const prdFiles = fs.readdirSync(prdsDir)
          .filter(f => f.endsWith('-prd.md'))
          .map(f => ({ name: f, mtime: fs.statSync(path.join(prdsDir, f)).mtimeMs }))
          .sort((a, b) => b.mtime - a.mtime);
        for (const f of prdFiles) {
          const fp = path.join(prdsDir, f.name);
          const c = fs.readFileSync(fp, 'utf8');
          if (/^- \*\*상태\*\*:\s*Draft/im.test(c)) {
            // Draft PRD 발견 → 마커 자동 생성 (post-write-sync 우회)
            const versionMatch = c.match(/^- \*\*버전\*\*:\s*v?(\d+\.\d+)/im);
            const claudeDir = path.join(ROOT, '.claude');
            if (!fs.existsSync(claudeDir)) fs.mkdirSync(claudeDir, { recursive: true });
            const markerData = {
              prd: `docs/prds/${f.name}`,
              version: versionMatch ? versionMatch[1] : '1.0',
              created_at: new Date(f.mtime).toISOString(),
              updated_at: new Date().toISOString(),
              source: 'session-gate-fallback'
            };
            try {
              fs.writeFileSync(MARKER_FILE, JSON.stringify(markerData, null, 2) + '\n');
            } catch { /* silent */ }
            break;
          }
        }
      }
    } catch { /* silent */ }
  }

  // [IMPL-04~06 early] PRD 검토 마커 처리 — markerInfo 사용 전 처리
  let markerInfo = null;
  let markerCleared = false;
  let markerExpired = null;
  if (fs.existsSync(MARKER_FILE)) {
    try {
      const marker = JSON.parse(fs.readFileSync(MARKER_FILE, 'utf8'));
      // [BUG FIX] PRD가 이미 Approved/Completed면 마커 삭제 (stale 방지)
      const markerPrdPath = path.join(ROOT, marker.prd);
      if (fs.existsSync(markerPrdPath)) {
        const prdContent = fs.readFileSync(markerPrdPath, 'utf8');
        if (/^- \*\*상태\*\*:\s*(Approved|Completed|Superseded)/im.test(prdContent)) {
          try { fs.unlinkSync(MARKER_FILE); } catch {}
          // stale 마커 — 표시하지 않음
        }
      }

      const ageHours = (Date.now() - new Date(marker.created_at).getTime()) / (1000 * 60 * 60);
      if (!fs.existsSync(MARKER_FILE)) {
        // 위에서 삭제됨 — skip
      } else if (ageHours > 72) {
        try {
          fs.unlinkSync(MARKER_FILE);
          fs.appendFileSync(path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl'), JSON.stringify({
            timestamp: new Date().toISOString(),
            event: 'prd-review-expired',
            prd: marker.prd,
            age_hours: Math.round(ageHours)
          }) + '\n');
        } catch { /* silent */ }
        markerExpired = { prd: marker.prd, age: Math.round(ageHours) };
      } else {
        const userMsg = readUserMessage();
        const approvalRegex = /\b(approve|승인|OK|진행시켜|진행해|진행하자|좋아|good|승인해)\b/i;
        if (userMsg && approvalRegex.test(userMsg)) {
          try {
            fs.unlinkSync(MARKER_FILE);
            fs.appendFileSync(path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl'), JSON.stringify({
              timestamp: new Date().toISOString(),
              event: 'prd-review-cleared',
              prd: marker.prd,
              method: 'user-keyword'
            }) + '\n');
          } catch { /* silent */ }
          markerCleared = marker.prd;
        } else {
          markerInfo = marker;
        }
      }
    } catch { /* silent */ }
  }

  // [IMPL-05 / FR-09] PRD 검토 마커 강조
  if (markerInfo) {
    output.push(`║  📋 검토대기:  ${markerInfo.prd} (v${markerInfo.version})`);
  }

  // [IMPL-06] iterations 표시
  if (iterations && iterations.total_backwards > 0) {
    const items = Object.entries(iterations)
      .filter(([k]) => k !== 'total_backwards')
      .map(([k, v]) => `${k} x${v}`)
      .join(', ');
    output.push(`║  🔁 Iterations: ${items} (total: ${iterations.total_backwards})`);
  }

  // [IMPL-08 / FR-10] TDD 단계 표시 — audit-log 마지막 backward-transition reason에서 추출
  try {
    const auditFile = path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl');
    if (fs.existsSync(auditFile)) {
      const lines = fs.readFileSync(auditFile, 'utf8').trim().split('\n').slice(-30);
      let lastTddPhase = null;
      // 가장 최근 backward-transition 찾기
      for (let i = lines.length - 1; i >= 0; i--) {
        try {
          const e = JSON.parse(lines[i]);
          if (e.event === 'backward-transition' && e.reason) {
            const m = e.reason.match(/\[(Red|Green|Refactor)\]/i);
            if (m) {
              const phase = m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
              const icon = { Red: '🔴', Green: '🟢', Refactor: '🔵' }[phase] || '';
              lastTddPhase = `${icon} ${phase}`;
              break;
            }
          }
        } catch { /* skip */ }
      }
      if (lastTddPhase) {
        output.push(`║  TDD: ${lastTddPhase}`);
      }
    }
  } catch { /* ignore */ }

  if (activeWork && activeWork !== '없음' && activeWork !== '{현재') {
    output.push(`║  Working On:  ${activeWork.substring(0, 60)}`);
  }

  if (unresolvedIssues && unresolvedIssues !== '없음' && !unresolvedIssues.startsWith('{')) {
    output.push(`║  ⚠ Issues:    ${unresolvedIssues.substring(0, 60)}`);
  }

  // ── 6b. [FR-03] Harness Loop: 에러 피드백 주입 ──────────────────────
  if (lastFailure && lastFailure.message) {
    const errFile = lastFailure.file ? ` (${lastFailure.file})` : '';
    const errType = lastFailure.type === 'lint' ? '⚠ Lint' : '🔴 Test';
    output.push(`║  ${errType} 실패${errFile}: ${lastFailure.message.substring(0, 80)}`);
    if (autoFixCount > 0) {
      output.push(`║  🔄 자동 수정 시도: ${autoFixCount}회`);
    }
  }

  // ── 6c. [FR-09] 린트 결과 주입 ─────────────────────────────────────
  if (lastLintResult && (lastLintResult.errors > 0 || lastLintResult.warnings > 0)) {
    output.push(`║  ⚠ Lint: ${lastLintResult.errors}E ${lastLintResult.warnings}W — ${(lastLintResult.summary || '').substring(0, 60)}`);
  }

  // ── 6d. [FR-10] Phase별 SKILL 경로 주입 ────────────────────────────
  const PHASE_SKILL_MAP = {
    analysis: 'analysis', prd: 'prd', plan: 'plan',
    dev: 'monitoring', test: 'test', report: 'report'
  };
  if (PHASE_SKILL_MAP[phase]) {
    output.push(`║  📖 참조: .claude/skills/${PHASE_SKILL_MAP[phase]}/SKILL.md`);
  }

  // ── 6e. [FR-06] 키워드 기반 Track 추천 ─────────────────────────────
  if (!track || phase === 'setup' || phase === 'complete' || phase === 'analysis') {
    const userMsg = readUserMessage();
    if (userMsg && userMsg.length > 2) {
      let suggestedTrack = null;
      let matchedKeyword = '';
      // Track A 키워드
      if (/(?:뭐야|설명해|어떻게\s*돼|알려줘|보여줘|무슨|왜\s|언제|어디)/i.test(userMsg)) {
        suggestedTrack = 'A'; matchedKeyword = userMsg.match(/(?:뭐야|설명해|어떻게\s*돼|알려줘|보여줘|무슨|왜\s|언제|어디)/i)[0];
      }
      // Track C 키워드 (B보다 먼저 — 더 구체적)
      else if (/(?:만들어|구현해|리팩토링|아키텍처|설계해|새\s*기능|모듈\s*추가)/i.test(userMsg)) {
        suggestedTrack = 'C'; matchedKeyword = userMsg.match(/(?:만들어|구현해|리팩토링|아키텍처|설계해|새\s*기능|모듈\s*추가)/i)[0];
      }
      // Track B 키워드
      else if (/(?:바꿔|수정해|고쳐|추가해|삭제해|변경해|업데이트해|패치)/i.test(userMsg)) {
        suggestedTrack = 'B'; matchedKeyword = userMsg.match(/(?:바꿔|수정해|고쳐|추가해|삭제해|변경해|업데이트해|패치)/i)[0];
      }
      if (suggestedTrack) {
        output.push(`║  💡 Track 추천: ${suggestedTrack} (키워드: '${matchedKeyword}') — 5축 점수로 확정`);
      }

      // ── 6f. [FR-07] 모호성 감지 ────────────────────────────────────
      const hasVerb = /(?:해줘|하자|해봐|만들|수정|분석|설명|구현|작성|실행|테스트|검토|보여)/i.test(userMsg);
      const hasPronounOnly = /^(?:이거|그거|저거|이것|그것|저것)\s*$/.test(userMsg.trim());
      if ((userMsg.length < 15 && !hasVerb) || hasPronounOnly) {
        output.push('║  ❓ 모호한 요청 감지 — 구체적 설명 권장');
      }
    }
  }

  // ── 7. 필수 조치 (ACTION REQUIRED) ──────────────────────────────────
  const actions = [];

  // 프로젝트 미설정
  if (!projectName) {
    actions.push('CLAUDE.md project_name 비어있음 → 프로젝트 설정 인터뷰 실행 (CLAUDE.md "세션 시작 루틴 Step 1")');
  }

  // Phase 불일치 — IMPL-06 (FR-06): 자동 동기화
  if (phaseDesync) {
    try {
      let sc = fs.readFileSync(SESSION_FILE, 'utf8');
      sc = sc.replace(/- \*\*현재 Phase\*\*:\s*.+/, `- **현재 Phase**: ${phase}`);
      fs.writeFileSync(SESSION_FILE, sc);
      actions.push(`Phase 자동 동기화: session-context → ${phase} (pipeline-state 기준)`);
    } catch {
      actions.push(`Phase 불일치 감지! pipeline-state=${phase} ≠ session-context=${sessionPhase}`);
    }
  }

  // 블로킹 태스크
  if (planProgress && planProgress.includes('블로킹:') && !planProgress.includes('블로킹:0')) {
    actions.push('블로킹 태스크 존재 → monitoring 스킬 읽고 우선 해결');
  }

  // Resume 지점
  if (nextTodo && nextTodo !== '없음' && !nextTodo.startsWith('{') && phase === 'dev') {
    actions.push(`Resume: ${nextTodo.substring(0, 70)}`);
  }

  // 세션 컨텍스트 미갱신 (3일 이상)
  if (lastUpdate && lastUpdate !== '{YYYY-MM-DD HH:mm}') {
    try {
      const lastDate = new Date(lastUpdate);
      const now = new Date();
      const daysDiff = Math.floor((now - lastDate) / (1000 * 60 * 60 * 24));
      if (daysDiff > 3) {
        actions.push(`session-context.md가 ${daysDiff}일간 미갱신 → 현재 상태 확인 후 갱신 필요`);
      }
    } catch { /* ignore date parsing */ }
  }

  // 마커 처리는 위(line 178 부근)에서 이미 완료. ACTION 알림만 남김.
  if (markerExpired) {
    actions.push(`⏰ PRD 검토 마커 자동 만료 (${markerExpired.age}시간 경과): ${markerExpired.prd}`);
  }
  if (markerCleared) {
    actions.push(`✅ PRD 검토 승인 키워드 감지 — 마커 해제: ${markerCleared}`);
  }
  if (markerInfo) {
    actions.push(`📋 PRD 검토 대기 중: ${markerInfo.prd} — "approve"/"승인"/"OK"/"진행" 또는 수정 요청`);
  }

  // [IMPL-11 / FR-11] Track 미설정 시 추천
  if (!track && phase !== 'unknown' && phase !== 'corrupted') {
    actions.push('Track 미설정 — `node .claude/hooks/advance-phase.js set-track <A|B|C>` 권장 (현재 C 폴백 중)');
  }

  // [IMPL-04 / FR-05] PRD 검토 대기 표시
  // prds/ 에 Draft 상태 PRD가 있으면 표시
  try {
    const prdsDir = path.join(ROOT, 'docs', 'prds');
    if (fs.existsSync(prdsDir)) {
      const prdFiles = fs.readdirSync(prdsDir).filter(f => f.endsWith('-prd.md'));
      for (const f of prdFiles) {
        const fp = path.join(prdsDir, f);
        try {
          const c = fs.readFileSync(fp, 'utf8');
          if (/^- \*\*상태\*\*:\s*Draft/im.test(c)) {
            actions.push(`📋 Awaiting Review: docs/prds/${f}`);
            actions.push(`   → 승인: node .claude/hooks/advance-phase.js approve prd "코멘트"`);
            break; // 첫 Draft만 표시
          }
        } catch { /* ignore */ }
      }
    }
  } catch { /* ignore */ }

  // [IMPL-13] Track B dev-journal 리마인더
  // Track B + analysis → dev 진입 전 dev-journal 작성 안내
  if (track === 'B' && phase === 'analysis') {
    actions.push('Track B: dev 전환 전 docs/memory/dev-journal.md 에 작업 엔트리 작성 필수');
  }
  if (track === 'B' && phase === 'dev') {
    // dev-journal 최근 갱신 확인
    try {
      const journalFile = path.join(ROOT, 'docs', 'memory', 'dev-journal.md');
      if (fs.existsSync(journalFile)) {
        const content = fs.readFileSync(journalFile, 'utf8');
        const hasEntry = /^### \[\d{4}-\d{2}-\d{2}/m.test(content);
        if (!hasEntry) {
          actions.push('Track B dev 단계인데 dev-journal에 엔트리 없음 → 즉시 작성 필요');
        }
      } else {
        actions.push('Track B dev 단계인데 dev-journal.md 파일 없음 → 생성 필요');
      }
    } catch { /* ignore */ }
  }

  // [IMPL-12] Hook 작동 감지 — audit-log 마지막 Write vs 실제 docs/ mtime
  try {
    const auditFile = path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl');
    if (fs.existsSync(auditFile)) {
      const lines = fs.readFileSync(auditFile, 'utf8').trim().split('\n').slice(-50);
      let lastWriteTime = 0;
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          if (entry.tool === 'Write' || entry.tool === 'Edit') {
            const t = new Date(entry.timestamp).getTime();
            if (t > lastWriteTime) lastWriteTime = t;
          }
        } catch { /* skip */ }
      }

      // docs/ 내 가장 최근 .md 파일 mtime 확인
      let latestDocMtime = 0;
      const subdirs = ['analysis', 'prds', 'plans', 'tests', 'reports'];
      for (const sub of subdirs) {
        const dir = path.join(ROOT, 'docs', sub);
        if (!fs.existsSync(dir)) continue;
        try {
          const files = fs.readdirSync(dir).filter(f => f.endsWith('.md'));
          for (const f of files) {
            const m = fs.statSync(path.join(dir, f)).mtimeMs;
            if (m > latestDocMtime) latestDocMtime = m;
          }
        } catch { /* skip */ }
      }

      // 5분(300000ms) 이상 차이 시 Hook 미작동 의심
      if (latestDocMtime > 0 && lastWriteTime > 0 &&
          latestDocMtime - lastWriteTime > 300000) {
        actions.push('⚠ Hook 미작동 의심: post-write-sync 자동 트리거 누락 가능. ' +
          'advance-phase.js 사용 시 self-heal 자동 실행됨');
      }
    }
  } catch { /* ignore */ }

  // [IMPL-14] 에러/차단 후 dev-journal 미기록 감지
  try {
    const auditFile = path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl');
    if (fs.existsSync(auditFile)) {
      const lines = fs.readFileSync(auditFile, 'utf8').trim().split('\n').slice(-10);
      let hasRecentBlock = false;
      let lastBlockTime = null;
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          if (entry.event && /block|force-override|circular|untested/i.test(entry.event)) {
            hasRecentBlock = true;
            lastBlockTime = entry.timestamp;
          }
        } catch { /* skip malformed */ }
      }

      if (hasRecentBlock && lastBlockTime) {
        // dev-journal 최종 수정 시각과 비교
        const journalFile = path.join(ROOT, 'docs', 'memory', 'dev-journal.md');
        if (fs.existsSync(journalFile)) {
          const stat = fs.statSync(journalFile);
          const journalMtime = stat.mtime.getTime();
          const blockTime = new Date(lastBlockTime).getTime();
          if (journalMtime < blockTime) {
            actions.push('최근 차단/이슈 발생 후 dev-journal 미갱신 → 시행착오 기록 필요');
          }
        } else {
          actions.push('최근 차단/이슈 발생 → docs/memory/dev-journal.md 생성 후 기록 필요');
        }
      }
    }
  } catch { /* ignore */ }

  if (actions.length > 0) {
    output.push('╠══════════════════════════════════════════════════════════════╣');
    output.push('║  ▶ ACTION REQUIRED:');
    actions.forEach((a, i) => output.push(`║    ${i + 1}. ${a}`));
  }

  // ── 7b. Agent 추천 + Domain Skills + Rules 주입 (FR-03, FR-07) ────
  try {
    const _agentsModule = require('./_agents');
    const _configModule = require('./_config');

    // Agent 추천 (FR-03)
    if (_configModule.getConfigValue('features.agent_recommendations', true)) {
      const agents = _agentsModule.getAgentsForPhase(phase);
      if (agents.length > 0) {
        output.push('╠══════════════════════════════════════════════════════════════╣');
        const agentList = agents.map(a => `${a.name}(${a.model})`).join(', ');
        output.push(`║  💡 Agent 추천: ${agentList}`);
      }
    }

    // Domain Skills 주입 (FR-07)
    if (_configModule.getConfigValue('features.domain_skill_injection', true)) {
      const lang = _configModule.getConfigValue('project.language', '');
      const fw = _configModule.getConfigValue('project.framework', '');
      if (lang || fw) {
        const skills = _agentsModule.getDomainSkillsForProject(lang, fw);
        if (skills.length > 0) {
          const skillList = skills.map(s => s.name).slice(0, 6).join(', ');
          const suffix = skills.length > 6 ? ` +${skills.length - 6}` : '';
          output.push(`║  📚 Domain: ${skillList}${suffix}`);
        }
        const rules = _agentsModule.getActiveRules(lang);
        if (rules.length > 0) {
          const ruleList = rules.map(r => `${r.pack}(${r.rules.join(',')})`).join(', ');
          output.push(`║  📏 Rules: ${ruleList}`);
        }
      }
    }
  } catch { /* silent — agent/domain 시스템 오류가 세션을 차단하면 안 됨 */ }

  // ── 7c. Instinct 주입 (FR-06) ─────────────────────────────────────
  try {
    const _learningModule = require('./_learning');
    const instincts = _learningModule.loadAllInstincts();
    const topInstincts = instincts
      .filter(i => i.confidence >= 0.7)
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 3);
    if (topInstincts.length > 0) {
      output.push('╠══════════════════════════════════════════════════════════════╣');
      topInstincts.forEach(i => {
        output.push(`║  🧠 Learned: ${i.pattern.substring(0, 60)} (${i.confidence})`);
      });
    }
  } catch { /* silent */ }

  // ── 7d. Cost 요약 (최근 세션) ─────────────────────────────────────
  try {
    const costFile = path.join(ROOT, 'docs', 'memory', 'cost-log.jsonl');
    if (fs.existsSync(costFile)) {
      const costLines = fs.readFileSync(costFile, 'utf8').trim().split('\n').filter(Boolean);
      if (costLines.length > 0) {
        const last = JSON.parse(costLines[costLines.length - 1]);
        if (last.hook_avg_ms !== undefined) {
          output.push(`║  📊 Cost: ${costLines.length} sessions | Hook avg ${last.hook_avg_ms}ms | ${last.observations || 0} obs`);
        }
      }
    }
  } catch { /* silent */ }

  // ── 8. Behavioral Feedback (Tier 1) 주입 ──────────────────────────
  try {
    const fbFile = path.join(ROOT, 'docs', 'memory', 'feedback-rules.json');
    if (fs.existsSync(fbFile)) {
      const rules = JSON.parse(fs.readFileSync(fbFile, 'utf8'));
      const active = rules.filter(r => {
        if (!r.active || r.action === 'block') return false;
        if (r.trigger && r.trigger.phase && r.trigger.phase !== '*') {
          const phases = r.trigger.phase.split('|');
          if (!phases.includes(phase)) return false;
        }
        return true;
      });
      if (active.length > 0) {
        output.push('╠══════════════════════════════════════════════════════════════╣');
        output.push('║  ⚠ BEHAVIORAL REMINDERS:');
        const icons = { critical: '🔴', high: '🟠', medium: '🟡', low: '⚪' };
        active.slice(0, 3).forEach(r => {
          const icon = icons[r.severity] || '';
          output.push(`║    ${icon} [${r.id}] ${r.message.substring(0, 65)}`);
        });
      }
    }
  } catch { /* silent — feedback 시스템 오류가 세션을 차단하면 안 됨 */ }

  // ── 8b. session-context 미갱신 경고 (H2) ───────────────────────────
  try {
    const scFile = path.join(ROOT, 'docs', 'memory', 'session-context.md');
    if (fs.existsSync(scFile)) {
      const scStat = fs.statSync(scFile);
      const ageHours = (Date.now() - scStat.mtimeMs) / (1000 * 60 * 60);
      if (ageHours > 2 && phase !== 'setup' && phase !== 'complete') {
        output.push('╠══════════════════════════════════════════════════════════════╣');
        output.push(`║  ⏰ session-context.md ${Math.floor(ageHours)}시간 미갱신 — 현재 작업 반영 필요`);
      }
    }
  } catch { /* silent */ }

  // ── 9. 응답 의무 리마인더 ────────────────────────────────────────────
  output.push('╠══════════════════════════════════════════════════════════════╣');
  output.push('║  ▶ 매 응답 전: CLAUDE.md A/B/C 복잡도 점수 판단 필수          ║');
  output.push('║  ▶ 매 응답 후: session-context.md(Rule1) + INDEX.md(Rule2)   ║');
  output.push('╚══════════════════════════════════════════════════════════════╝');

  console.log(output.join('\n'));

} catch {
  // Hook 오류 시 아무것도 출력하지 않음 — 사용자 프롬프트 차단 방지
}

process.exit(0);
