---
name: vuejs-patterns
description: Vue 3 Composition API, composables, Pinia stores, Vue Router, Nuxt 3, and advanced patterns
languages: ["TypeScript", "JavaScript"]
frameworks: ["Vue", "Vue 3", "Nuxt", "Pinia"]
phases: ["dev", "test"]
---

# Vue.js Patterns

## When to Activate

- Project uses Vue 3 with Composition API or `<script setup>`
- Building composables for reusable stateful logic
- Managing state with Pinia stores
- Routing with Vue Router or Nuxt 3 conventions
- Using Nuxt 3 features (auto-imports, useFetch, server routes)

---

## Core Patterns

### 1. Composition API Fundamentals

```vue
<script setup lang="ts">
import { ref, reactive, computed, watch, watchEffect } from "vue";

// ref — single value (access via .value in script, auto-unwrapped in template)
const count = ref(0);

// reactive — deep reactive object (no .value needed, but can't reassign root)
const form = reactive({
  name: "",
  email: "",
});

// computed — derived value, cached until dependencies change
const doubleCount = computed(() => count.value * 2);

// watch — react to specific source changes
watch(count, (newVal, oldVal) => {
  console.log(`count changed: ${oldVal} → ${newVal}`);
});

// watch with options
watch(
  () => form.name,
  (newName) => {
    console.log(`name changed to: ${newName}`);
  },
  { immediate: true, deep: false }
);

// watchEffect — auto-tracks dependencies, runs immediately
watchEffect(() => {
  console.log(`Current count: ${count.value}, name: ${form.name}`);
});

function increment() {
  count.value++;
}
</script>

<template>
  <button @click="increment">{{ count }} (double: {{ doubleCount }})</button>
  <input v-model="form.name" placeholder="Name" />
  <input v-model="form.email" placeholder="Email" />
</template>
```

**ref vs reactive:**

| | `ref` | `reactive` |
|---|-------|-----------|
| Primitives | Yes | No |
| Objects | Yes (wrap) | Yes |
| Reassign root | Yes (`x.value = newObj`) | No |
| Destructure | Loses reactivity | Loses reactivity (use `toRefs`) |

### 2. Composables (`useXxx`)

Composables extract reusable stateful logic. Convention: `use` prefix, return refs/methods.

```ts
// composables/useFetch.ts
import { ref, type Ref } from "vue";

interface UseFetchReturn<T> {
  data: Ref<T | null>;
  error: Ref<string | null>;
  loading: Ref<boolean>;
  execute: () => Promise<void>;
}

export function useFetch<T>(url: string): UseFetchReturn<T> {
  const data = ref<T | null>(null) as Ref<T | null>;
  const error = ref<string | null>(null);
  const loading = ref(false);

  async function execute() {
    loading.value = true;
    error.value = null;
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      data.value = await response.json();
    } catch (e) {
      error.value = (e as Error).message;
    } finally {
      loading.value = false;
    }
  }

  execute(); // auto-fetch on creation

  return { data, error, loading, execute };
}
```

```vue
<script setup lang="ts">
import { useFetch } from "@/composables/useFetch";

interface User {
  id: number;
  name: string;
}

const { data: users, loading, error } = useFetch<User[]>("/api/users");
</script>

<template>
  <div v-if="loading">Loading...</div>
  <div v-else-if="error">Error: {{ error }}</div>
  <ul v-else>
    <li v-for="user in users" :key="user.id">{{ user.name }}</li>
  </ul>
</template>
```

**Mouse position composable:**

```ts
// composables/useMouse.ts
import { ref, onMounted, onUnmounted } from "vue";

export function useMouse() {
  const x = ref(0);
  const y = ref(0);

  function update(event: MouseEvent) {
    x.value = event.pageX;
    y.value = event.pageY;
  }

  onMounted(() => window.addEventListener("mousemove", update));
  onUnmounted(() => window.removeEventListener("mousemove", update));

  return { x, y };
}
```

### 3. Pinia Store

```ts
// stores/counter.ts
import { defineStore } from "pinia";
import { ref, computed } from "vue";

// Setup syntax (recommended — mirrors Composition API)
export const useCounterStore = defineStore("counter", () => {
  // state
  const count = ref(0);

  // getters
  const doubleCount = computed(() => count.value * 2);

  // actions
  function increment() {
    count.value++;
  }

  async function fetchAndSet(url: string) {
    const res = await fetch(url);
    const data = await res.json();
    count.value = data.count;
  }

  return { count, doubleCount, increment, fetchAndSet };
});
```

```ts
// stores/user.ts — Options syntax (alternative)
import { defineStore } from "pinia";

interface UserState {
  name: string;
  isLoggedIn: boolean;
}

export const useUserStore = defineStore("user", {
  state: (): UserState => ({
    name: "",
    isLoggedIn: false,
  }),
  getters: {
    greeting: (state) => `Hello, ${state.name || "Guest"}`,
  },
  actions: {
    login(name: string) {
      this.name = name;
      this.isLoggedIn = true;
    },
    logout() {
      this.$patch({ name: "", isLoggedIn: false });
    },
  },
});
```

**Using a store in a component:**

```vue
<script setup lang="ts">
import { useCounterStore } from "@/stores/counter";
import { storeToRefs } from "pinia";

const store = useCounterStore();

// storeToRefs preserves reactivity for state/getters
const { count, doubleCount } = storeToRefs(store);

// actions are plain functions — destructure directly
const { increment } = store;
</script>

<template>
  <p>{{ count }} (x2 = {{ doubleCount }})</p>
  <button @click="increment">+1</button>
</template>
```

### 4. Vue Router

```ts
// router/index.ts
import { createRouter, createWebHistory } from "vue-router";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", component: () => import("@/views/Home.vue") },
    {
      path: "/dashboard",
      component: () => import("@/views/Dashboard.vue"),
      meta: { requiresAuth: true },
      children: [
        { path: "settings", component: () => import("@/views/Settings.vue") },
      ],
    },
    { path: "/user/:id", component: () => import("@/views/User.vue") },
    { path: "/:pathMatch(.*)*", component: () => import("@/views/404.vue") },
  ],
});

// Navigation guard
router.beforeEach((to, from) => {
  const userStore = useUserStore();
  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    return { path: "/login", query: { redirect: to.fullPath } };
  }
});

export default router;
```

**Using route params in a component:**

```vue
<script setup lang="ts">
import { useRoute, useRouter } from "vue-router";

const route = useRoute();
const router = useRouter();

// Access reactive params
const userId = computed(() => route.params.id as string);

// Programmatic navigation
function goHome() {
  router.push("/");
}
</script>
```

### 5. Nuxt 3

**Auto-imports:** Nuxt auto-imports Vue APIs, composables from `composables/`, and utilities from `utils/`.

```vue
<!-- No imports needed in Nuxt 3 -->
<script setup lang="ts">
// ref, computed, watch — auto-imported from Vue
// useFetch, useAsyncData, navigateTo — auto-imported from Nuxt
const count = ref(0);
</script>
```

**Data fetching:**

```vue
<script setup lang="ts">
// useFetch — wrapper around $fetch with SSR support
const { data: posts, pending, error, refresh } = await useFetch("/api/posts", {
  query: { page: 1 },
  transform: (raw) => raw.map((p) => ({ ...p, title: p.title.trim() })),
});

// useAsyncData — more control, custom key
const { data: user } = await useAsyncData("current-user", () =>
  $fetch("/api/me")
);

// Lazy variants — don't block navigation
const { data: stats, pending: statsLoading } = useLazyFetch("/api/stats");
</script>
```

**Server routes:**

```ts
// server/api/posts.get.ts
export default defineEventHandler(async (event) => {
  const query = getQuery(event);
  const posts = await db.post.findMany({ take: Number(query.limit) || 10 });
  return posts;
});

// server/api/posts.post.ts
export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  const post = await db.post.create({ data: body });
  return post;
});
```

### 6. Template Refs

```vue
<script setup lang="ts">
import { ref, onMounted } from "vue";

const inputRef = ref<HTMLInputElement | null>(null);

onMounted(() => {
  inputRef.value?.focus();
});
</script>

<template>
  <input ref="inputRef" type="text" />
</template>
```

### 7. Provide / Inject

```ts
// Parent — provide a value
import { provide, ref } from "vue";

const theme = ref("dark");
provide("theme", theme); // reactive injection
```

```ts
// Deeply nested child — inject the value
import { inject, type Ref } from "vue";

const theme = inject<Ref<string>>("theme");
// Use with default: inject("theme", ref("light"))
```

### 8. Custom Directives

```ts
// directives/vFocus.ts
import type { Directive } from "vue";

export const vFocus: Directive = {
  mounted(el: HTMLElement) {
    el.focus();
  },
};
```

```vue
<script setup lang="ts">
import { vFocus } from "@/directives/vFocus";
</script>

<template>
  <input v-focus type="text" />
</template>
```

### 9. Teleport

```vue
<template>
  <button @click="showModal = true">Open Modal</button>

  <!-- Renders inside <body>, not inside this component's DOM -->
  <Teleport to="body">
    <div v-if="showModal" class="modal-overlay" @click.self="showModal = false">
      <div class="modal-content">
        <h2>Modal Title</h2>
        <p>Content rendered outside component tree.</p>
        <button @click="showModal = false">Close</button>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
const showModal = ref(false);
</script>
```

---

## Anti-Patterns

1. **Using Options API in new Vue 3 projects** — Composition API with `<script setup>` is more concise, tree-shakeable, and TypeScript-friendly. Prefer it for all new code.

2. **Destructuring reactive objects without `toRefs`** — loses reactivity:
   ```ts
   // BAD: count is no longer reactive
   const { count } = store;

   // GOOD
   const { count } = storeToRefs(store);
   ```

3. **Mutating props directly** — Vue emits warnings. Use `emit` or `defineModel()` (Vue 3.4+) instead.

4. **Overusing `watch` when `computed` suffices** — if you only need a derived value, use `computed`. Reserve `watch` for side effects (API calls, DOM manipulation).

5. **Putting business logic in components** — extract to composables or Pinia stores. Components should focus on UI rendering and user interaction.

6. **Ignoring Nuxt auto-imports** — manually importing `ref`, `computed`, `useFetch` in Nuxt adds noise. Trust the auto-import system, configure it in `nuxt.config.ts` if needed.

7. **Using `reactive` for primitives** — `reactive` only works with objects. Use `ref` for strings, numbers, booleans.

8. **Not using `$patch` for batch state updates in Pinia** — multiple individual mutations trigger multiple subscriber notifications. Use `$patch` to batch them:
   ```ts
   // BAD: two separate triggers
   store.name = "Alice";
   store.age = 30;

   // GOOD: single trigger
   store.$patch({ name: "Alice", age: 30 });
   ```
