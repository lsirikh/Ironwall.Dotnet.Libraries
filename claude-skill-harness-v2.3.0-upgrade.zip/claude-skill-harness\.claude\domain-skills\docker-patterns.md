---
name: "Docker Patterns"
description: "Dockerfile best practices, Docker Compose configuration, multi-stage builds, and language-specific containerization patterns"
languages: ["Python", "C#", "TypeScript"]
frameworks: ["Docker", "Docker Compose"]
phases: ["dev", "test"]
---

# Docker Patterns

## When to Activate

- Dockerfile 작성 또는 최적화
- Docker Compose 설정 (로컬 개발 환경, 다중 서비스)
- 컨테이너 이미지 크기 줄이기, 빌드 시간 단축
- 개발/프로덕션 환경별 설정 분리
- 컨테이너 헬스체크, 로깅, 시크릿 관리

---

## Core Patterns

### 1. Dockerfile Best Practices

**핵심 원칙:**
- 레이어 캐싱을 활용하여 빌드 속도를 높인다
- 변경 빈도가 낮은 명령을 위에, 높은 명령을 아래에 배치
- .dockerignore로 불필요한 파일을 제외한다
- 프로덕션에서는 반드시 non-root 사용자로 실행한다

```dockerfile
# 나쁜 예 — 모든 파일 복사 후 의존성 설치 (캐시 무효화)
COPY . /app
RUN pip install -r requirements.txt

# 좋은 예 — 의존성 파일만 먼저 복사 (캐시 활용)
COPY requirements.txt /app/
RUN pip install -r requirements.txt
COPY . /app
```

### 2. Multi-Stage Builds

빌드 도구를 최종 이미지에서 제거하여 크기를 줄인다.

**Python:**
```dockerfile
# === Build Stage ===
FROM python:3.12-slim AS builder
WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir --prefix=/install -r requirements.txt

COPY . .

# === Runtime Stage ===
FROM python:3.12-slim AS runtime
WORKDIR /app

# non-root 사용자 생성
RUN groupadd -r appuser && useradd -r -g appuser appuser

# 빌드 결과만 복사
COPY --from=builder /install /usr/local
COPY --from=builder /app /app

USER appuser
EXPOSE 8000

HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1

CMD ["gunicorn", "main:app", "-w", "4", "-k", "uvicorn.workers.UvicornWorker", "-b", "0.0.0.0:8000"]
```

**C# .NET:**
```dockerfile
# === Build Stage ===
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src

# 프로젝트 파일만 먼저 복사하여 restore 캐싱
COPY *.csproj .
RUN dotnet restore

COPY . .
RUN dotnet publish -c Release -o /app/publish --no-restore

# === Runtime Stage ===
FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS runtime
WORKDIR /app

RUN groupadd -r appuser && useradd -r -g appuser appuser

COPY --from=build /app/publish .

USER appuser
EXPOSE 8080

HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD curl -f http://localhost:8080/health || exit 1

ENTRYPOINT ["dotnet", "MyApp.dll"]
```

**TypeScript (Node.js):**
```dockerfile
# === Build Stage ===
FROM node:20-alpine AS builder
WORKDIR /app

# package.json만 먼저 복사하여 npm ci 캐싱
COPY package.json package-lock.json ./
RUN npm ci --only=production && cp -R node_modules /prod_modules
RUN npm ci  # devDependencies 포함 (빌드용)

COPY . .
RUN npm run build

# === Runtime Stage ===
FROM node:20-alpine AS runtime
WORKDIR /app

RUN addgroup -S appuser && adduser -S appuser -G appuser

# production 의존성만 복사
COPY --from=builder /prod_modules ./node_modules
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/package.json .

USER appuser
EXPOSE 3000

HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
  CMD wget --no-verbose --tries=1 --spider http://localhost:3000/health || exit 1

CMD ["node", "dist/index.js"]
```

### 3. .dockerignore

```gitignore
# Version Control
.git
.gitignore

# IDE
.vscode
.idea
*.swp

# Dependencies (컨테이너 내부에서 설치)
node_modules
__pycache__
*.pyc
.venv
venv

# Build outputs
dist
build
bin
obj

# Environment & Secrets
.env
.env.*
*.pem
*.key

# Docker
Dockerfile*
docker-compose*
.dockerignore

# Docs & Tests (프로덕션 이미지에 불필요)
docs
tests
*.md
LICENSE
```

### 4. Docker Compose — Development Environment

```yaml
# docker-compose.yml — 기본 설정
version: "3.9"

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: runtime          # multi-stage의 특정 단계
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/mydb
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_healthy
    networks:
      - backend
    restart: unless-stopped

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: mydb
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql  # 초기화 스크립트
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U user -d mydb"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - backend

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - backend

volumes:
  postgres_data:
  redis_data:

networks:
  backend:
    driver: bridge
```

### 5. Development vs Production — Override Files

```yaml
# docker-compose.override.yml — 개발 전용 (자동으로 병합됨)
services:
  app:
    build:
      target: builder            # 빌드 도구 포함 이미지
    volumes:
      - .:/app                   # 소스 코드 마운트 (핫 리로드)
      - /app/node_modules        # node_modules는 컨테이너 것 사용
    environment:
      - DEBUG=true
      - LOG_LEVEL=debug
    command: ["uvicorn", "main:app", "--reload", "--host", "0.0.0.0"]
```

```yaml
# docker-compose.prod.yml — 프로덕션 전용
# docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
services:
  app:
    build:
      target: runtime
    restart: always
    environment:
      - DEBUG=false
      - LOG_LEVEL=warning
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: "1.0"
          memory: 512M
    logging:
      driver: json-file
      options:
        max-size: "10m"
        max-file: "3"
```

### 6. Environment Variable Management

```yaml
# .env 파일 (docker-compose.yml과 같은 디렉토리)
POSTGRES_USER=user
POSTGRES_PASSWORD=secret_password
POSTGRES_DB=mydb
APP_PORT=8000
```

```yaml
# docker-compose.yml에서 참조
services:
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
  app:
    ports:
      - "${APP_PORT}:8000"
```

**시크릿 관리 (프로덕션):**
```yaml
# Docker Secrets (Swarm mode)
services:
  app:
    secrets:
      - db_password
    environment:
      DB_PASSWORD_FILE: /run/secrets/db_password

secrets:
  db_password:
    file: ./secrets/db_password.txt  # 로컬
    # external: true                 # Swarm에서 관리
```

### 7. Health Checks

```dockerfile
# Dockerfile — HEALTHCHECK 명령
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \
  CMD curl -f http://localhost:8000/health || exit 1
```

```yaml
# docker-compose.yml — healthcheck
services:
  app:
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 5s
      start_period: 10s
      retries: 3
```

**상태 확인:**
```bash
# 컨테이너 헬스 상태 확인
docker inspect --format='{{.State.Health.Status}}' container_name
# 결과: starting | healthy | unhealthy
```

### 8. Logging Best Practices

```yaml
# docker-compose.yml — 로그 드라이버 설정
services:
  app:
    logging:
      driver: json-file
      options:
        max-size: "10m"    # 로그 파일 최대 크기
        max-file: "5"      # 로테이션 파일 수
        tag: "{{.Name}}"   # 태그 형식
```

```python
# Python — 구조화된 JSON 로깅 (stdout으로 출력)
import logging, json, sys

class JSONFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps({
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
        })

handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JSONFormatter())
logger = logging.getLogger("app")
logger.addHandler(handler)
logger.setLevel(logging.INFO)
```

### 9. Layer Caching Strategy

```dockerfile
# 레이어 캐싱 최적화 순서
# 1. 기본 이미지 (거의 안 바뀜)
FROM python:3.12-slim

# 2. 시스템 패키지 (드물게 바뀜)
RUN apt-get update && apt-get install -y --no-install-recommends \
    curl && rm -rf /var/lib/apt/lists/*

# 3. 의존성 파일 복사 + 설치 (가끔 바뀜)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 4. 소스 코드 복사 (자주 바뀜)
COPY . .

# 5. 빌드/실행 명령 (거의 안 바뀜)
CMD ["gunicorn", "main:app"]
```

### 10. Common Commands Reference

```bash
# 빌드 & 실행
docker compose up -d --build            # 빌드 후 백그라운드 실행
docker compose down -v                   # 중지 + 볼륨 삭제
docker compose logs -f app               # 특정 서비스 로그 추적

# 디버깅
docker compose exec app bash             # 실행 중인 컨테이너에 접속
docker compose run --rm app pytest       # 일회성 명령 실행
docker compose ps                        # 서비스 상태 확인

# 이미지 관리
docker image prune -f                    # 미사용 이미지 정리
docker system df                         # 디스크 사용량 확인
docker build --no-cache .                # 캐시 없이 빌드

# 멀티 파일 실행
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

---

## Anti-Patterns

### 1. Running as Root
- 컨테이너가 root로 실행되면 호스트 탈출 시 심각한 보안 위험
- **해결:** `USER appuser`로 non-root 사용자 지정

### 2. Fat Images
- `python:3.12` (900MB) 대신 `python:3.12-slim` (150MB) 사용
- 빌드 도구를 최종 이미지에 포함하지 않는다 (multi-stage builds)

### 3. No .dockerignore
- `.git`, `node_modules`, `__pycache__` 등이 이미지에 포함되어 크기 증가 + 캐시 무효화
- **해결:** 반드시 .dockerignore 작성

### 4. Hardcoded Secrets in Dockerfile
- `ENV DB_PASSWORD=secret123` — 이미지 레이어에 시크릿이 영구 저장됨
- **해결:** 런타임 환경 변수 또는 Docker Secrets 사용

### 5. No Health Checks
- 프로세스는 살아있지만 응답 불가 상태를 감지하지 못함
- **해결:** HEALTHCHECK 명령 + 애플리케이션 /health 엔드포인트

### 6. Using `latest` Tag
- `FROM node:latest` — 빌드 시점에 따라 다른 이미지 사용, 재현성 없음
- **해결:** `FROM node:20-alpine` — 항상 구체적 버전 명시

### 7. Single-layer COPY + RUN
- `COPY . . && RUN npm install` — 소스 코드 변경 시 의존성도 재설치
- **해결:** 의존성 파일 먼저 복사 → 설치 → 나머지 소스 복사

### 8. No Log Rotation
- `json-file` 드라이버의 기본 설정은 로그 무제한 → 디스크 가득 참
- **해결:** `max-size`, `max-file` 옵션으로 로테이션 설정

### 9. depends_on Without healthcheck
- `depends_on: [db]`만 쓰면 db 컨테이너 시작만 보장, 준비 완료는 보장 안 됨
- **해결:** `depends_on.condition: service_healthy` + healthcheck 설정
