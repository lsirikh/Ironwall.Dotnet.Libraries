---
name: java-testing
description: Java testing patterns — JUnit 5, Mockito, Spring Boot test slices, AssertJ, Testcontainers, fixture patterns
languages: ["Java"]
frameworks: ["JUnit", "Spring Boot"]
phases: ["test"]
---

# Java Testing Patterns

## When to Activate

- Writing or reviewing unit, integration, or slice tests in Java
- Using JUnit 5, Mockito, AssertJ, or Testcontainers
- Testing Spring Boot components with @WebMvcTest, @DataJpaTest, @SpringBootTest

---

## Core Patterns

### 1. JUnit 5 Fundamentals

```java
class OrderServiceTest {
    private OrderService svc;
    private OrderRepository repo;

    @BeforeEach void setUp() {
        repo = mock(OrderRepository.class);
        svc = new OrderService(repo);
    }

    @Test @DisplayName("should return order when found")
    void shouldReturnOrder() {
        when(repo.findById(1L)).thenReturn(Optional.of(new Order(1L, "PENDING")));
        assertThat(svc.getOrderById(1L).status()).isEqualTo("PENDING");
    }

    @Test @DisplayName("should throw when order not found")
    void shouldThrowWhenNotFound() {
        when(repo.findById(999L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> svc.getOrderById(999L))
                .isInstanceOf(OrderNotFoundException.class);
    }

    @AfterEach void tearDown() { /* cleanup if needed */ }
}
```

### 2. @ParameterizedTest

```java
@ParameterizedTest
@ValueSource(strings = {"user@example.com", "a@b.co", "admin@test.org"})
void shouldAcceptValidEmails(String email) {
    assertThat(validator.isValid(email)).isTrue();
}

@ParameterizedTest
@ValueSource(strings = {"", "invalid", "@no-local.com", "no-domain@"})
void shouldRejectInvalidEmails(String email) {
    assertThat(validator.isValid(email)).isFalse();
}

@ParameterizedTest
@CsvSource({"100, 10, 10.0", "200, 3, 66.67", "0, 5, 0.0"})
void shouldCalculateAverage(int total, int count, double expected) {
    assertThat(Calculator.average(total, count)).isCloseTo(expected, within(0.01));
}
```

### 3. @Nested Groups

```java
class UserServiceTest {
    @BeforeEach void setUp() { /* ... */ }

    @Nested @DisplayName("when creating a user")
    class CreateUser {
        @Test void shouldSaveAndReturn() {
            when(repo.save(any(User.class))).thenAnswer(inv -> {
                User u = inv.getArgument(0); u.setId(1L); return u;
            });
            assertThat(svc.createUser(new CreateUserRequest("Alice", "a@t.com")).name())
                    .isEqualTo("Alice");
        }
        @Test void shouldRejectDuplicateEmail() {
            when(repo.findByEmail("e@t.com")).thenReturn(Optional.of(new User()));
            assertThatThrownBy(() -> svc.createUser(new CreateUserRequest("B", "e@t.com")))
                    .isInstanceOf(DuplicateEmailException.class);
        }
    }

    @Nested @DisplayName("when deleting")
    class DeleteUser {
        @Test void shouldDelete() {
            when(repo.existsById(1L)).thenReturn(true);
            svc.deleteUser(1L);
            verify(repo).deleteById(1L);
        }
    }
}
```

### 4. Mockito

```java
@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
    @Mock PaymentGateway gateway;
    @Mock OrderRepository repo;
    @InjectMocks PaymentService svc;

    @Test void shouldProcessPayment() {
        when(repo.findById(1L)).thenReturn(Optional.of(new Order(1L, BigDecimal.TEN)));
        when(gateway.charge(any())).thenReturn(new PaymentResult("txn-1", true));
        assertThat(svc.processPayment(1L).success()).isTrue();
        verify(gateway).charge(any(PaymentRequest.class));
    }
}

// ArgumentCaptor
@Test void shouldSendCorrectNotification() {
    ArgumentCaptor<Notification> cap = ArgumentCaptor.forClass(Notification.class);
    svc.registerUser(new CreateUserRequest("Alice", "a@t.com"));
    verify(notifService).send(cap.capture());
    assertThat(cap.getValue().recipient()).isEqualTo("a@t.com");
}

// Verify call count
@Test void shouldRetryOnFailure() {
    when(api.call()).thenThrow(new TimeoutException())
            .thenThrow(new TimeoutException()).thenReturn("ok");
    assertThat(resilient.callWithRetry()).isEqualTo("ok");
    verify(api, times(3)).call();
}
```

### 5. Spring Boot Test Slices

#### @WebMvcTest (Controller)

```java
@WebMvcTest(UserController.class)
class UserControllerTest {
    @Autowired MockMvc mockMvc;
    @MockBean UserService userService;

    @Test void shouldReturnUser() throws Exception {
        when(userService.getUserById(1L)).thenReturn(new UserResponse(1L, "Alice", "a@t.com"));
        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Alice"));
    }

    @Test void shouldValidateRequest() throws Exception {
        mockMvc.perform(post("/api/users").contentType(APPLICATION_JSON)
                        .content("""{"name":"","email":"bad"}"""))
                .andExpect(status().isBadRequest());
    }
}
```

#### @DataJpaTest (Repository)

```java
@DataJpaTest
class ProductRepositoryTest {
    @Autowired ProductRepository repo;
    @Autowired TestEntityManager em;

    @Test void shouldFindActiveByCategory() {
        em.persist(new Product("Widget", "TOOLS", true));
        em.persist(new Product("Gadget", "TOOLS", false));
        em.flush();
        assertThat(repo.findByCategoryAndActiveTrue("TOOLS"))
                .extracting(Product::getName).containsExactly("Widget");
    }
}
```

#### @SpringBootTest (Full Context)

```java
@SpringBootTest(webEnvironment = RANDOM_PORT)
class OrderIntegrationTest {
    @Autowired TestRestTemplate rest;

    @Test void shouldCreateAndRetrieve() {
        var resp = rest.postForEntity("/api/orders",
                new CreateOrderRequest("ITEM-1", 2), OrderResponse.class);
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        var get = rest.getForEntity("/api/orders/" + resp.getBody().id(), OrderResponse.class);
        assertThat(get.getStatusCode()).isEqualTo(HttpStatus.OK);
    }
}
```

### 6. AssertJ

```java
assertThat(user.getName()).isEqualTo("Alice");
assertThat(users).hasSize(3).extracting(User::getName)
        .containsExactly("Alice", "Bob", "Charlie");
assertThat(users).filteredOn(User::isActive).extracting(User::getEmail)
        .containsExactlyInAnyOrder("alice@t.com", "charlie@t.com");
assertThatThrownBy(() -> svc.process(null))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessageContaining("must not be null");
assertThat(map).containsEntry("status", "OK").doesNotContainKey("password");
```

### 7. Testcontainers

```java
@SpringBootTest @Testcontainers
class OrderRepoIntegrationTest {
    @Container
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:16-alpine");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", pg::getJdbcUrl);
        r.add("spring.datasource.username", pg::getUsername);
        r.add("spring.datasource.password", pg::getPassword);
    }

    @Autowired OrderRepository repo;

    @Test void shouldPersist() {
        Order saved = repo.save(new Order("PENDING", BigDecimal.TEN));
        assertThat(repo.findById(saved.getId())).isPresent();
    }
}

// Redis — same pattern with GenericContainer
@Container static GenericContainer<?> redis =
        new GenericContainer<>("redis:7-alpine").withExposedPorts(6379);
```

### 8. Test Profiles and Fixtures

```yaml
# application-test.yml
spring:
  datasource.url: jdbc:h2:mem:testdb
  jpa.hibernate.ddl-auto: create-drop
```

```java
@SpringBootTest @ActiveProfiles("test")
class ServiceTest { /* uses test profile */ }

// Fixture pattern
class UserFixture {
    public static User defaultUser() {
        return User.builder().id(1L).name("Test").email("t@t.com")
                .active(true).role(Role.USER).build();
    }
    public static User admin() {
        return User.builder().id(2L).name("Admin").email("a@t.com")
                .active(true).role(Role.ADMIN).build();
    }
}
// Usage: when(repo.findById(1L)).thenReturn(Optional.of(UserFixture.defaultUser()));
```

---

## Anti-Patterns

### Never Test Implementation Details

```java
verify(repo).flush(); verify(em).clear();       // BAD — coupled to internals
assertThat(svc.getUserById(1L).name()).isEqualTo("Alice"); // GOOD — test behavior
```

### Never Share Mutable State

```java
static List<String> results = new ArrayList<>(); // BAD — leaks between tests
// GOOD — initialize in @BeforeEach
```

### Never Thread.sleep() in Tests

```java
Thread.sleep(5000);                              // BAD — slow and flaky
await().atMost(5, SECONDS).untilAsserted(() ->   // GOOD — Awaitility
        assertThat(repo.findAll()).isNotEmpty());
```

### Never Hardcode Volatile Data

```java
assertThat(result.getDate()).isEqualTo(LocalDate.of(2026, 4, 20)); // BAD
assertThat(result.getDate()).isToday();                             // GOOD
```
