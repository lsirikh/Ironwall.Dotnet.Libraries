# Rust Naming Conventions

## Must Always
- Use snake_case for functions, methods, variables, modules, crate names
- Use PascalCase for types (structs, enums, traits), type parameters
- Use SCREAMING_SNAKE_CASE for constants and statics
- Prefix lifetime parameters with `'`: `'a`, `'static`
- Use `new()` for constructors, `with_xxx()` for builder pattern
- Name boolean methods with `is_`, `has_`, `can_`, `should_` prefix
- Name conversion methods: `as_xxx()` (cheap ref), `to_xxx()` (expensive clone), `into_xxx()` (consuming)
- Name fallible methods: `try_xxx()` returning `Result`
- Crate names: lowercase with hyphens in Cargo.toml, underscores in code

## Must Never
- Use `get_` prefix for simple field accessors (just `name()` not `get_name()`)
- Abbreviate unless universally understood (use `config` not `cfg`, `error` not `err` — exception: `err` in closures OK)
