# Go Naming Conventions

## Must Always
- Use MixedCaps (PascalCase) for exported names, mixedCaps (camelCase) for unexported
- Keep names short: `i` not `index` for loop vars, `r` for reader, `ctx` for context
- Use acronyms consistently: `HTTP`, `URL`, `ID` (all caps when exported), `httpClient` (lowercase when unexported)
- Name interfaces with `-er` suffix when single method: `Reader`, `Writer`, `Stringer`
- Name packages as short, lowercase, single-word: `http`, `fmt`, `io` (never `utils`, `common`, `helpers`)
- Name test files as `*_test.go` in same package
- Name test functions as `TestXxx`, benchmarks as `BenchmarkXxx`
- Getters: `Name()` not `GetName()`. Setters: `SetName()`

## Must Never
- Use underscores in Go names (except test functions `Test_xxx` for subtests)
- Stutter: `http.HTTPServer` → `http.Server`
- Use `I` prefix for interfaces: `Reader` not `IReader`
- Name packages after their parent directory differently
