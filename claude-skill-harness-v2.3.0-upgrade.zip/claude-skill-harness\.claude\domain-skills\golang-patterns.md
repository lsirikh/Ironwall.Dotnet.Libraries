---
name: golang-patterns
description: >
  Go 언어 핵심 패턴 가이드. 에러 처리, 동시성, 인터페이스, 제네릭,
  함수형 옵션 패턴 등 실무에서 반복되는 Go 관용구를 정리한다.
languages: ["Go"]
frameworks: ["Go 1.21+"]
phases: ["dev", "test"]
---

# Go Patterns

## When to Activate

- Go 소스 파일(`.go`)을 생성하거나 수정할 때
- 에러 처리, 동시성, 인터페이스 설계에 대한 리뷰가 필요할 때
- 코드 리뷰에서 Go 관용구 준수 여부를 확인할 때

---

## Core Patterns

### 1. Error Handling

```go
// Sentinel errors
var (
    ErrNotFound     = errors.New("repository: not found")
    ErrInvalidInput = errors.New("repository: invalid input")
)

// Custom error type
type ValidationError struct {
    Field, Message string
}
func (e *ValidationError) Error() string {
    return fmt.Sprintf("validation: %s: %s", e.Field, e.Message)
}

// Wrapping with context
func GetUser(id int) (*User, error) {
    u, err := db.FindByID(id)
    if err != nil {
        return nil, fmt.Errorf("GetUser(%d): %w", id, err)
    }
    return u, nil
}

// Checking wrapped errors
if errors.Is(err, ErrNotFound) { /* 404 */ }

var ve *ValidationError
if errors.As(err, &ve) { log.Printf("field %s: %s", ve.Field, ve.Message) }
```

### 2. Goroutines and Channels

```go
// Fan-out / fan-in
func fanOut(ctx context.Context, jobs <-chan int, workers int) <-chan int {
    results := make(chan int)
    var wg sync.WaitGroup
    for i := 0; i < workers; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            for job := range jobs {
                select {
                case <-ctx.Done(): return
                case results <- job * 2:
                }
            }
        }()
    }
    go func() { wg.Wait(); close(results) }()
    return results
}

// Select with timeout + done channel
func process(ctx context.Context) error {
    done := make(chan struct{})
    go func() { defer close(done); heavyWork() }()
    select {
    case <-done:                            return nil
    case <-ctx.Done():                      return ctx.Err()
    case <-time.After(30 * time.Second):    return errors.New("timeout")
    }
}

// context.Context propagation — 첫 번째 인자로 전달
func FetchData(ctx context.Context, url string) ([]byte, error) {
    req, _ := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
    resp, err := http.DefaultClient.Do(req)
    if err != nil { return nil, fmt.Errorf("fetch: %w", err) }
    defer resp.Body.Close()
    return io.ReadAll(resp.Body)
}
```

### 3. Interfaces

```go
// Small interfaces (1-2 methods)
type Reader interface { Read(p []byte) (int, error) }
type Stringer interface { String() string }

// Accept interfaces, return structs
type UserStore interface {
    FindByID(ctx context.Context, id int) (*User, error)
}
type UserService struct { store UserStore }
func NewUserService(s UserStore) *UserService { return &UserService{store: s} }
```

### 4. Struct Embedding

```go
type Logger struct{ prefix string }
func (l *Logger) Log(msg string) { log.Printf("[%s] %s", l.prefix, msg) }

type Server struct {
    *Logger  // s.Log("msg") 직접 호출 가능
    addr string
}
```

### 5. Generics

```go
// Type constraints
type Number interface { ~int | ~int64 | ~float64 }
func Sum[T Number](vals []T) T {
    var t T
    for _, v := range vals { t += v }
    return t
}

// comparable — 맵 키, 동등 비교
func Contains[T comparable](s []T, target T) bool {
    for _, v := range s { if v == target { return true } }
    return false
}
func Unique[T comparable](s []T) []T {
    seen := map[T]struct{}{}
    out := make([]T, 0, len(s))
    for _, v := range s {
        if _, ok := seen[v]; !ok { seen[v] = struct{}{}; out = append(out, v) }
    }
    return out
}
```

### 6. Defer Patterns

```go
func WriteFile(path string, data []byte) (err error) {
    f, err := os.Create(path)
    if err != nil { return fmt.Errorf("create: %w", err) }
    defer func() {
        if cerr := f.Close(); cerr != nil && err == nil {
            err = fmt.Errorf("close: %w", cerr)
        }
    }()
    _, err = f.Write(data)
    return err
}
```

### 7. Functional Options

```go
type ServerOption func(*Server)
func WithPort(p int) ServerOption       { return func(s *Server) { s.port = p } }
func WithTimeout(d time.Duration) ServerOption { return func(s *Server) { s.timeout = d } }

func NewServer(addr string, opts ...ServerOption) *Server {
    s := &Server{addr: addr, port: 8080, timeout: 30 * time.Second}
    for _, o := range opts { o(s) }
    return s
}
// srv := NewServer("localhost", WithPort(9090), WithTimeout(60*time.Second))
```

### 8. Table-Driven Patterns (Non-Test)

```go
var routes = []struct {
    Method, Path string
    Handler      http.HandlerFunc
}{
    {"GET", "/users", listUsers},
    {"POST", "/users", createUser},
    {"DELETE", "/users/{id}", deleteUser},
}
func RegisterRoutes(mux *http.ServeMux) {
    for _, r := range routes {
        mux.HandleFunc(fmt.Sprintf("%s %s", r.Method, r.Path), r.Handler)
    }
}
```

---

## Anti-Patterns

### 1. init() 남용

```go
// BAD — 테스트/디버깅 어려움
func init() {
    db, _ = sql.Open("postgres", os.Getenv("DB_URL")) // 전역 상태
}
// GOOD — 명시적 초기화
func NewDB(dsn string) (*sql.DB, error) { return sql.Open("postgres", dsn) }
```

### 2. 에러 무시

```go
// BAD
_ = json.Unmarshal(data, &result)
// GOOD
if err := json.Unmarshal(data, &result); err != nil { return err }
```

### 3. 고루틴 누수

```go
// BAD — 종료 조건 없음
go func() { for { doWork() } }()
// GOOD — context로 종료
go func(ctx context.Context) {
    for { select { case <-ctx.Done(): return; default: doWork() } }
}(ctx)
```

### 4. 큰 인터페이스

```go
// BAD — 메서드 10개짜리 인터페이스
type UserManager interface { Create(); Update(); Delete(); Find(); /* ... */ }
// GOOD — 역할별 분리
type UserReader interface { FindByID(ctx context.Context, id int) (*User, error) }
type UserWriter interface { Create(ctx context.Context, u *User) error }
```

### 5. 채널 vs 뮤텍스 오용

```go
// BAD — 단순 카운터에 채널
// GOOD — sync.Mutex
type Counter struct { mu sync.Mutex; count int }
func (c *Counter) Inc() { c.mu.Lock(); defer c.mu.Unlock(); c.count++ }
```
