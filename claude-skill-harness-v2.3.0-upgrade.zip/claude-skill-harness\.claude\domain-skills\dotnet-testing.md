---
name: dotnet-testing
description: .NET testing patterns — xUnit, NUnit, Moq, FluentAssertions, TestContainers, AAA pattern
languages: ["C#"]
frameworks: [".NET", "xUnit", "NUnit"]
phases: ["test"]
---

# .NET Testing Patterns

## When to Activate

- Writing unit tests with xUnit or NUnit
- Setting up mocks with Moq
- Writing expressive assertions with FluentAssertions
- Building integration tests with TestContainers
- Structuring test code with AAA (Arrange-Act-Assert)
- Reviewing test quality and coverage

---

## Core Patterns

### 1. AAA Pattern (Arrange-Act-Assert)

Every test follows three distinct sections. Keep them visually separated.

```csharp
[Fact]
public async Task CreateOrder_WithValidRequest_ReturnsOrderWithCorrectTotal()
{
    // Arrange
    var repository = new Mock<IOrderRepository>();
    var pricing = new PricingEngine();
    var service = new OrderService(repository.Object, pricing);

    var request = new CreateOrderRequest
    {
        CustomerId = 42,
        Items = new[]
        {
            new OrderItemRequest { ProductId = 1, Quantity = 2, UnitPrice = 10.00m },
            new OrderItemRequest { ProductId = 2, Quantity = 1, UnitPrice = 25.00m }
        }
    };

    // Act
    var result = await service.CreateOrderAsync(request);

    // Assert
    result.Total.Should().Be(45.00m);
    result.Items.Should().HaveCount(2);
    repository.Verify(r => r.SaveAsync(It.IsAny<Order>(), default), Times.Once);
}
```

> **Rule**: One logical assertion per test. Multiple `Should()` calls on the same
> result are fine. Multiple distinct behaviors need separate test methods.

---

### 2. xUnit Patterns

#### Fact and Theory

```csharp
public class PricingEngineTests
{
    // Fact — single test case, no parameters
    [Fact]
    public void CalculateTotal_EmptyCart_ReturnsZero()
    {
        var engine = new PricingEngine();
        var result = engine.CalculateTotal(Array.Empty<CartItem>());
        result.Should().Be(0m);
    }

    // Theory + InlineData — parameterized tests
    [Theory]
    [InlineData(100, 0.10, 90)]
    [InlineData(200, 0.15, 170)]
    [InlineData(50, 0, 50)]
    [InlineData(0, 0.50, 0)]
    public void ApplyDiscount_VariousInputs_ReturnsExpected(
        decimal price, decimal discount, decimal expected)
    {
        var engine = new PricingEngine();
        var result = engine.ApplyDiscount(price, discount);
        result.Should().Be(expected);
    }
}
```

#### ClassData for Complex Parameters

```csharp
public class InvalidOrderTestData : IEnumerable<object[]>
{
    public IEnumerator<object[]> GetEnumerator()
    {
        yield return new object[]
        {
            new CreateOrderRequest
            {
                CustomerId = 0,
                Items = new List<OrderItem>()
            },
            "Customer ID is required"
        };
        yield return new object[]
        {
            new CreateOrderRequest
            {
                CustomerId = 1,
                Items = null
            },
            "At least one item is required"
        };
        yield return new object[]
        {
            new CreateOrderRequest
            {
                CustomerId = 1,
                Items = new List<OrderItem> { new() { Quantity = -1 } }
            },
            "Quantity must be positive"
        };
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

[Theory]
[ClassData(typeof(InvalidOrderTestData))]
public async Task CreateOrder_InvalidRequest_ReturnsValidationError(
    CreateOrderRequest request, string expectedError)
{
    var service = CreateService();
    var result = await service.CreateOrderAsync(request);
    result.Errors.Should().Contain(e => e.Message == expectedError);
}
```

#### IClassFixture for Shared Setup

```csharp
// Expensive setup shared across all tests in the class
public class DatabaseFixture : IAsyncLifetime
{
    public string ConnectionString { get; private set; }

    public async Task InitializeAsync()
    {
        // Runs once before all tests in classes that use this fixture
        var db = await TestDatabase.CreateAsync();
        ConnectionString = db.ConnectionString;
        await db.SeedAsync();
    }

    public async Task DisposeAsync()
    {
        await TestDatabase.DropAsync(ConnectionString);
    }
}

public class OrderRepositoryTests : IClassFixture<DatabaseFixture>
{
    private readonly DatabaseFixture _fixture;

    public OrderRepositoryTests(DatabaseFixture fixture)
    {
        _fixture = fixture;
    }

    [Fact]
    public async Task GetById_ExistingOrder_ReturnsOrder()
    {
        var repo = new OrderRepository(_fixture.ConnectionString);
        var order = await repo.GetByIdAsync(1);
        order.Should().NotBeNull();
    }
}
```

#### Collection Fixtures for Cross-Class Sharing

```csharp
[CollectionDefinition("Database")]
public class DatabaseCollection : ICollectionFixture<DatabaseFixture> { }

[Collection("Database")]
public class OrderTests
{
    public OrderTests(DatabaseFixture fixture) { /* ... */ }
}

[Collection("Database")]
public class ProductTests
{
    public ProductTests(DatabaseFixture fixture) { /* same fixture instance */ }
}
```

---

### 3. NUnit Patterns

#### TestCase and SetUp/TearDown

```csharp
[TestFixture]
public class CalculatorTests
{
    private Calculator _calculator;

    [SetUp]   // Runs before EACH test
    public void SetUp()
    {
        _calculator = new Calculator();
    }

    [TearDown]   // Runs after EACH test
    public void TearDown()
    {
        _calculator?.Dispose();
    }

    [OneTimeSetUp]   // Runs once before ALL tests
    public void OneTimeSetUp()
    {
        // Global initialization
    }

    [Test]
    public void Add_TwoPositiveNumbers_ReturnsSum()
    {
        var result = _calculator.Add(2, 3);
        Assert.That(result, Is.EqualTo(5));
    }

    [TestCase(10, 5, 2)]
    [TestCase(9, 3, 3)]
    [TestCase(100, 10, 10)]
    public void Divide_ValidInputs_ReturnsQuotient(int a, int b, int expected)
    {
        var result = _calculator.Divide(a, b);
        Assert.That(result, Is.EqualTo(expected));
    }

    [TestCase(0)]
    public void Divide_ByZero_ThrowsException(int divisor)
    {
        Assert.Throws<DivideByZeroException>(
            () => _calculator.Divide(10, divisor));
    }
}
```

---

### 4. Moq Patterns

#### Setup, Returns, Verify

```csharp
[Fact]
public async Task ProcessOrder_ValidOrder_SavesAndNotifies()
{
    // Arrange
    var repo = new Mock<IOrderRepository>();
    var notifier = new Mock<INotificationService>();
    var logger = new Mock<ILogger<OrderProcessor>>();

    repo.Setup(r => r.SaveAsync(It.IsAny<Order>(), It.IsAny<CancellationToken>()))
        .ReturnsAsync((Order o, CancellationToken _) =>
        {
            o.Id = 42;  // Simulate DB-assigned ID
            return o;
        });

    var processor = new OrderProcessor(repo.Object, notifier.Object, logger.Object);

    // Act
    var result = await processor.ProcessAsync(new Order { Total = 100m });

    // Assert
    result.Id.Should().Be(42);

    repo.Verify(
        r => r.SaveAsync(
            It.Is<Order>(o => o.Total == 100m),
            It.IsAny<CancellationToken>()),
        Times.Once);

    notifier.Verify(
        n => n.SendAsync(
            It.Is<string>(msg => msg.Contains("42")),
            It.IsAny<CancellationToken>()),
        Times.Once);
}
```

#### Callback for Capturing Arguments

```csharp
[Fact]
public async Task BulkProcess_MultipleItems_SavesEachItem()
{
    var savedOrders = new List<Order>();
    var repo = new Mock<IOrderRepository>();

    repo.Setup(r => r.SaveAsync(It.IsAny<Order>(), default))
        .Callback<Order, CancellationToken>((order, _) => savedOrders.Add(order))
        .ReturnsAsync((Order o, CancellationToken _) => o);

    var processor = new OrderProcessor(repo.Object);
    await processor.BulkProcessAsync(new[] { new Order(), new Order(), new Order() });

    savedOrders.Should().HaveCount(3);
}
```

#### Mock Sequences

```csharp
[Fact]
public async Task Retry_FailsThenSucceeds_ReturnsResult()
{
    var service = new Mock<IExternalApi>();

    // First call throws, second succeeds
    service.SetupSequence(s => s.FetchDataAsync(It.IsAny<CancellationToken>()))
        .ThrowsAsync(new HttpRequestException("Timeout"))
        .ReturnsAsync(new ApiResponse { Data = "Success" });

    var client = new ResilientClient(service.Object, maxRetries: 2);
    var result = await client.GetDataAsync();

    result.Data.Should().Be("Success");
    service.Verify(s => s.FetchDataAsync(It.IsAny<CancellationToken>()), Times.Exactly(2));
}
```

#### Mock HttpMessageHandler

```csharp
var handler = new Mock<HttpMessageHandler>();
handler.Protected()
    .Setup<Task<HttpResponseMessage>>(
        "SendAsync",
        ItExpr.IsAny<HttpRequestMessage>(),
        ItExpr.IsAny<CancellationToken>())
    .ReturnsAsync(new HttpResponseMessage
    {
        StatusCode = HttpStatusCode.OK,
        Content = new StringContent("{\"id\": 1}")
    });

var httpClient = new HttpClient(handler.Object)
{
    BaseAddress = new Uri("https://api.example.com")
};
```

---

### 5. FluentAssertions

#### Basic Assertions

```csharp
// Strings
name.Should().Be("Alice");
name.Should().StartWith("Al").And.HaveLength(5);
name.Should().MatchRegex(@"^[A-Z][a-z]+$");

// Numbers
total.Should().BeGreaterThan(0).And.BeLessThanOrEqualTo(1000);
percentage.Should().BeApproximately(0.33, precision: 0.01);

// Collections
orders.Should().HaveCount(3);
orders.Should().ContainSingle(o => o.Status == "Pending");
orders.Should().BeInDescendingOrder(o => o.CreatedAt);
orders.Should().OnlyContain(o => o.Total > 0);
orders.Should().NotContainNulls();
```

#### Object Comparison

```csharp
// BeEquivalentTo — structural comparison (ignores reference equality)
var actual = await service.GetOrderAsync(1);
actual.Should().BeEquivalentTo(new
{
    Id = 1,
    CustomerName = "Alice",
    Status = "Completed"
}, options => options
    .Excluding(o => o.CreatedAt)   // Ignore volatile fields
    .Using<decimal>(ctx => ctx.Subject.Should()
        .BeApproximately(ctx.Expectation, 0.01m))
        .WhenTypeIs<decimal>());    // Custom comparison for decimals

// .Which for chained assertions
var order = orders.Should().ContainSingle(o => o.Id == 42).Which;
order.Status.Should().Be("Shipped");
order.Items.Should().HaveCountGreaterThan(0);
```

#### Exception Assertions

```csharp
var act = async () => await service.DeleteOrderAsync(-1);

await act.Should().ThrowAsync<ArgumentException>()
    .WithMessage("*must be positive*")
    .Where(ex => ex.ParamName == "orderId");

// Should not throw
var safeAct = () => service.ValidateOrder(validOrder);
safeAct.Should().NotThrow();
```

#### Execution Time

```csharp
var act = () => service.ProcessLargeDataset(data);
act.ExecutionTime().Should().BeLessThan(TimeSpan.FromSeconds(5));
```

---

### 6. TestContainers for Integration Tests

```csharp
public class OrderRepositoryIntegrationTests : IAsyncLifetime
{
    private readonly MsSqlContainer _sqlContainer = new MsSqlBuilder()
        .WithImage("mcr.microsoft.com/mssql/server:2022-latest")
        .WithPassword("Strong_password_123!")
        .Build();

    private OrderRepository _repository;

    public async Task InitializeAsync()
    {
        await _sqlContainer.StartAsync();

        var connectionString = _sqlContainer.GetConnectionString();

        // Run migrations
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlServer(connectionString)
            .Options;

        using var context = new AppDbContext(options);
        await context.Database.MigrateAsync();

        _repository = new OrderRepository(connectionString);
    }

    public async Task DisposeAsync()
    {
        await _sqlContainer.DisposeAsync();
    }

    [Fact]
    public async Task SaveAndRetrieve_RoundTrip_ReturnsEquivalentOrder()
    {
        // Arrange
        var order = new Order
        {
            CustomerName = "Alice",
            Total = 99.99m,
            Items = new List<OrderItem>
            {
                new() { ProductName = "Widget", Quantity = 2, UnitPrice = 49.99m }
            }
        };

        // Act
        var savedId = await _repository.SaveAsync(order);
        var retrieved = await _repository.GetByIdAsync(savedId);

        // Assert
        retrieved.Should().BeEquivalentTo(order, opt => opt
            .Excluding(o => o.Id)
            .Excluding(o => o.CreatedAt));
    }
}
```

#### Redis TestContainer

```csharp
private readonly RedisContainer _redis = new RedisBuilder()
    .WithImage("redis:7-alpine")
    .Build();

[Fact]
public async Task CacheService_SetAndGet_ReturnsValue()
{
    var connectionString = _redis.GetConnectionString();
    var cache = new RedisCacheService(connectionString);

    await cache.SetAsync("key", "value", TimeSpan.FromMinutes(5));
    var result = await cache.GetAsync<string>("key");

    result.Should().Be("value");
}
```

---

## Anti-Patterns

### Test Structure

- Multiple unrelated assertions in one test — hard to diagnose failures
- Shared mutable state between tests — order-dependent failures
- Test names that describe implementation, not behavior (`Test_Method_Called`)
- Not using `async Task` for async tests (using `async void`) — swallowed exceptions

### Mocking

- Mocking concrete classes instead of interfaces — fragile, requires virtual methods
- Over-mocking — verifying every internal call instead of observable behavior
- Not verifying critical calls with `Times.Once` — false positive if method never called
- Mock returning `null` by default for reference types — hidden `NullReferenceException`

### Assertions

- Using `Assert.True(a == b)` instead of `Assert.Equal(a, b)` — bad failure messages
- Asserting on `ToString()` output instead of structured data
- Not asserting exceptions with specific messages/types — too broad

### Integration Tests

- Using real external services in CI — flaky, slow, credential issues
- Not cleaning up test data — tests interfere with each other
- Hardcoded connection strings — use TestContainers or environment variables
- Not isolating database state per test — shared data causes order-dependent failures
