---
name: dotnet-patterns
description: Modern .NET / C# development patterns — async/await, LINQ, nullable, records, minimal API, DI, IOptions
languages: ["C#"]
frameworks: [".NET", ".NET 8"]
phases: ["dev", "test"]
---

# .NET Modern Patterns

## When to Activate

- Writing or reviewing C# code targeting .NET 6+
- Implementing async operations, LINQ queries, or DI registrations
- Configuring application options or minimal API endpoints
- Enabling or enforcing nullable reference types
- Using records, pattern matching, or modern C# features

---

## Core Patterns

### 1. Async/Await Best Practices

#### ConfigureAwait

Library code should use `ConfigureAwait(false)` to avoid deadlocks.
Application code (ASP.NET Core) does NOT need it — there is no SynchronizationContext.

```csharp
// Library code
public async Task<Data> GetDataAsync(CancellationToken ct = default)
{
    var response = await _httpClient.GetAsync(url, ct).ConfigureAwait(false);
    var content = await response.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
    return JsonSerializer.Deserialize<Data>(content)!;
}
```

#### ValueTask for Hot Paths

Use `ValueTask<T>` when the result is frequently available synchronously (cached).

```csharp
public ValueTask<CachedItem> GetItemAsync(string key)
{
    if (_cache.TryGetValue(key, out var item))
        return ValueTask.FromResult(item); // No allocation

    return new ValueTask<CachedItem>(LoadFromDatabaseAsync(key));
}
```

> **Rule**: Never await a `ValueTask<T>` more than once. Never use `.Result` on it.

#### CancellationToken Propagation

Always accept and forward `CancellationToken`. Place it as the last parameter.

```csharp
public async Task<Order> ProcessOrderAsync(
    OrderRequest request,
    CancellationToken cancellationToken = default)
{
    cancellationToken.ThrowIfCancellationRequested();

    var validated = await _validator.ValidateAsync(request, cancellationToken);
    var saved = await _repository.SaveAsync(validated, cancellationToken);
    await _eventBus.PublishAsync(new OrderCreated(saved.Id), cancellationToken);
    return saved;
}
```

#### Avoid async void

`async void` swallows exceptions. Use `async Task` always, except for event handlers.

```csharp
// BAD
async void OnButtonClick(object sender, EventArgs e) { ... }

// GOOD — if you must use async void for events, wrap in try/catch
async void OnButtonClick(object sender, EventArgs e)
{
    try { await DoWorkAsync(); }
    catch (Exception ex) { _logger.LogError(ex, "Unhandled"); }
}
```

---

### 2. LINQ Best Practices

#### Deferred Execution Awareness

LINQ queries are not executed until enumerated. Materialize when needed.

```csharp
// BAD — query executes twice (once for Count, once for iteration)
var query = orders.Where(o => o.Total > 100);
Console.WriteLine($"Found {query.Count()} orders");
foreach (var order in query) { ... }

// GOOD — materialize once
var expensiveOrders = orders.Where(o => o.Total > 100).ToList();
Console.WriteLine($"Found {expensiveOrders.Count} orders");
foreach (var order in expensiveOrders) { ... }
```

#### Avoid Multiple Enumeration

```csharp
// BAD — enumerates source multiple times
public void Process(IEnumerable<Item> items)
{
    if (!items.Any()) return;        // enumeration 1
    var first = items.First();       // enumeration 2
    foreach (var item in items) { }  // enumeration 3
}

// GOOD — materialize or use a single pass
public void Process(IEnumerable<Item> items)
{
    var list = items.ToList();
    if (list.Count == 0) return;
    var first = list[0];
    foreach (var item in list) { }
}
```

#### Prefer Method Syntax for Complex Queries

```csharp
var result = employees
    .Where(e => e.Department == "Engineering")
    .GroupBy(e => e.Level)
    .Select(g => new
    {
        Level = g.Key,
        Count = g.Count(),
        AvgSalary = g.Average(e => e.Salary)
    })
    .OrderByDescending(x => x.AvgSalary);
```

---

### 3. Nullable Reference Types

#### Enable Project-Wide

```xml
<!-- .csproj -->
<PropertyGroup>
    <Nullable>enable</Nullable>
    <WarningsAsErrors>CS8600;CS8601;CS8602;CS8603</WarningsAsErrors>
</PropertyGroup>
```

#### Annotations

```csharp
public class UserService
{
    // Non-nullable — guaranteed to have a value
    private readonly ILogger<UserService> _logger;

    // Nullable — explicitly may be null
    public string? MiddleName { get; set; }

    // Null-forgiving operator — use sparingly, only when you KNOW it is not null
    public string DisplayName => _user!.Name;

    // Guard with pattern matching
    public string GetGreeting(User? user)
    {
        if (user is null)
            return "Hello, Guest";

        // After null check, user is non-null in this branch
        return $"Hello, {user.Name}";
    }

    // Required members (.NET 7+)
    public required string Email { get; init; }
}
```

---

### 4. Records and Pattern Matching

#### Records for Immutable Data

```csharp
// Positional record — concise
public record OrderSummary(int Id, decimal Total, DateTime CreatedAt);

// Record with body — when you need validation or computed properties
public record Money(decimal Amount, string Currency)
{
    public Money Add(Money other)
    {
        if (Currency != other.Currency)
            throw new InvalidOperationException("Currency mismatch");
        return this with { Amount = Amount + other.Amount };
    }
}

// Record struct for value semantics without heap allocation
public readonly record struct Point(double X, double Y);
```

#### Pattern Matching

```csharp
public decimal CalculateDiscount(Customer customer) => customer switch
{
    { Tier: "Gold", YearsActive: > 5 } => 0.25m,
    { Tier: "Gold" }                   => 0.15m,
    { Tier: "Silver" }                 => 0.10m,
    { OrderCount: > 100 }             => 0.05m,
    _                                  => 0m
};

// List patterns (.NET 7+)
public string Describe(int[] numbers) => numbers switch
{
    []           => "empty",
    [var single] => $"one element: {single}",
    [var first, .., var last] => $"first={first}, last={last}"
};
```

---

### 5. Minimal API Patterns

```csharp
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Route groups for organization
var api = app.MapGroup("/api/v1");
var orders = api.MapGroup("/orders").RequireAuthorization();

orders.MapGet("/", async (IOrderRepository repo, CancellationToken ct) =>
    Results.Ok(await repo.GetAllAsync(ct)));

orders.MapGet("/{id:int}", async (int id, IOrderRepository repo, CancellationToken ct) =>
    await repo.FindAsync(id, ct) is { } order
        ? Results.Ok(order)
        : Results.NotFound());

orders.MapPost("/", async (CreateOrderRequest request,
    IValidator<CreateOrderRequest> validator,
    IOrderService service,
    CancellationToken ct) =>
{
    var validation = await validator.ValidateAsync(request, ct);
    if (!validation.IsValid)
        return Results.ValidationProblem(validation.ToDictionary());

    var order = await service.CreateAsync(request, ct);
    return Results.Created($"/api/v1/orders/{order.Id}", order);
})
.WithName("CreateOrder")
.Produces<Order>(StatusCodes.Status201Created)
.ProducesValidationProblem();

app.Run();
```

---

### 6. Dependency Injection Registration

#### Lifetime Selection

| Lifetime | When to Use |
|----------|-------------|
| `AddTransient` | Lightweight, stateless services |
| `AddScoped` | Per-request state (DbContext, UnitOfWork) |
| `AddSingleton` | Thread-safe shared state, caches, HttpClient factories |

```csharp
builder.Services.AddScoped<IOrderRepository, OrderRepository>();
builder.Services.AddTransient<IValidator<CreateOrderRequest>, CreateOrderValidator>();
builder.Services.AddSingleton<ICacheService, RedisCacheService>();

// Keyed services (.NET 8)
builder.Services.AddKeyedSingleton<INotifier, EmailNotifier>("email");
builder.Services.AddKeyedSingleton<INotifier, SmsNotifier>("sms");

// Usage
public class OrderService([FromKeyedServices("email")] INotifier notifier) { }
```

#### Avoid Service Locator

```csharp
// BAD — service locator anti-pattern
public class OrderService
{
    public void Process()
    {
        var repo = ServiceProvider.GetService<IOrderRepository>(); // Don't
    }
}

// GOOD — constructor injection
public class OrderService(IOrderRepository repository, ILogger<OrderService> logger)
{
    public async Task ProcessAsync(CancellationToken ct)
    {
        var orders = await repository.GetPendingAsync(ct);
        logger.LogInformation("Processing {Count} orders", orders.Count);
    }
}
```

---

### 7. IOptions Pattern

#### Configuration Classes

```csharp
public class SmtpSettings
{
    public const string SectionName = "Smtp";

    public required string Host { get; init; }
    public int Port { get; init; } = 587;
    public required string Username { get; init; }
    public required string Password { get; init; }
    public bool UseSsl { get; init; } = true;
}
```

#### Registration and Validation

```csharp
builder.Services
    .AddOptions<SmtpSettings>()
    .Bind(builder.Configuration.GetSection(SmtpSettings.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();  // Fail fast at startup
```

#### Injection Variants

```csharp
public class EmailService
{
    // IOptions<T> — singleton, read once at startup
    public EmailService(IOptions<SmtpSettings> options)
    {
        var settings = options.Value;
    }

    // IOptionsSnapshot<T> — scoped, re-reads per request
    public EmailService(IOptionsSnapshot<SmtpSettings> options)
    {
        var settings = options.Value;
    }

    // IOptionsMonitor<T> — singleton, live reload with change notification
    public EmailService(IOptionsMonitor<SmtpSettings> options)
    {
        var settings = options.CurrentValue;
        options.OnChange(newSettings => { /* react to config change */ });
    }
}
```

---

## Anti-Patterns

### Async

- `async void` methods (except UI event handlers) — exceptions disappear
- `.Result` or `.Wait()` on async calls — causes deadlocks in UI/legacy ASP.NET
- `Task.Run()` wrapping purely async code — wastes a thread pool thread
- Forgetting `CancellationToken` — makes operations non-cancellable

### LINQ

- Calling `.ToList()` inside a loop on a query — materializes repeatedly
- Using `Count() > 0` instead of `Any()` — evaluates entire sequence
- Chaining `.OrderBy().OrderBy()` instead of `.OrderBy().ThenBy()`

### DI

- Injecting `IServiceProvider` directly — service locator anti-pattern
- Capturing scoped service in singleton — causes captive dependency bug
- Registering everything as Singleton — prevents proper per-request isolation

### Nullable

- Suppressing all warnings with `#nullable disable` — defeats the purpose
- Overusing `!` (null-forgiving) — hides real null bugs
- Not checking nullable returns from dictionary/LINQ lookups
