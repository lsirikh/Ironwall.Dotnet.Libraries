---
name: dotnet-framework-patterns
description: .NET Framework 4.x patterns — App.config, WCF, GAC, Global.asax, and migration strategies to modern .NET
languages: ["C#"]
frameworks: [".NET Framework", ".NET Framework 4.8"]
phases: ["dev"]
---

# .NET Framework Patterns

## When to Activate

- Working with legacy .NET Framework 4.x projects
- Maintaining WCF services or Web.config-heavy applications
- Planning migration from .NET Framework to .NET 6/8
- Dealing with GAC assemblies or COM interop
- Troubleshooting Global.asax lifecycle issues

---

## Core Patterns

### 1. App.config / Web.config Management

#### AppSettings and ConnectionStrings

```xml
<!-- App.config -->
<configuration>
  <appSettings>
    <add key="MaxRetries" value="3" />
    <add key="ApiBaseUrl" value="https://api.example.com" />
  </appSettings>
  <connectionStrings>
    <add name="DefaultConnection"
         connectionString="Server=.;Database=MyDb;Integrated Security=true"
         providerName="System.Data.SqlClient" />
  </connectionStrings>
</configuration>
```

```csharp
// Reading values
string maxRetries = ConfigurationManager.AppSettings["MaxRetries"];
string connStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
```

#### Custom Configuration Sections

```csharp
public class CacheSettings : ConfigurationSection
{
    [ConfigurationProperty("enabled", DefaultValue = true)]
    public bool Enabled => (bool)this["enabled"];

    [ConfigurationProperty("durationMinutes", DefaultValue = 30)]
    public int DurationMinutes => (int)this["durationMinutes"];

    [ConfigurationProperty("providers")]
    public ProviderElementCollection Providers =>
        (ProviderElementCollection)this["providers"];
}
```

```xml
<configuration>
  <configSections>
    <section name="cacheSettings"
             type="MyApp.CacheSettings, MyApp" />
  </configSections>
  <cacheSettings enabled="true" durationMinutes="60">
    <providers>
      <add name="redis" host="localhost" port="6379" />
    </providers>
  </cacheSettings>
</configuration>
```

#### Config Transforms (Web.config)

```xml
<!-- Web.Release.config -->
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
  <connectionStrings>
    <add name="DefaultConnection"
         connectionString="Server=prod-db;Database=MyDb;..."
         xdt:Transform="SetAttributes" xdt:Locator="Match(name)" />
  </connectionStrings>
  <system.web>
    <compilation xdt:Transform="RemoveAttributes(debug)" />
  </system.web>
</configuration>
```

> **Key difference from modern .NET**: No `appsettings.json`, no `IConfiguration`,
> no environment-based loading. Transforms are build-time, not runtime.

---

### 2. WCF Service Patterns

#### Service Contract Definition

```csharp
[ServiceContract(Namespace = "http://example.com/services")]
public interface IOrderService
{
    [OperationContract]
    Task<Order> GetOrderAsync(int orderId);

    [OperationContract]
    [FaultContract(typeof(ValidationFault))]
    Task<int> CreateOrderAsync(OrderRequest request);

    [OperationContract(IsOneWay = true)]
    void NotifyOrderShipped(int orderId);
}

[DataContract(Namespace = "http://example.com/data")]
public class OrderRequest
{
    [DataMember(Order = 1, IsRequired = true)]
    public string CustomerName { get; set; }

    [DataMember(Order = 2)]
    public List<OrderItem> Items { get; set; }
}
```

#### Service Implementation

```csharp
[ServiceBehavior(
    InstanceContextMode = InstanceContextMode.PerCall,
    ConcurrencyMode = ConcurrencyMode.Multiple)]
public class OrderService : IOrderService
{
    public async Task<Order> GetOrderAsync(int orderId)
    {
        using (var context = new OrderDbContext())
        {
            return await context.Orders.FindAsync(orderId);
        }
    }

    public async Task<int> CreateOrderAsync(OrderRequest request)
    {
        if (string.IsNullOrEmpty(request.CustomerName))
            throw new FaultException<ValidationFault>(
                new ValidationFault("CustomerName is required"));
        // ...
    }
}
```

#### WCF Client Proxy

```csharp
// Generated proxy or ChannelFactory
using (var factory = new ChannelFactory<IOrderService>("OrderServiceEndpoint"))
{
    var client = factory.CreateChannel();
    try
    {
        var order = await client.GetOrderAsync(42);
        ((ICommunicationObject)client).Close();
    }
    catch
    {
        ((ICommunicationObject)client).Abort();
        throw;
    }
}
```

> **Modern equivalent**: gRPC or minimal API with HTTP/JSON.

---

### 3. Assembly and GAC Concepts

#### Assembly Versioning

```csharp
// AssemblyInfo.cs
[assembly: AssemblyVersion("2.0.0.0")]        // CLR identity
[assembly: AssemblyFileVersion("2.0.1.0")]     // File version (display)
[assembly: AssemblyInformationalVersion("2.0.1-beta")]  // NuGet/semantic
```

#### Binding Redirects

When multiple dependencies reference different versions of the same assembly:

```xml
<runtime>
  <assemblyBinding xmlns="urn:schemas-microsoft-com:asm.v1">
    <dependentAssembly>
      <assemblyIdentity name="Newtonsoft.Json"
                        publicKeyToken="30ad4fe6b2a6aeed"
                        culture="neutral" />
      <bindingRedirect oldVersion="0.0.0.0-13.0.0.0"
                       newVersion="13.0.0.0" />
    </dependentAssembly>
  </assemblyBinding>
</runtime>
```

#### GAC (Global Assembly Cache)

- Shared assemblies installed system-wide with strong names
- Requires `gacutil` or MSI for installation
- Modern .NET does NOT use GAC — use NuGet packages instead

```bash
# Install to GAC (admin required)
gacutil /i MySharedLibrary.dll

# List GAC contents
gacutil /l MySharedLibrary
```

---

### 4. Global.asax Lifecycle

```csharp
public class MvcApplication : System.Web.HttpApplication
{
    // Called ONCE when app starts
    protected void Application_Start()
    {
        AreaRegistration.RegisterAllAreas();
        FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
        RouteConfig.RegisterRoutes(RouteTable.Routes);
        BundleConfig.RegisterBundles(BundleTable.Bundles);

        // DI container setup
        var container = new ContainerBuilder();
        container.RegisterControllers(typeof(MvcApplication).Assembly);
        DependencyResolver.SetResolver(
            new AutofacDependencyResolver(container.Build()));
    }

    // Called ONCE when app shuts down
    protected void Application_End()
    {
        // Cleanup resources
    }

    // Called on every unhandled exception
    protected void Application_Error()
    {
        var exception = Server.GetLastError();
        // Log, redirect to error page
        Server.ClearError();
        Response.Redirect("~/Error");
    }

    // Called at start of every request
    protected void Application_BeginRequest()
    {
        // Custom headers, CORS, URL rewriting
    }

    // Called for authentication
    protected void Application_AuthenticateRequest()
    {
        // Custom auth logic
    }
}
```

> **Modern equivalent**: `Program.cs` with middleware pipeline.

---

### 5. Migration from .NET Framework to .NET 6/8

#### Step-by-Step Strategy

1. **Analyze**: Run .NET Portability Analyzer or `apiport` tool
2. **Prepare**: Retarget to .NET Framework 4.8 (highest compat)
3. **Shared code**: Move business logic to .NET Standard 2.0 libraries
4. **Replace**: Swap Framework-specific APIs

```bash
# Install API Portability Analyzer
dotnet tool install -g apiport

# Analyze assemblies
apiport analyze -f MyApp.dll -t ".NET 8"
```

#### Common Replacements

| .NET Framework | Modern .NET |
|----------------|-------------|
| `ConfigurationManager` | `IConfiguration` + `appsettings.json` |
| `Web.config transforms` | Environment-based `appsettings.{env}.json` |
| `Global.asax` | `Program.cs` + middleware |
| `System.Web.HttpContext` | `Microsoft.AspNetCore.Http.HttpContext` |
| WCF client | gRPC or `HttpClient` |
| `System.Drawing` | `SkiaSharp` or `ImageSharp` |
| `AppDomain` | `AssemblyLoadContext` |

#### Compatibility Shim (Microsoft.Windows.Compatibility)

```xml
<!-- .csproj for .NET 8 project needing some Framework APIs -->
<ItemGroup>
  <PackageReference Include="Microsoft.Windows.Compatibility" Version="8.0.0" />
</ItemGroup>
```

This NuGet provides access to Windows-specific APIs:
- `System.Drawing.Common` (Windows-only)
- Registry access
- `System.DirectoryServices`
- `System.ServiceProcess`

#### Side-by-Side Migration Pattern

Run both Framework and modern .NET apps simultaneously during transition:

```
[Reverse Proxy (YARP)]
    |
    +-- /api/v2/*  --> .NET 8 App  (new endpoints)
    |
    +-- /api/v1/*  --> .NET Framework App  (legacy, gradually migrated)
```

---

## Anti-Patterns

### Configuration

- Hardcoding connection strings instead of using `connectionStrings` section
- Not using config transforms — deploying dev settings to production
- Storing secrets in plain text in `Web.config` — use DPAPI or environment variables

### WCF

- Using `BasicHttpBinding` without transport security in production
- Not disposing `ChannelFactory` or client proxies — leaks connections
- Catching generic `Exception` instead of `FaultException<T>`
- Using `InstanceContextMode.Single` with mutable state — concurrency bugs

### Migration

- Attempting a "big bang" rewrite — use incremental strangler fig pattern
- Ignoring `System.Web` dependencies deep in business logic
- Assuming `HttpContext.Current` will work — it does not exist in modern .NET
- Skipping the Portability Analyzer step — leads to surprise API gaps

### Assembly

- Not setting up binding redirects — causes `FileLoadException` at runtime
- Manually copying DLLs instead of using NuGet — version conflicts
- Relying on GAC for deployment — makes xcopy deploy impossible
