# TypeScript Coding Patterns

> Always-on coding pattern rules for TypeScript codebases.
> Covers strict mode, types, React hooks, imports, async, and nullability.

---

## Strict Mode & Compiler

### Do
- Enable `strict: true` in `tsconfig.json`
- Enable `noUncheckedIndexedAccess` for safer array/object access
- Enable `exactOptionalPropertyTypes` to distinguish `undefined` from missing
- Fix all compiler warnings -- do not suppress with `@ts-ignore` without comment

### Don't
- Use `@ts-ignore` without an explanatory comment and tracking issue
- Disable strict checks per-file to work around type issues
- Leave `any` casts that could be replaced with proper types

---

## Types & Interfaces

### Do
- Prefer `interface` for object shapes (extendable, better error messages)
- Use `type` for unions, intersections, and mapped types
- Use discriminated unions for state modeling: `{ status: 'loading' } | { status: 'ok'; data: T }`
- Use `unknown` instead of `any` -- narrow with type guards
- Use `as const` for literal types and immutable arrays
- Define return types explicitly for public functions

### Don't
- Use `any` -- prefer `unknown` with type narrowing
- Use `object` type -- use `Record<string, unknown>` or a specific interface
- Create overly generic types that lose type safety
- Use `enum` when a union of string literals suffices: `type Dir = 'up' | 'down'`

```typescript
// Do
interface User {
  id: string;
  name: string;
  role: UserRole;
}

type Result<T> = { ok: true; data: T } | { ok: false; error: Error };

// Don't
const data: any = fetchData(); // loses type safety
```

---

## React Hooks (when applicable)

### Do
- Call hooks only at the top level of React functions (not in loops/conditions)
- Call hooks only from React function components or custom hooks
- Prefix custom hooks with `use`: `useAuth`, `useFetchData`
- Keep dependency arrays complete and accurate
- Use `useCallback` for stable function references passed as props
- Use `useMemo` for expensive computations, not premature optimization

### Don't
- Call hooks conditionally: ~~`if (x) { useState() }`~~
- Omit dependencies from `useEffect` / `useMemo` / `useCallback`
- Use `useEffect` for derived state (use `useMemo` or compute during render)
- Put complex logic directly in `useEffect` -- extract to functions/hooks

---

## Imports & Module Structure

### Do
- Use absolute path aliases: `@/services/user-service`
- Use barrel exports (`index.ts`) only for package-level public API
- Group imports: external libs -> absolute internal -> relative
- Use `import type` for type-only imports

### Don't
- Create circular imports -- restructure modules or use dependency injection
- Import from deep internal paths of other packages
- Re-export everything in barrel files (only export public API)
- Mix `require` and `import` in the same codebase

---

## Async Patterns

### Do
- Prefer `async/await` over `.then()` chains
- Use `try/catch` for error handling in async functions
- Use `AbortController` for cancellable operations (fetch, long-running tasks)
- Use `Promise.all` for independent concurrent operations
- Handle promise rejections -- never leave unhandled promises

### Don't
- Mix `.then()` and `await` in the same function
- Ignore errors from promises (always handle or propagate)
- Use `Promise.all` when one failure should not cancel others (use `Promise.allSettled`)
- Create floating promises without `await` or explicit void annotation

```typescript
// Do
async function fetchUser(id: string, signal?: AbortSignal): Promise<User> {
  const res = await fetch(`/api/users/${id}`, { signal });
  if (!res.ok) throw new ApiError(res.status);
  return res.json() as Promise<User>;
}

// Don't
function fetchUser(id: string) {
  return fetch(`/api/users/${id}`)
    .then(r => r.json())  // no error handling, no type
}
```

---

## Nullability & Safety

### Do
- Prefer optional chaining (`?.`) for potentially null/undefined access
- Use nullish coalescing (`??`) over logical OR (`||`) for default values
- Use type guards or assertion functions for narrowing
- Validate external data at system boundaries (API responses, user input)

### Don't
- Use non-null assertion (`!`) unless null is provably impossible
- Use `||` for defaults when `0`, `""`, or `false` are valid values
- Assume API responses match TypeScript types without validation

---

## Quick Reference

| Pattern            | Do                                  | Don't                             |
|--------------------|-------------------------------------|-----------------------------------|
| Types              | `interface` for objects, `type` for unions | `any`                       |
| Unknown data       | `unknown` + type guard              | `any` cast                        |
| Hooks              | Top-level, complete deps            | Conditional hooks                 |
| Imports            | `@/` absolute, `import type`        | Circular imports                  |
| Async              | `async/await` + `try/catch`         | Unhandled `.then()` chains        |
| Nullability        | `?.`, `??`, type guards             | `!` non-null assertion            |
| Compiler           | `strict: true`                      | `@ts-ignore` without comment      |
| State modeling     | Discriminated unions                | Boolean flags for state           |
