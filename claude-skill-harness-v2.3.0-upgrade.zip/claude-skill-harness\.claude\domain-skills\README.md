# Domain Skills

Domain-specific knowledge modules. Each skill is a standalone .md file with YAML frontmatter.

## Frontmatter Standard

```yaml
---
name: skill-name
description: Brief description for auto-matching
languages: ["C#", "Python"]      # Matched against CLAUDE.md language field
frameworks: ["FastAPI", "WPF"]   # Matched against CLAUDE.md framework field
phases: ["dev", "test"]          # Phases where this skill is most relevant
---
```

## Adding a New Domain Skill

1. Create `{name}.md` in this directory
2. Add YAML frontmatter with languages/frameworks arrays
3. Write content: "When to Activate", "Core Patterns", "Anti-Patterns"
4. No Hook code changes needed — session-gate auto-detects via frontmatter matching
