# Testing Rules (All Languages)

> Always-on coding guidelines for writing and maintaining tests.
> Applies to every language and framework in this project.

---

## Must Always

### Test Writing
- Write tests before or alongside implementation (TDD preferred)
- Maintain 80%+ code coverage on core business logic
- Follow the AAA pattern: **Arrange** -> **Act** -> **Assert**
- Use descriptive test names: `should_{expected_behavior}_when_{condition}`
- Keep each test focused on a single behavior

### Coverage Strategy
- Test the happy path first
- Test edge cases: empty inputs, boundary values, max limits
- Test error scenarios: invalid input, network failures, timeouts
- Test security-relevant paths: auth, authorization, input validation

### Isolation & Data
- Isolate unit tests -- no external dependencies (DB, network, filesystem)
- Use mocks/stubs/fakes for external services
- Use fixtures or factories for test data, never production data
- Reset state between tests (fresh setup per test)

### CI Integration
- Run tests in CI on every PR -- no merge without green tests
- Fail the build on test failure, not just warn
- Track coverage trends; alert on significant drops

---

## Must Never

### Anti-Patterns
- Test implementation details (private methods, internal state)
- Share mutable state between tests
- Use `sleep()` or hard-coded delays in tests (use mocks, fakes, or `waitFor`)
- Write tests that depend on execution order
- Assert on randomly generated data without seeding

### Skipping & Ignoring
- Skip or disable failing tests without a documented reason and ticket
- Leave `TODO` tests uncommitted for more than one sprint
- Comment out tests instead of fixing them

### Data & Security
- Use production data or real credentials in tests
- Hard-code environment-specific values (URLs, ports, paths)
- Commit test snapshots of sensitive data

---

## Quick Reference

| Category       | Do                                    | Don't                              |
|----------------|---------------------------------------|------------------------------------|
| Pattern        | AAA (Arrange-Act-Assert)              | Mixed setup and assertions         |
| Naming         | `should_X_when_Y`                     | `test1`, `testStuff`               |
| Dependencies   | Mock external services                | Call real APIs in unit tests        |
| State          | Fresh setup per test                  | Shared mutable state               |
| Timing         | Mock clocks / use waitFor             | `sleep(2000)`                      |
| Coverage       | 80%+ on business logic                | 100% on getters/setters            |
| CI             | Block merge on failure                | Allow red builds                   |
| Flaky tests    | Fix root cause immediately            | Re-run until green                 |
