---
name: css-patterns
description: CSS patterns — Tailwind CSS, CSS Modules, responsive design, CSS variables, layout, and accessibility
languages: ["CSS", "TypeScript"]
frameworks: ["Tailwind CSS", "CSS Modules"]
phases: ["dev"]
---

# CSS Patterns

## When to Activate

- Styling components with Tailwind CSS utility classes
- Using CSS Modules for scoped component styles
- Building responsive layouts (mobile-first, container queries)
- Implementing theming with CSS custom properties
- Applying accessibility best practices for styling (focus states, motion, contrast)

---

## Core Patterns

### 1. Tailwind CSS

**Utility-first approach:**

```tsx
// Instead of writing custom CSS, compose utilities directly
export function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm
                    hover:shadow-md transition-shadow duration-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <div className="text-gray-600 text-sm leading-relaxed">{children}</div>
    </div>
  );
}
```

**Custom configuration (`tailwind.config.ts`):**

```ts
import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eff6ff",
          500: "#3b82f6",
          900: "#1e3a5f",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      spacing: {
        18: "4.5rem",
        88: "22rem",
      },
      animation: {
        "fade-in": "fadeIn 0.3s ease-out",
      },
      keyframes: {
        fadeIn: {
          from: { opacity: "0", transform: "translateY(4px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
```

**Responsive design (mobile-first breakpoints):**

```tsx
// sm: 640px, md: 768px, lg: 1024px, xl: 1280px, 2xl: 1536px
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
  {items.map((item) => (
    <Card key={item.id} title={item.title}>
      {item.description}
    </Card>
  ))}
</div>

// Text sizing across breakpoints
<h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold">
  Responsive Heading
</h1>

// Show/hide elements at breakpoints
<nav className="hidden md:flex gap-4">Desktop Nav</nav>
<button className="md:hidden">Menu</button>
```

**Dark mode:**

```tsx
// tailwind.config.ts: darkMode: "class" (toggle) or "media" (OS preference)

<div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
  <h1 className="text-black dark:text-white">Works in both modes</h1>
  <p className="text-gray-600 dark:text-gray-400">Subtle text adapts too</p>
</div>
```

**@apply for reusable patterns (use sparingly):**

```css
/* styles/components.css */
@layer components {
  .btn-primary {
    @apply rounded-md bg-brand-500 px-4 py-2 text-sm font-medium text-white
           hover:bg-brand-600 focus:outline-none focus:ring-2
           focus:ring-brand-500 focus:ring-offset-2
           disabled:opacity-50 disabled:cursor-not-allowed
           transition-colors duration-150;
  }

  .input-field {
    @apply block w-full rounded-md border border-gray-300 px-3 py-2
           text-sm placeholder:text-gray-400
           focus:border-brand-500 focus:ring-1 focus:ring-brand-500
           dark:border-gray-600 dark:bg-gray-800 dark:text-white;
  }
}
```

### 2. CSS Modules

**Scoped styles — class names are auto-hashed to avoid collisions:**

```css
/* components/Button.module.css */
.button {
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.15s;
}

.primary {
  composes: button;
  background-color: var(--color-brand);
  color: white;
}

.secondary {
  composes: button;
  background-color: transparent;
  border: 1px solid var(--color-border);
  color: var(--color-text);
}

.large {
  padding: 0.75rem 1.5rem;
  font-size: 1.125rem;
}
```

```tsx
// components/Button.tsx
import styles from "./Button.module.css";
import clsx from "clsx";

type Variant = "primary" | "secondary";
type Size = "default" | "large";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export function Button({
  variant = "primary",
  size = "default",
  className,
  ...props
}: ButtonProps) {
  return (
    <button
      className={clsx(
        styles[variant],
        size === "large" && styles.large,
        className
      )}
      {...props}
    />
  );
}
```

### 3. Responsive Design Patterns

**Mobile-first approach:**

```css
/* Base styles apply to mobile (smallest screens) */
.container {
  padding: 1rem;
  width: 100%;
}

/* Scale up for larger screens */
@media (min-width: 640px) {
  .container { max-width: 640px; margin: 0 auto; }
}

@media (min-width: 1024px) {
  .container { max-width: 1024px; padding: 2rem; }
}
```

**Container queries — style based on parent container, not viewport:**

```css
/* Define a containment context */
.card-container {
  container-type: inline-size;
  container-name: card;
}

/* Respond to the container's width */
@container card (min-width: 400px) {
  .card-body {
    display: flex;
    gap: 1rem;
  }
}

@container card (min-width: 600px) {
  .card-body {
    gap: 2rem;
  }
  .card-title {
    font-size: 1.5rem;
  }
}
```

```tsx
// Tailwind CSS container queries (with @tailwindcss/container-queries plugin)
<div className="@container">
  <div className="flex flex-col @md:flex-row @lg:gap-8">
    <img className="w-full @md:w-1/3" src={src} alt={alt} />
    <div className="@md:w-2/3">Content</div>
  </div>
</div>
```

### 4. CSS Variables (Custom Properties)

**Theming system:**

```css
/* styles/theme.css */
:root {
  /* Light theme (default) */
  --color-bg: #ffffff;
  --color-text: #1a1a1a;
  --color-text-muted: #6b7280;
  --color-border: #e5e7eb;
  --color-brand: #3b82f6;
  --color-brand-hover: #2563eb;

  --radius-sm: 0.25rem;
  --radius-md: 0.5rem;
  --radius-lg: 1rem;

  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.05);
  --shadow-md: 0 4px 6px rgb(0 0 0 / 0.1);
}

[data-theme="dark"] {
  --color-bg: #0f172a;
  --color-text: #f1f5f9;
  --color-text-muted: #94a3b8;
  --color-border: #334155;
  --color-brand: #60a5fa;
  --color-brand-hover: #93c5fd;

  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.3);
  --shadow-md: 0 4px 6px rgb(0 0 0 / 0.4);
}
```

```css
/* Usage */
.card {
  background: var(--color-bg);
  color: var(--color-text);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-sm);
}
```

**Dynamic theming with JavaScript:**

```ts
function setTheme(theme: "light" | "dark") {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);
}

// Override individual variables at runtime
document.documentElement.style.setProperty("--color-brand", "#8b5cf6");
```

### 5. Layout Patterns

**Flexbox — common patterns:**

```css
/* Centered content */
.centered {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}

/* Header with logo left, nav right */
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 2rem;
}

/* Sticky footer layout */
.app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.app-main {
  flex: 1; /* Pushes footer to bottom */
}
```

**CSS Grid — common layouts:**

```css
/* Holy grail layout */
.layout {
  display: grid;
  grid-template-columns: 250px 1fr 200px;
  grid-template-rows: auto 1fr auto;
  grid-template-areas:
    "header header header"
    "sidebar main aside"
    "footer footer footer";
  min-height: 100vh;
}

.layout-header  { grid-area: header; }
.layout-sidebar { grid-area: sidebar; }
.layout-main    { grid-area: main; }
.layout-aside   { grid-area: aside; }
.layout-footer  { grid-area: footer; }

/* Responsive: collapse to single column on mobile */
@media (max-width: 768px) {
  .layout {
    grid-template-columns: 1fr;
    grid-template-areas:
      "header"
      "main"
      "sidebar"
      "aside"
      "footer";
  }
}
```

```css
/* Auto-fill responsive grid */
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
}
```

### 6. Accessibility

**Focus states:**

```css
/* Remove default outline but provide visible focus for keyboard users */
button:focus-visible {
  outline: 2px solid var(--color-brand);
  outline-offset: 2px;
}

/* Do NOT remove focus on :focus (affects all users).
   Use :focus-visible — only fires on keyboard navigation. */
```

```tsx
// Tailwind focus-visible
<button className="focus:outline-none focus-visible:ring-2
                   focus-visible:ring-brand-500 focus-visible:ring-offset-2">
  Click me
</button>
```

**Reduced motion:**

```css
/* Respect user preference for reduced motion */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

```tsx
// Tailwind motion-safe / motion-reduce
<div className="motion-safe:animate-fade-in motion-reduce:opacity-100">
  Animated only if user allows motion
</div>
```

**Color contrast and screen readers:**

```css
/* Visually hidden but accessible to screen readers */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

```tsx
// Use semantic elements and ARIA where needed
<button aria-label="Close dialog">
  <XIcon className="h-5 w-5" aria-hidden="true" />
</button>

// Skip link for keyboard navigation
<a href="#main-content" className="sr-only focus:not-sr-only
   focus:fixed focus:top-4 focus:left-4 focus:z-50
   focus:bg-white focus:px-4 focus:py-2 focus:rounded">
  Skip to main content
</a>
```

---

## Anti-Patterns

1. **Using arbitrary values everywhere in Tailwind** — `w-[347px]` and `mt-[13px]` break the design system. Use the spacing/sizing scale or extend the config. Reserve arbitrary values for truly one-off cases.

2. **Nesting too many `@apply` rules** — defeats the purpose of utility-first CSS. If you need 10+ utilities in `@apply`, it is probably a component that should use inline classes.

3. **Not using mobile-first** — writing desktop styles first and then overriding for mobile creates more CSS. Start with the smallest screen and layer up.

4. **Hardcoding colors and sizes** — use CSS variables or Tailwind config values. Hardcoded values make theming and redesigns painful.

5. **Removing `:focus` styles without replacement** — `outline: none` without a visible focus indicator makes the site unusable for keyboard users. Always pair with `:focus-visible` styles.

6. **Using `vh` for mobile heights** — `100vh` does not account for mobile browser chrome. Use `100dvh` (dynamic viewport height) or `min-height: 100svh`.

7. **Ignoring `prefers-reduced-motion`** — animations that cannot be disabled cause accessibility issues (vestibular disorders). Always provide a reduced-motion fallback.

8. **Using `!important` as first resort** — indicates a specificity problem. Fix the cascade instead. In Tailwind, use the `!` prefix only when overriding third-party styles.
