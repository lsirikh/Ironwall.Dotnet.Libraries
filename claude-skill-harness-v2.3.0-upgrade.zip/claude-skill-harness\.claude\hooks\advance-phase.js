// .claude/hooks/advance-phase.js
// Phase 전환 CLI — 슬림 오케스트레이터 (v2.0 리팩토링)
//
// 사용법:
//   node .claude/hooks/advance-phase.js <phase>
//   node .claude/hooks/advance-phase.js status
//   node .claude/hooks/advance-phase.js set-track <A|B|C>
//   node .claude/hooks/advance-phase.js approve prd "코멘트"
//   node .claude/hooks/advance-phase.js new-cycle "토픽"
//   node .claude/hooks/advance-phase.js bump-major
//
// 모듈 구조:
//   _common.js              — 공유 유틸리티
//   advance-phase-harness.js — Harness Loop (자동 테스트)
//   advance-phase-changelog.js — 버전 + CHANGELOG
//   advance-phase-memory.js — dev-journal 아카이브 + audit-log GC
//   advance-phase-heal.js   — INDEX 재구축 + artifacts self-heal
//   advance-phase-transitions.js — 백워드 전환 + TDD 마커

const fs = require('fs');
const path = require('path');

// ── 모듈 로드 ───────────────────────────────────────────────────────
const { PROJECT_ROOT, STATE_FILE, appendAudit, scanDocsDir, setupHookPerfMonitoring,
        hasDevJournalEntry, readClaudeMdField } = require('./_common');
const { runAutoTest, saveLastFailure, clearLastFailure } = require('./advance-phase-harness');
const changelog = require('./advance-phase-changelog');
const memory = require('./advance-phase-memory');
const heal = require('./advance-phase-heal');
const transitions = require('./advance-phase-transitions');

setupHookPerfMonitoring('advance-phase.js');

// ── 상수 ────────────────────────────────────────────────────────────
const PHASES = ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete'];
const TRACK_ROUTES = {
  A: ['setup', 'analysis', 'complete'],
  B: ['setup', 'analysis', 'dev', 'test', 'complete'],
  C: ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete']
};
const ALLOWED_BACKWARDS = {
  'test→dev': '테스트 실패로 코드 수정',
  'test→plan': '테스트 결과로 태스크 추가/변경',
  'dev→plan': '개발 중 계획 수정',
  'plan→prd': '계획 중 요구사항 변경',
  'report→dev': '리포트 중 추가 수정',
  'report→test': '추가 테스트 필요',
  'complete→analysis': '새 사이클 시작'
};
const ITERATION_WARN_THRESHOLD = 5;
const ITERATION_HARD_LIMIT = 10;
const PRDS_DIR = path.join(PROJECT_ROOT, 'docs', 'prds');
const PLANS_DIR = path.join(PROJECT_ROOT, 'docs', 'plans');
const AUDIT_LOG = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');

// ── 인자 파싱 ───────────────────────────────────────────────────────
const args = process.argv.slice(2);
const FORCE = args.includes('--force');
function parseReason(argv) {
  const eqMatch = argv.find(a => a.startsWith('--reason='));
  if (eqMatch) return eqMatch.substring('--reason='.length);
  const idx = argv.indexOf('--reason');
  if (idx !== -1 && idx + 1 < argv.length) return argv[idx + 1];
  return null;
}
const REASON = parseReason(args);
const positional = args.filter((a, i) => {
  if (a.startsWith('--')) return false;
  if (args[i - 1] === '--reason') return false;
  return true;
});
let targetPhase = positional[0];
const trackArg = positional[1];

// ── 헬퍼 ────────────────────────────────────────────────────────────
function getCurrentState() {
  if (!fs.existsSync(STATE_FILE)) return { phase: 'setup', track: 'C' };
  try {
    const s = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    return { phase: s.phase || 'setup', track: s.track || 'C', activePrd: s.activePrd, activePlan: s.activePlan };
  } catch { return { phase: 'setup', track: 'C' }; }
}

function validateTrackRoute(track, fromPhase, toPhase) {
  const route = TRACK_ROUTES[track];
  if (!route) return { error: `알 수 없는 Track: ${track}` };
  if (!route.includes(toPhase)) return { error: `Track ${track}는 '${toPhase}' Phase를 허용하지 않음. 허용 경로: ${route.join(' → ')}` };
  const fromIdx = route.indexOf(fromPhase);
  const toIdx = route.indexOf(toPhase);
  if (fromIdx >= 0 && toIdx <= fromIdx && fromPhase !== toPhase) {
    const edge = `${fromPhase}→${toPhase}`;
    if (ALLOWED_BACKWARDS[edge]) return { backward: true, edge, description: ALLOWED_BACKWARDS[edge] };
    return { error: `백워드 전환 차단: ${fromPhase} → ${toPhase}는 허용되지 않음.\n허용 백워드: ${Object.keys(ALLOWED_BACKWARDS).join(', ')}` };
  }
  return { ok: true };
}

function hasJournalCompletionMarker() {
  const f = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal.md');
  if (!fs.existsSync(f)) return false;
  try { return /완료|✅/.test(fs.readFileSync(f, 'utf8')); } catch { return false; }
}

// ── 게이트 조건 ─────────────────────────────────────────────────────
const GATES = {
  plan: () => {
    const { track } = getCurrentState();
    if (track !== 'C') return null;
    if (!fs.existsSync(PRDS_DIR)) return 'docs/prds/ 디렉토리 없음';
    const prds = fs.readdirSync(PRDS_DIR).filter(f => f.endsWith('.md') && f !== 'skill-system-manual.md');
    if (prds.length === 0) return 'PRD 파일 없음';
    for (const prd of prds) {
      if (/^- \*\*상태\*\*:\s*Approved/im.test(fs.readFileSync(path.join(PRDS_DIR, prd), 'utf8'))) return null;
    }
    return 'Approved 상태인 PRD가 없음';
  },
  dev: () => {
    const { track } = getCurrentState();
    if (track === 'B' && !hasDevJournalEntry()) return 'Track B는 dev-journal 엔트리 필요\n형식: ### [YYYY-MM-DD HH:mm] 작업제목';
    if (track === 'C') {
      if (!fs.existsSync(PRDS_DIR)) return 'docs/prds/ 없음';
      const prds = fs.readdirSync(PRDS_DIR).filter(f => f.endsWith('.md') && f !== 'skill-system-manual.md');
      let hasApproved = false;
      for (const prd of prds) { if (/^- \*\*상태\*\*:\s*Approved/im.test(fs.readFileSync(path.join(PRDS_DIR, prd), 'utf8'))) { hasApproved = true; break; } }
      if (!hasApproved) return 'Track C dev: Approved PRD 없음';
      if (!fs.existsSync(PLANS_DIR)) return 'docs/plans/ 없음';
      const plans = fs.readdirSync(PLANS_DIR).filter(f => f.endsWith('.md'));
      if (plans.length === 0) return 'Plan 파일 없음';
      let hasUnchecked = false;
      for (const plan of plans) { if (/\[ \]|\[~\]/.test(fs.readFileSync(path.join(PLANS_DIR, plan), 'utf8'))) { hasUnchecked = true; break; } }
      if (!hasUnchecked) return 'Plan에 미완료 태스크 없음 — test로 이동 필요';
    }
    return null;
  },
  test: () => {
    const { track } = getCurrentState();
    if (track === 'C') {
      if (!fs.existsSync(PLANS_DIR)) return null;
      const plans = fs.readdirSync(PLANS_DIR).filter(f => f.endsWith('.md'));
      let totalImpl = 0, doneImpl = 0;
      for (const plan of plans) {
        const c = fs.readFileSync(path.join(PLANS_DIR, plan), 'utf8');
        totalImpl += (c.match(/^- \[[ x~!\-]\] \*\*\[IMPL-\d+\]\*\*/gm) || []).length;
        doneImpl += (c.match(/^- \[x\] \*\*\[IMPL-\d+\]\*\*/gm) || []).length;
      }
      if (totalImpl > 0 && (doneImpl / totalImpl) * 100 < 80) return `IMPL ${doneImpl}/${totalImpl} (${Math.round((doneImpl/totalImpl)*100)}%). 80% 필요`;
    }
    return null;
  },
  report: () => {
    const { track } = getCurrentState();
    if (track === 'C') {
      const testsDir = path.join(PROJECT_ROOT, 'docs', 'tests');
      if (!fs.existsSync(testsDir) || fs.readdirSync(testsDir).filter(f => f.endsWith('.md')).length === 0)
        return 'docs/tests/ test-result 파일 없음';
    }
    return null;
  },
  complete: () => {
    const { track } = getCurrentState();
    if (track === 'C') {
      if (fs.existsSync(PLANS_DIR)) {
        for (const plan of fs.readdirSync(PLANS_DIR).filter(f => f.endsWith('.md'))) {
          const c = fs.readFileSync(path.join(PLANS_DIR, plan), 'utf8');
          const remaining = (c.match(/^- \[ \]/gm) || []).length + (c.match(/^- \[~\]/gm) || []).length + (c.match(/^- \[!\]/gm) || []).length;
          if (remaining > 0) return `미완료 태스크 ${remaining}개. 모든 태스크를 [x]로 표시 필요`;
        }
      }
    }
    if (track === 'B' && !hasJournalCompletionMarker()) return 'dev-journal에 "완료" 또는 "✅" 마커 필요';
    return null;
  }
};

// ══════════════════════════════════════════════════════════════════════
// 명령 디스패치
// ══════════════════════════════════════════════════════════════════════

// ── status (+ --debug 진단 모드, FR-19) ─────────────────────────────
if (targetPhase === 'status') {
  if (!fs.existsSync(STATE_FILE)) { console.log('[STATUS] pipeline-state.json 없음 — 초기 상태'); process.exit(0); }
  const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  console.log(`[STATUS] phase: ${state.phase}`);
  console.log(`  track:      ${state.track || '(미설정 → C 폴백)'}`);
  console.log(`  activePrd:  ${state.activePrd || '없음'}`);
  console.log(`  activePlan: ${state.activePlan || '없음'}`);
  console.log(`  version:    ${changelog.readClaudeMdVersion()}`);
  console.log(`  last_changelog_date: ${state.last_changelog_date || '(없음)'}`);
  if (state.iterations && Object.keys(state.iterations).length > 0) {
    const items = Object.entries(state.iterations).filter(([k]) => k !== 'total_backwards').map(([k, v]) => `${k} x${v}`).join(', ');
    console.log(`  iterations: ${items} (total: ${state.iterations.total_backwards || 0})`);
  }
  console.log(`  updated_at: ${state.updated_at}`);
  if (state.track && TRACK_ROUTES[state.track]) console.log(`  허용 경로:  ${TRACK_ROUTES[state.track].join(' → ')}`);

  // --debug: 진단 모드 (FR-19)
  if (FORCE || args.includes('--debug')) {
    console.log('\n── DIAGNOSTIC MODE ──');
    const track = state.track || 'C';
    const route = TRACK_ROUTES[track] || [];
    const phaseIdx = route.indexOf(state.phase);
    const nextPhase = phaseIdx >= 0 && phaseIdx + 1 < route.length ? route[phaseIdx + 1] : '(없음)';
    console.log(`  다음 Phase: ${nextPhase}`);

    // 게이트 체크
    if (nextPhase !== '(없음)' && GATES[nextPhase]) {
      const gateErr = GATES[nextPhase]();
      console.log(`  ${nextPhase} 게이트: ${gateErr ? '❌ ' + gateErr : '✅ 통과'}`);
    }

    // 아티팩트 검증
    const artifacts = ['docs/prds', 'docs/plans', 'docs/tests', 'docs/reports', 'docs/memory/dev-journal.md'];
    for (const a of artifacts) {
      const fp = path.join(PROJECT_ROOT, a);
      if (fs.existsSync(fp)) {
        const stat = fs.statSync(fp);
        if (stat.isDirectory()) {
          const count = fs.readdirSync(fp).filter(f => f.endsWith('.md')).length;
          console.log(`  ${a}: ${count}개 파일`);
        } else {
          console.log(`  ${a}: ✅ (${stat.size} bytes)`);
        }
      } else {
        console.log(`  ${a}: ❌ 없음`);
      }
    }

    // 피드백 규칙 상태
    const fbFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'feedback-rules.json');
    if (fs.existsSync(fbFile)) {
      try {
        const rules = JSON.parse(fs.readFileSync(fbFile, 'utf8'));
        const active = rules.filter(r => r.active);
        const blocks = active.filter(r => r.action === 'block');
        console.log(`  피드백 규칙: ${active.length}개 활성 (${blocks.length}개 block)`);
      } catch { console.log('  피드백 규칙: 파싱 오류'); }
    }

    // 모듈 존재 확인
    const modules = ['_common.js', '_state.js', '_config.js', '_gates.js',
                     'advance-phase-harness.js', 'advance-phase-changelog.js',
                     'advance-phase-memory.js', 'advance-phase-heal.js', 'advance-phase-transitions.js'];
    const missing = modules.filter(m => !fs.existsSync(path.join(PROJECT_ROOT, '.claude', 'hooks', m)));
    console.log(`  모듈: ${modules.length - missing.length}/${modules.length} 존재${missing.length > 0 ? ' (누락: ' + missing.join(', ') + ')' : ''}`);
  }

  process.exit(0);
}

// ── set-track ───────────────────────────────────────────────────────
if (targetPhase === 'set-track') {
  if (!trackArg || !['A', 'B', 'C'].includes(trackArg.toUpperCase())) {
    console.error('사용법: node .claude/hooks/advance-phase.js set-track <A|B|C>');
    process.exit(1);
  }
  const track = trackArg.toUpperCase();
  let state = {};
  if (fs.existsSync(STATE_FILE)) { try { state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { state = {}; } }
  const prevTrack = state.track || null;
  state.track = track;
  state.updated_at = new Date().toISOString();
  const memDir = path.join(PROJECT_ROOT, 'docs', 'memory');
  if (!fs.existsSync(memDir)) fs.mkdirSync(memDir, { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
  console.log(`[OK] track: ${prevTrack || '(미설정)'} → ${track}`);
  console.log(`  허용 경로: ${TRACK_ROUTES[track].join(' → ')}`);
  appendAudit({ event: 'track-set', from: prevTrack, to: track });
  process.exit(0);
}

// ── approve ─────────────────────────────────────────────────────────
if (targetPhase === 'approve') {
  if (trackArg !== 'prd') { console.error('사용법: node advance-phase.js approve prd "코멘트"'); process.exit(1); }
  const prds = scanDocsDir('prds');
  if (prds.length === 0) { console.error('[ERROR] PRD 파일 없음'); process.exit(1); }
  const comment = REASON || positional[2] || '승인';
  const result = changelog.executePrdApproval(prds[0].name, comment);
  if (!result.ok) { console.error(`[ERROR] ${result.error}`); process.exit(1); }
  appendAudit({ event: 'user-approval', target: 'prd', file: result.prdPath, comment });
  // session-context "다음 할 일" 갱신
  const sf = path.join(PROJECT_ROOT, 'docs', 'memory', 'session-context.md');
  try { if (fs.existsSync(sf)) { let c = fs.readFileSync(sf, 'utf8'); c = c.replace(/(## 다음 할 일\n\n?)([^\n#]+)/, '$1PRD 승인 완료 — plan 작성 시작 (advance-phase.js plan)'); fs.writeFileSync(sf, c); } } catch {}
  console.log(`[OK] PRD 승인 완료: ${prds[0].name}\n  코멘트: "${comment}"\n  다음: node .claude/hooks/advance-phase.js plan`);
  process.exit(0);
}

// ── new-cycle ───────────────────────────────────────────────────────
if (targetPhase === 'new-cycle') {
  const cycleTopic = trackArg || REASON || '새 사이클';
  let state = {};
  if (fs.existsSync(STATE_FILE)) { try { state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { state = {}; } }
  if (state.phase && state.phase !== 'complete' && !FORCE) {
    console.error(`[BLOCKED] 현재 phase: ${state.phase}. complete에서만 가능.`);
    process.exit(1);
  }
  // Approved PRD 자동 backfill
  try {
    const prds = scanDocsDir('prds');
    for (const p of prds) {
      if (/^- \*\*상태\*\*:\s*Approved/im.test(fs.readFileSync(path.join(PROJECT_ROOT, p.path), 'utf8'))) {
        changelog.completePrd(p.path);
      }
    }
  } catch {}
  const prevPhase = state.phase || 'unknown';
  state.phase = 'analysis'; state.activePrd = null; state.activePlan = null; state.iterations = {};
  state.updated_at = new Date().toISOString();
  const memDir = path.join(PROJECT_ROOT, 'docs', 'memory');
  if (!fs.existsSync(memDir)) fs.mkdirSync(memDir, { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
  console.log(`[OK] new-cycle: ${prevPhase} → analysis\n  토픽: ${cycleTopic}`);
  try { heal.rebuildIndexAuto(); } catch {}
  appendAudit({ event: 'new-cycle', from: prevPhase, topic: cycleTopic });
  process.exit(0);
}

// ── bump-major ──────────────────────────────────────────────────────
if (targetPhase === 'bump-major') {
  let state = {};
  if (fs.existsSync(STATE_FILE)) { try { state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { state = {}; } }
  try {
    const result = changelog.updateChangelog(state, 'major');
    console.log(`[OK] bump-major: ${result.prevVersion || changelog.readClaudeMdVersion()} → ${result.version}`);
    state.last_changelog_date = new Date().toISOString().slice(0, 10);
    state.updated_at = new Date().toISOString();
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
    appendAudit({ event: 'bump-major', from: result.prevVersion, to: result.version });
  } catch (err) { console.error(`[ERROR] ${err.message}`); process.exit(1); }
  process.exit(0);
}

// ══════════════════════════════════════════════════════════════════════
// 메인 Phase 전환 로직
// ══════════════════════════════════════════════════════════════════════

if (!targetPhase) { console.error(`사용법: node .claude/hooks/advance-phase.js <phase>\n가능: ${PHASES.join(', ')}`); process.exit(1); }
if (!PHASES.includes(targetPhase)) { console.error(`[ERROR] 알 수 없는 phase: ${targetPhase}`); process.exit(1); }

// ── 게이트 검사 ─────────────────────────────────────────────────────
let isBackward = false, backwardEdge = null;

if (!FORCE) {
  const currentSt = getCurrentState();
  const routeResult = validateTrackRoute(currentSt.track, currentSt.phase, targetPhase);
  if (routeResult.error) {
    console.error(`[GATE BLOCKED] Track ${currentSt.track} 경로 검증 실패\n이유: ${routeResult.error}`);
    process.exit(1);
  }
  if (routeResult.backward) {
    if (!REASON) { console.error(`[GATE BLOCKED] 백워드 ${routeResult.edge}는 --reason 필수`); process.exit(1); }
    isBackward = true; backwardEdge = routeResult.edge;
    console.warn(`[BACKWARD] ${routeResult.edge} 전환 — 이유: ${REASON}`);
  } else {
    const gate = GATES[targetPhase];
    if (gate) {
      const err = gate();
      if (err) { console.error(`[GATE BLOCKED] ${targetPhase} 전환 거부\n이유: ${err}`); process.exit(1); }
    }
  }
} else { console.warn('[WARN] --force — 게이트 스킵'); }

// ── 상태 갱신 ───────────────────────────────────────────────────────
let state = {};
if (fs.existsSync(STATE_FILE)) { try { state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { state = {}; } }
const prevPhase = state.phase || 'unknown';
state.phase = targetPhase;
state.updated_at = new Date().toISOString();

// 백워드 이터레이션 카운터
if (isBackward && backwardEdge) {
  if (!state.iterations) state.iterations = {};
  state.iterations[backwardEdge] = (state.iterations[backwardEdge] || 0) + 1;
  state.iterations.total_backwards = (state.iterations.total_backwards || 0) + 1;
  if (state.iterations[backwardEdge] > ITERATION_HARD_LIMIT && !FORCE) {
    console.error(`[HARD GATE] ${backwardEdge} 이터레이션 ${state.iterations[backwardEdge]}회 — 하드 리미트 초과`);
    console.error('  설계 회고가 필요합니다. 동일 전환이 10회 이상 반복되면 근본 원인 분석 필수.');
    console.error('  사용자에게 상황을 보고하고 지시를 받으세요.');
    appendAudit({ event: 'iteration-hard-limit', edge: backwardEdge, count: state.iterations[backwardEdge] });
    process.exit(1);
  } else if (state.iterations[backwardEdge] > ITERATION_WARN_THRESHOLD) {
    console.warn(`[WARN] ${backwardEdge} 이터레이션 ${state.iterations[backwardEdge]}회 초과 — 설계 재검토 권장`);
    appendAudit({ event: 'iteration-warning', edge: backwardEdge, count: state.iterations[backwardEdge] });
  }
  try { transitions.appendDevJournalBackward(prevPhase, targetPhase, REASON, state.iterations); } catch {}
}

// ── Harness Loop (test Phase) ───────────────────────────────────────
if (targetPhase === 'test') {
  const testResult = runAutoTest();
  if (testResult.skip) {
    console.log(`  Harness Loop: ${testResult.reason} — 수동 테스트 모드`);
  } else if (testResult.pass) {
    state = clearLastFailure(state);
    console.log('  Harness Loop: ✅ 테스트 통과');
    appendAudit({ event: 'auto-test-pass', command: readClaudeMdField('test_command') });
  } else {
    state = saveLastFailure(state, 'test', testResult);
    state.autoFixCount = (state.autoFixCount || 0) + 1;
    const maxFix = readClaudeMdField('max_auto_fix') || 3;
    appendAudit({ event: 'auto-test-fail', attempt: state.autoFixCount, max: maxFix, error: (testResult.message || '').substring(0, 200) });
    if (state.autoFixCount >= maxFix) {
      console.warn(`  Harness Loop: ❌ 실패 (${state.autoFixCount}/${maxFix}) — 자동 수정 한도 도달`);
      appendAudit({ event: 'auto-fix-limit', attempts: state.autoFixCount });
    } else {
      state.phase = 'dev'; targetPhase = 'dev';
      console.warn(`  Harness Loop: ❌ 실패 (${state.autoFixCount}/${maxFix}) — dev 자동 복귀`);
      appendAudit({ event: 'auto-fix-loop', from: 'test', to: 'dev', attempt: state.autoFixCount });
    }
  }
}

// ── [FR-17] Tier 3: 행동 피드백 자동 승격 (7일 내 3회 위반 → remind→block) ──
try {
  const fbFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'feedback-rules.json');
  if (fs.existsSync(fbFile) && fs.existsSync(path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl'))) {
    const rules = JSON.parse(fs.readFileSync(fbFile, 'utf8'));
    const auditLines = fs.readFileSync(path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl'), 'utf8').split('\n');
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    let changed = false;
    for (const rule of rules) {
      if (!rule.active || rule.action !== 'remind') continue;
      const violations = auditLines.filter(l => {
        try { const e = JSON.parse(l); return e.event === 'feedback-violation' && e.rule_id === rule.id && new Date(e.timestamp).getTime() > sevenDaysAgo; }
        catch { return false; }
      });
      if (violations.length >= 3) {
        rule.action = 'block';
        rule.promoted_at = new Date().toISOString();
        console.log(`  [FEEDBACK] ${rule.id}: remind → block (${violations.length}회 위반/7일)`);
        appendAudit({ event: 'feedback-promotion', rule_id: rule.id, violations: violations.length });
        changed = true;
      }
    }
    if (changed) fs.writeFileSync(fbFile, JSON.stringify(rules, null, 2) + '\n');
  }
} catch { /* silent */ }

// ── complete 처리 ───────────────────────────────────────────────────
if (targetPhase === 'complete' && state.track === 'C') {
  // artifacts 강제 갱신
  try {
    const recentPrd = scanDocsDir('prds')[0];
    const recentPlan = scanDocsDir('plans')[0];
    if (recentPrd) { state.activePrd = recentPrd.path; state.artifacts = state.artifacts || {}; state.artifacts.prd = { path: recentPrd.path, recorded_at: new Date().toISOString() }; }
    if (recentPlan) { state.activePlan = recentPlan.path; state.artifacts = state.artifacts || {}; state.artifacts.plan = { path: recentPlan.path, recorded_at: new Date().toISOString() }; }
  } catch {}
  // PRD Completed
  try { if (state.activePrd) { const r = changelog.completePrd(state.activePrd); if (r.ok) console.log(`  PRD 자동 Completed: ${state.activePrd}`); } } catch {}
  // Memory hygiene
  try { const ja = memory.archiveDevJournalIfNeeded(); if (ja && ja.ok) console.log(`  dev-journal 아카이브: ${ja.archived}건 → ${ja.file}`); } catch {}
  try { const ag = memory.gcAuditLogIfNeeded(); if (ag && ag.ok) console.log(`  audit-log GC: ${ag.archived}건 → ${ag.file}`); } catch {}
  // CHANGELOG
  if (!FORCE) {
    try {
      const cr = changelog.updateChangelog(state, 'auto');
      if (cr.skipped) { console.log(`  CHANGELOG: 이미 기록됨, 스킵`); }
      else { console.log(`  CHANGELOG: ${cr.prevVersion} → ${cr.version}`); state.last_changelog_date = new Date().toISOString().slice(0, 10); }
    } catch (err) { console.error(`  [WARN] CHANGELOG 실패: ${err.message}`); appendAudit({ event: 'changelog-update-failed', error: err.message }); }
  }
}
if (targetPhase === 'complete') { state.activePrd = null; state.activePlan = null; }

// ── 상태 저장 ───────────────────────────────────────────────────────
const memoryDir = path.join(PROJECT_ROOT, 'docs', 'memory');
if (!fs.existsSync(memoryDir)) fs.mkdirSync(memoryDir, { recursive: true });
state = heal.healArtifacts(state);
fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
console.log(`[OK] phase: ${prevPhase} → ${targetPhase}`);
console.log(`  pipeline-state: ${STATE_FILE}`);

// INDEX 재구축
try { const r = heal.rebuildIndexAuto(); if (r.ok) console.log(`  INDEX.md: 자동 재구축 (총 ${r.totalDocs}개 문서)`); }
catch (err) { console.warn(`  [WARN] INDEX 실패: ${err.message}`); }

// session-context 동기화
const SESSION_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'session-context.md');
try {
  if (fs.existsSync(SESSION_FILE)) {
    let content = fs.readFileSync(SESSION_FILE, 'utf8');
    content = content.replace(/- \*\*현재 Phase\*\*: .+/, `- **현재 Phase**: ${targetPhase}`);
    content = content.replace(/- \*\*마지막 업데이트\*\*: .+/, `- **마지막 업데이트**: ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`);
    if (targetPhase === 'complete') {
      content = content.replace(/- \*\*활성 PRD\*\*: .+/, '- **활성 PRD**: 없음').replace(/- \*\*활성 Plan\*\*: .+/, '- **활성 Plan**: 없음');
    }
    fs.writeFileSync(SESSION_FILE, content);
    console.log(`  session-context: Phase 동기화 완료 → ${targetPhase}`);
  }
} catch (err) { console.log(`  [WARN] session-context 동기화 실패: ${err.message}`); }

// [FR-09] Agent 추천 안내
try {
  const _agents = require('./_agents');
  const nextAgents = _agents.getAgentsForPhase(targetPhase);
  if (nextAgents.length > 0) {
    const list = nextAgents.map(a => `${a.name}(${a.model})`).join(', ');
    console.log(`  💡 다음 Phase 활용 Agent: ${list}`);
  }
} catch { /* silent */ }

// 감사 로그
appendAudit({
  event: FORCE ? 'force-phase-override' : isBackward ? 'backward-transition' : 'phase-transition',
  from: prevPhase, to: targetPhase,
  force: FORCE || undefined, backward: isBackward || undefined,
  edge: backwardEdge || undefined, reason: REASON || undefined,
  iteration_count: (isBackward && state.iterations) ? state.iterations[backwardEdge] : undefined
});
