// .claude/hooks/pre-compact.js
// PreCompact Hook — 컨텍스트 컴팩션 전 현재 상태 스냅샷 저장
//
// Claude Code가 대화 컨텍스트를 압축하기 직전에 실행.
// 현재 작업 상태, 진행 중인 태스크, 중요 컨텍스트를 보존하여
// 컴팩션 후에도 작업 연속성을 유지한다.

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(ROOT, 'docs', 'memory', 'pipeline-state.json');
const SESSION_FILE = path.join(ROOT, 'docs', 'memory', 'session-context.md');
const AUDIT_LOG = path.join(ROOT, 'docs', 'memory', 'audit-log.jsonl');
const COMPACT_LOG = path.join(ROOT, 'docs', 'memory', 'compact-log.jsonl');

try {
  const snapshot = {
    timestamp: new Date().toISOString(),
    event: 'pre-compact'
  };

  // 1. pipeline-state 스냅샷
  if (fs.existsSync(STATE_FILE)) {
    try {
      const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      snapshot.phase = state.phase;
      snapshot.track = state.track;
      snapshot.activePrd = state.activePrd || null;
      snapshot.activePlan = state.activePlan || null;
      snapshot.iterations = state.iterations || {};
    } catch { /* silent */ }
  }

  // 2. 현재 작업 중인 태스크 (plan에서 [~] 상태)
  if (snapshot.activePlan) {
    try {
      const planPath = path.join(ROOT, snapshot.activePlan);
      if (fs.existsSync(planPath)) {
        const planContent = fs.readFileSync(planPath, 'utf8');
        const inProgress = [];
        const re = /^- \[~\] \*\*\[([A-Z]+-\d+)\]\*\*\s*(.+)/gm;
        let m;
        while ((m = re.exec(planContent)) !== null) {
          inProgress.push({ id: m[1], title: m[2].substring(0, 60) });
        }
        if (inProgress.length > 0) {
          snapshot.in_progress_tasks = inProgress;
        }

        // 진행률
        const doneCount = (planContent.match(/^- \[x\]/gm) || []).length;
        const totalCount = (planContent.match(/^- \[[ x~!\-]\]/gm) || []).length;
        if (totalCount > 0) {
          snapshot.progress = `${doneCount}/${totalCount} (${Math.round(doneCount / totalCount * 100)}%)`;
        }
      }
    } catch { /* silent */ }
  }

  // 3. session-context 요약 (다음 할 일)
  if (fs.existsSync(SESSION_FILE)) {
    try {
      const sc = fs.readFileSync(SESSION_FILE, 'utf8');
      const nextMatch = sc.match(/## 다음 할 일\n\n(.+)/);
      if (nextMatch) {
        snapshot.next_task = nextMatch[1].substring(0, 100);
      }
    } catch { /* silent */ }
  }

  // 4. compact-log에 스냅샷 저장
  const memDir = path.dirname(COMPACT_LOG);
  if (!fs.existsSync(memDir)) fs.mkdirSync(memDir, { recursive: true });
  fs.appendFileSync(COMPACT_LOG, JSON.stringify(snapshot) + '\n');

  // 5. audit-log에도 기록
  fs.appendFileSync(AUDIT_LOG, JSON.stringify({
    timestamp: snapshot.timestamp,
    event: 'pre-compact',
    phase: snapshot.phase,
    track: snapshot.track,
    progress: snapshot.progress || 'N/A'
  }) + '\n');

  // 6. stdout 출력 — Claude에게 컴팩션 후 복구 힌트
  const hints = [];
  if (snapshot.phase) hints.push(`Phase: ${snapshot.phase}`);
  if (snapshot.track) hints.push(`Track: ${snapshot.track}`);
  if (snapshot.activePlan) hints.push(`Plan: ${snapshot.activePlan}`);
  if (snapshot.progress) hints.push(`Progress: ${snapshot.progress}`);
  if (snapshot.in_progress_tasks) {
    hints.push(`Working: ${snapshot.in_progress_tasks.map(t => t.id).join(', ')}`);
  }
  if (snapshot.next_task) hints.push(`Next: ${snapshot.next_task}`);

  if (hints.length > 0) {
    console.log(`[Compact Snapshot] ${hints.join(' | ')}`);
  }

} catch { /* silent — 컴팩션을 차단하면 안 됨 */ }

process.exit(0);
