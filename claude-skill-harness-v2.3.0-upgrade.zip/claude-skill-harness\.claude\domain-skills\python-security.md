---
name: python-security
description: Python 보안 패턴 — 입력 검증, SQL injection 방지, 인증, 시크릿 관리
languages: ["Python"]
frameworks: ["Python", "FastAPI"]
phases: ["test"]
---

# Python Security

## When to Activate

- Python 보안 리뷰 시
- 인증/인가 구현 시

## Core Patterns

### Input Validation (Pydantic)

```python
from pydantic import BaseModel, field_validator, constr

class UserInput(BaseModel):
    name: constr(min_length=1, max_length=100)
    email: str
    age: int

    @field_validator("email")
    @classmethod
    def validate_email(cls, v):
        if not re.match(r"^[\w.-]+@[\w.-]+\.\w+$", v):
            raise ValueError("Invalid email format")
        return v.lower()
```

### SQL Injection Prevention

```python
# BAD: string formatting
cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")

# GOOD: parameterized query
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))

# GOOD: SQLAlchemy ORM
user = session.query(User).filter(User.id == user_id).first()
```

### JWT Authentication

```python
from jose import jwt, JWTError
from datetime import datetime, timedelta

SECRET_KEY = os.environ["JWT_SECRET"]
ALGORITHM = "HS256"

def create_token(data: dict, expires_delta: timedelta = timedelta(hours=1)):
    to_encode = data.copy()
    to_encode["exp"] = datetime.utcnow() + expires_delta
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
```

### Password Hashing

```python
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

hashed = pwd_context.hash("plain_password")
is_valid = pwd_context.verify("plain_password", hashed)
```

### Environment Variables (pydantic-settings)

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str
    jwt_secret: str
    debug: bool = False

    model_config = ConfigDict(env_file=".env")

settings = Settings()  # auto-loads from environment
```

### Rate Limiting

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.get("/api/data")
@limiter.limit("10/minute")
async def get_data(request: Request):
    ...
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| f-string SQL | Parameterized queries | SQL injection |
| `eval(user_input)` | AST/parser | Code injection |
| Hardcoded secrets | `os.environ` / pydantic-settings | Exposure risk |
| MD5/SHA1 passwords | bcrypt/argon2 | Crackable |
| `DEBUG=True` in prod | Environment config | Info leak |
| `*` CORS origins in prod | Explicit origins list | Security |
| Token in URL query param | Authorization header | Logged in URLs |
