# Agents

Phase-aware agent definitions. Each agent is a .md file with YAML frontmatter.

## Frontmatter Standard

```yaml
---
name: agent-name
description: What this agent does
tools: ["Read", "Grep", "Glob"]
model: sonnet
phases: ["dev", "test"]
---
```

## Phase-Agent Mapping

| Phase | Agents | Required |
|-------|--------|----------|
| analysis | architect | Optional |
| plan | planner | Optional |
| dev | code-reviewer, tdd-guide, build-error-resolver | Recommended |
| test | security-reviewer, tdd-guide | Optional |
| report | doc-updater | Optional |
