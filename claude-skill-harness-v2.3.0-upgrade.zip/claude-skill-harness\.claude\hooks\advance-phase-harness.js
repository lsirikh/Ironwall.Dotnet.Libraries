// .claude/hooks/advance-phase-harness.js
// Harness Loop 헬퍼 — FR-01~05 자동 테스트 실행/실패 관리

const path = require('path');
const { execSync } = require('child_process');
const { readClaudeMdField } = require('./_common');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

function runAutoTest() {
  const cmd = readClaudeMdField('test_command');
  if (!cmd) return { skip: true, reason: 'test_command 미설정' };
  try {
    const output = execSync(cmd, {
      cwd: PROJECT_ROOT,
      timeout: 60000,
      encoding: 'utf8',
      stdio: ['pipe', 'pipe', 'pipe']
    });
    return { pass: true, output: (output || '').substring(0, 500) };
  } catch (err) {
    const msg = (err.stderr || err.stdout || err.message || '').substring(0, 500);
    const fileMatch = msg.match(/([^\s:]+\.\w+):(\d+)/);
    return {
      pass: false,
      message: msg,
      file: fileMatch ? `${fileMatch[1]}:${fileMatch[2]}` : null
    };
  }
}

function saveLastFailure(state, type, result) {
  state.lastFailure = {
    type, message: (result.message || '').substring(0, 500),
    file: result.file || null, timestamp: new Date().toISOString()
  };
  return state;
}

function clearLastFailure(state) {
  state.lastFailure = null;
  state.autoFixCount = 0;
  return state;
}

module.exports = { runAutoTest, saveLastFailure, clearLastFailure };
