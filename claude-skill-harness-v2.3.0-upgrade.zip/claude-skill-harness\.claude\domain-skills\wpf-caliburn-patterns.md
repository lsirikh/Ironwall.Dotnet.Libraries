---
name: wpf-caliburn-patterns
description: WPF MVVM patterns with Caliburn.Micro — conductors, screen lifecycle, event aggregator, conventions, WindowManager
languages: ["C#"]
frameworks: ["WPF", "Caliburn.Micro"]
phases: ["dev", "test"]
---

# WPF + Caliburn.Micro Patterns

## When to Activate

- Building or maintaining WPF desktop applications with Caliburn.Micro
- Implementing screen navigation with Conductors
- Wiring ViewModels to Views using naming conventions
- Handling inter-ViewModel communication via EventAggregator
- Managing window/dialog lifecycle with WindowManager
- Integrating Caliburn.Micro with Autofac or other DI containers

---

## Core Patterns

### 1. Bootstrapper with DI Integration

#### Basic Bootstrapper with Autofac

```csharp
public class AppBootstrapper : BootstrapperBase
{
    private IContainer _container;

    public AppBootstrapper()
    {
        Initialize();
    }

    protected override void Configure()
    {
        var builder = new ContainerBuilder();

        // Caliburn.Micro infrastructure
        builder.RegisterType<WindowManager>()
            .As<IWindowManager>().SingleInstance();
        builder.RegisterType<EventAggregator>()
            .As<IEventAggregator>().SingleInstance();

        // ViewModels — register all in this assembly
        builder.RegisterAssemblyTypes(typeof(AppBootstrapper).Assembly)
            .Where(t => t.Name.EndsWith("ViewModel"))
            .AsSelf()
            .InstancePerDependency();

        // Views
        builder.RegisterAssemblyTypes(typeof(AppBootstrapper).Assembly)
            .Where(t => t.Name.EndsWith("View"))
            .AsSelf();

        _container = builder.Build();
    }

    protected override object GetInstance(Type service, string key)
    {
        return key == null
            ? _container.Resolve(service)
            : _container.ResolveKeyed(key, service);
    }

    protected override IEnumerable<object> GetAllInstances(Type service)
    {
        var type = typeof(IEnumerable<>).MakeGenericType(service);
        return ((IEnumerable<object>)_container.Resolve(type));
    }

    protected override void BuildUp(object instance)
    {
        _container.InjectProperties(instance);
    }

    protected override async void OnStartup(object sender, StartupEventArgs e)
    {
        await DisplayRootViewForAsync<ShellViewModel>();
    }

    protected override void OnExit(object sender, EventArgs e)
    {
        _container.Dispose();
        base.OnExit(sender, e);
    }
}
```

---

### 2. Screen Lifecycle

Every ViewModel inheriting `Screen` has a defined lifecycle.

```csharp
public class OrderDetailViewModel : Screen
{
    private readonly IOrderRepository _repository;
    private readonly IWindowManager _windowManager;
    private int _orderId;

    public OrderDetailViewModel(
        IOrderRepository repository, IWindowManager windowManager)
    {
        _repository = repository;
        _windowManager = windowManager;
    }

    // Called by conductor or navigation logic before activation
    public void Initialize(int orderId)
    {
        _orderId = orderId;
    }

    // Called when the screen is activated (shown)
    protected override async Task OnActivateAsync(CancellationToken cancellationToken)
    {
        await base.OnActivateAsync(cancellationToken);
        DisplayName = "Order Detail";
        Order = await _repository.GetByIdAsync(_orderId, cancellationToken);
    }

    // Called when the screen is deactivated
    // close=true means the screen is being closed, not just hidden
    protected override async Task OnDeactivateAsync(bool close, CancellationToken ct)
    {
        if (close && HasUnsavedChanges)
        {
            await SaveDraftAsync(ct);
        }
        await base.OnDeactivateAsync(close, ct);
    }

    // Called before closing — return false to cancel close
    public override async Task<bool> CanCloseAsync(CancellationToken ct)
    {
        if (!HasUnsavedChanges) return true;

        var result = await _windowManager.ShowDialogAsync(
            new ConfirmDialogViewModel("Save changes before closing?"));
        return result == true;
    }

    // Close the screen programmatically
    public async Task CloseAsync()
    {
        await TryCloseAsync(result: true);
    }

    private Order _order;
    public Order Order
    {
        get => _order;
        set => Set(ref _order, value);
    }

    public bool HasUnsavedChanges { get; private set; }
}
```

#### Lifecycle Order

1. Constructor (DI resolves dependencies)
2. `OnInitializedAsync()` (once per instance)
3. `OnActivateAsync()` (each time screen is shown)
4. `OnDeactivateAsync(close: false)` (screen hidden but alive)
5. `OnDeactivateAsync(close: true)` (screen removed)

---

### 3. Conductors

#### Conductor&lt;T&gt; — Single Active Item

For a main content region that shows one screen at a time.

```csharp
public class ShellViewModel : Conductor<Screen>
{
    private readonly IWindowManager _windowManager;

    public ShellViewModel(IWindowManager windowManager)
    {
        _windowManager = windowManager;
    }

    public async Task ShowDashboard()
    {
        await ActivateItemAsync(IoC.Get<DashboardViewModel>());
    }

    public async Task ShowOrders()
    {
        var vm = IoC.Get<OrderListViewModel>();
        await ActivateItemAsync(vm);
    }
}
```

#### Conductor&lt;T&gt;.Collection.OneActive — Tab-Like Navigation

```csharp
public class WorkspaceViewModel : Conductor<Screen>.Collection.OneActive
{
    public async Task OpenOrder(int orderId)
    {
        // Check if already open
        var existing = Items.OfType<OrderDetailViewModel>()
            .FirstOrDefault(vm => vm.OrderId == orderId);

        if (existing != null)
        {
            await ActivateItemAsync(existing);
            return;
        }

        var vm = IoC.Get<OrderDetailViewModel>();
        vm.Initialize(orderId);
        await ActivateItemAsync(vm);
    }

    // Items property holds all open tabs
    // ActiveItem is the currently visible tab
    // Closing a tab calls OnDeactivateAsync(close: true)
}
```

#### Conductor&lt;T&gt;.Collection.AllActive — All Items Visible

```csharp
public class DashboardViewModel : Conductor<Screen>.Collection.AllActive
{
    protected override async Task OnActivateAsync(CancellationToken ct)
    {
        await base.OnActivateAsync(ct);
        // All widgets activate simultaneously
        await ActivateItemAsync(IoC.Get<SalesChartViewModel>(), ct);
        await ActivateItemAsync(IoC.Get<AlertsPanelViewModel>(), ct);
        await ActivateItemAsync(IoC.Get<RecentOrdersViewModel>(), ct);
    }
}
```

---

### 4. EventAggregator

Loosely-coupled inter-ViewModel messaging.

#### Event Definition

```csharp
public class OrderCreatedEvent
{
    public int OrderId { get; init; }
    public string CustomerName { get; init; }
    public DateTime CreatedAt { get; init; }
}

public class ThemeChangedEvent
{
    public string ThemeName { get; init; }
}
```

#### Publishing

```csharp
public class OrderFormViewModel : Screen
{
    private readonly IEventAggregator _events;
    private readonly IOrderRepository _repository;

    public OrderFormViewModel(IEventAggregator events, IOrderRepository repository)
    {
        _events = events;
        _repository = repository;
    }

    public async Task SubmitOrder()
    {
        var order = await _repository.CreateAsync(CurrentOrder);

        await _events.PublishOnUIThreadAsync(new OrderCreatedEvent
        {
            OrderId = order.Id,
            CustomerName = order.CustomerName,
            CreatedAt = DateTime.UtcNow
        });
    }
}
```

#### Subscribing with HandleAsync&lt;T&gt;

```csharp
public class OrderListViewModel : Screen, IHandle<OrderCreatedEvent>
{
    private readonly IEventAggregator _events;

    public OrderListViewModel(IEventAggregator events)
    {
        _events = events;
    }

    protected override async Task OnActivateAsync(CancellationToken ct)
    {
        await base.OnActivateAsync(ct);
        // Subscribe when activated
        _events.SubscribeOnPublishedThread(this);
    }

    protected override async Task OnDeactivateAsync(bool close, CancellationToken ct)
    {
        if (close)
        {
            // Unsubscribe when closed to prevent memory leaks
            _events.Unsubscribe(this);
        }
        await base.OnDeactivateAsync(close, ct);
    }

    public async Task HandleAsync(OrderCreatedEvent message, CancellationToken ct)
    {
        // Handle on UI thread — safe to update bound collections
        Orders.Add(new OrderSummary
        {
            Id = message.OrderId,
            Customer = message.CustomerName
        });
    }
}
```

---

### 5. Convention-Based Binding

Caliburn.Micro auto-binds `x:Name` in XAML to ViewModel properties and methods.

#### View (XAML)

```xml
<Window x:Class="MyApp.Views.LoginView"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">
    <StackPanel Margin="20">
        <!-- x:Name="Username" binds to ViewModel.Username property -->
        <TextBox x:Name="Username" />

        <!-- x:Name="Password" binds to ViewModel.Password property -->
        <PasswordBox x:Name="Password" />

        <!-- x:Name="Login" binds Click to ViewModel.Login() method -->
        <!-- CanLogin property auto-enables/disables the button -->
        <Button x:Name="Login" Content="Sign In" />

        <!-- x:Name="ErrorMessage" binds to ViewModel.ErrorMessage -->
        <TextBlock x:Name="ErrorMessage" Foreground="Red" />
    </StackPanel>
</Window>
```

#### ViewModel

```csharp
public class LoginViewModel : Screen
{
    private readonly IAuthService _authService;

    public LoginViewModel(IAuthService authService)
    {
        _authService = authService;
    }

    private string _username;
    public string Username
    {
        get => _username;
        set
        {
            Set(ref _username, value);
            NotifyOfPropertyChange(() => CanLogin);
        }
    }

    private string _password;
    public string Password
    {
        get => _password;
        set
        {
            Set(ref _password, value);
            NotifyOfPropertyChange(() => CanLogin);
        }
    }

    // Guard property — disables button when false
    public bool CanLogin =>
        !string.IsNullOrEmpty(Username) && !string.IsNullOrEmpty(Password);

    // Action method — bound to Button Click via x:Name="Login"
    public async Task Login()
    {
        try
        {
            var result = await _authService.AuthenticateAsync(Username, Password);
            if (result.Success)
                await TryCloseAsync(true);
            else
                ErrorMessage = result.ErrorMessage;
        }
        catch (Exception ex)
        {
            ErrorMessage = "Connection failed. Please try again.";
        }
    }

    private string _errorMessage;
    public string ErrorMessage
    {
        get => _errorMessage;
        set => Set(ref _errorMessage, value);
    }
}
```

#### Naming Conventions

| XAML `x:Name` | Resolves to |
|---------------|-------------|
| `Username` | Property `Username` (two-way binding for TextBox) |
| `Login` | Method `Login()` (click handler for Button) |
| `CanLogin` | Guard for `Login` action (enables/disables) |
| `Items` | `ItemsSource` binding for ListBox/DataGrid |
| `SelectedItem` | `SelectedItem` binding for selectors |

---

### 6. WindowManager

```csharp
public class ShellViewModel : Conductor<Screen>
{
    private readonly IWindowManager _windowManager;

    public ShellViewModel(IWindowManager windowManager)
    {
        _windowManager = windowManager;
    }

    // Show a modal dialog — returns bool? (true/false/null)
    public async Task ShowSettings()
    {
        var vm = IoC.Get<SettingsViewModel>();
        var result = await _windowManager.ShowDialogAsync(vm);

        if (result == true)
        {
            ApplySettings(vm.Settings);
        }
    }

    // Show a non-modal window
    public async Task OpenMonitor()
    {
        var vm = IoC.Get<MonitorViewModel>();
        await _windowManager.ShowWindowAsync(vm);
    }

    // Show a popup
    public async Task ShowPreview()
    {
        var vm = IoC.Get<PreviewViewModel>();
        await _windowManager.ShowPopupAsync(vm);
    }
}
```

---

### 7. Coroutine Support (IResult)

Sequences of async operations with UI interaction.

```csharp
public class ImportViewModel : Screen
{
    private readonly IImportService _importService;

    public ImportViewModel(IImportService importService)
    {
        _importService = importService;
    }

    public IEnumerable<IResult> ImportFile()
    {
        var openFile = new OpenFileResult("CSV Files|*.csv");
        yield return openFile;

        var filePath = openFile.SelectedFile;
        if (filePath == null) yield break;

        var busy = new BusyResult("Importing data...");
        yield return busy;

        var import = new AsyncResult(async ct =>
        {
            var data = await _importService.ImportAsync(filePath, ct);
            ImportedCount = data.Count;
        });
        yield return import;

        yield return new NotificationResult($"Imported {ImportedCount} records.");
    }

    public int ImportedCount { get; private set; }
}

// Custom IResult implementation
public class AsyncResult : IResult
{
    private readonly Func<CancellationToken, Task> _action;

    public AsyncResult(Func<CancellationToken, Task> action) => _action = action;

    public event EventHandler<ResultCompletionEventArgs> Completed;

    public async void Execute(CoroutineExecutionContext context)
    {
        try
        {
            await _action(CancellationToken.None);
            Completed?.Invoke(this, new ResultCompletionEventArgs());
        }
        catch (Exception ex)
        {
            Completed?.Invoke(this, new ResultCompletionEventArgs { Error = ex });
        }
    }
}
```

---

### 8. View-Model-First Approach

Caliburn.Micro resolves Views from ViewModels by convention:

| ViewModel | View |
|-----------|------|
| `ShellViewModel` | `ShellView` |
| `ViewModels.OrderDetailViewModel` | `Views.OrderDetailView` |
| `Features.Orders.ListViewModel` | `Features.Orders.ListView` |

```xml
<!-- ContentControl in parent view binds to ActiveItem -->
<!-- Caliburn auto-resolves the correct View -->
<ContentControl x:Name="ActiveItem" />
```

Override view location when conventions do not fit:

```csharp
// In Bootstrapper.Configure()
ViewLocator.AddNamespaceMapping("*.ViewModels.Dialogs", "*.Views.Shared");
```

---

## Anti-Patterns

### Lifecycle

- Not calling `base.OnActivateAsync()` / `base.OnDeactivateAsync()` — breaks conductor logic
- Doing heavy work in constructor instead of `OnActivateAsync` — blocks UI thread
- Forgetting to unsubscribe from `EventAggregator` on close — memory leaks

### Conventions

- Using `x:Name` that does not match any ViewModel member — silent binding failure
- Mixing explicit `{Binding ...}` with convention bindings on the same control
- Naming a guard `IsLoginEnabled` instead of `CanLogin` — convention mismatch

### Conductors

- Not awaiting `ActivateItemAsync` — screen may not be ready when accessed
- Opening duplicate screens without checking `Items` collection first
- Using `IoC.Get<T>()` directly in ViewModel instead of constructor injection

### EventAggregator

- Publishing on background thread and updating UI-bound properties — cross-thread exception
- Subscribing in constructor instead of `OnActivateAsync` — receives events when not visible
- Not implementing `IHandle<T>` interface — `HandleAsync` method silently ignored
