// .claude/hooks/advance-phase-transitions.js
// 백워드 전환 + TDD 마커 + dev-journal 자동 엔트리

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

function extractTddPhase(reason) {
  if (!reason) return null;
  const m = reason.match(/\[(Red|Green|Refactor)\]/i);
  if (!m) return null;
  const phase = m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
  const icons = { Red: '🔴', Green: '🟢', Refactor: '🔵' };
  return { phase, icon: icons[phase] || '' };
}

function appendDevJournalBackward(fromPhase, toPhase, reason, iterations) {
  const journalFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal.md');
  const now = new Date().toISOString().slice(0, 16).replace('T', ' ');
  const edge = `${fromPhase}→${toPhase}`;
  const count = (iterations && iterations[edge]) || 1;
  const total = (iterations && iterations.total_backwards) || 1;

  const tdd = extractTddPhase(reason);
  const tddLine = tdd ? `\n- **TDD 단계**: ${tdd.icon} ${tdd.phase}` : '';

  const entry = `### [${now}] 🔁 ${fromPhase} → ${toPhase} (${count}회차)\n- **이유**: ${reason}${tddLine}\n- **이전 phase**: ${fromPhase}\n- **다음 phase**: ${toPhase}\n- **이터레이션**: ${edge} x${count}, total backwards x${total}\n`;

  try {
    let content = '';
    if (fs.existsSync(journalFile)) {
      content = fs.readFileSync(journalFile, 'utf8');
    } else {
      content = `# 개발 일지 (Dev Journal)\n\n## 엔트리\n\n`;
    }
    if (content.includes('## 엔트리')) {
      content = content.replace(/(## 엔트리\n\n?)/, `$1${entry}\n`);
    } else {
      content += `\n## 엔트리\n\n${entry}\n`;
    }
    fs.writeFileSync(journalFile, content);
  } catch {}
}

module.exports = { extractTddPhase, appendDevJournalBackward };
