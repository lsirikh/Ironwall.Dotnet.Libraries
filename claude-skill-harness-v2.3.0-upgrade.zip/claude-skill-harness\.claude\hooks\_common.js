// .claude/hooks/_common.js
// 공통 헬퍼 모듈 — IMPL-12 (FR-12)
//
// 본 사이클(system-optimization-prd)의 핵심 산출물.
// pre-tool-gate, session-gate, post-write-sync, advance-phase가 공통으로 사용하는
// 헬퍼 함수들을 추출하여 중복 제거 및 일관성 확보.
//
// 점진적 마이그레이션:
//   v1: 본 모듈 신설 + pre-tool-gate.js만 require로 사용 (이번 사이클)
//   v2: post-write-sync.js, session-gate.js 마이그레이션 (다음 사이클)
//   v3: advance-phase.js 마이그레이션 (가장 큰 파일이므로 신중)

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');
const AUDIT_LOG = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');

/**
 * pipeline-state.json 로드 — 폴백 안전
 * 미존재/파손 시 { phase: 'setup', track: 'C' } 반환 (가장 엄격한 상태)
 * @returns {Object} state
 */
function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return { phase: 'setup', track: 'C' };
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (!parsed.phase) return { phase: 'setup', track: 'C' };
    if (!parsed.track) parsed.track = 'C';
    return parsed;
  } catch {
    return { phase: 'setup', track: 'C' };
  }
}

/**
 * pipeline-state.json 저장 (atomic)
 */
function saveState(state) {
  try {
    state.updated_at = new Date().toISOString();
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
    return true;
  } catch { return false; }
}

/**
 * docs 하위 디렉토리 스캔 (mtime 역순 정렬)
 * @param {string} subdir - 'analysis' | 'prds' | 'plans' | 'tests' | 'reports'
 * @returns {Array<{name, mtime, path}>}
 */
function scanDocsDir(subdir) {
  const dir = path.join(PROJECT_ROOT, 'docs', subdir);
  if (!fs.existsSync(dir)) return [];
  try {
    return fs.readdirSync(dir)
      .filter(f => f.endsWith('.md') && f !== 'INDEX.md' && f !== 'Manual.md')
      .map(f => {
        const fp = path.join(dir, f);
        return {
          name: f,
          mtime: fs.statSync(fp).mtimeMs,
          path: `docs/${subdir}/${f}`
        };
      })
      .sort((a, b) => b.mtime - a.mtime);
  } catch { return []; }
}

/**
 * 경로 정규화 — 정규식 매칭용
 * Windows 백슬래시 → 슬래시, 드라이브 레터 제거, leading / 보장
 * 목적: /docs/, /src/ 패턴이 OS에 무관하게 매칭되도록 함
 */
function normalizePathForRegex(rawPath) {
  if (!rawPath) return '';
  let slashed = rawPath.replace(/\\/g, '/');
  // Windows 드라이브 레터 제거: C:/workspace/src/ → /workspace/src/
  slashed = slashed.replace(/^[A-Za-z]:/, '');
  // leading / 보장
  if (!slashed.startsWith('/')) slashed = '/' + slashed;
  return slashed;
}

/**
 * 경로 정규화 — fs 접근용 (leading / 제거 + PROJECT_ROOT 결합)
 */
function resolveFilePath(rawPath) {
  if (!rawPath) return null;
  const slashed = rawPath.replace(/\\/g, '/');
  if (/^[A-Za-z]:/.test(slashed)) return slashed;
  const rel = slashed.startsWith('/') ? slashed.substring(1) : slashed;
  return path.join(PROJECT_ROOT, rel);
}

/**
 * audit-log에 이벤트 추가 (silent)
 */
function appendAudit(event) {
  try {
    fs.appendFileSync(AUDIT_LOG, JSON.stringify({
      timestamp: new Date().toISOString(),
      ...event
    }) + '\n');
  } catch { /* silent */ }
}

/**
 * Hook 실행 시간 자동 측정 (>100ms 시 audit-log 기록)
 * @param {string} hookName - 'pre-tool-gate.js' 등
 */
function setupHookPerfMonitoring(hookName) {
  const start = Date.now();
  process.on('exit', () => {
    const elapsed = Date.now() - start;
    if (elapsed > 100) {
      appendAudit({ event: 'hook-perf', hook: hookName, elapsed_ms: elapsed });
    }
  });
}

/**
 * dev-journal에 작업 엔트리가 있는지 확인 (Track B 필수)
 * 자동 백워드 엔트리(🔁)만으로는 통과 불가 — 작업 내용 엔트리 필요
 * 작업 엔트리 판별: "- **Track**: B" 또는 "- **대상**:" 필드 포함
 * @returns {boolean}
 */
function hasDevJournalEntry() {
  try {
    const journalPath = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal.md');
    if (!fs.existsSync(journalPath)) return false;
    const content = fs.readFileSync(journalPath, 'utf8');
    // 엔트리 단위 분할
    const entries = content.split(/(?=^### \[)/m).filter(e => e.startsWith('### ['));
    if (entries.length === 0) return false;
    // 자동 백워드(🔁)가 아닌 작업 엔트리 존재 확인
    return entries.some(e => !e.includes('🔁') && /- \*\*(Track|대상)\*\*:/m.test(e));
  } catch { return false; }
}

/**
 * Plan 파일에서 태스크 진행률 계산
 * @param {string} planAbsPath - Plan 파일 절대 경로
 * @returns {{done:number, total:number, pct:number}}
 */
function calcPlanProgress(planAbsPath) {
  try {
    if (!fs.existsSync(planAbsPath)) return { done: 0, total: 0, pct: 0 };
    const content = fs.readFileSync(planAbsPath, 'utf8');
    const checked = (content.match(/^- \[x\]/gm) || []).length;
    const unchecked = (content.match(/^- \[ \]/gm) || []).length;
    const inprogress = (content.match(/^- \[~\]/gm) || []).length;
    const blocked = (content.match(/^- \[!\]/gm) || []).length;
    const skipped = (content.match(/^- \[-\]/gm) || []).length;
    const total = checked + unchecked + inprogress + blocked + skipped;
    const pct = total > 0 ? Math.round((checked / total) * 100) : 0;
    return { done: checked, total, pct };
  } catch { return { done: 0, total: 0, pct: 0 }; }
}

/**
 * PRD 파일에서 Approved 상태 확인
 * @param {string} prdAbsPath - PRD 파일 절대 경로
 * @returns {boolean}
 */
function isPrdApproved(prdAbsPath) {
  try {
    const content = fs.readFileSync(prdAbsPath, 'utf8');
    return /^- \*\*상태\*\*:\s*(Approved|Completed)/im.test(content);
  } catch { return false; }
}

/**
 * CLAUDE.md에서 yaml 필드 값 추출
 * @param {string} fieldName - 'test_command', 'lint_command' 등
 * @returns {string|number|null}
 */
function readClaudeMdField(fieldName) {
  try {
    const claudeMdPath = path.join(PROJECT_ROOT, 'CLAUDE.md');
    if (!fs.existsSync(claudeMdPath)) return null;
    const content = fs.readFileSync(claudeMdPath, 'utf8');
    const m = content.match(new RegExp(fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*"([^"]*)"'));
    if (m) return m[1] || null;
    const n = content.match(new RegExp(fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':\\s*(\\d+)'));
    if (n) return parseInt(n[1], 10);
    return null;
  } catch { return null; }
}

module.exports = {
  PROJECT_ROOT,
  STATE_FILE,
  AUDIT_LOG,
  loadState,
  saveState,
  scanDocsDir,
  normalizePathForRegex,
  resolveFilePath,
  appendAudit,
  setupHookPerfMonitoring,
  hasDevJournalEntry,
  calcPlanProgress,
  isPrdApproved,
  readClaudeMdField
};
