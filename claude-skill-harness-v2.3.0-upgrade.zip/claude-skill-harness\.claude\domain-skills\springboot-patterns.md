---
name: springboot-patterns
description: Spring Boot development patterns — layered architecture, DI, REST controllers, JPA, transactions, caching, events, exception handling
languages: ["Java"]
frameworks: ["Spring Boot", "Spring"]
phases: ["dev", "test"]
---

# Spring Boot Patterns

## When to Activate

- Building or reviewing Spring Boot applications
- Designing layered architecture (Controller / Service / Repository)
- Implementing REST APIs with validation and RFC 7807 error handling
- Configuring DI, profiles, JPA, transactions, caching, or events

---

## Core Patterns

### 1. Layered Architecture

Controller -> Service -> Repository. Never skip layers.

```java
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
}

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public UserResponse getUserById(Long id) {
        return userRepository.findById(id)
                .map(UserResponse::from)
                .orElseThrow(() -> new UserNotFoundException(id));
    }
}

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}
```

### 2. Dependency Injection

Always constructor injection. Use `@Qualifier` for multiple implementations.

```java
// GOOD — constructor injection (immutable, testable)
@Service
public class OrderService {
    private final OrderRepository repo;
    private final PaymentGateway gateway;
    public OrderService(OrderRepository repo, PaymentGateway gateway) {
        this.repo = repo; this.gateway = gateway;
    }
}

// @Qualifier for disambiguation
@Service
public class AlertService {
    public AlertService(@Qualifier("emailSender") NotificationSender sender) {
        this.sender = sender;
    }
}
```

### 3. Configuration

```java
// Type-safe config with @ConfigurationProperties
@ConfigurationProperties(prefix = "app.mail")
@Validated
public record MailProperties(
        @NotBlank String host,
        @Min(1) @Max(65535) int port,
        @NotBlank String fromAddress,
        Duration timeout) {}
```

```yaml
# application.yml
app:
  mail:
    host: smtp.example.com
    port: 587
    from-address: noreply@example.com
    timeout: 5s

# application-dev.yml — profile-specific
spring:
  datasource:
    url: jdbc:h2:mem:devdb
  jpa.show-sql: true
```

```java
@Profile("dev")
@Component
public class DevDataInitializer implements CommandLineRunner {
    @Override public void run(String... args) { /* seed dev data */ }
}
```

### 4. REST Controllers

```java
@RestController
@RequestMapping("/api/v1/products")
@RequiredArgsConstructor
public class ProductController {
    private final ProductService service;

    @GetMapping
    public List<ProductResponse> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return service.findAll(PageRequest.of(page, size)).getContent();
    }

    @PostMapping
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody CreateProductRequest req) {
        ProductResponse created = service.create(req);
        return ResponseEntity.created(URI.create("/api/v1/products/" + created.id()))
                .body(created);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }
}
```

### 5. Exception Handling (RFC 7807 ProblemDetail)

```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ProblemDetail handleNotFound(ResourceNotFoundException ex) {
        ProblemDetail p = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        p.setTitle("Resource Not Found");
        return p;
    }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidation(MethodArgumentNotValidException ex) {
        ProblemDetail p = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        p.setTitle("Validation Failed");
        p.setProperty("fieldErrors", ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(FieldError::getField,
                        fe -> fe.getDefaultMessage() != null ? fe.getDefaultMessage() : "invalid",
                        (a, b) -> a)));
        return p;
    }
}
```

### 6. JPA / Hibernate

```java
@Entity @Table(name = "orders")
@Getter @Setter @NoArgsConstructor
public class Order {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private String status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id") private Customer customer;
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();
    @CreationTimestamp private LocalDateTime createdAt;
}

// Spring Data query methods + Specification
@Repository
public interface OrderRepository extends JpaRepository<Order, Long>,
        JpaSpecificationExecutor<Order> {
    @Query("SELECT o FROM Order o JOIN FETCH o.items WHERE o.customer.id = :cid")
    List<Order> findByCustomerWithItems(@Param("cid") Long cid);
}

public class OrderSpecs {
    public static Specification<Order> hasStatus(String s) {
        return (root, q, cb) -> cb.equal(root.get("status"), s);
    }
}
// Usage: orderRepo.findAll(where(hasStatus("PENDING")).and(createdAfter(date)));
```

### 7. Transactions

```java
@Transactional
public void transfer(Long fromId, Long toId, BigDecimal amount) {
    Account from = accountRepo.findById(fromId).orElseThrow();
    Account to = accountRepo.findById(toId).orElseThrow();
    from.debit(amount); to.credit(amount);
    accountRepo.save(from); accountRepo.save(to);
}

@Transactional(readOnly = true) // enables read optimizations
public AccountBalance getBalance(Long id) { ... }

@Transactional(isolation = Isolation.SERIALIZABLE) // for critical ops
public void criticalUpdate(Long id, BigDecimal bal) { ... }
```

### 8. Caching

```java
@Cacheable(value = "products", key = "#id")
public ProductResponse findById(Long id) { ... }

@CacheEvict(value = "products", key = "#id")
public ProductResponse update(Long id, UpdateReq req) { ... }

@CacheEvict(value = "products", allEntries = true)
public void refreshCache() {}
```

### 9. Actuator Health Checks

```java
@Component
public class ExternalApiHealth implements HealthIndicator {
    @Override public Health health() {
        try { restClient.get().uri("/health").retrieve().toBodilessEntity();
            return Health.up().withDetail("api", "external").build();
        } catch (Exception ex) { return Health.down().withException(ex).build(); }
    }
}
```

### 10. Event-Driven

```java
public record OrderPlacedEvent(Long orderId, Long customerId, BigDecimal total) {}

// Publish
@Transactional
public OrderResponse placeOrder(CreateOrderRequest req) {
    Order order = createAndSave(req);
    eventPublisher.publishEvent(new OrderPlacedEvent(order.getId(), ...));
    return OrderResponse.from(order);
}

// Listen (sync, async, and transactional variants)
@EventListener
public void onOrderPlaced(OrderPlacedEvent e) { notifService.confirm(e.orderId()); }
@Async @EventListener
public void onOrderAsync(OrderPlacedEvent e) { inventory.reserve(e.orderId()); }

@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
public void afterCommit(OrderPlacedEvent e) { notifService.notifyWarehouse(e.orderId()); }
```

---

## Anti-Patterns

### Never Field Injection

```java
@Autowired private UserRepository repo;   // BAD — untestable
// GOOD — constructor injection (see pattern 2)
```

### Never Swallow Exceptions in @Transactional

```java
// BAD — transaction commits with inconsistent state
@Transactional public void process(Order o) {
    try { paymentService.charge(o); } catch (PaymentException e) { log.error("", e); }
    orderRepo.save(o);
}
// GOOD — let it propagate so transaction rolls back
```

### Never EAGER Fetch / Never Expose Entities

```java
@ManyToOne(fetch = FetchType.EAGER)  // BAD — N+1 queries
@ManyToOne(fetch = FetchType.LAZY)   // GOOD — JOIN FETCH when needed

public User getUser(Long id) { ... }         // BAD — leaks internals
public UserResponse getUser(Long id) { ... } // GOOD — use DTO
```
