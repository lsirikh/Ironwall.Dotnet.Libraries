// .claude/hooks/advance-phase-memory.js
// Memory Hygiene — dev-journal 아카이브 + audit-log GC

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const AUDIT_LOG = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');

function archiveDevJournalIfNeeded() {
  const journalFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal.md');
  if (!fs.existsSync(journalFile)) return { skipped: true };
  try {
    const content = fs.readFileSync(journalFile, 'utf8');
    const lines = content.split('\n');
    if (lines.length < 200) return { skipped: true, reason: 'under-threshold' };

    const entriesIdx = content.indexOf('## 엔트리');
    if (entriesIdx === -1) return { skipped: true, reason: 'no-entries-section' };
    const headerEnd = content.indexOf('\n', entriesIdx) + 1;
    const header = content.substring(0, headerEnd);
    const body = content.substring(headerEnd);

    const entries = body.split(/(?=^### )/m).filter(e => e.trim());
    if (entries.length < 6) return { skipped: true, reason: 'too-few-entries' };

    const archiveCount = Math.floor(entries.length / 3);
    const toArchive = entries.slice(-archiveCount);
    const toKeep = entries.slice(0, -archiveCount);

    const today = new Date();
    const quarter = `${today.getFullYear()}-Q${Math.floor(today.getMonth() / 3) + 1}`;
    const archiveDir = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal-archive');
    if (!fs.existsSync(archiveDir)) fs.mkdirSync(archiveDir, { recursive: true });
    const archiveFile = path.join(archiveDir, `${quarter}.md`);

    let archiveHeader = '';
    if (!fs.existsSync(archiveFile)) archiveHeader = `# Dev Journal Archive — ${quarter}\n\n## 엔트리\n\n`;
    fs.appendFileSync(archiveFile, archiveHeader + toArchive.join(''));
    fs.writeFileSync(journalFile, header + '\n' + toKeep.join(''));
    return { ok: true, archived: archiveCount, file: `dev-journal-archive/${quarter}.md` };
  } catch (err) { return { error: err.message }; }
}

function gcAuditLogIfNeeded() {
  if (!fs.existsSync(AUDIT_LOG)) return { skipped: true };
  try {
    const lines = fs.readFileSync(AUDIT_LOG, 'utf8').split('\n').filter(l => l.trim());
    if (lines.length < 1000) return { skipped: true, reason: 'under-threshold' };

    const half = Math.floor(lines.length / 2);
    const toArchive = lines.slice(0, half);
    const toKeep = lines.slice(half);

    const today = new Date().toISOString().slice(0, 10);
    const archiveDir = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log-archive');
    if (!fs.existsSync(archiveDir)) fs.mkdirSync(archiveDir, { recursive: true });
    fs.appendFileSync(path.join(archiveDir, `${today}.jsonl`), toArchive.join('\n') + '\n');
    fs.writeFileSync(AUDIT_LOG, toKeep.join('\n') + '\n');
    return { ok: true, archived: half, file: `audit-log-archive/${today}.jsonl` };
  } catch (err) { return { error: err.message }; }
}

module.exports = { archiveDevJournalIfNeeded, gcAuditLogIfNeeded };
