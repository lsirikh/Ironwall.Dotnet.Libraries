---
name: efcore-patterns
description: Entity Framework Core patterns — DbContext, migrations, query optimization, change tracking, global filters, value conversions
languages: ["C#"]
frameworks: ["Entity Framework Core", "EF Core"]
phases: ["dev"]
---

# EF Core Patterns

## When to Activate

- Configuring `DbContext` and entity mappings with Fluent API
- Creating and managing database migrations
- Optimizing EF Core queries (projections, tracking, split queries)
- Implementing global query filters (soft delete, multi-tenancy)
- Working with change tracker behavior
- Setting up connection resilience for cloud databases
- Defining value conversions for custom types

---

## Core Patterns

### 1. DbContext Configuration

#### OnModelCreating with Fluent API

```csharp
public class AppDbContext : DbContext
{
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Product> Products => Set<Product>();

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Apply all configurations from assembly
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
    }

    // Override SaveChanges to auto-set audit fields
    public override async Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        foreach (var entry in ChangeTracker.Entries<IAuditable>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedAt = DateTime.UtcNow;
                    break;
                case EntityState.Modified:
                    entry.Entity.ModifiedAt = DateTime.UtcNow;
                    break;
            }
        }
        return await base.SaveChangesAsync(ct);
    }
}
```

#### Separate Configuration Classes

```csharp
public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.ToTable("Orders");

        builder.HasKey(o => o.Id);

        builder.Property(o => o.OrderNumber)
            .IsRequired()
            .HasMaxLength(20);

        builder.Property(o => o.Total)
            .HasPrecision(18, 2);

        builder.Property(o => o.Status)
            .HasConversion<string>()   // Store enum as string
            .HasMaxLength(50);

        // Relationships
        builder.HasOne(o => o.Customer)
            .WithMany(c => c.Orders)
            .HasForeignKey(o => o.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasMany(o => o.Items)
            .WithOne(i => i.Order)
            .HasForeignKey(i => i.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        // Index
        builder.HasIndex(o => o.OrderNumber).IsUnique();
        builder.HasIndex(o => o.CreatedAt);
        builder.HasIndex(o => new { o.CustomerId, o.Status });

        // Global query filter
        builder.HasQueryFilter(o => !o.IsDeleted);
    }
}
```

#### Registration in Program.cs

```csharp
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(30),
                errorNumbersToAdd: null);
            sqlOptions.CommandTimeout(30);
            sqlOptions.MigrationsAssembly("MyApp.Migrations");
        });

    if (builder.Environment.IsDevelopment())
    {
        options.EnableSensitiveDataLogging();
        options.EnableDetailedErrors();
    }
});
```

---

### 2. Migration Strategy

#### Creating and Applying Migrations

```bash
# Add a new migration
dotnet ef migrations add AddOrderStatus \
    --project src/MyApp.Infrastructure \
    --startup-project src/MyApp.Api

# Apply pending migrations
dotnet ef database update

# Generate SQL script (for production deployment)
dotnet ef migrations script \
    --from PreviousMigration \
    --to AddOrderStatus \
    --idempotent \
    --output migrations.sql

# List migrations
dotnet ef migrations list

# Remove last migration (if not applied)
dotnet ef migrations remove
```

#### Custom Migration with Data Seeding

```csharp
public partial class AddOrderStatus : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>(
            name: "Status",
            table: "Orders",
            type: "nvarchar(50)",
            nullable: false,
            defaultValue: "Pending");

        // Data migration — set existing orders
        migrationBuilder.Sql(@"
            UPDATE Orders
            SET Status = CASE
                WHEN CompletedAt IS NOT NULL THEN 'Completed'
                WHEN CancelledAt IS NOT NULL THEN 'Cancelled'
                ELSE 'Pending'
            END
        ");

        migrationBuilder.CreateIndex(
            name: "IX_Orders_Status",
            table: "Orders",
            column: "Status");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex("IX_Orders_Status", "Orders");
        migrationBuilder.DropColumn("Status", "Orders");
    }
}
```

#### Production Migration Approach

```csharp
// Startup migration (simple scenarios)
using var scope = app.Services.CreateScope();
var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
await db.Database.MigrateAsync();

// For production: prefer generated SQL scripts reviewed by DBA
// dotnet ef migrations script --idempotent > deploy.sql
```

---

### 3. Query Optimization

#### AsNoTracking for Read-Only Queries

```csharp
// Single query — no tracking overhead
public async Task<List<OrderSummary>> GetRecentOrdersAsync(CancellationToken ct)
{
    return await _context.Orders
        .AsNoTracking()
        .Where(o => o.CreatedAt >= DateTime.UtcNow.AddDays(-30))
        .Select(o => new OrderSummary
        {
            Id = o.Id,
            CustomerName = o.Customer.Name,
            Total = o.Total,
            ItemCount = o.Items.Count
        })
        .OrderByDescending(o => o.Id)
        .ToListAsync(ct);
}

// Global no-tracking for read-heavy DbContext
builder.Services.AddDbContext<ReadOnlyDbContext>(options =>
{
    options.UseSqlServer(connectionString);
    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
});
```

#### Projection — Select Only What You Need

```csharp
// BAD — loads entire entity graph
var orders = await _context.Orders
    .Include(o => o.Customer)
    .Include(o => o.Items)
        .ThenInclude(i => i.Product)
    .ToListAsync(ct);

// GOOD — project to DTO, EF generates efficient SQL
var orders = await _context.Orders
    .Select(o => new OrderDto
    {
        Id = o.Id,
        CustomerName = o.Customer.Name,
        TotalAmount = o.Total,
        Items = o.Items.Select(i => new OrderItemDto
        {
            ProductName = i.Product.Name,
            Quantity = i.Quantity,
            LineTotal = i.Quantity * i.UnitPrice
        }).ToList()
    })
    .ToListAsync(ct);
```

#### Split Queries for Large Includes

```csharp
// Default: Single query with JOINs — can cause cartesian explosion
var orders = await _context.Orders
    .Include(o => o.Items)
    .Include(o => o.Payments)
    .ToListAsync(ct);
// Problem: If order has 10 items and 3 payments, result has 30 rows

// GOOD: Split query — separate SQL per include
var orders = await _context.Orders
    .Include(o => o.Items)
    .Include(o => o.Payments)
    .AsSplitQuery()
    .ToListAsync(ct);
// Generates 3 queries: Orders, Items (with OrderId), Payments (with OrderId)
```

#### Compiled Queries for Hot Paths

```csharp
public class OrderRepository
{
    // Compiled once, reused — avoids expression tree compilation overhead
    private static readonly Func<AppDbContext, int, CancellationToken, Task<Order?>>
        _getByIdCompiled = EF.CompileAsyncQuery(
            (AppDbContext ctx, int id, CancellationToken ct) =>
                ctx.Orders
                    .Include(o => o.Items)
                    .FirstOrDefault(o => o.Id == id));

    public Task<Order?> GetByIdAsync(int id, CancellationToken ct)
        => _getByIdCompiled(_context, id, ct);
}
```

---

### 4. Change Tracker Behavior

```csharp
// Check what is being tracked
foreach (var entry in _context.ChangeTracker.Entries())
{
    Console.WriteLine($"{entry.Entity.GetType().Name}: {entry.State}");
}

// Explicitly set state for disconnected entities
public async Task UpdateOrderAsync(Order order, CancellationToken ct)
{
    // Attach and mark as modified
    _context.Entry(order).State = EntityState.Modified;

    // Or update specific properties only
    _context.Attach(order);
    _context.Entry(order).Property(o => o.Status).IsModified = true;
    _context.Entry(order).Property(o => o.Total).IsModified = true;

    await _context.SaveChangesAsync(ct);
}

// ExecuteUpdate — bulk update without loading entities (.NET 7+)
await _context.Orders
    .Where(o => o.Status == "Pending" && o.CreatedAt < cutoffDate)
    .ExecuteUpdateAsync(
        s => s.SetProperty(o => o.Status, "Expired")
              .SetProperty(o => o.ModifiedAt, DateTime.UtcNow),
        ct);

// ExecuteDelete — bulk delete without loading entities
await _context.Orders
    .Where(o => o.IsDeleted && o.DeletedAt < DateTime.UtcNow.AddYears(-1))
    .ExecuteDeleteAsync(ct);
```

---

### 5. Connection Resilience

```csharp
options.UseSqlServer(connectionString, sqlOptions =>
{
    // Retry on transient failures (network blips, Azure SQL throttling)
    sqlOptions.EnableRetryOnFailure(
        maxRetryCount: 5,
        maxRetryDelay: TimeSpan.FromSeconds(30),
        errorNumbersToAdd: new[] { 4060, 40197, 40501, 40613, 49918, 49919, 49920 });
});
```

#### Manual Transaction with Retry Strategy

```csharp
// When using EnableRetryOnFailure, manual transactions need ExecutionStrategy
var strategy = _context.Database.CreateExecutionStrategy();

await strategy.ExecuteAsync(async () =>
{
    using var transaction = await _context.Database.BeginTransactionAsync();
    try
    {
        var order = new Order { Total = 100m };
        _context.Orders.Add(order);
        await _context.SaveChangesAsync();

        var payment = new Payment { OrderId = order.Id, Amount = 100m };
        _context.Payments.Add(payment);
        await _context.SaveChangesAsync();

        await transaction.CommitAsync();
    }
    catch
    {
        await transaction.RollbackAsync();
        throw;
    }
});
```

---

### 6. Global Query Filters

#### Soft Delete

```csharp
public interface ISoftDeletable
{
    bool IsDeleted { get; set; }
    DateTime? DeletedAt { get; set; }
}

// In OnModelCreating or IEntityTypeConfiguration
builder.HasQueryFilter(o => !o.IsDeleted);

// All queries automatically exclude soft-deleted records
var orders = await _context.Orders.ToListAsync(); // WHERE IsDeleted = 0

// Bypass filter when needed (e.g., admin panel, auditing)
var allOrders = await _context.Orders.IgnoreQueryFilters().ToListAsync();
```

#### Multi-Tenancy

```csharp
public class AppDbContext : DbContext
{
    private readonly ITenantService _tenantService;

    public AppDbContext(DbContextOptions options, ITenantService tenantService)
        : base(options)
    {
        _tenantService = tenantService;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>()
            .HasQueryFilter(o => o.TenantId == _tenantService.CurrentTenantId);

        modelBuilder.Entity<Product>()
            .HasQueryFilter(p => p.TenantId == _tenantService.CurrentTenantId);
    }
}
```

---

### 7. Value Conversions

#### Enum to String

```csharp
builder.Property(o => o.Status)
    .HasConversion<string>()
    .HasMaxLength(50);
```

#### Strongly-Typed IDs

```csharp
public readonly record struct OrderId(int Value);

public class OrderIdConverter : ValueConverter<OrderId, int>
{
    public OrderIdConverter()
        : base(id => id.Value, value => new OrderId(value)) { }
}

// Registration
builder.Property(o => o.Id)
    .HasConversion<OrderIdConverter>();
```

#### JSON Column (.NET 7+)

```csharp
public class Order
{
    public int Id { get; set; }
    public ShippingAddress Address { get; set; }  // Stored as JSON
    public List<string> Tags { get; set; }        // Stored as JSON array
}

builder.Entity<Order>(entity =>
{
    entity.OwnsOne(o => o.Address, addr =>
    {
        addr.ToJson();  // Stored as JSON column
    });

    entity.Property(o => o.Tags)
        .HasConversion(
            v => JsonSerializer.Serialize(v, (JsonSerializerOptions)null),
            v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions)null)!);
});
```

#### Custom Value Converter

```csharp
public class MoneyConverter : ValueConverter<Money, decimal>
{
    public MoneyConverter()
        : base(
            money => money.Amount,
            amount => new Money(amount, "USD")) { }
}

public class DateOnlyConverter : ValueConverter<DateOnly, DateTime>
{
    public DateOnlyConverter()
        : base(
            d => d.ToDateTime(TimeOnly.MinValue),
            d => DateOnly.FromDateTime(d)) { }
}
```

---

## Anti-Patterns

### Queries

- Loading entire entity graphs with `Include` when only a few fields are needed
- Using `ToList()` before `Where()` — loads all rows into memory, filters in C#
- Calling `Count()` when `Any()` suffices — unnecessary full scan
- N+1 queries: iterating a collection and querying inside the loop
- Not using `AsNoTracking()` for read-only scenarios — unnecessary memory overhead

### Migrations

- Editing already-applied migrations — causes inconsistent databases
- Deleting migration files without reverting — breaks migration chain
- Using `Database.EnsureCreated()` alongside migrations — they are mutually exclusive
- Not testing `Down()` method — unable to roll back in production

### Change Tracking

- Calling `SaveChanges()` inside a loop — should batch outside the loop
- Attaching entities from one context to another without detaching first
- Forgetting that `Update()` marks ALL properties as modified — use `Attach` + explicit marking

### Configuration

- Putting entity configuration in `OnModelCreating` directly — grows unmaintainable
- Not setting `DeleteBehavior` explicitly — defaults may cascade unexpectedly
- Missing indexes on frequently filtered/joined columns — slow queries
- Using `HasData()` for large seed datasets — migrations become enormous
