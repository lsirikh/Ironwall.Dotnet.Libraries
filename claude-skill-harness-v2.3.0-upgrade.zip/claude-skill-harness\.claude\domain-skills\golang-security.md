---
name: golang-security
description: >
  Go 보안 코딩 가이드. 입력 검증, SQL 인젝션 방지, XSS 방지, TLS 설정,
  비밀 관리, 속도 제한, 보안 헤더, CORS, 암호화 모범 사례를 다룬다.
languages: ["Go"]
frameworks: ["Go", "net/http"]
phases: ["test"]
---

# Go Security

## When to Activate

- Go로 HTTP 서버나 API를 구현할 때
- 사용자 입력을 처리하거나 데이터베이스와 상호작용할 때
- 인증, 인가, 암호화 로직을 구현할 때
- 보안 코드 리뷰나 프로덕션 배포 전 체크리스트 확인 시

---

## Core Patterns

### 1. Input Validation

```go
// strconv safe parsing — 에러 + 범위 검증
func parseAge(input string) (int, error) {
    age, err := strconv.Atoi(input)
    if err != nil { return 0, fmt.Errorf("invalid age %q: %w", input, err) }
    if age < 0 || age > 150 { return 0, fmt.Errorf("age %d out of range", age) }
    return age, nil
}

// Regex validation — 화이트리스트 방식
var (
    emailRe    = regexp.MustCompile(`^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$`)
    usernameRe = regexp.MustCompile(`^[a-zA-Z0-9_]{3,32}$`)
)
func ValidateEmail(e string) error {
    if !emailRe.MatchString(e) { return fmt.Errorf("invalid email: %q", e) }
    return nil
}
```

### 2. SQL Injection Prevention

```go
// BAD — 문자열 연결 (인젝션 취약)
query := "SELECT * FROM users WHERE name = '" + name + "'"

// GOOD — database/sql 플레이스홀더
row := db.QueryRow("SELECT id, name FROM users WHERE name = $1", name)

// GOOD — 다중 파라미터
rows, _ := db.Query(
    `SELECT id, name FROM users WHERE name LIKE $1 AND age >= $2 LIMIT 100`,
    "%"+name+"%", minAge,
)

// GOOD — sqlx named queries
import "github.com/jmoiron/sqlx"
type Filter struct {
    Name   string `db:"name"`
    Status string `db:"status"`
}
rows, _ := db.NamedQuery(`SELECT * FROM users WHERE name=:name AND status=:status`, filter)
```

### 3. XSS Prevention

```go
import "html/template"  // NOT "text/template"

var tmpl = template.Must(template.New("page").Parse(`
<html><body>
  <h1>{{.Title}}</h1>
  <p>{{.Content}}</p>
</body></html>
`))

func render(w http.ResponseWriter, data PageData) {
    w.Header().Set("Content-Type", "text/html; charset=utf-8")
    tmpl.Execute(w, data)  // html/template이 자동 이스케이프
}
// BAD: text/template은 이스케이프 없음 — HTML 출력에 절대 사용 금지
```

### 4. TLS Configuration

```go
func newTLSConfig() *tls.Config {
    return &tls.Config{
        MinVersion: tls.VersionTLS12,
        CurvePreferences: []tls.CurveID{tls.X25519, tls.CurveP256},
        CipherSuites: []uint16{
            tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
            tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
            tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
            tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
        },
    }
}

func StartSecureServer(addr, cert, key string) error {
    srv := &http.Server{
        Addr: addr, TLSConfig: newTLSConfig(),
        ReadTimeout: 10 * time.Second, WriteTimeout: 15 * time.Second,
    }
    return srv.ListenAndServeTLS(cert, key)
}
```

### 5. Secrets from Environment

```go
// BAD — 하드코딩
const apiKey = "sk-abc123456789"

// GOOD — os.Getenv
func loadConfig() (*Config, error) {
    key := os.Getenv("API_KEY")
    if key == "" { return nil, errors.New("API_KEY required") }
    return &Config{APIKey: key}, nil
}

// GOOD — envconfig 라이브러리
import "github.com/kelseyhightower/envconfig"

type Config struct {
    DBHost  string        `envconfig:"DB_HOST" required:"true"`
    DBPort  int           `envconfig:"DB_PORT" default:"5432"`
    APIKey  string        `envconfig:"API_KEY" required:"true"`
    Timeout time.Duration `envconfig:"TIMEOUT" default:"30s"`
}
func LoadConfig() (*Config, error) {
    var c Config
    return &c, envconfig.Process("APP", &c)
}
```

### 6. Rate Limiting

```go
import "golang.org/x/time/rate"

// 글로벌 속도 제한 미들웨어
func RateLimit(rps float64, burst int) func(http.Handler) http.Handler {
    lim := rate.NewLimiter(rate.Limit(rps), burst)
    return func(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
            if !lim.Allow() {
                http.Error(w, "rate limit exceeded", http.StatusTooManyRequests)
                return
            }
            next.ServeHTTP(w, r)
        })
    }
}

// IP별 속도 제한 — map[string]*rate.Limiter + sync.Mutex로 구현
```

### 7. Secure HTTP Headers

```go
func SecurityHeaders(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("X-Content-Type-Options", "nosniff")
        w.Header().Set("X-Frame-Options", "DENY")
        w.Header().Set("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
        w.Header().Set("Content-Security-Policy", "default-src 'self'")
        w.Header().Set("Referrer-Policy", "strict-origin-when-cross-origin")
        next.ServeHTTP(w, r)
    })
}
```

### 8. CORS with rs/cors

```go
import "github.com/rs/cors"

func setupCORS(h http.Handler) http.Handler {
    return cors.New(cors.Options{
        AllowedOrigins:   []string{"https://app.example.com"},  // NOT "*"
        AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE"},
        AllowedHeaders:   []string{"Authorization", "Content-Type"},
        AllowCredentials: true,
        MaxAge:           3600,
    }).Handler(h)
}
// BAD: AllowedOrigins: ["*"] + AllowCredentials: true 조합은 보안 취약
```

### 9. Crypto Best Practices

```go
// GOOD — crypto/rand (암호학적 안전)
func GenerateToken(n int) (string, error) {
    b := make([]byte, n)
    if _, err := rand.Read(b); err != nil { return "", err }
    return hex.EncodeToString(b), nil
}
// BAD — math/rand는 예측 가능, 보안 용도 금지

// 비밀번호 해싱 — bcrypt
import "golang.org/x/crypto/bcrypt"
func Hash(pw string) (string, error) {
    h, err := bcrypt.GenerateFromPassword([]byte(pw), bcrypt.DefaultCost)
    return string(h), err
}
func Check(hash, pw string) bool {
    return bcrypt.CompareHashAndPassword([]byte(hash), []byte(pw)) == nil
}

// 타이밍 공격 방지 — crypto/subtle
func ValidateKey(got, want string) bool {
    return subtle.ConstantTimeCompare([]byte(got), []byte(want)) == 1
}
```

### 10. gosec Linter

```bash
go install github.com/securego/gosec/v2/cmd/gosec@latest
gosec ./...                                    # 전체 스캔
gosec -fmt=json -out=report.json ./...         # JSON 리포트
gosec -include=G101,G201,G301 ./...            # 특정 규칙만
```

주요 규칙:

```go
// G101: var password = "admin123"       — 하드코딩 자격 증명
// G201: fmt.Sprintf("...WHERE id=%s")   — SQL 포매팅
// G301: os.MkdirAll(path, 0777)         — 과도한 권한 (0750 권장)
// G304: os.ReadFile(userInput)          — 경로 검증 필요
// G401: md5.New()                       — 약한 해시 (sha256 권장)
```

---

## Anti-Patterns

### 1. 시크릿 하드코딩

```go
// BAD
const dbPass = "secret123"
// GOOD
dbPass := os.Getenv("DB_PASSWORD")
```

### 2. TLS 인증서 검증 비활성화

```go
// BAD — 중간자 공격에 취약
&tls.Config{InsecureSkipVerify: true}
// GOOD — 커스텀 CA 풀
pool := x509.NewCertPool()
caCert, _ := os.ReadFile("ca.pem")
pool.AppendCertsFromPEM(caCert)
&tls.Config{RootCAs: pool}
```

### 3. 에러 메시지에 내부 정보 노출

```go
// BAD — DB 에러를 사용자에게 그대로 전달
http.Error(w, err.Error(), 500)
// GOOD — 내부 로깅, 사용자에게는 일반 메시지
log.Printf("query failed: %v", err)
http.Error(w, "internal server error", 500)
```

### 4. CORS 와일드카드 + 자격증명

```go
// BAD — 보안 무력화
cors.Options{AllowedOrigins: []string{"*"}, AllowCredentials: true}
// GOOD — 명시적 오리진
cors.Options{AllowedOrigins: []string{"https://app.example.com"}, AllowCredentials: true}
```
