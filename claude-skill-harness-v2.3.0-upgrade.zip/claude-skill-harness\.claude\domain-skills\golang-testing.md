---
name: golang-testing
description: >
  Go 테스트 전략 가이드. 테이블 주도 테스트, 픽스처, 벤치마크, httptest,
  testify, 골든 파일, 빌드 태그, 커버리지, 레이스 감지를 다룬다.
languages: ["Go"]
frameworks: ["Go", "testing"]
phases: ["test"]
---

# Go Testing

## When to Activate

- Go 테스트 파일(`_test.go`)을 생성하거나 수정할 때
- 테스트 전략, 커버리지, 벤치마크에 대한 논의가 있을 때
- CI/CD 파이프라인에서 Go 테스트 설정을 구성할 때

---

## Core Patterns

### 1. Table-Driven Tests with t.Run

```go
func TestParseAge(t *testing.T) {
    tests := []struct {
        name    string
        input   string
        want    int
        wantErr bool
    }{
        {"valid", "25", 25, false},
        {"negative", "-1", 0, true},
        {"non-numeric", "abc", 0, true},
        {"empty", "", 0, true},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            got, err := ParseAge(tt.input)
            if (err != nil) != tt.wantErr {
                t.Errorf("ParseAge(%q) err=%v, wantErr=%v", tt.input, err, tt.wantErr)
                return
            }
            if got != tt.want {
                t.Errorf("ParseAge(%q) = %d, want %d", tt.input, got, tt.want)
            }
        })
    }
}
```

### 2. Test Fixtures with TestMain

```go
var testDB *sql.DB

func TestMain(m *testing.M) {
    testDB, _ = sql.Open("postgres", os.Getenv("TEST_DB_URL"))
    code := m.Run()
    testDB.Close()
    os.Exit(code)
}

func setupTable(t *testing.T) {
    t.Helper()
    testDB.Exec(`CREATE TABLE IF NOT EXISTS test_users (id SERIAL, name TEXT)`)
    t.Cleanup(func() { testDB.Exec("DROP TABLE IF EXISTS test_users") })
}
```

### 3. testing.T Helpers

```go
// t.Helper — 실패 시 호출자 줄 번호를 보고
func requireNoError(t *testing.T, err error) {
    t.Helper()
    if err != nil { t.Fatalf("unexpected error: %v", err) }
}

// t.Cleanup — 테스트 종료 시 자동 정리
func tempFile(t *testing.T, content string) string {
    t.Helper()
    f, err := os.CreateTemp("", "test-*.txt")
    if err != nil { t.Fatal(err) }
    t.Cleanup(func() { os.Remove(f.Name()) })
    f.WriteString(content); f.Close()
    return f.Name()
}

// t.Parallel — 독립 테스트 병렬 실행
func TestValidation(t *testing.T) {
    tests := []struct{ name, email string; valid bool }{
        {"valid", "a@b.com", true}, {"bad", "nope", false},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            t.Parallel()
            if got := IsValidEmail(tt.email); got != tt.valid {
                t.Errorf("IsValidEmail(%q)=%v, want %v", tt.email, got, tt.valid)
            }
        })
    }
}
```

### 4. Benchmarks

```go
func BenchmarkFibonacci(b *testing.B) {
    for i := 0; i < b.N; i++ { Fibonacci(20) }
}

func BenchmarkJSONDecode(b *testing.B) {
    data, _ := os.ReadFile("testdata/large.json")
    b.ResetTimer()
    b.ReportAllocs()
    for i := 0; i < b.N; i++ {
        var r map[string]interface{}
        json.Unmarshal(data, &r)
    }
}
// go test -bench=BenchmarkJSONDecode -benchmem
```

### 5. Testify

```go
import (
    "github.com/stretchr/testify/assert"
    "github.com/stretchr/testify/require"
)

func TestCreateUser(t *testing.T) {
    user, err := svc.Create("Alice", "alice@example.com")
    require.NoError(t, err)   // 실패 시 즉시 중단
    assert.Equal(t, "Alice", user.Name)  // 실패해도 계속
}

// suite — 셋업/티어다운 체계적 관리
type UserSuite struct {
    suite.Suite
    svc *UserService
}
func (s *UserSuite) SetupTest()    { s.svc = NewUserService(NewMockStore()) }
func (s *UserSuite) TestCreate()   { u, err := s.svc.Create("B", "b@t.com"); s.NoError(err); s.Equal("B", u.Name) }
func TestUserSuite(t *testing.T)   { suite.Run(t, new(UserSuite)) }

// mock — 인터페이스 모킹
type MockStore struct { mock.Mock }
func (m *MockStore) FindByID(ctx context.Context, id int) (*User, error) {
    args := m.Called(ctx, id)
    if args.Get(0) == nil { return nil, args.Error(1) }
    return args.Get(0).(*User), args.Error(1)
}

func TestGetUser(t *testing.T) {
    store := new(MockStore)
    store.On("FindByID", mock.Anything, 1).Return(&User{ID: 1, Name: "A"}, nil)
    svc := NewUserService(store)
    u, err := svc.GetUser(context.Background(), 1)
    require.NoError(t, err)
    assert.Equal(t, "A", u.Name)
    store.AssertExpectations(t)
}
```

### 6. httptest

```go
// NewRecorder — 핸들러 직접 테스트
func TestHealth(t *testing.T) {
    req := httptest.NewRequest(http.MethodGet, "/health", nil)
    w := httptest.NewRecorder()
    HealthHandler(w, req)
    assert.Equal(t, 200, w.Result().StatusCode)
    body, _ := io.ReadAll(w.Result().Body)
    assert.JSONEq(t, `{"status":"ok"}`, string(body))
}

// NewServer — 클라이언트 테스트
func TestAPIClient(t *testing.T) {
    srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(User{ID: 1, Name: "Test"})
    }))
    defer srv.Close()
    client := NewAPIClient(srv.URL)
    u, err := client.GetUser(context.Background(), 1)
    require.NoError(t, err)
    assert.Equal(t, "Test", u.Name)
}
```

### 7. Golden Files

```go
var update = flag.Bool("update", false, "update golden files")

func TestRender(t *testing.T) {
    got := RenderTemplate(sampleData)
    golden := filepath.Join("testdata", t.Name()+".golden")
    if *update {
        os.MkdirAll("testdata", 0o755)
        os.WriteFile(golden, []byte(got), 0o644)
    }
    want, _ := os.ReadFile(golden)
    assert.Equal(t, string(want), got)
}
// 갱신: go test -run TestRender -update
```

### 8. Build Tags for Integration Tests

```go
//go:build integration

package db_test

func TestDBIntegration(t *testing.T) {
    db := connectTestDB(t)
    _, err := db.Exec("INSERT INTO users (name) VALUES ($1)", "Alice")
    require.NoError(t, err)
    var name string
    db.QueryRow("SELECT name FROM users WHERE name=$1", "Alice").Scan(&name)
    assert.Equal(t, "Alice", name)
}
// go test -tags=integration ./...
```

### 9. Coverage

```bash
go test -cover ./...                          # 패키지 커버리지
go test -coverprofile=coverage.out ./...      # 프로파일 생성
go tool cover -html=coverage.out              # HTML 시각화
go tool cover -func=coverage.out              # 함수별 확인
```

### 10. Race Detection

```go
// go test -race ./...
func TestConcurrentMap(t *testing.T) {
    m := NewSafeMap()
    var wg sync.WaitGroup
    for i := 0; i < 100; i++ {
        wg.Add(1)
        go func(n int) {
            defer wg.Done()
            m.Set(fmt.Sprintf("k%d", n), n)
            m.Get(fmt.Sprintf("k%d", n))
        }(i)
    }
    wg.Wait()
    assert.Equal(t, 100, m.Len())
}
// CI: go test -race -count=1 ./...
```

---

## Anti-Patterns

### 1. 테스트 간 상태 공유

```go
// BAD — 전역 변수로 순서 의존
var counter int
func TestA(t *testing.T) { counter++; assert.Equal(t, 1, counter) }
// GOOD — 테스트마다 독립 상태
func TestA(t *testing.T) { c := 0; c++; assert.Equal(t, 1, c) }
```

### 2. 에러 메시지 없는 단순 비교

```go
// BAD
if got != want { t.Fail() }
// GOOD
if got != want { t.Errorf("Hash(%q) = %q, want %q", input, got, want) }
```

### 3. httptest 없이 실제 서버에 요청

```go
// BAD — 네트워크 상태에 의존
resp, _ := http.Get("https://api.example.com/users/1")
// GOOD — httptest로 격리 (위 6번 패턴 참고)
```

### 4. t.Parallel 미사용

```go
// BAD — 순차 실행으로 느림
func TestS1(t *testing.T) { time.Sleep(time.Second) }
// GOOD — 병렬로 속도 향상
func TestS1(t *testing.T) { t.Parallel(); time.Sleep(time.Second) }
```
