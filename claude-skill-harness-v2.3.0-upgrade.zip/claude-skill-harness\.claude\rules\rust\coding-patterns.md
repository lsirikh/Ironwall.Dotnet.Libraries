# Rust Coding Patterns

## Must Always
- Use `?` operator for error propagation instead of manual match
- Prefer `Result<T, E>` over `panic!()` for recoverable errors
- Use `#[derive()]` for common traits: Debug, Clone, PartialEq, Eq, Hash
- Prefer `&str` over `String` in function parameters (accept borrowed, return owned)
- Use `impl Trait` in argument position for simple generics
- Use `Option::map`, `and_then`, `unwrap_or_default` instead of manual match
- Document public API with `///` doc comments including examples
- Use `clippy` and fix all warnings: `cargo clippy -- -D warnings`
- Keep `unsafe` blocks minimal, document invariants with `// SAFETY:` comment
- Use `Arc<Mutex<T>>` for shared mutable state across threads

## Must Never
- Use `.unwrap()` in library code (OK in tests and prototypes with comment)
- Use `unsafe` without `// SAFETY:` justification comment
- Ignore compiler warnings — fix or explicitly allow with reason
- Clone when borrowing suffices (check ownership transfer necessity)
- Use `Box<dyn Error>` in libraries (use thiserror for custom errors)
- Leak memory with `mem::forget` or `Box::leak` without justification
