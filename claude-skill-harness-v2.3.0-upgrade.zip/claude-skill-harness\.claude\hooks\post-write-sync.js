// .claude/hooks/post-write-sync.js
// PostToolUse command Hook — 파일 쓰기 후 자동 상태 갱신 (강화 버전)
// matcher: Write|Edit
//
// 기존: pipeline-state.json 갱신 + session-context.md 마지막 수정 파일
// 추가: INDEX.md 자동 행 삽입 + 문서 수 카운트 + 감사 로그
//
// 차단 Hook이 아닌 부가 기능이므로 모든 오류를 silent skip 처리

const fs = require('fs');
const path = require('path');

// IMPL-10 (FR-10): Hook 실행 시간 자동 측정
const _hookStart = Date.now();
process.on('exit', () => {
  const elapsed = Date.now() - _hookStart;
  if (elapsed > 100) {
    try {
      const al = path.join(path.resolve(__dirname, '..', '..'), 'docs', 'memory', 'audit-log.jsonl');
      fs.appendFileSync(al, JSON.stringify({
        timestamp: new Date().toISOString(),
        event: 'hook-perf',
        hook: 'post-write-sync.js',
        elapsed_ms: elapsed
      }) + '\n');
    } catch { /* silent */ }
  }
});

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');
const SESSION_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'session-context.md');
const INDEX_FILE = path.join(PROJECT_ROOT, 'docs', 'INDEX.md');

try {
  let toolInput = {};
  try {
    toolInput = JSON.parse(process.env.CLAUDE_TOOL_INPUT || '{}');
  } catch {
    process.exit(0);
  }

  const rawPath = (toolInput.file_path || toolInput.path || '').replace(/\\/g, '/');
  if (!rawPath) process.exit(0);

  // 경로 정규화: 정규식 매칭을 위해 항상 앞에 /를 붙인다
  // "docs/prds/foo.md" → "/docs/prds/foo.md" (매칭 일관성 보장)
  const filePath = rawPath.startsWith('/') || rawPath.includes(':') ? rawPath : '/' + rawPath;

  const timestamp = new Date().toISOString().slice(0, 10);

  // ── pipeline-state.json 갱신 — PRD/Plan 아티팩트 자동 기록 ──────────
  if (fs.existsSync(STATE_FILE)) {
    try {
      const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));

      let updated = false;

      // docs/prds/ 파일이 쓰여지면 artifacts.prd 갱신
      if (/\/docs\/prds\//.test(filePath) && filePath.endsWith('.md')) {
        state.artifacts = state.artifacts || {};
        state.artifacts.prd = {
          path: filePath.replace(/^.*?(docs\/prds\/)/, 'docs/prds/'),
          recorded_at: new Date().toISOString()
        };
        state.activePrd = state.artifacts.prd.path;
        updated = true;
      }

      // docs/plans/ 파일이 쓰여지면 artifacts.plan 갱신
      if (/\/docs\/plans\//.test(filePath) && filePath.endsWith('.md')) {
        state.artifacts = state.artifacts || {};
        state.artifacts.plan = {
          path: filePath.replace(/^.*?(docs\/plans\/)/, 'docs/plans/'),
          recorded_at: new Date().toISOString()
        };
        state.activePlan = state.artifacts.plan.path;
        updated = true;
      }

      if (updated) {
        state.updated_at = new Date().toISOString();
        fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2) + '\n');
      }
    } catch {
      // pipeline-state.json 갱신 실패 → silent skip
    }
  }

  // ── INDEX.md 자동 갱신 ──────────────────────────────────────────────
  if (/\/docs\//.test(filePath) && filePath.endsWith('.md') &&
      !filePath.includes('INDEX.md') && !filePath.includes('memory/')) {
    try {
      if (fs.existsSync(INDEX_FILE)) {
        let indexContent = fs.readFileSync(INDEX_FILE, 'utf8');

        // 마지막 갱신 날짜 업데이트
        indexContent = indexContent.replace(
          /- \*\*마지막 갱신\*\*: .*/,
          `- **마지막 갱신**: ${timestamp}`
        );

        // 파일명 추출
        const fileName = path.basename(filePath);

        // 이미 INDEX에 등록된 파일인지 확인
        const alreadyListed = indexContent.includes(fileName);

        if (!alreadyListed) {
          // ── 문서 유형별 자동 행 삽입 ────────────────────────────────
          const fullPath = filePath.replace(/^.*?(docs\/)/, '');
          let newRow = '';
          let sectionMarker = '';

          // docs/analysis/*.md
          if (/\/docs\/analysis\//.test(filePath)) {
            const topic = fileName.replace(/-analysis\.md$/, '');
            newRow = `| [${fileName}](analysis/${fileName}) | ${topic} 분석 | ${timestamp} |`;
            sectionMarker = '## 분석 (docs/analysis/)';
          }
          // docs/prds/*.md
          else if (/\/docs\/prds\//.test(filePath)) {
            const topic = fileName.replace(/-prd\.md$/, '');
            // PRD 파일에서 상태 읽기 시도
            let status = 'Draft';
            try {
              const prdFullPath = filePath.startsWith('/') || filePath.includes(':')
                ? filePath : path.join(PROJECT_ROOT, filePath);
              const normalizedPath = prdFullPath.replace(/\//g, path.sep);
              if (fs.existsSync(normalizedPath)) {
                const prdContent = fs.readFileSync(normalizedPath, 'utf8');
                if (/Approved/i.test(prdContent)) status = 'Approved';
                else if (/Completed/i.test(prdContent)) status = 'Completed';
                else if (/Review/i.test(prdContent)) status = 'Review';
              }
            } catch { /* ignore */ }
            newRow = `| [${fileName}](prds/${fileName}) | ${topic} | ${status} | ${timestamp} |`;
            sectionMarker = '## 요구사항 정의서 (docs/prds/)';
          }
          // docs/plans/*.md
          else if (/\/docs\/plans\//.test(filePath)) {
            const topic = fileName.replace(/-prd-plan\.md$/, '');
            // Plan 파일에서 태스크 수 읽기 시도
            let progress = '0/0';
            try {
              const planFullPath = filePath.startsWith('/') || filePath.includes(':')
                ? filePath : path.join(PROJECT_ROOT, filePath);
              const normalizedPath = planFullPath.replace(/\//g, path.sep);
              if (fs.existsSync(normalizedPath)) {
                const planContent = fs.readFileSync(normalizedPath, 'utf8');
                const done = (planContent.match(/\[x\]/g) || []).length;
                const total = done +
                  (planContent.match(/\[~\]/g) || []).length +
                  (planContent.match(/\[!\]/g) || []).length +
                  (planContent.match(/\[ \]/g) || []).length;
                progress = `${done}/${total}`;
              }
            } catch { /* ignore */ }
            const prdLink = `[PRD](prds/${topic}-prd.md)`;
            newRow = `| [${fileName}](plans/${fileName}) | ${prdLink} | ${progress} | ${timestamp} |`;
            sectionMarker = '## 구현 플랜 (docs/plans/)';
          }
          // docs/tests/*.md
          else if (/\/docs\/tests\//.test(filePath)) {
            newRow = `| [${fileName}](tests/${fileName}) | -% | -% | ${timestamp} |`;
            sectionMarker = '## 테스트 결과 (docs/tests/)';
          }
          // docs/reports/*.md
          else if (/\/docs\/reports\//.test(filePath)) {
            const topic = fileName.replace(/-report\.md$/, '');
            const chain = `[PRD](prds/${topic}-prd.md) → [Plan](plans/${topic}-prd-plan.md)`;
            newRow = `| [${fileName}](reports/${fileName}) | ${chain} | ${timestamp} |`;
            sectionMarker = '## 완료 리포트 (docs/reports/)';
          }

          // 행 삽입
          if (newRow && sectionMarker) {
            const sectionIdx = indexContent.indexOf(sectionMarker);
            if (sectionIdx !== -1) {
              // 섹션의 테이블 헤더(|---|) 다음 줄을 찾아 그 뒤에 삽입
              const afterSection = indexContent.substring(sectionIdx);
              const headerDividerMatch = afterSection.match(/\|[-|]+\|\n/);
              if (headerDividerMatch) {
                const insertPos = sectionIdx + headerDividerMatch.index + headerDividerMatch[0].length;
                indexContent = indexContent.substring(0, insertPos) +
                  newRow + '\n' +
                  indexContent.substring(insertPos);
              }
            }
          }

          // 총 문서 수 업데이트
          if (newRow) {
            indexContent = indexContent.replace(
              /- \*\*총 문서 수\*\*: (\d+)개/,
              (match, num) => `- **총 문서 수**: ${parseInt(num) + 1}개`
            );
          }
        }
        // 이미 등록된 파일 — Plan 진행률 업데이트
        else if (/\/docs\/plans\//.test(filePath)) {
          try {
            const planFullPath = filePath.startsWith('/') || filePath.includes(':')
              ? filePath : path.join(PROJECT_ROOT, filePath);
            const normalizedPath = planFullPath.replace(/\//g, path.sep);
            if (fs.existsSync(normalizedPath)) {
              const planContent = fs.readFileSync(normalizedPath, 'utf8');
              const done = (planContent.match(/\[x\]/g) || []).length;
              const total = done +
                (planContent.match(/\[~\]/g) || []).length +
                (planContent.match(/\[!\]/g) || []).length +
                (planContent.match(/\[ \]/g) || []).length;
              // INDEX에서 해당 파일 행의 진행률 컬럼 업데이트
              const rowPattern = new RegExp(
                `(\\| \\[${fileName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\][^|]+\\|[^|]+\\| )\\d+/\\d+( \\|)`
              );
              indexContent = indexContent.replace(rowPattern, `$1${done}/${total}$2`);
            }
          } catch { /* ignore */ }
        }
        // 이미 등록된 PRD — 상태 업데이트
        else if (/\/docs\/prds\//.test(filePath)) {
          try {
            const prdFullPath = filePath.startsWith('/') || filePath.includes(':')
              ? filePath : path.join(PROJECT_ROOT, filePath);
            const normalizedPath = prdFullPath.replace(/\//g, path.sep);
            if (fs.existsSync(normalizedPath)) {
              const prdContent = fs.readFileSync(normalizedPath, 'utf8');
              let status = 'Draft';
              if (/Completed/i.test(prdContent)) status = 'Completed';
              else if (/Approved/i.test(prdContent)) status = 'Approved';
              else if (/Review/i.test(prdContent)) status = 'Review';
              // INDEX에서 해당 파일 행의 상태 컬럼 업데이트
              const rowPattern = new RegExp(
                `(\\| \\[${fileName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\][^|]+\\|[^|]+\\| )\\w+( \\|)`
              );
              indexContent = indexContent.replace(rowPattern, `$1${status}$2`);
            }
          } catch { /* ignore */ }
        }

        fs.writeFileSync(INDEX_FILE, indexContent);
      }
    } catch {
      // INDEX.md 갱신 실패 → silent skip
    }
  }

  // ── [IMPL-01 / FR-01~03] PRD Draft 작성 시 검토 마커 자동 생성 ──
  // approval-authentication-prd
  if (/\/docs\/prds\/.*-prd\.md$/i.test(filePath)) {
    try {
      let prdAbs;
      if (/^[A-Za-z]:/.test(filePath)) {
        prdAbs = filePath;
      } else {
        const rel = filePath.startsWith('/') ? filePath.substring(1) : filePath;
        prdAbs = path.join(PROJECT_ROOT, rel);
      }
      const normalizedPrd = prdAbs.replace(/\//g, path.sep);
      if (fs.existsSync(normalizedPrd)) {
        const prdContent = fs.readFileSync(normalizedPrd, 'utf8');
        // PRD가 Draft 상태일 때만 마커 유지/생성
        if (/^- \*\*상태\*\*:\s*Draft/im.test(prdContent)) {
          const claudeDir = path.join(PROJECT_ROOT, '.claude');
          if (!fs.existsSync(claudeDir)) fs.mkdirSync(claudeDir, { recursive: true });
          const markerFile = path.join(claudeDir, '.pending-prd-review');
          const versionMatch = prdContent.match(/^- \*\*버전\*\*:\s*v?(\d+\.\d+)/im);
          const now = new Date().toISOString();
          let marker;
          if (fs.existsSync(markerFile)) {
            // 기존 마커 — updated_at만 갱신
            try {
              marker = JSON.parse(fs.readFileSync(markerFile, 'utf8'));
              marker.updated_at = now;
              if (versionMatch) marker.version = versionMatch[1];
            } catch {
              marker = null;
            }
          }
          if (!marker) {
            // 신규 마커 — SHA-256 해시 + 30분 토큰 만료 (FR-16)
            const crypto = require('crypto');
            const prdHash = crypto.createHash('sha256').update(prdContent).digest('hex');
            const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
            marker = {
              prd: filePath.replace(/^.*?(docs\/prds\/)/, 'docs/prds/'),
              version: versionMatch ? versionMatch[1] : '1.0',
              created_at: now,
              updated_at: now,
              prd_hash: prdHash,
              token_expires: expiresAt
            };
          }
          fs.writeFileSync(markerFile, JSON.stringify(marker, null, 2) + '\n');
        } else {
          // PRD가 더 이상 Draft가 아니면 마커 자동 삭제 (Approved 전환된 경우)
          const markerFile = path.join(PROJECT_ROOT, '.claude', '.pending-prd-review');
          try {
            if (fs.existsSync(markerFile)) {
              const m = JSON.parse(fs.readFileSync(markerFile, 'utf8'));
              if (m.prd && filePath.endsWith(path.basename(m.prd))) {
                fs.unlinkSync(markerFile);
              }
            }
          } catch { /* silent */ }
        }
      }
    } catch { /* silent */ }
  }

  // ── [IMPL-09 / FR-12] PRD 변경 이력 행 추가 리마인더 ───────────────
  // PRD가 Edit되었지만 변경 이력 테이블 마지막 행 시간이 5분 이상 오래되면 경고
  if (/\/docs\/prds\/.*-prd\.md$/i.test(filePath)) {
    try {
      let prdAbs;
      if (/^[A-Za-z]:/.test(filePath)) {
        prdAbs = filePath;
      } else {
        const rel = filePath.startsWith('/') ? filePath.substring(1) : filePath;
        prdAbs = path.join(PROJECT_ROOT, rel);
      }
      const normalizedPrd = prdAbs.replace(/\//g, path.sep);
      if (fs.existsSync(normalizedPrd)) {
        const prdContent = fs.readFileSync(normalizedPrd, 'utf8');
        // 변경 이력 테이블의 마지막 날짜 행 추출
        const historyMatches = prdContent.match(/\|\s*(\d{4}-\d{2}-\d{2})[^\n]*\|/g) || [];
        if (historyMatches.length > 0) {
          // 마지막 행의 날짜
          const lastRow = historyMatches[historyMatches.length - 1];
          const dateMatch = lastRow.match(/(\d{4}-\d{2}-\d{2})/);
          if (dateMatch) {
            const lastDate = new Date(dateMatch[1] + 'T00:00:00Z').getTime();
            const fileMtime = fs.statSync(normalizedPrd).mtimeMs;
            // 파일 수정 시각이 마지막 변경 이력 날짜보다 1일 이상 늦으면 경고
            // (날짜 단위라 1일을 임계로)
            if (fileMtime - lastDate > 24 * 60 * 60 * 1000) {
              console.error(
                '[WARN] PRD 수정됨 — 변경 이력 행 추가 필요\n' +
                '  파일: ' + filePath + '\n' +
                '  마지막 이력: ' + dateMatch[1] + '\n' +
                '  → "변경 이력" 테이블에 새 행을 추가하세요'
              );
            }
          }
        }
      }
    } catch { /* silent */ }
  }

  // ── [IMPL-15] Plan FR-IMPL 연결 검증 (Track C만) ───────────────────
  // ── [IMPL-16] Plan 순환 의존 자동 감지 ─────────────────────────────
  if (/\/docs\/plans\//.test(filePath) && filePath.endsWith('.md')) {
    try {
      // 현재 Track 확인 (Track C에서만 FR 검증)
      let currentTrack = 'C';
      try {
        if (fs.existsSync(STATE_FILE)) {
          const st = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
          currentTrack = st.track || 'C';
        }
      } catch { /* default C */ }

      // 경로 해석: 절대 경로(C:/...) 또는 PROJECT_ROOT 기준 상대 경로
      // filePath는 정규식 매칭용으로 앞에 /가 붙어있을 수 있음 → 제거 후 PROJECT_ROOT와 결합
      let planAbs;
      if (/^[A-Za-z]:/.test(filePath)) {
        planAbs = filePath;
      } else {
        const rel = filePath.startsWith('/') ? filePath.substring(1) : filePath;
        planAbs = path.join(PROJECT_ROOT, rel);
      }
      const normalizedPlan = planAbs.replace(/\//g, path.sep);

      if (fs.existsSync(normalizedPlan)) {
        const planContent = fs.readFileSync(normalizedPlan, 'utf8');

        // ── [IMPL-15] FR-IMPL 연결 검증 (Track C만) ─────────────────
        if (currentTrack === 'C') {
          // Plan 파일명에서 topic 추출 → 연관 PRD 찾기
          const planFileName = path.basename(filePath);
          const topic = planFileName.replace(/-prd-plan\.md$/, '').replace(/-plan\.md$/, '');
          const prdPath = path.join(PROJECT_ROOT, 'docs', 'prds', `${topic}-prd.md`);

          if (fs.existsSync(prdPath)) {
            const prdContent = fs.readFileSync(prdPath, 'utf8');

            // PRD에서 FR-XX 추출 (테이블의 첫 컬럼)
            const prdFrIds = new Set();
            const prdFrMatches = prdContent.match(/^\|\s*FR-(\d+)\s*\|/gm) || [];
            prdFrMatches.forEach(m => {
              const id = m.match(/FR-(\d+)/)[1];
              prdFrIds.add(id);
            });

            // Plan에서 "관련 FR:" 필드 추출
            const planFrIds = new Set();
            const planFrLines = planContent.match(/관련 FR:\s*([^\n]+)/g) || [];
            planFrLines.forEach(line => {
              const ids = line.match(/FR-(\d+)/g) || [];
              ids.forEach(id => planFrIds.add(id.replace('FR-', '')));
            });

            // 미연결 FR (PRD에 있지만 Plan에 없음)
            const unimplemented = [...prdFrIds].filter(id => !planFrIds.has(id));
            // 고아 IMPL FR (Plan에 있지만 PRD에 없음)
            const orphan = [...planFrIds].filter(id => !prdFrIds.has(id));

            const warnings = [];
            if (unimplemented.length > 0) {
              warnings.push(`미구현 FR: ${unimplemented.map(id => 'FR-' + id).join(', ')}`);
            }
            if (orphan.length > 0) {
              warnings.push(`고아 FR 참조: ${orphan.map(id => 'FR-' + id).join(', ')}`);
            }

            if (warnings.length > 0) {
              const auditFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');
              fs.appendFileSync(auditFile, JSON.stringify({
                timestamp: new Date().toISOString(),
                event: 'fr-impl-mismatch',
                file: filePath,
                warnings
              }) + '\n');
              console.error('[WARN] Plan FR-IMPL 매핑 검증:\n  ' + warnings.join('\n  '));
            }
          }
        }

        // ── [IMPL-16] 순환 의존 + 무효 참조 감지 ────────────────────
        const taskGraph = {}; // { taskId: [depIds] }
        const allTaskIds = new Set();

        // 태스크 ID 추출: - [상태] **[ID-XX]**
        const taskIdMatches = planContent.match(/^- \[[ x~!\-]\] \*\*\[([A-Z]+-\d+)\]\*\*/gm) || [];
        taskIdMatches.forEach(line => {
          const m = line.match(/\[([A-Z]+-\d+)\]/);
          if (m) allTaskIds.add(m[1]);
        });

        // 각 태스크의 "의존:" 필드 추출
        // 패턴: "- [상태] **[ID-XX]** ..." 다음에 나오는 "  - 의존: ..."
        const sections = planContent.split(/^- \[[ x~!\-]\] \*\*\[/gm);
        sections.forEach(section => {
          const idMatch = section.match(/^([A-Z]+-\d+)\]/);
          if (!idMatch) return;
          const taskId = idMatch[1];
          // "  - 의존: ID, ID, ..." 패턴
          const depMatch = section.match(/의존:\s*([A-Z0-9\-,\s]+)/);
          if (depMatch) {
            const deps = (depMatch[1].match(/[A-Z]+-\d+/g) || []);
            taskGraph[taskId] = deps;
          } else {
            taskGraph[taskId] = [];
          }
        });

        // 무효 참조 감지
        const invalidRefs = [];
        for (const [taskId, deps] of Object.entries(taskGraph)) {
          deps.forEach(dep => {
            if (!allTaskIds.has(dep)) {
              invalidRefs.push(`${taskId} → ${dep} (존재하지 않음)`);
            }
          });
        }

        // 순환 감지 (DFS)
        const cycles = [];
        function dfs(node, visited, stack) {
          if (stack.includes(node)) {
            const cycleStart = stack.indexOf(node);
            cycles.push([...stack.slice(cycleStart), node].join(' → '));
            return;
          }
          if (visited.has(node)) return;
          visited.add(node);
          const deps = taskGraph[node] || [];
          for (const dep of deps) {
            if (allTaskIds.has(dep)) {
              dfs(dep, visited, [...stack, node]);
            }
          }
        }

        const globalVisited = new Set();
        for (const taskId of Object.keys(taskGraph)) {
          if (!globalVisited.has(taskId)) {
            dfs(taskId, globalVisited, []);
          }
        }

        // 중복 cycle 제거
        const uniqueCycles = [...new Set(cycles)];

        const depWarnings = [];
        if (uniqueCycles.length > 0) {
          depWarnings.push('순환 의존 감지:');
          uniqueCycles.forEach((c, i) => depWarnings.push(`  ${i + 1}. ${c}`));
        }
        if (invalidRefs.length > 0) {
          depWarnings.push('무효 의존 참조:');
          invalidRefs.forEach(r => depWarnings.push(`  - ${r}`));
        }

        if (depWarnings.length > 0) {
          const auditFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');
          fs.appendFileSync(auditFile, JSON.stringify({
            timestamp: new Date().toISOString(),
            event: uniqueCycles.length > 0 ? 'circular-dependency' : 'invalid-dep-reference',
            file: filePath,
            cycles: uniqueCycles,
            invalid_refs: invalidRefs
          }) + '\n');
          console.error('[WARN] Plan 의존성 검증:\n' + depWarnings.join('\n'));
        }
      }
    } catch {
      // 검증 실패는 silent skip — 부가 기능
    }
  }

  // ── [FR-08] Harness Loop: src/ 파일 린트 자동 실행 ────────────────
  const isSrcFile = /\/src\//i.test(filePath) ||
    (/\.(py|js|ts|jsx|tsx|cs|cpp|java|go|rs)$/i.test(filePath) && !/\/docs\//i.test(filePath) && !/\/\.claude\//i.test(filePath));

  if (isSrcFile) {
    try {
      // CLAUDE.md에서 lint_command 읽기 (IMPL-09)
      const claudeMdPath = path.join(PROJECT_ROOT, 'CLAUDE.md');
      let lintCmd = null;
      if (fs.existsSync(claudeMdPath)) {
        const claudeContent = fs.readFileSync(claudeMdPath, 'utf8');
        const m = claudeContent.match(/lint_command:\s*"([^"]+)"/);
        if (m && m[1]) lintCmd = m[1];
      }

      if (lintCmd) {
        // IMPL-10: 린트 실행
        const { execSync } = require('child_process');
        let lintResult = { errors: 0, warnings: 0, summary: '', timestamp: new Date().toISOString() };

        try {
          execSync(lintCmd, {
            cwd: PROJECT_ROOT,
            timeout: 10000, // NFR-02: 10초 타임아웃
            encoding: 'utf8',
            stdio: ['pipe', 'pipe', 'pipe']
          });
          // exit 0 = 린트 통과
          lintResult.summary = 'clean';
        } catch (lintErr) {
          const output = (lintErr.stderr || lintErr.stdout || '').substring(0, 300);
          const errorCount = (output.match(/error/gi) || []).length;
          const warnCount = (output.match(/warn/gi) || []).length;
          lintResult.errors = errorCount;
          lintResult.warnings = Math.max(warnCount, 1); // 실패면 최소 1
          lintResult.summary = output.split('\n')[0] || 'lint failed';
        }

        // pipeline-state.json에 저장
        if (fs.existsSync(STATE_FILE)) {
          try {
            const st = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
            st.lastLintResult = lintResult;
            st.updated_at = new Date().toISOString();
            fs.writeFileSync(STATE_FILE, JSON.stringify(st, null, 2) + '\n');
          } catch { /* silent */ }
        }

        // [FR-12 / IMPL-14] 린트 감사 로그
        try {
          const auditFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');
          fs.appendFileSync(auditFile, JSON.stringify({
            timestamp: new Date().toISOString(),
            event: 'auto-lint-run',
            file: filePath.replace(/^.*?(src\/|tests\/)/, '$1'),
            errors: lintResult.errors,
            warnings: lintResult.warnings
          }) + '\n');
        } catch { /* silent */ }
      }
    } catch {
      // 린트 실행 실패 → silent skip (NFR-04 graceful degradation)
    }
  }

  // ── [FR-17] Tier 3: 행동 피드백 위반 기록 ──────────────────────────
  try {
    const fbFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'feedback-rules.json');
    if (fs.existsSync(fbFile)) {
      const rules = JSON.parse(fs.readFileSync(fbFile, 'utf8'));
      const phase = (() => { try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')).phase; } catch { return 'unknown'; } })();
      const toolName = process.env.CLAUDE_TOOL_NAME || '';
      for (const rule of rules) {
        if (!rule.active || rule.action !== 'block') continue;
        const t = rule.trigger || {};
        if (t.phase && t.phase !== '*' && !t.phase.split('|').includes(phase)) continue;
        if (t.tool && t.tool !== '*' && t.tool !== toolName) continue;
        if (t.target && !new RegExp(t.target, 'i').test(filePath)) continue;
        // 매칭됨 → 위반 기록
        const auditDir = path.join(PROJECT_ROOT, 'docs', 'memory');
        fs.appendFileSync(path.join(auditDir, 'audit-log.jsonl'), JSON.stringify({
          timestamp: new Date().toISOString(),
          event: 'feedback-violation',
          rule_id: rule.id,
          tool: toolName,
          phase,
          path: filePath.replace(/^.*?(docs\/|src\/|\.claude\/)/, '$1')
        }) + '\n');
      }
    }
  } catch { /* silent */ }

  // ── 감사 로그 기록 ──────────────────────────────────────────────────
  try {
    const memoryDir = path.join(PROJECT_ROOT, 'docs', 'memory');
    if (fs.existsSync(memoryDir)) {
      const auditFile = path.join(memoryDir, 'audit-log.jsonl');
      const auditEntry = JSON.stringify({
        timestamp: new Date().toISOString(),
        tool: process.env.CLAUDE_TOOL_NAME || 'unknown',
        file: filePath.replace(/^.*?(docs\/|src\/|tests\/|\.claude\/)/, '$1'),
        phase: (() => {
          try {
            if (fs.existsSync(STATE_FILE)) {
              return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')).phase || 'unknown';
            }
          } catch { /* ignore */ }
          return 'unknown';
        })()
      });
      fs.appendFileSync(auditFile, auditEntry + '\n');
    }
  } catch {
    // 감사 로그 실패 → silent skip
  }

  // ── session-context.md 갱신 — 마지막 수정 파일 기록 ──────────────────
  if (fs.existsSync(SESSION_FILE)) {
    try {
      let content = fs.readFileSync(SESSION_FILE, 'utf8');

      // 상대 경로로 변환
      const relativePath = filePath
        .replace(/^.*?(docs\/|src\/|tests\/|\.claude\/)/, '$1')
        .replace(/\\/g, '/');

      const newLine = `- \`${relativePath}\` — ${timestamp} (Hook 자동)`;

      // "마지막으로 수정한 파일" 섹션이 있으면 첫 번째 줄로 추가
      if (content.includes('## 마지막으로 수정한 파일')) {
        const sectionRegex = /(## 마지막으로 수정한 파일\n)((?:- .+\n)*)/;
        const match = content.match(sectionRegex);
        if (match) {
          const existingLines = match[2].split('\n').filter(l => l.startsWith('- '));
          const filtered = existingLines.filter(l => !l.includes(relativePath));
          const trimmed = [newLine, ...filtered].slice(0, 5);
          content = content.replace(
            sectionRegex,
            `## 마지막으로 수정한 파일\n${trimmed.join('\n')}\n`
          );
        }
      }

      // 마지막 업데이트 날짜 갱신
      content = content.replace(
        /- \*\*마지막 업데이트\*\*: .+/,
        `- **마지막 업데이트**: ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`
      );

      fs.writeFileSync(SESSION_FILE, content);
    } catch {
      // session-context.md 갱신 실패 → silent skip
    }
  }

} catch {
  // 최상위 폴백 — 부가 기능이므로 에러 무시
}

// ── [FR-10] Observation JSONL 기록 ──────────────────────────────────
// 도구 사용 관찰을 기록. 향후 Learning Loop의 데이터 소스.
try {
  const _cfg = require('./_config');
  if (_cfg.getConfigValue('features.observations', true)) {
    const obsFile = path.join(ROOT, 'docs', 'memory', 'observations.jsonl');
    const toolName = process.env.CLAUDE_TOOL_NAME || '';
    let toolInput = {};
    try { toolInput = JSON.parse(process.env.CLAUDE_TOOL_INPUT || '{}'); } catch {}
    const filePath = toolInput.file_path || toolInput.path || '';

    if (filePath) {
      const ext = path.extname(filePath);
      let statePhase = 'unknown';
      try {
        const s = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs', 'memory', 'pipeline-state.json'), 'utf8'));
        statePhase = s.phase || 'unknown';
      } catch {}

      fs.appendFileSync(obsFile, JSON.stringify({
        timestamp: new Date().toISOString(),
        phase: statePhase,
        tool: toolName,
        file_path: filePath.replace(/\\/g, '/'),
        file_type: ext,
        action: toolName === 'Write' ? 'create' : 'edit',
        duration_ms: Date.now() - _hookStart,
        result: 'success'
      }) + '\n');
    }
  }
} catch { /* silent — observation 실패가 도구를 차단하면 안 됨 */ }

process.exit(0);
