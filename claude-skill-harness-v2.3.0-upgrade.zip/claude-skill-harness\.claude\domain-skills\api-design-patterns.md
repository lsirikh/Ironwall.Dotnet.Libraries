---
name: "API Design Patterns"
description: "REST best practices, versioning, pagination, error handling, and alternative protocols (gRPC, GraphQL)"
languages: ["Python", "C#", "TypeScript"]
frameworks: ["FastAPI", "ASP.NET", "Express"]
phases: ["analysis", "dev"]
---

# API Design Patterns

## When to Activate

- REST API 엔드포인트 설계 또는 리뷰
- API 버전 관리 전략 결정
- 에러 응답 형식, 페이지네이션, 필터링 규칙 논의
- gRPC 또는 GraphQL 도입 검토
- API Rate Limiting, Idempotency 설계

---

## Core Patterns

### 1. REST Resource Naming

**규칙:**
- 복수 명사 사용: `/users`, `/orders` (동사 금지: `/getUsers`)
- 계층 관계는 중첩: `/users/{id}/orders`
- 2단계까지만 중첩하고, 그 이상은 쿼리 파라미터로
- kebab-case 사용: `/order-items` (camelCase, snake_case 금지)

```
# 좋은 예
GET    /users              → 목록 조회
POST   /users              → 생성
GET    /users/{id}          → 단건 조회
PUT    /users/{id}          → 전체 수정
PATCH  /users/{id}          → 부분 수정
DELETE /users/{id}          → 삭제
GET    /users/{id}/orders   → 사용자의 주문 목록

# 나쁜 예
GET    /getUser?id=1
POST   /createUser
PUT    /updateUserName
DELETE /deleteUserById
```

### 2. HTTP Methods & Status Codes

| Method | 용도 | 멱등성 | 안전 |
|--------|------|--------|------|
| GET | 리소스 조회 | Yes | Yes |
| POST | 리소스 생성 | No | No |
| PUT | 전체 교체 | Yes | No |
| PATCH | 부분 수정 | No* | No |
| DELETE | 삭제 | Yes | No |

**주요 상태 코드:**
```
# 성공
200 OK            — GET, PUT, PATCH 성공
201 Created       — POST 생성 성공 (Location 헤더 포함)
204 No Content    — DELETE 성공

# 클라이언트 오류
400 Bad Request   — 유효성 검증 실패
401 Unauthorized  — 인증 안 됨
403 Forbidden     — 인가 안 됨 (인증은 됨)
404 Not Found     — 리소스 없음
409 Conflict      — 충돌 (중복 생성 등)
422 Unprocessable — 형식은 맞지만 비즈니스 규칙 위반
429 Too Many Req  — Rate Limit 초과

# 서버 오류
500 Internal      — 서버 내부 오류
502 Bad Gateway   — 업스트림 서비스 오류
503 Unavailable   — 서비스 일시 중단
```

### 3. API Versioning

| 전략 | 예시 | 장점 | 단점 |
|------|------|------|------|
| **URL Path** | `/api/v1/users` | 명확, 라우팅 쉬움 | URL 변경 |
| **Header** | `Accept: application/vnd.api.v1+json` | URL 깔끔 | 디버깅 어려움 |
| **Query Param** | `/api/users?version=1` | 선택적 | 캐싱 복잡 |

**권장: URL Path 방식** — 가장 직관적이고 팀 합의가 쉽다.

```python
# FastAPI — URL Path versioning
from fastapi import APIRouter

v1_router = APIRouter(prefix="/api/v1")
v2_router = APIRouter(prefix="/api/v2")

@v1_router.get("/users/{user_id}")
async def get_user_v1(user_id: int):
    return {"id": user_id, "name": "Alice"}  # v1: name만

@v2_router.get("/users/{user_id}")
async def get_user_v2(user_id: int):
    return {"id": user_id, "first_name": "Alice", "last_name": "Kim"}  # v2: 분리
```

```csharp
// ASP.NET — URL Path versioning
[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
[ApiVersion("1.0")]
public class UsersV1Controller : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult Get(int id) => Ok(new { Id = id, Name = "Alice" });
}

[ApiVersion("2.0")]
public class UsersV2Controller : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult Get(int id) => Ok(new { Id = id, FirstName = "Alice", LastName = "Kim" });
}
```

### 4. Pagination

**Cursor-based (권장 — 실시간 데이터):**
```json
// GET /api/v1/orders?cursor=eyJpZCI6MTAwfQ&limit=20
{
  "data": [...],
  "pagination": {
    "next_cursor": "eyJpZCI6MTIwfQ",
    "has_more": true,
    "limit": 20
  }
}
```

**Offset-based (간단한 관리 도구):**
```json
// GET /api/v1/orders?page=3&per_page=20
{
  "data": [...],
  "pagination": {
    "page": 3,
    "per_page": 20,
    "total": 245,
    "total_pages": 13
  }
}
```

**Cursor vs Offset:**
| 항목 | Cursor | Offset |
|------|--------|--------|
| 대량 데이터 성능 | O(1) | O(N) — OFFSET 클수록 느림 |
| 중간 삽입/삭제 시 | 안전 | 중복/누락 발생 |
| 임의 페이지 접근 | 불가 | 가능 |

### 5. Filtering & Sorting

```
# 필터링 — 쿼리 파라미터
GET /api/v1/orders?status=pending&min_amount=100&created_after=2024-01-01

# 정렬 — sort 파라미터
GET /api/v1/orders?sort=-created_at,+amount
# - 접두사: 내림차순, + 또는 없음: 오름차순

# 필드 선택 — fields 파라미터
GET /api/v1/users?fields=id,name,email
```

```python
# FastAPI — 필터링 + 정렬 구현
from fastapi import Query
from typing import Optional

@v1_router.get("/orders")
async def list_orders(
    status: Optional[str] = Query(None, regex="^(pending|confirmed|shipped)$"),
    min_amount: Optional[float] = Query(None, ge=0),
    sort: Optional[str] = Query("-created_at"),
    cursor: Optional[str] = None,
    limit: int = Query(20, ge=1, le=100),
):
    query = build_query(status=status, min_amount=min_amount)
    query = apply_sort(query, sort)
    query = apply_cursor(query, cursor, limit)
    return paginate(query, limit)
```

### 6. Error Response — RFC 7807 Problem Details

```json
{
  "type": "https://api.example.com/errors/validation",
  "title": "Validation Error",
  "status": 422,
  "detail": "The 'email' field is not a valid email address.",
  "instance": "/api/v1/users",
  "errors": [
    {
      "field": "email",
      "message": "Must be a valid email address",
      "rejected_value": "not-an-email"
    }
  ],
  "trace_id": "abc-123-def"
}
```

```python
# FastAPI — 통일된 에러 응답
from fastapi import HTTPException
from fastapi.responses import JSONResponse

class ProblemDetail(Exception):
    def __init__(self, status: int, title: str, detail: str, errors: list = None):
        self.status = status
        self.title = title
        self.detail = detail
        self.errors = errors or []

@app.exception_handler(ProblemDetail)
async def problem_handler(request, exc: ProblemDetail):
    return JSONResponse(
        status_code=exc.status,
        content={
            "type": f"https://api.example.com/errors/{exc.status}",
            "title": exc.title,
            "status": exc.status,
            "detail": exc.detail,
            "instance": str(request.url),
            "errors": exc.errors,
        },
    )
```

### 7. Rate Limiting

```
# 응답 헤더
X-RateLimit-Limit: 100          # 윈도우당 허용 횟수
X-RateLimit-Remaining: 42       # 남은 횟수
X-RateLimit-Reset: 1704067200   # 리셋 시각 (Unix timestamp)
Retry-After: 30                 # 429 응답 시 재시도까지 대기 초

# 전략
- Fixed Window: 1분에 100회 (구현 간단, 경계 시점 burst 가능)
- Sliding Window: 최근 1분 기준 100회 (더 정확)
- Token Bucket: 토큰 소진 시 차단, 일정 속도로 충전 (burst 허용)
```

```typescript
// Express — express-rate-limit
import rateLimit from "express-rate-limit";

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,       // 1분
  max: 100,                   // 윈도우당 100회
  standardHeaders: true,      // RateLimit-* 헤더
  legacyHeaders: false,
  message: {
    type: "https://api.example.com/errors/rate-limit",
    title: "Too Many Requests",
    status: 429,
    detail: "Rate limit exceeded. Try again later.",
  },
});

app.use("/api/", apiLimiter);
```

### 8. Idempotency Keys

POST 요청의 중복 실행을 방지한다.

```
# 클라이언트가 고유 키를 생성하여 헤더에 포함
POST /api/v1/payments
Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000

# 서버 로직:
# 1. 키가 이미 존재하면 → 캐싱된 이전 응답 반환
# 2. 키가 없으면 → 처리 후 키+응답 저장 (TTL 24시간)
```

```python
# FastAPI — Idempotency 미들웨어 (Redis)
import redis, json, hashlib
from fastapi import Request, Response

r = redis.Redis()

@app.middleware("http")
async def idempotency_middleware(request: Request, call_next):
    if request.method != "POST":
        return await call_next(request)
    key = request.headers.get("Idempotency-Key")
    if not key:
        return await call_next(request)
    cache_key = f"idempotency:{key}"
    cached = r.get(cache_key)
    if cached:
        data = json.loads(cached)
        return Response(content=data["body"], status_code=data["status"],
                        media_type="application/json")
    response = await call_next(request)
    body = b"".join([chunk async for chunk in response.body_iterator])
    r.setex(cache_key, 86400, json.dumps({"body": body.decode(), "status": response.status_code}))
    return Response(content=body, status_code=response.status_code, media_type="application/json")
```

### 9. Bulk Operations

```json
// POST /api/v1/users/bulk
{
  "operations": [
    {"method": "create", "body": {"name": "Alice", "email": "alice@example.com"}},
    {"method": "create", "body": {"name": "Bob", "email": "bob@example.com"}},
    {"method": "update", "id": 5, "body": {"name": "Charlie Updated"}}
  ]
}

// 응답 — 각 작업의 개별 결과
{
  "results": [
    {"index": 0, "status": 201, "data": {"id": 10, "name": "Alice"}},
    {"index": 1, "status": 201, "data": {"id": 11, "name": "Bob"}},
    {"index": 2, "status": 200, "data": {"id": 5, "name": "Charlie Updated"}}
  ],
  "summary": {"total": 3, "succeeded": 3, "failed": 0}
}
```

### 10. gRPC Basics

```protobuf
// user.proto — Protocol Buffers 정의
syntax = "proto3";

package user;

service UserService {
  rpc GetUser (GetUserRequest) returns (UserResponse);
  rpc ListUsers (ListUsersRequest) returns (stream UserResponse);  // Server streaming
}

message GetUserRequest {
  string user_id = 1;
}

message UserResponse {
  string id = 1;
  string name = 2;
  string email = 3;
}

message ListUsersRequest {
  int32 page_size = 1;
  string page_token = 2;
}
```

**gRPC 사용 시점:** 내부 서비스 간 통신, 실시간 스트리밍, 양방향 통신, 저지연 요구.

### 11. GraphQL Basics

```graphql
# Schema-first 정의
type User {
  id: ID!
  name: String!
  email: String!
  orders: [Order!]!   # 연관 데이터를 한 번에 조회
}

type Order {
  id: ID!
  amount: Float!
  status: String!
}

type Query {
  user(id: ID!): User
  users(limit: Int = 20, cursor: String): UserConnection!
}

type Mutation {
  createUser(input: CreateUserInput!): User!
}
```

**GraphQL 사용 시점:** 다양한 클라이언트(웹/모바일)가 서로 다른 필드 조합을 요구할 때, Over-fetching/Under-fetching 방지.

---

## Anti-Patterns

### 1. Verb-based URLs
- `/api/getUsers`, `/api/deleteOrder/123` — HTTP 메서드로 표현해야 할 동작을 URL에 넣음
- **해결:** 리소스 명사 + HTTP 메서드 조합

### 2. Ignoring Status Codes
- 모든 응답에 200을 반환하고 body에 에러 코드를 넣음
- **해결:** HTTP 상태 코드를 의미에 맞게 사용

### 3. Breaking Changes Without Versioning
- 기존 필드 제거, 타입 변경을 버전 없이 배포하여 클라이언트 장애 유발
- **해결:** 새 버전(v2)을 만들고, 기존 버전 deprecation 기간을 공지

### 4. Offset Pagination on Large Tables
- 100만 건 테이블에서 `?page=50000` → 느린 쿼리
- **해결:** Cursor-based pagination 사용

### 5. Inconsistent Error Format
- 엔드포인트마다 에러 형식이 다름
- **해결:** RFC 7807 Problem Details로 통일

### 6. No Rate Limiting
- 악의적 또는 버그성 대량 요청이 서버를 다운시킴
- **해결:** API Gateway 또는 미들웨어에서 Rate Limiting 적용

### 7. Missing Idempotency on POST
- 네트워크 타임아웃 후 클라이언트가 재시도하면 리소스가 중복 생성됨
- **해결:** Idempotency Key 패턴 적용
