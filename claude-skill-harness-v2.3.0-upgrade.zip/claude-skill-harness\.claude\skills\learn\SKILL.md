---
name: learn
description: |
  세션에서 반복 패턴을 학습하여 instinct로 추출하고 feedback-rule로 변환하는 스킬.
  "/learn", "학습해줘", "패턴 추출해줘", "뭘 배웠어?", "instinct 보여줘" 등에서 사용한다.
  observations.jsonl을 분석하여 도구 선호, 워크플로우 패턴 등을 자동 식별한다.
---

# Learn 스킬 — 연속 학습

## 역할

세션 중 축적된 도구 사용 관찰(observations.jsonl)을 분석하여
반복 패턴을 instinct(본능)으로 추출하고, 높은 확신도의 instinct를
feedback-rules.json으로 자동 변환하여 다음 세션에 적용한다.

---

## 실행 절차

### 1. Observation 로드 + 분석

`docs/memory/observations.jsonl`에서 최근 200개를 로드한다.

```
_learning.js API 사용:
  const obs = loadObservations(200);
  const analysis = analyzeObservations(obs);
```

**분석 결과 형식:**
```
파일 유형 통계:
  .cs: 45회 (Edit: 38, Write: 7)
  .js: 23회 (Edit: 20, Write: 3)
  .md: 15회 (Write: 12, Edit: 3)

도구 선호:
  Edit: 61회 | Write: 22회

Phase 분포:
  dev: 68회 | test: 10회 | analysis: 5회
```

observation이 10개 미만이면:
"관찰 데이터가 부족합니다 ({N}개). 더 많은 작업 후 다시 시도해주세요."

### 2. Instinct 후보 추출

```
const candidates = extractInstincts(analysis);
```

3회+ 반복 패턴만 추출. 기존 instinct과 중복되면 제외.

### 3. 사용자에게 후보 표시

```
🧠 학습 결과 — {N}개 패턴 발견:

1. ".cs 파일은 주로 Edit 도구로 작업 (38회/45회)"
   - 유형: tool-preference | 확신도: 0.84
   - [저장] [스킵]

2. "dev phase에서 .js 파일을 주로 편집 (20회)"
   - 유형: workflow | 확신도: 0.74
   - [저장] [스킵]

저장할 패턴 번호를 선택하세요 (예: "1, 2" 또는 "전부"):
```

### 4. 선택된 instinct 저장

사용자가 선택한 후보를 instincts.jsonl에 저장한다.
이미 존재하는 유사 패턴이 있으면 occurrences를 증가시킨다.

```
const id = nextInstinctId();
saveInstinct({
  id,
  pattern: candidate.pattern,
  evidence: [],
  confidence: candidate.confidence,
  category: candidate.category,
  created_at: new Date().toISOString().slice(0, 10),
  last_seen: new Date().toISOString().slice(0, 10),
  occurrences: candidate.occurrences,
  scope: "project"
});
```

### 5. Feedback Rule 변환 제안

confidence > 0.8인 instinct에 대해 feedback-rule 변환을 제안한다.

```
📋 높은 확신도 instinct → feedback rule 변환 가능:

  INST-001: ".cs 파일은 주로 Edit 도구로 작업" (0.84)
  → 변환 시: dev phase에서 .cs 파일 작업 시 remind 표시

  이 규칙을 feedback-rules.json에 추가할까요? (y/n)
```

**중요 (NFR-03):** action은 반드시 `"remind"`. `"block"` 규칙은 절대 자동 생성하지 않는다.

사용자 확인 후:
```
const rule = instinctToRule(instinct);
appendFeedbackRule(rule);
```

### 6. GC 실행

```
const gc = gcObservations(1000);
if (gc.archived > 0) {
  "📦 {gc.archived}개 관찰 기록을 아카이브했습니다."
}
```

---

## Observation GC 시 확인 없이 자동 실행

GC는 사용자 확인 없이 실행한다. 아카이브된 데이터는 `docs/memory/observations-archive/` 에서 확인 가능.

---

## 기존 Instinct 조회

"/instinct 보여줘" 또는 "뭘 배웠어?" 요청 시:

```
🧠 현재 Instinct 목록:

| ID | 패턴 | 확신도 | 횟수 | 마지막 확인 |
|----|------|--------|------|-----------|
| INST-001 | .cs 파일은 주로 Edit 도구로 작업 | 0.84 | 38 | 2026-04-20 |
| INST-002 | dev phase에서 .js 파일 주 편집 | 0.74 | 20 | 2026-04-20 |

feedback-rule로 변환된: FB-AUTO-001 (INST-001 기반)
```

---

## 글로벌 승격 (/promote)

"/promote" 또는 "글로벌로 승격해줘" 요청 시:

### 승격 조건
- confidence **0.9 이상**만 승격 가능
- 사용자가 **직접 선택** (자동 승격 없음)
- 글로벌 instinct도 action은 **remind만**

### 실행 절차

1. 프로젝트 instincts에서 confidence >= 0.9인 목록 표시:
```
🌐 글로벌 승격 가능한 Instinct:

1. INST-001: ".cs 파일은 주로 Edit 도구로 작업" (0.92)
2. INST-003: "Python은 항상 pytest 사용" (0.95)

승격할 번호를 선택하세요 (모든 프로젝트에서 적용됩니다):
```

2. 사용자 선택 후:
```
_learning.js API:
  promoteToGlobal(instinct)
    → ~/.claude/global-instincts.jsonl에 저장
    → 프로젝트 instinct scope를 "global"로 갱신
```

3. 확인:
```
✅ INST-001 글로벌 승격 완료
  저장: ~/.claude/global-instincts.jsonl
  이제 모든 프로젝트에서 자동 적용됩니다.
```

### 글로벌 instinct 조회

"/글로벌 instinct" 또는 "전역 학습 보여줘" 시:
```
🌐 글로벌 Instinct (모든 프로젝트 공유):

| ID | 패턴 | 확신도 | 승격일 | 출처 프로젝트 |
|----|------|--------|--------|-------------|
| INST-001 | .cs 파일은 Edit 도구 선호 | 0.92 | 2026-04-21 | skill-set |
```

### 글로벌 저장소 위치
- `~/.claude/global-instincts.jsonl`
- session-gate.js가 프로젝트 + 글로벌 instinct을 병합하여 표시

---

## 완료 후 처리

1. session-context.md 갱신: "학습 실행: {N}개 instinct 추출, {M}개 rule 변환"
2. 사용자에게 요약:
   ```
   ✅ 학습 완료
   - 분석: {total}개 관찰
   - 추출: {N}개 instinct
   - 변환: {M}개 feedback rule
   - GC: {archived}개 아카이브
   ```

---

## process 연동

이 스킬은 Phase 독립적이다 — 어떤 Phase에서든 실행 가능.
단, complete Phase에서 실행 시 특히 유용 (사이클 전체의 학습 정리).
