---
name: blazor-patterns
description: Blazor patterns — component lifecycle, JS interop, state management, Server vs WASM, render optimization, auth
languages: ["C#"]
frameworks: ["Blazor", "Blazor Server", "Blazor WASM"]
phases: ["dev"]
---

# Blazor Patterns

## When to Activate

- Building or maintaining Blazor Server or Blazor WebAssembly applications
- Implementing component lifecycle (OnInitializedAsync, OnParametersSetAsync)
- Calling JavaScript from C# or vice versa (JS interop)
- Managing application state (cascading parameters, Fluxor)
- Choosing between Server and WASM hosting models
- Optimizing render performance
- Adding authentication/authorization to Blazor apps

---

## Core Patterns

### 1. Component Lifecycle

#### Lifecycle Method Order

1. `SetParametersAsync` — receives parameters from parent
2. `OnInitialized` / `OnInitializedAsync` — first-time initialization
3. `OnParametersSet` / `OnParametersSetAsync` — after each parameter change
4. `OnAfterRender` / `OnAfterRenderAsync` — after DOM is rendered (access JS, refs)

```razor
@page "/orders/{OrderId:int}"
@inject IOrderService OrderService
@inject ILogger<OrderDetail> Logger
@implements IAsyncDisposable

<h3>@_order?.CustomerName</h3>

@if (_loading)
{
    <LoadingSpinner />
}
else if (_order is not null)
{
    <OrderSummary Order="_order" />
}
else
{
    <Alert Type="danger">Order not found.</Alert>
}

@code {
    [Parameter]
    public int OrderId { get; set; }

    private Order? _order;
    private bool _loading = true;
    private CancellationTokenSource _cts = new();

    // Called once when component is first created
    protected override async Task OnInitializedAsync()
    {
        Logger.LogInformation("Component initialized for order {Id}", OrderId);
        await LoadOrderAsync();
    }

    // Called every time parameters change (e.g., navigating to different OrderId)
    protected override async Task OnParametersSetAsync()
    {
        // Cancel previous load if parameters changed while loading
        await _cts.CancelAsync();
        _cts = new CancellationTokenSource();
        await LoadOrderAsync();
    }

    // Called after each render
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Safe to access JS, DOM refs here
            Logger.LogDebug("First render complete");
        }
    }

    private async Task LoadOrderAsync()
    {
        _loading = true;
        try
        {
            _order = await OrderService.GetByIdAsync(OrderId, _cts.Token);
        }
        catch (OperationCanceledException)
        {
            // Navigation changed, ignore
        }
        finally
        {
            _loading = false;
        }
    }

    public async ValueTask DisposeAsync()
    {
        await _cts.CancelAsync();
        _cts.Dispose();
    }
}
```

---

### 2. JS Interop

#### Calling JavaScript from C#

```csharp
// Inject IJSRuntime
@inject IJSRuntime JS

@code {
    private ElementReference _chartContainer;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            // Call global JS function
            await JS.InvokeVoidAsync("initializeChart", _chartContainer, _chartData);

            // Call with return value
            var width = await JS.InvokeAsync<int>("getWindowWidth");

            // Call with timeout
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            await JS.InvokeVoidAsync("longRunningOperation", cts.Token);
        }
    }

    // Dispose JS resources
    public async ValueTask DisposeAsync()
    {
        await JS.InvokeVoidAsync("destroyChart", _chartContainer);
    }
}
```

#### JavaScript Module Isolation

```csharp
// Load a JS module specific to this component
private IJSObjectReference? _module;

protected override async Task OnAfterRenderAsync(bool firstRender)
{
    if (firstRender)
    {
        _module = await JS.InvokeAsync<IJSObjectReference>(
            "import", "./js/chartModule.js");
        await _module.InvokeVoidAsync("initialize", _chartContainer);
    }
}

public async ValueTask DisposeAsync()
{
    if (_module is not null)
    {
        await _module.InvokeVoidAsync("dispose");
        await _module.DisposeAsync();
    }
}
```

```javascript
// wwwroot/js/chartModule.js
export function initialize(element) {
    // Chart initialization
}

export function dispose() {
    // Cleanup
}
```

#### Calling C# from JavaScript

```csharp
// Create a reference that JS can call back into
private DotNetObjectReference<OrderDetail>? _dotNetRef;

protected override void OnInitialized()
{
    _dotNetRef = DotNetObjectReference.Create(this);
}

protected override async Task OnAfterRenderAsync(bool firstRender)
{
    if (firstRender)
    {
        await JS.InvokeVoidAsync("registerCallback", _dotNetRef);
    }
}

[JSInvokable]
public async Task OnJsEvent(string eventData)
{
    // Called from JavaScript
    _message = eventData;
    StateHasChanged(); // Trigger re-render
}

public void Dispose()
{
    _dotNetRef?.Dispose();
}
```

```javascript
// In JavaScript
function registerCallback(dotNetRef) {
    document.addEventListener('custom-event', async (e) => {
        await dotNetRef.invokeMethodAsync('OnJsEvent', e.detail);
    });
}
```

---

### 3. State Management

#### Cascading Parameters

```razor
<!-- App.razor or layout — provide state to all descendants -->
<CascadingValue Value="_currentTheme" Name="Theme">
<CascadingValue Value="_currentUser" Name="User">
    @Body
</CascadingValue>
</CascadingValue>

@code {
    private Theme _currentTheme = Theme.Default;
    private UserInfo? _currentUser;
}

<!-- Any child component — consume cascading value -->
@code {
    [CascadingParameter(Name = "Theme")]
    public Theme CurrentTheme { get; set; }

    [CascadingParameter(Name = "User")]
    public UserInfo? CurrentUser { get; set; }
}
```

#### Scoped Service for In-Memory State

```csharp
// Registered as scoped — one instance per circuit (Server) or per app (WASM)
public class AppState
{
    private readonly List<CartItem> _cartItems = new();

    public IReadOnlyList<CartItem> CartItems => _cartItems.AsReadOnly();
    public int CartCount => _cartItems.Count;

    public event Action? OnChange;

    public void AddToCart(CartItem item)
    {
        _cartItems.Add(item);
        NotifyStateChanged();
    }

    public void RemoveFromCart(int productId)
    {
        _cartItems.RemoveAll(i => i.ProductId == productId);
        NotifyStateChanged();
    }

    public void Clear()
    {
        _cartItems.Clear();
        NotifyStateChanged();
    }

    private void NotifyStateChanged() => OnChange?.Invoke();
}

// Registration
builder.Services.AddScoped<AppState>();
```

```razor
<!-- Component subscribing to state changes -->
@inject AppState State
@implements IDisposable

<span class="badge">@State.CartCount</span>

@code {
    protected override void OnInitialized()
    {
        State.OnChange += StateHasChanged;
    }

    public void Dispose()
    {
        State.OnChange -= StateHasChanged;
    }
}
```

#### Fluxor (Redux-Like State Management)

```csharp
// State — immutable record
[FeatureState]
public record CounterState
{
    public int Count { get; init; } = 0;
    public bool IsLoading { get; init; } = false;
}

// Actions
public record IncrementAction;
public record LoadCountAction;
public record LoadCountSuccessAction(int Count);

// Reducers — pure functions
public static class CounterReducers
{
    [ReducerMethod]
    public static CounterState OnIncrement(CounterState state, IncrementAction action)
        => state with { Count = state.Count + 1 };

    [ReducerMethod]
    public static CounterState OnLoadCount(CounterState state, LoadCountAction action)
        => state with { IsLoading = true };

    [ReducerMethod]
    public static CounterState OnLoadCountSuccess(
        CounterState state, LoadCountSuccessAction action)
        => state with { Count = action.Count, IsLoading = false };
}

// Effects — side effects (API calls)
public class CounterEffects
{
    private readonly ICounterApi _api;

    public CounterEffects(ICounterApi api) => _api = api;

    [EffectMethod]
    public async Task HandleLoadCount(LoadCountAction action, IDispatcher dispatcher)
    {
        var count = await _api.GetCurrentCountAsync();
        dispatcher.Dispatch(new LoadCountSuccessAction(count));
    }
}
```

```razor
<!-- Component using Fluxor -->
@inherits Fluxor.Blazor.Web.Components.FluxorComponent
@inject IState<CounterState> CounterState
@inject IDispatcher Dispatcher

<p>Count: @CounterState.Value.Count</p>

@if (CounterState.Value.IsLoading)
{
    <LoadingSpinner />
}

<button @onclick="Increment">+1</button>
<button @onclick="LoadFromServer">Refresh</button>

@code {
    private void Increment() => Dispatcher.Dispatch(new IncrementAction());
    private void LoadFromServer() => Dispatcher.Dispatch(new LoadCountAction());
}
```

---

### 4. Server vs WASM Trade-Offs

| Aspect | Blazor Server | Blazor WASM |
|--------|--------------|-------------|
| Initial load | Fast (small download) | Slow (downloads .NET runtime + DLLs) |
| Runtime | Server-side, SignalR connection | Client-side, in-browser via WebAssembly |
| Latency | Every UI event = network round-trip | No network for UI — direct in browser |
| Offline | Not possible | Possible (PWA) |
| Server resources | High (1 circuit per user) | Low (static file hosting) |
| API access | Direct (same process) | HTTP calls required |
| Scalability | Limited by server connections | Scales with CDN |
| Security | Code stays on server | Code downloadable by client |
| Debugging | Standard .NET debugging | Browser DevTools + limited debugging |

#### When to Choose Server

- Internal line-of-business apps with low user count
- Sensitive business logic that must stay on the server
- Fast initial load is critical
- Real-time data with direct database access

#### When to Choose WASM

- Public-facing apps with many concurrent users
- Offline/PWA requirements
- Rich client-side interactivity with minimal latency
- Can serve from a CDN (no active server per user)

#### .NET 8 Hybrid (Auto Mode)

```csharp
// Program.cs — .NET 8 Auto render mode
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddInteractiveWebAssemblyComponents();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddInteractiveWebAssemblyRenderMode();
```

```razor
<!-- Component chooses render mode -->
@rendermode InteractiveAuto  <!-- Server first, switches to WASM when ready -->
@rendermode InteractiveServer
@rendermode InteractiveWebAssembly
```

---

### 5. Render Optimization

#### ShouldRender

```csharp
@code {
    private int _previousCount;

    // Prevent unnecessary re-renders
    protected override bool ShouldRender()
    {
        if (_count == _previousCount) return false;
        _previousCount = _count;
        return true;
    }
}
```

#### @key for List Rendering

```razor
<!-- Without @key — Blazor reuses DOM elements by index (wrong updates) -->
<ul>
    @foreach (var item in _items)
    {
        <li>@item.Name</li>  <!-- Inserting at start shifts all elements -->
    }
</ul>

<!-- With @key — Blazor tracks elements by identity (correct updates) -->
<ul>
    @foreach (var item in _items)
    {
        <li @key="item.Id">@item.Name</li>  <!-- Only changed elements update -->
    }
</ul>
```

#### Virtualization for Large Lists

```razor
<!-- Only renders visible items — essential for large datasets -->
<Virtualize Items="_allOrders" Context="order" ItemSize="50">
    <ItemContent>
        <OrderRow Order="order" />
    </ItemContent>
    <Placeholder>
        <LoadingRow />
    </Placeholder>
</Virtualize>

<!-- With async item provider for server-side paging -->
<Virtualize ItemsProvider="LoadOrders" Context="order" ItemSize="50">
    <OrderRow Order="order" />
</Virtualize>

@code {
    private async ValueTask<ItemsProviderResult<Order>> LoadOrders(
        ItemsProviderRequest request)
    {
        var result = await OrderService.GetPagedAsync(
            request.StartIndex, request.Count, request.CancellationToken);

        return new ItemsProviderResult<Order>(result.Items, result.TotalCount);
    }
}
```

#### Minimize StateHasChanged Calls

```csharp
// BAD — triggers render for every item in loop
foreach (var item in items)
{
    ProcessItem(item);
    StateHasChanged();  // N renders!
}

// GOOD — single render after all updates
foreach (var item in items)
{
    ProcessItem(item);
}
StateHasChanged();  // 1 render
```

---

### 6. Authentication and Authorization in Blazor

#### Setup

```csharp
// Program.cs
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();
builder.Services.AddAuthorizationCore();
```

#### Custom AuthenticationStateProvider

```csharp
public class CustomAuthStateProvider : AuthenticationStateProvider
{
    private readonly ITokenService _tokenService;
    private readonly HttpClient _httpClient;

    public CustomAuthStateProvider(ITokenService tokenService, HttpClient httpClient)
    {
        _tokenService = tokenService;
        _httpClient = httpClient;
    }

    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        var token = await _tokenService.GetTokenAsync();

        if (string.IsNullOrEmpty(token))
            return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));

        var claims = ParseClaimsFromJwt(token);
        var identity = new ClaimsIdentity(claims, "jwt");
        var user = new ClaimsPrincipal(identity);

        _httpClient.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);

        return new AuthenticationState(user);
    }

    public void NotifyAuthStateChanged()
    {
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }

    private IEnumerable<Claim> ParseClaimsFromJwt(string jwt)
    {
        var payload = jwt.Split('.')[1];
        var jsonBytes = Convert.FromBase64String(PadBase64(payload));
        var kvp = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonBytes);
        return kvp.Select(kv => new Claim(kv.Key, kv.Value.ToString()));
    }
}
```

#### Protecting Components

```razor
<!-- Require authentication -->
<AuthorizeView>
    <Authorized>
        <p>Welcome, @context.User.Identity?.Name!</p>
        <NavLink href="/dashboard">Dashboard</NavLink>
    </Authorized>
    <NotAuthorized>
        <p>Please <a href="/login">log in</a>.</p>
    </NotAuthorized>
    <Authorizing>
        <LoadingSpinner />
    </Authorizing>
</AuthorizeView>

<!-- Role-based -->
<AuthorizeView Roles="Admin,Manager">
    <button @onclick="DeleteOrder">Delete</button>
</AuthorizeView>

<!-- Policy-based -->
<AuthorizeView Policy="CanManageOrders">
    <OrderManagementPanel />
</AuthorizeView>

<!-- Protect entire page -->
@page "/admin"
@attribute [Authorize(Roles = "Admin")]
```

---

## Anti-Patterns

### Lifecycle

- Calling `StateHasChanged()` in `OnInitializedAsync` — already called automatically after
- Doing async work in `OnInitialized` (sync version) — use `OnInitializedAsync` instead
- Not disposing `CancellationTokenSource` or event subscriptions — memory leaks
- Accessing `ElementReference` in `OnInitializedAsync` — DOM not rendered yet, use `OnAfterRenderAsync`

### JS Interop

- Calling JS interop in `OnInitializedAsync` — use `OnAfterRenderAsync(firstRender: true)`
- Not disposing `IJSObjectReference` or `DotNetObjectReference` — memory leaks
- Blocking on JS interop with `.Result` in Blazor Server — deadlocks the circuit

### State

- Using static fields for per-user state in Blazor Server — shared across all users
- Not unsubscribing from `AppState.OnChange` — components re-render after disposal
- Storing sensitive data in WASM local storage — accessible to any JS on the page

### Performance

- Rendering large lists without `<Virtualize>` — renders thousands of DOM elements
- Not using `@key` in dynamic lists — incorrect element reuse on insert/remove
- Triggering `StateHasChanged()` on every keystroke without debouncing
- Using `InteractiveServer` for components that do not need interactivity — wastes circuits
