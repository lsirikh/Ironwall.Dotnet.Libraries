# Java Naming Conventions

## Must Always
- Use PascalCase for classes, interfaces, enums, records, annotations
- Use camelCase for methods, variables, parameters
- Use SCREAMING_SNAKE_CASE for constants (`static final`)
- Package names: all lowercase, reverse domain: `com.example.project.service`
- Boolean methods: `is`, `has`, `can` prefix: `isActive()`, `hasPermission()`
- Interface naming: behavior-based like `Serializable`, `Comparable` (no `I` prefix)
- Generic type parameters: `T` (type), `E` (element), `K`/`V` (key/value), `R` (return)
- Test classes: `XxxTest` (unit), `XxxIT` (integration)
- Factory methods: `of()`, `from()`, `valueOf()`, `getInstance()`

## Must Never
- Use Hungarian notation (`strName`, `iCount`)
- Start with underscore or dollar sign
- Use abbreviations unless universally known (use `customer` not `cust`)
