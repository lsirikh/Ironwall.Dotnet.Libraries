---
name: nextjs-patterns
description: Next.js App Router patterns — RSC, data fetching, routing, middleware, metadata, and optimization
languages: ["TypeScript", "JavaScript"]
frameworks: ["Next.js", "React"]
phases: ["dev", "test"]
---

# Next.js Patterns

## When to Activate

- Project uses Next.js 13+ with App Router (`app/` directory)
- Building pages, layouts, or API route handlers
- Configuring middleware, metadata, or image/font optimization
- Deciding between Server Components and Client Components
- Implementing data fetching with caching or revalidation

---

## Core Patterns

### 1. App Router Directory Structure

The `app/` directory uses file-system conventions for routing and UI composition.

```
app/
├── layout.tsx          # Root layout (wraps all pages)
├── page.tsx            # Home route "/"
├── loading.tsx         # Suspense fallback for this segment
├── error.tsx           # Error boundary for this segment
├── not-found.tsx       # 404 UI
├── global-error.tsx    # Root-level error boundary
├── dashboard/
│   ├── layout.tsx      # Nested layout for /dashboard/*
│   ├── page.tsx        # /dashboard
│   └── settings/
│       └── page.tsx    # /dashboard/settings
└── api/
    └── users/
        └── route.ts    # Route handler: /api/users
```

**layout.tsx** — Shared UI that preserves state across navigations:

```tsx
// app/layout.tsx
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "My App",
  description: "Built with Next.js",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
```

**loading.tsx** — Instant loading state via React Suspense:

```tsx
// app/dashboard/loading.tsx
export default function Loading() {
  return <div className="animate-pulse">Loading dashboard...</div>;
}
```

**error.tsx** — Must be a Client Component:

```tsx
// app/dashboard/error.tsx
"use client";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div>
      <h2>Something went wrong</h2>
      <button onClick={() => reset()}>Try again</button>
    </div>
  );
}
```

### 2. React Server Components vs Client Components

By default, components in `app/` are **Server Components**.

| Aspect | Server Component | Client Component |
|--------|-----------------|-----------------|
| Directive | None (default) | `"use client"` at top |
| Runs on | Server only | Server (SSR) + Client |
| Can use | `async/await`, DB, fs | `useState`, `useEffect`, event handlers |
| Bundle | Not in JS bundle | Included in JS bundle |

```tsx
// Server Component (default) — can be async, access DB directly
// app/users/page.tsx
import { db } from "@/lib/db";

export default async function UsersPage() {
  const users = await db.user.findMany();
  return (
    <ul>
      {users.map((u) => (
        <li key={u.id}>{u.name}</li>
      ))}
    </ul>
  );
}
```

```tsx
// Client Component — interactive UI
// app/users/search-bar.tsx
"use client";

import { useState } from "react";

export function SearchBar({ onSearch }: { onSearch: (q: string) => void }) {
  const [query, setQuery] = useState("");

  return (
    <input
      value={query}
      onChange={(e) => setQuery(e.target.value)}
      onKeyDown={(e) => e.key === "Enter" && onSearch(query)}
      placeholder="Search users..."
    />
  );
}
```

**Rule of thumb:** Keep components on the server by default. Push `"use client"` to the leaves — wrap only the interactive parts.

### 3. Data Fetching

**fetch with caching and revalidation:**

```tsx
// Cache indefinitely (default in Next.js)
const data = await fetch("https://api.example.com/posts", {
  cache: "force-cache",
});

// Revalidate every 60 seconds (ISR)
const data = await fetch("https://api.example.com/posts", {
  next: { revalidate: 60 },
});

// No cache — always fresh
const data = await fetch("https://api.example.com/posts", {
  cache: "no-store",
});
```

**Server Actions** — mutate data from Client Components without API routes:

```tsx
// app/actions.ts
"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";

export async function createPost(formData: FormData) {
  const title = formData.get("title") as string;
  await db.post.create({ data: { title } });
  revalidatePath("/posts");
}
```

```tsx
// app/posts/new-post-form.tsx
"use client";

import { createPost } from "@/app/actions";

export function NewPostForm() {
  return (
    <form action={createPost}>
      <input name="title" required />
      <button type="submit">Create</button>
    </form>
  );
}
```

### 4. Route Handlers

```tsx
// app/api/users/route.ts
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const page = searchParams.get("page") ?? "1";

  const users = await fetchUsers(Number(page));
  return NextResponse.json(users);
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const user = await createUser(body);
  return NextResponse.json(user, { status: 201 });
}
```

### 5. Middleware

```tsx
// middleware.ts (project root)
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const token = request.cookies.get("session")?.value;

  if (!token && request.nextUrl.pathname.startsWith("/dashboard")) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/api/protected/:path*"],
};
```

### 6. Dynamic Routes

```
app/blog/[slug]/page.tsx        → /blog/hello-world
app/docs/[...slug]/page.tsx     → /docs/a/b/c (catch-all, required)
app/shop/[[...slug]]/page.tsx   → /shop OR /shop/a/b (optional catch-all)
```

```tsx
// app/blog/[slug]/page.tsx
type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const posts = await fetchPosts();
  return posts.map((post) => ({ slug: post.slug }));
}

export default async function BlogPost({ params }: Props) {
  const { slug } = await params;
  const post = await fetchPost(slug);
  return <article>{post.content}</article>;
}
```

### 7. Metadata API

```tsx
// Static metadata
export const metadata: Metadata = {
  title: "Blog",
  openGraph: { title: "Blog", description: "Read our latest posts" },
};

// Dynamic metadata
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await fetchPost(slug);
  return {
    title: post.title,
    description: post.excerpt,
  };
}
```

### 8. Image and Font Optimization

```tsx
// next/image — automatic optimization, lazy loading, sizing
import Image from "next/image";

export function Avatar({ src, name }: { src: string; name: string }) {
  return (
    <Image
      src={src}
      alt={name}
      width={64}
      height={64}
      className="rounded-full"
      priority={false}  // true for above-the-fold images
    />
  );
}
```

```tsx
// next/font — zero layout shift, self-hosted
import { Inter, Roboto_Mono } from "next/font/google";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const robotoMono = Roboto_Mono({
  subsets: ["latin"],
  variable: "--font-roboto-mono",
});

// Use in layout
<body className={`${inter.variable} ${robotoMono.variable}`}>
```

---

## Anti-Patterns

1. **Marking everything `"use client"`** — defeats the purpose of RSC. Only wrap interactive leaves, not entire page trees.

2. **Fetching in Client Components when server fetch suffices** — causes waterfalls and exposes API keys. Fetch on the server, pass as props.

3. **Using `useEffect` for initial data** — in App Router, prefer `async` Server Components or Server Actions instead of `useEffect` + `useState` fetch patterns.

4. **Ignoring `loading.tsx` / `error.tsx`** — these are free Suspense/Error boundaries. Without them, the whole page blocks or crashes.

5. **Putting middleware logic in layouts** — middleware runs on the Edge before rendering. Auth redirects belong there, not in `layout.tsx`.

6. **Using `next/image` without `width`/`height` or `fill`** — causes layout shift. Always provide dimensions or use `fill` with a sized container.

7. **Not using `generateStaticParams`** for known dynamic routes — missing out on static generation at build time.

8. **Importing server-only code in Client Components** — use the `server-only` package to get a build-time error if a server module is accidentally imported client-side:
   ```bash
   npm install server-only
   ```
   ```tsx
   // lib/db.ts
   import "server-only";
   export const db = /* ... */;
   ```
