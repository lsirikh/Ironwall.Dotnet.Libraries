// .claude/hooks/pre-tool-gate.js
// PreToolUse command Hook — Phase별 소스 코드 쓰기 하드 차단
// matcher: Write|Edit|Bash
//
// 동작 원리:
//   stdout에 {"decision":"block","reason":"..."} 출력 → 해당 툴 실행 취소
//   아무것도 출력하지 않고 exit(0) → 허용

const fs = require('fs');
const path = require('path');

// IMPL-10 (FR-10): Hook 실행 시간 자동 측정
const _hookStart = Date.now();
process.on('exit', () => {
  const elapsed = Date.now() - _hookStart;
  if (elapsed > 100) {
    try {
      const al = path.join(path.resolve(__dirname, '..', '..'), 'docs', 'memory', 'audit-log.jsonl');
      fs.appendFileSync(al, JSON.stringify({
        timestamp: new Date().toISOString(),
        event: 'hook-perf',
        hook: 'pre-tool-gate.js',
        elapsed_ms: elapsed
      }) + '\n');
    } catch { /* silent */ }
  }
});

// _common.js 점진적 마이그레이션 — v1.1에서 dead code 제거
// (require해놓고 미사용이라 C-2 fix로 제거. 실제 마이그레이션은 다음 사이클)

// ── 프로젝트 루트 추정 ────────────────────────────────────────────────
// Hook은 프로젝트 루트에서 실행됨 (Claude Code가 보장)
const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const STATE_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');

// ── 환경변수에서 툴 정보 추출 ──────────────────────────────────────────
const TOOL_NAME = process.env.CLAUDE_TOOL_NAME || '';
let TOOL_INPUT = {};
try {
  TOOL_INPUT = JSON.parse(process.env.CLAUDE_TOOL_INPUT || '{}');
} catch (parseErr) {
  // 파싱 실패 시 빈 객체로 폴백 — allow() 호출하지 않고 검증 계속 진행
  TOOL_INPUT = {};
  try {
    const al = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');
    fs.appendFileSync(al, JSON.stringify({
      timestamp: new Date().toISOString(),
      event: 'tool-input-parse-error',
      hook: 'pre-tool-gate.js',
      error: parseErr.message
    }) + '\n');
  } catch { /* silent */ }
}

// ── MCP 도구 → Write/Edit 정규화 ──────────────────────────────────────
// MCP filesystem 도구를 기존 Write/Edit 게이트로 라우팅
const MCP_WRITE_TOOLS = ['mcp__filesystem__write_file', 'mcp__filesystem__edit_file', 'mcp__filesystem__move_file'];
let EFFECTIVE_TOOL = TOOL_NAME;
if (MCP_WRITE_TOOLS.includes(TOOL_NAME)) {
  EFFECTIVE_TOOL = 'Write'; // MCP 쓰기 도구를 Write로 취급
  // MCP 도구는 path 필드를 사용 (file_path가 아님)
  if (!TOOL_INPUT.file_path && TOOL_INPUT.path) {
    TOOL_INPUT.file_path = TOOL_INPUT.path;
  }
}

// ── 헬퍼 함수 ──────────────────────────────────────────────────────────
function block(reason) {
  console.log(JSON.stringify({ decision: 'block', reason }));
  process.exit(0);
}

function allow() {
  process.exit(0);
}

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) {
      // pipeline-state.json이 없으면 자동 생성 (setup Phase = src 차단)
      // 이전 버전은 'dev'로 폴백하여 모든 쓰기를 허용했으나
      // 이는 프로세스 우회의 근본 원인이었음
      try {
        const memDir = path.join(PROJECT_ROOT, 'docs', 'memory');
        if (!fs.existsSync(memDir)) {
          fs.mkdirSync(memDir, { recursive: true });
        }
        const initState = {
          phase: 'setup',
          track: null,
          activePrd: null,
          activePlan: null,
          artifacts: {},
          updated_at: new Date().toISOString()
        };
        fs.writeFileSync(STATE_FILE, JSON.stringify(initState, null, 2) + '\n');
      } catch { /* 생성 실패해도 setup 폴백 */ }
      return { phase: 'setup', track: 'C' };
    }
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (!parsed.phase) return { phase: 'setup', track: 'C' };
    // 하위 호환: track 미설정 시 가장 엄격한 C로 폴백
    if (!parsed.track) parsed.track = 'C';
    return parsed;
  } catch {
    // [RISK-01] 파일 파손/읽기 실패 → setup으로 폴백 (src 보호)
    return { phase: 'setup', track: 'C' };
  }
}

// dev-journal.md 엔트리 존재 확인 (Track B용)
function hasDevJournalEntry() {
  const journalFile = path.join(PROJECT_ROOT, 'docs', 'memory', 'dev-journal.md');
  if (!fs.existsSync(journalFile)) return false;
  try {
    const content = fs.readFileSync(journalFile, 'utf8');
    return /^### \[\d{4}-\d{2}-\d{2}/m.test(content);
  } catch {
    return false;
  }
}

// ── 메인 로직 (전체 try-catch 래핑 — RISK-01 폴백) ──────────────────
try {
  const state = loadState();
  const phase = state.phase;
  const track = state.track || 'C'; // 미설정 시 가장 엄격한 C 폴백

  // ── Write / Edit 차단 규칙 ──────────────────────────────────────────
  if (['Write', 'Edit', 'MultiEdit'].includes(EFFECTIVE_TOOL)) {
    const rawPath = (TOOL_INPUT.file_path || TOOL_INPUT.path || '').replace(/\\/g, '/');
    // 경로 정규화: 정규식 매칭 일관성을 위해 항상 앞에 /를 붙인다
    // (post-write-sync.js와 동일한 패턴)
    const filePath = rawPath.startsWith('/') || /^[A-Za-z]:/.test(rawPath)
      ? rawPath
      : '/' + rawPath;

    // [IMPL-07] pipeline-state.json 직접 편집 차단 (always-allow보다 우선)
    if (/\/docs\/memory\/pipeline-state\.json$/i.test(filePath)) {
      block(
        '[CRITICAL] pipeline-state.json 직접 수정 금지\n' +
        '대신 사용:\n' +
        '  Phase 전환: node .claude/hooks/advance-phase.js <phase>\n' +
        '  Track 설정: node .claude/hooks/advance-phase.js set-track <A|B|C>\n' +
        '이 파일은 advance-phase.js와 post-write-sync.js만 수정할 수 있습니다.'
      );
    }

    // [IMPL-02 / FR-04] Claude PRD 자동 승인 차단 (RISK-01 예외 처리 포함)
    // 기존 PRD를 Approved로 변경 시도 → 차단
    // 신규 PRD + Draft 작성은 허용 (예외)
    if (/\/docs\/prds\/.*-prd\.md$/i.test(filePath)) {
      // content 추출 (Write의 content / Edit의 new_string)
      const content = TOOL_INPUT.content || TOOL_INPUT.new_string || '';
      const hasApprovedPattern = /^- \*\*상태\*\*:\s*(Approved|Completed)/im.test(content);

      if (hasApprovedPattern) {
        // 기존 파일 여부 확인
        const absPath = filePath.startsWith('/') && !/^[A-Za-z]:/.test(filePath)
          ? path.join(PROJECT_ROOT, filePath.substring(1))
          : (/^[A-Za-z]:/.test(filePath) ? filePath : path.join(PROJECT_ROOT, filePath));
        const normalized = absPath.replace(/\//g, path.sep);
        const isExisting = fs.existsSync(normalized);

        // 기존 파일이거나, 신규지만 Draft가 없으면 차단
        // (신규 + Draft 동시에 있으면 작성 중인 PRD이므로 허용)
        const hasDraft = /^- \*\*상태\*\*:\s*Draft/im.test(content);
        if (isExisting || !hasDraft) {
          block(
            '[CRITICAL] PRD 자동 승인 차단\n' +
            'Claude는 PRD를 직접 Approved/Completed로 변경할 수 없습니다.\n' +
            '사용자 검토 후 다음 명령으로 승인:\n' +
            '  node .claude/hooks/advance-phase.js approve prd "코멘트"\n' +
            '\n' +
            '예외: 신규 PRD 파일 + Draft 작성은 허용됨'
          );
        }
        // 신규 + Draft 둘 다 있으면 통과 (예외)
      }
    }

    // [IMPL-11] Track C에서 PRD 신규 파일 생성 시 analysis 부재 경고
    if (/\/docs\/prds\/.+\.md$/i.test(filePath) && track === 'C') {
      try {
        // 신규 파일 여부 확인
        const absPath = filePath.startsWith('/') || /^[A-Za-z]:/.test(filePath)
          ? filePath
          : path.join(PROJECT_ROOT, filePath);
        const normalized = absPath.replace(/\//g, path.sep);
        const isNewFile = !fs.existsSync(normalized);

        if (isNewFile) {
          const analysisDir = path.join(PROJECT_ROOT, 'docs', 'analysis');
          let hasAnalysis = false;
          if (fs.existsSync(analysisDir)) {
            hasAnalysis = fs.readdirSync(analysisDir).some(f => f.endsWith('.md'));
          }
          if (!hasAnalysis) {
            console.error(
              '[WARN] Track C에서 분석 파일 없이 PRD 작성 중\n' +
              '권장: analysis 스킬로 docs/analysis/{topic}-analysis.md 먼저 작성\n' +
              '(차단되지 않음, 진행은 가능)'
            );
          }
        }
      } catch { /* 경고만, 차단 아님 */ }
    }

    // docs/, .claude/, config/, docker/, tests/, 설정 파일 → 항상 허용
    const alwaysAllowPatterns = [
      /\/docs\//i,
      /\/\.claude\//i,
      /\/config\//i,
      /\/docker\//i,
      /\/tests\//i,
      /\/alembic\//i,
      /CLAUDE\.md$/i,
      /README\.md$/i,
      /CHANGELOG\.md$/i,
      /\.gitignore$/i,
      /\.env/i,
      /pyproject\.toml$/i,
      /package\.json$/i,
    ];

    if (alwaysAllowPatterns.some(p => p.test(filePath))) {
      allow();
    }

    // src/ 하위 소스 파일 판별
    const isSrcFile = /\/src\//i.test(filePath) ||
                      /\.(py|js|ts|jsx|tsx|cs|cpp|java|go|rs)$/i.test(filePath);

    if (isSrcFile) {
      // setup / analysis / prd / plan 단계에서는 src 쓰기 완전 차단
      const blockedPhases = ['setup', 'analysis', 'prd', 'plan', 'complete'];
      if (blockedPhases.includes(phase)) {
        const phaseMessages = {
          setup: 'CLAUDE.md 프로젝트 설정이 완료되지 않음',
          analysis: 'analysis 단계 진행 중 — 코드 분석이 먼저 필요',
          prd: 'PRD가 Approved 상태가 아님',
          plan: 'Plan 파일이 없거나 태스크가 비어 있음',
        };
        block(
          `[HARD GATE] 소스 코드 작성 차단\n` +
          `현재 phase: ${phase}, track: ${track}\n` +
          `이유: ${phaseMessages[phase]}\n` +
          `해결: 먼저 해당 단계 산출물을 완성하세요.\n` +
          `Phase 전환: node .claude/hooks/advance-phase.js dev`
        );
      }

      // [IMPL-09] dev 단계 Track별 이중 검증
      if (phase === 'dev') {
        // Track A: dev 자체가 허용 경로 외 → 차단
        if (track === 'A') {
          block(
            '[HARD GATE] Track A는 코드 수정을 허용하지 않습니다.\n' +
            'Track 변경: node .claude/hooks/advance-phase.js set-track B (간단작업)\n' +
            '         또는 set-track C (복합작업)'
          );
        }

        // Track B: dev-journal 엔트리 필수
        if (track === 'B') {
          if (!hasDevJournalEntry()) {
            block(
              '[HARD GATE] Track B dev 진입 차단\n' +
              '이유: docs/memory/dev-journal.md 에 작업 엔트리가 없음\n' +
              '해결: dev-journal에 다음 형식으로 엔트리 추가:\n' +
              '  ### [YYYY-MM-DD HH:mm] 작업 제목\n' +
              '  - **Track**: B\n' +
              '  - **대상**: src/...\n' +
              '  - **이유**: ...\n' +
              '  - **영향**: ...'
            );
          }
        }

        // Track C: PRD Approved + Plan 이중 검증
        if (track === 'C') {
          // PRD Approved 검증
          let hasApprovedPrd = false;
          try {
            const prdsDir = path.join(PROJECT_ROOT, 'docs', 'prds');
            if (fs.existsSync(prdsDir)) {
              const prds = fs.readdirSync(prdsDir).filter(f => f.endsWith('.md'));
              for (const prd of prds) {
                const c = fs.readFileSync(path.join(prdsDir, prd), 'utf8');
                if (/^- \*\*상태\*\*:\s*Approved/im.test(c)) {
                  hasApprovedPrd = true;
                  break;
                }
              }
            }
          } catch {
            // [IMPL-10] 안전 방향 폴백 — 검증 실패 시 차단
            block(
              '[HARD GATE] Track C dev 진입 차단 (PRD 검증 실패)\n' +
              '이유: docs/prds/ 읽기 실패. 안전 방향 폴백 작동.'
            );
          }
          if (!hasApprovedPrd) {
            block(
              '[HARD GATE] Track C dev 진입 차단\n' +
              '이유: Approved 상태인 PRD가 없음\n' +
              '해결: docs/prds/{topic}-prd.md 의 상태를 Approved로 변경'
            );
          }

          // Plan 파일 + 태스크 검증
          try {
            const plansDir = path.join(PROJECT_ROOT, 'docs', 'plans');
            if (!fs.existsSync(plansDir)) {
              block('[HARD GATE] Track C dev 진입 차단: docs/plans/ 디렉토리 없음');
            }
            const planFiles = fs.readdirSync(plansDir).filter(f => f.endsWith('.md'));
            if (planFiles.length === 0) {
              block(
                '[HARD GATE] Track C dev 진입 차단\n' +
                '이유: docs/plans/ 에 Plan 파일이 없음\n' +
                '해결: plan 스킬로 구현 계획 작성'
              );
            }
            // [ ] 태스크 존재 확인
            let hasUnchecked = false;
            for (const plan of planFiles) {
              const c = fs.readFileSync(path.join(plansDir, plan), 'utf8');
              if (/\[ \]|\[~\]/.test(c)) {
                hasUnchecked = true;
                break;
              }
            }
            if (!hasUnchecked) {
              block(
                '[HARD GATE] Plan에 미완료 태스크가 없음\n' +
                '해결: test 단계로 이동 또는 새 태스크 추가'
              );
            }
          } catch (planErr) {
            // [IMPL-10] 안전 방향 폴백 — 검증 실패 시 차단
            block(
              '[HARD GATE] Track C dev 진입 차단 (Plan 검증 실패)\n' +
              `이유: ${planErr.message || 'Plan 디렉토리 읽기 실패'}\n` +
              '안전 방향 폴백 작동.'
            );
          }
        }
      }
    }

    // 여기까지 도달하면 허용
    allow();
  }

  // ── Bash 차단 규칙 ──────────────────────────────────────────────────
  if (TOOL_NAME === 'Bash') {
    const cmd = TOOL_INPUT.command || '';

    // 위험 명령어 항상 차단
    if (/rm\s+-rf\s+\/|rm\s+-rf\s+\.\s*$|format\s+[a-z]:/i.test(cmd)) {
      block('[SAFETY] 위험한 삭제 명령 차단: ' + cmd.substring(0, 80));
    }

    // [IMPL-03 / FR-04, FR-05] Bash로 approve prd 명령 호출 차단
    // 마커 파일 존재 시 — Claude의 자동 승인 우회 방지
    if (/advance-phase\.js\s+approve\s+prd/.test(cmd)) {
      const markerFile = path.join(PROJECT_ROOT, '.claude', '.pending-prd-review');
      if (fs.existsSync(markerFile)) {
        let marker = {};
        try { marker = JSON.parse(fs.readFileSync(markerFile, 'utf8')); } catch {}
        block(
          '[CRITICAL] PRD 검토 대기 중 — approve 명령 차단\n' +
          '\n' +
          '검토 대기 PRD: ' + (marker.prd || '(unknown)') + '\n' +
          '버전: ' + (marker.version || '?') + '\n' +
          '생성 시각: ' + (marker.created_at || '?') + '\n' +
          '\n' +
          'Claude는 PRD 작성 직후 같은 응답에서 approve를 호출할 수 없습니다.\n' +
          '사용자가 다음 메시지에서 명시 승인 키워드를 입력해야 마커가 해제됩니다.\n' +
          '응답을 마무리하고 사용자 검토를 기다리세요.'
        );
      }
    }

    // [IMPL-08 + RISK-02] non-dev Phase에서 src/ 쓰기 조작 차단
    // 읽기 전용 명령(cat, grep, head, tail, ls, find, file, wc, rg)은 항상 허용
    const nonDevPhases = ['setup', 'analysis', 'prd', 'plan', 'complete'];
    if (nonDevPhases.includes(phase)) {
      // 패턴 1: sed -i, awk -i (in-place 수정)
      const inplaceEdit = /(?:sed|awk|perl)\s+(?:-[a-z]*i[a-z]*\b|--in-place\b)[^|;&\n]*\bsrc\//i;

      // 패턴 2: 리다이렉션으로 src/ 파일 쓰기 (>, >>)
      // echo/cat/printf/tee 등 다양한 출력 명령
      const redirectWrite = /(?:^|\||;|&&)\s*(?:echo|printf|cat|tee|jq|yq|curl|wget)[^|;&\n]*[>]+\s*[^|;&\n]*\bsrc\//i;

      // 패턴 3: cp/mv가 src/로 향함 (대상이 src/)
      const cpMvIntoSrc = /\b(?:cp|mv|install)\s+[^|;&\n]*\bsrc\/[^|;&\n]*$/im;

      // 패턴 4: 컴파일러/빌드 도구
      const compileBuild = /\b(?:gcc|g\+\+|clang|clang\+\+|rustc|cargo\s+build|javac|csc|tsc|dotnet\s+build|go\s+build|swiftc)\b/i;

      if (inplaceEdit.test(cmd)) {
        block(
          `[HARD GATE] ${phase} 단계에서 sed/awk/perl로 src/ 수정 차단\n` +
          `이유: Write/Edit 차단을 우회하여 소스 코드를 수정하려고 했습니다.\n` +
          `해결: Phase를 dev로 전환 후 Write/Edit 툴 사용\n` +
          `Phase 전환: node .claude/hooks/advance-phase.js dev`
        );
      }
      if (redirectWrite.test(cmd)) {
        block(
          `[HARD GATE] ${phase} 단계에서 리다이렉션으로 src/ 파일 쓰기 차단\n` +
          `이유: Write/Edit 차단을 우회하여 소스 코드를 작성하려고 했습니다.\n` +
          `해결: Phase를 dev로 전환 후 Write 툴 사용`
        );
      }
      if (cpMvIntoSrc.test(cmd)) {
        block(
          `[HARD GATE] ${phase} 단계에서 src/ 로 파일 복사/이동 차단\n` +
          `이유: 소스 코드 구조 변경은 dev 단계에서만 허용됩니다.\n` +
          `해결: Phase를 dev로 전환`
        );
      }
      if (compileBuild.test(cmd)) {
        block(
          `[HARD GATE] ${phase} 단계에서 컴파일/빌드 차단\n` +
          `이유: 구현되지 않은 코드를 컴파일할 수 없습니다.\n` +
          `해결: Phase를 dev로 전환 후 빌드`
        );
      }
    }

    // prd/plan 단계에서 빌드/실행 차단 (분석/조회 명령은 허용)
    if (['prd', 'plan'].includes(phase)) {
      const execPatterns = /(?:python|python3)\s+(?!-c\s+(?:import|print|sys))[\w\/\\]+\.py|pytest|jest|npm\s+(?:start|run\s+dev)|dotnet\s+run|uvicorn|gunicorn/;
      if (execPatterns.test(cmd)) {
        block(
          `[HARD GATE] ${phase} 단계에서 코드 실행 차단\n` +
          `이유: 구현도 안 된 코드를 실행할 수 없음\n` +
          `해결: Phase를 dev로 전환 후 실행 가능\n` +
          `Phase 전환: node .claude/hooks/advance-phase.js dev`
        );
      }
    }

    allow();
  }

  // 기타 툴은 허용
  allow();

} catch (err) {
  // [RISK-01] 최상위 폴백 — 안전 방향(차단)으로 처리
  // 에러로 게이트 우회 방지: 감사 로그 기록 후 block
  try {
    const al = path.join(path.resolve(__dirname, '..', '..'), 'docs', 'memory', 'audit-log.jsonl');
    fs.appendFileSync(al, JSON.stringify({
      timestamp: new Date().toISOString(),
      event: 'hook-crash',
      hook: 'pre-tool-gate.js',
      error: err.message,
      stack: (err.stack || '').substring(0, 300)
    }) + '\n');
  } catch { /* silent */ }
  block('[SAFETY] pre-tool-gate 내부 오류 — 안전 방향으로 차단. 오류: ' + err.message);
}
