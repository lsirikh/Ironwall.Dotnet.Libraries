# C# Naming Conventions

> Always-on naming rules for C# codebases.
> Follows Microsoft .NET naming guidelines with project-specific refinements.

---

## Casing Rules

### PascalCase
- Classes: `UserService`, `OrderProcessor`
- Methods: `GetUserById`, `CalculateTotal`
- Properties: `FirstName`, `IsActive`
- Public fields: `MaxRetryCount`
- Enums and enum values: `OrderStatus.Pending`
- Interfaces: `IRepository`, `IUserService` (always I-prefix)
- Namespaces: `Company.Project.Module`
- Events: `OnItemAdded`, `DataReceived`
- Delegates: `EventHandler`, `Func`, `Action`

### camelCase
- Parameters: `userId`, `orderCount`
- Local variables: `totalPrice`, `isValid`
- Private fields with underscore prefix: `_logger`, `_connectionString`

### UPPER_CASE
- Constants only: `MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`

---

## Must Always

### Naming Patterns
- Suffix async methods with `Async`: `GetDataAsync`, `SaveChangesAsync`
- Prefix interfaces with `I`: `IRepository`, `IService`, `IDisposable`
- Prefix boolean properties/variables with `Is`, `Has`, `Can`, `Should`: `IsEnabled`, `HasAccess`
- Use noun or noun-phrase for classes: `CustomerRepository`, `PaymentGateway`
- Use verb or verb-phrase for methods: `SendEmail`, `ValidateInput`
- Name generic type parameters with `T` prefix: `T`, `TKey`, `TValue`, `TEntity`

### File Organization
- One primary type per file
- File name matches type name: `UserService.cs` for class `UserService`
- Namespace matches folder structure

### Clarity
- Use meaningful, self-documenting names
- Prefer full words over abbreviations: `customer` not `cust`, `repository` not `repo`
- Use domain-specific terminology consistently

---

## Must Never

- Use Hungarian notation: ~~`strName`~~, ~~`intCount`~~, ~~`lstItems`~~
- Use abbreviations unless universally known (`Id`, `Url`, `Http` are OK)
- Use single-character names except in lambdas/loops: `x => x.Id`, `for (int i = ...)`
- Prefix classes with `C`: ~~`CUser`~~
- Use underscores in public member names: ~~`Get_User`~~
- Name booleans without a verb prefix: ~~`active`~~ -> `isActive`
- Use `Impl` suffix: ~~`UserServiceImpl`~~ -> `UserService` (interface: `IUserService`)

---

## Quick Reference

| Element            | Convention     | Example                    |
|--------------------|----------------|----------------------------|
| Class              | PascalCase     | `OrderProcessor`           |
| Interface          | I + PascalCase | `IOrderRepository`         |
| Method             | PascalCase     | `GetOrderByIdAsync`        |
| Property           | PascalCase     | `TotalAmount`              |
| Parameter          | camelCase      | `orderId`                  |
| Local variable     | camelCase      | `itemCount`                |
| Private field      | _camelCase     | `_logger`                  |
| Constant           | UPPER_CASE     | `MAX_CONNECTIONS`          |
| Enum               | PascalCase     | `OrderStatus.Shipped`      |
| Generic param      | T + PascalCase | `TKey`, `TValue`           |
| Async method       | + Async suffix | `SaveAsync`                |
| Boolean            | Is/Has/Can     | `IsValid`, `HasPermission` |
