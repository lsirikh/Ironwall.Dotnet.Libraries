---
name: rust-security
description: Rust security patterns — memory safety, input validation, SQL injection prevention, secrets, cryptography, dependency auditing, web security
languages: ["Rust"]
frameworks: ["Rust", "actix-web", "axum"]
phases: ["test"]
---

# Rust Security

## When to Activate

- Rust 웹 서비스 또는 보안 관련 코드 작성 시
- `unsafe` 코드 리뷰 또는 보안 감사 시
- 의존성 보안 점검, 시크릿 관리, 암호화 작업 시
- actix-web 또는 axum 프레임워크 사용 시

## Core Patterns

### Memory Safety — Minimizing unsafe

```rust
// BAD — unnecessary unsafe
fn get_first(s: &[i32]) -> i32 { unsafe { *s.as_ptr() } }

// GOOD — safe alternative
fn get_first_safe(s: &[i32]) -> Option<&i32> { s.first() }

// When unsafe IS required, document SAFETY invariants
/// # Safety
/// `ptr` must be valid, aligned, and point to initialized `T`.
unsafe fn read_raw<T>(ptr: *const T) -> T {
    // SAFETY: caller guarantees validity via function contract
    std::ptr::read(ptr)
}

// Encapsulate unsafe behind a safe public API
pub struct AlignedBuffer { ptr: *mut u8, len: usize }
impl AlignedBuffer {
    pub fn new(size: usize) -> Self {
        let layout = std::alloc::Layout::from_size_align(size, 64).unwrap();
        let ptr = unsafe { std::alloc::alloc_zeroed(layout) };
        Self { ptr, len: size }
    }
    pub fn as_slice(&self) -> &[u8] {
        unsafe { std::slice::from_raw_parts(self.ptr, self.len) }
    }
}
impl Drop for AlignedBuffer {
    fn drop(&mut self) {
        let layout = std::alloc::Layout::from_size_align(self.len, 64).unwrap();
        unsafe { std::alloc::dealloc(self.ptr, layout) };
    }
}
```

```bash
# Miri detects UB: use-after-free, data races, uninitialized reads
rustup component add miri
cargo +nightly miri test
```

### Input Validation — serde + validator

```rust
use serde::Deserialize;
use validator::Validate;

#[derive(Deserialize, Validate)]
pub struct CreateUserRequest {
    #[validate(length(min = 1, max = 100))]
    pub name: String,
    #[validate(email)]
    pub email: String,
    #[validate(range(min = 0, max = 150))]
    pub age: u32,
    #[validate(length(min = 8, max = 128))]
    #[validate(custom(function = "validate_password_strength"))]
    pub password: String,
}

fn validate_password_strength(pw: &str) -> Result<(), validator::ValidationError> {
    let ok = pw.chars().any(|c| c.is_uppercase())
        && pw.chars().any(|c| c.is_lowercase())
        && pw.chars().any(|c| c.is_ascii_digit());
    if ok { Ok(()) } else { Err(validator::ValidationError::new("weak")) }
}

// Axum handler with validation
async fn create_user(
    axum::Json(body): axum::Json<CreateUserRequest>,
) -> Result<impl axum::response::IntoResponse, (axum::http::StatusCode, String)> {
    body.validate().map_err(|e| (axum::http::StatusCode::BAD_REQUEST, format!("{e}")))?;
    Ok(axum::http::StatusCode::CREATED)
}
```

### SQL Injection Prevention — sqlx Bind Parameters

```rust
use sqlx::PgPool;

// GOOD — parameterized queries
async fn find_user(pool: &PgPool, email: &str) -> Result<User, sqlx::Error> {
    sqlx::query_as!(User, "SELECT id, name, email FROM users WHERE email = $1", email)
        .fetch_one(pool).await
}

// GOOD — dynamic queries with QueryBuilder
async fn search(pool: &PgPool, name: Option<&str>, limit: i64) -> Result<Vec<User>, sqlx::Error> {
    let mut qb = sqlx::QueryBuilder::new("SELECT * FROM users WHERE 1=1");
    if let Some(n) = name {
        qb.push(" AND name ILIKE ").push_bind(format!("%{n}%"));
    }
    qb.push(" LIMIT ").push_bind(limit);
    qb.build_query_as::<User>().fetch_all(pool).await
}

// BAD — NEVER interpolate user input into SQL
// let q = format!("SELECT * FROM users WHERE email = '{email}'"); // SQL INJECTION
```

### Secret Management — dotenvy + secrecy

```rust
use secrecy::{ExposeSecret, Secret};

pub struct AppConfig {
    pub database_url: String,
    pub api_key: Secret<String>,    // Debug prints "[REDACTED]"
    pub jwt_secret: Secret<String>,
}

impl AppConfig {
    pub fn from_env() -> Self {
        dotenvy::dotenv().ok();
        Self {
            database_url: std::env::var("DATABASE_URL").unwrap(),
            api_key: Secret::new(std::env::var("API_KEY").unwrap()),
            jwt_secret: Secret::new(std::env::var("JWT_SECRET").unwrap()),
        }
    }
}

fn use_secret(cfg: &AppConfig) {
    println!("{:?}", cfg.api_key);              // prints [REDACTED]
    let key = cfg.api_key.expose_secret();      // explicit opt-in
    make_api_call(key);
}
```

### Cryptography — argon2, ring, rustls

```rust
use argon2::{Argon2, PasswordHash, PasswordHasher, PasswordVerifier};
use argon2::password_hash::{rand_core::OsRng, SaltString};

fn hash_password(pw: &str) -> Result<String, argon2::password_hash::Error> {
    let salt = SaltString::generate(&mut OsRng);
    Ok(Argon2::default().hash_password(pw.as_bytes(), &salt)?.to_string())
}

fn verify_password(pw: &str, hash: &str) -> bool {
    let parsed = PasswordHash::new(hash).unwrap();
    Argon2::default().verify_password(pw.as_bytes(), &parsed).is_ok()
}

// HMAC signing with ring
use ring::hmac;
fn sign(key: &[u8], msg: &[u8]) -> Vec<u8> {
    hmac::sign(&hmac::Key::new(hmac::HMAC_SHA256, key), msg).as_ref().to_vec()
}
fn verify_sig(key: &[u8], msg: &[u8], sig: &[u8]) -> bool {
    hmac::verify(&hmac::Key::new(hmac::HMAC_SHA256, key), msg, sig).is_ok()
}

// Secure random
fn generate_token() -> [u8; 32] {
    let mut buf = [0u8; 32];
    ring::rand::SystemRandom::new().fill(&mut buf).unwrap();
    buf
}
```

### Dependency Auditing

```bash
# cargo-audit — check RustSec vulnerability database
cargo install cargo-audit
cargo audit

# cargo-deny — comprehensive dependency policy
cargo install cargo-deny
cargo deny init     # creates deny.toml
cargo deny check    # run all checks
```

```toml
# deny.toml essentials
[advisories]
vulnerability = "deny"
unmaintained = "warn"

[licenses]
unlicensed = "deny"
allow = ["MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause"]

[bans]
multiple-versions = "warn"
deny = [{ name = "openssl" }]  # prefer rustls

[sources]
unknown-registry = "deny"
unknown-git = "deny"
```

### Web Security — CORS, Headers, Rate Limiting (Axum + Tower)

```rust
use axum::Router;
use tower_http::cors::CorsLayer;
use tower_http::set_header::SetResponseHeaderLayer;
use http::{HeaderName, HeaderValue};
use std::time::Duration;

fn build_app() -> Router {
    let cors = CorsLayer::new()
        .allow_origin(["https://example.com".parse().unwrap()])
        .allow_methods([http::Method::GET, http::Method::POST])
        .allow_headers([http::header::CONTENT_TYPE, http::header::AUTHORIZATION]);

    Router::new()
        .route("/api/data", axum::routing::get(handler))
        .layer(cors)
        .layer(SetResponseHeaderLayer::overriding(
            HeaderName::from_static("x-content-type-options"), HeaderValue::from_static("nosniff")))
        .layer(SetResponseHeaderLayer::overriding(
            HeaderName::from_static("x-frame-options"), HeaderValue::from_static("DENY")))
        .layer(SetResponseHeaderLayer::overriding(
            HeaderName::from_static("strict-transport-security"),
            HeaderValue::from_static("max-age=63072000; includeSubDomains")))
        .layer(tower::limit::RateLimitLayer::new(10, Duration::from_secs(60)))
}
```

### Error Handling — Never Expose Internals

```rust
use axum::{http::StatusCode, response::{IntoResponse, Response}, Json};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AppError {
    #[error("not found: {0}")]
    NotFound(String),
    #[error("unauthorized")]
    Unauthorized,
    #[error("internal: {0}")]
    Internal(#[from] anyhow::Error),
    #[error("database: {0}")]
    Database(#[from] sqlx::Error),
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        // Log full error internally
        match &self {
            AppError::Internal(e) => tracing::error!("internal: {e:#}"),
            AppError::Database(e) => tracing::error!("db: {e}"),
            _ => tracing::warn!("client error: {self}"),
        }
        // NEVER expose internals to client
        let (status, msg) = match self {
            AppError::NotFound(e) => (StatusCode::NOT_FOUND, format!("{e} not found")),
            AppError::Unauthorized => (StatusCode::UNAUTHORIZED, "auth required".into()),
            AppError::Internal(_) | AppError::Database(_) =>
                (StatusCode::INTERNAL_SERVER_ERROR, "an internal error occurred".into()),
        };
        (status, Json(serde_json::json!({ "error": msg }))).into_response()
    }
}
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| `unsafe` without `// SAFETY:` | Document all safety invariants | Reviewers need context |
| Returning raw DB errors to clients | Generic "internal error" message | Leaks schema and queries |
| `CORS: allow_origin(Any)` in prod | Whitelist specific origins | Open CORS defeats same-origin |
| Hardcoded secrets in source | `dotenvy` + `Secret<String>` | Secrets end up in git history |
| `format!("...{input}...")` in SQL | `sqlx::query!` with bind params | SQL injection vulnerability |
| `openssl` crate | `ring` + `rustls` | Pure Rust, no C dependency |
| Plain text password storage | `argon2` with random salt | Hashing protects credentials |
| No dependency auditing | `cargo audit` + `cargo deny` in CI | Known CVEs are exploitable |
| `unwrap()` on crypto operations | Proper `Result` handling | Crypto failures must not crash |
| Logging secrets / tokens | `secrecy::Secret<T>` wrappers | Prevents accidental exposure |
| No rate limiting on auth | `tower::limit::RateLimitLayer` | Brute-force protection |
| `#[allow(unsafe_code)]` crate-wide | `#![forbid(unsafe_code)]` | Minimizes unsafe surface |
