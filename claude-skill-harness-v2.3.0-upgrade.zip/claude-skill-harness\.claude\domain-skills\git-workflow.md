---
name: "Git Workflow"
description: "Branching strategies, conventional commits, PR best practices, merge strategies, and everyday git operations"
languages: ["*"]
frameworks: ["*"]
phases: ["dev"]
---

# Git Workflow

## When to Activate

- 브랜치 전략 수립 또는 변경
- 커밋 메시지 컨벤션 결정
- PR 작성, 리뷰, 머지 방식 논의
- git 충돌 해결, rebase, cherry-pick 등 실무 작업
- .gitignore, git hooks 설정

---

## Core Patterns

### 1. Branching Strategies

**GitHub Flow (권장 — 소규모 팀, 빠른 배포):**
```
main ─────────────────────────────────────────→
  └─ feature/add-login ──PR──merge──→
  └─ fix/null-pointer ──PR──merge──→
```
- `main`은 항상 배포 가능 상태
- 기능 브랜치에서 작업 → PR → 코드 리뷰 → main에 머지
- 단순하고 CI/CD와 잘 맞음

**GitFlow (릴리스 주기가 긴 프로젝트):**
```
main ──────────────────────────→ (릴리스 태그)
  └─ develop ─────────────────→
      └─ feature/xxx ──→ develop
      └─ release/1.0 ──→ main + develop
      └─ hotfix/yyy ──→ main + develop
```
- `main`: 프로덕션 코드
- `develop`: 다음 릴리스 통합 브랜치
- 복잡하지만 릴리스 관리가 체계적

**Trunk-Based (대규모 팀, 높은 자동화):**
```
main ─────────────────────────────────────────→
  └─ short-lived branch (1-2일) ──merge──→
```
- 브랜치 수명이 매우 짧음 (1-2일)
- Feature Flag로 미완성 기능 숨김
- 높은 수준의 CI/CD, 테스트 자동화 필요

**브랜치 네이밍:**
```
feature/add-user-authentication
fix/order-total-calculation
refactor/extract-payment-module
docs/api-endpoint-guide
test/add-order-service-unit-tests
chore/upgrade-dependencies
hotfix/critical-login-bug
release/2.1.0
```

### 2. Conventional Commits

```
<type>(<scope>): <subject>

<body>

<footer>
```

**타입:**
| Type | 용도 | 예시 |
|------|------|------|
| `feat` | 새 기능 | `feat(auth): add OAuth2 login` |
| `fix` | 버그 수정 | `fix(cart): correct total calculation` |
| `refactor` | 리팩토링 (동작 변경 없음) | `refactor(user): extract validation logic` |
| `docs` | 문서 변경 | `docs(api): update endpoint examples` |
| `test` | 테스트 추가/수정 | `test(order): add edge case tests` |
| `chore` | 빌드, CI, 설정 등 | `chore(deps): upgrade FastAPI to 0.110` |
| `style` | 포맷팅 (동작 변경 없음) | `style: apply black formatting` |
| `perf` | 성능 개선 | `perf(query): add index for user lookup` |
| `ci` | CI/CD 변경 | `ci: add GitHub Actions workflow` |

**규칙:**
- subject는 명령형 현재 시제: "add" (O), "added" (X), "adds" (X)
- subject 첫 글자 소문자, 끝에 마침표 없음
- body는 "왜" 변경했는지 설명 (72자 줄바꿈)
- Breaking Change는 footer에 `BREAKING CHANGE:` 표기

```
feat(api)!: change user endpoint response format

Restructure the user response to separate first and last names
instead of a single name field for better i18n support.

BREAKING CHANGE: GET /api/v1/users/{id} response field "name"
is replaced by "first_name" and "last_name".
```

### 3. PR Best Practices

**제목 형식:**
```
feat(auth): add Google OAuth2 login
fix(order): prevent negative quantity in cart
refactor(payment): extract Stripe integration to service layer
```

**설명 템플릿:**
```markdown
## Summary
- 무엇을 왜 변경했는지 1-3줄 요약

## Changes
- 주요 변경 사항 목록

## Test Plan
- [ ] 단위 테스트 추가/통과 확인
- [ ] 수동 테스트 시나리오
- [ ] 엣지 케이스 확인

## Screenshots (UI 변경 시)
Before | After
```

**리뷰 체크리스트:**
```markdown
- [ ] 코드가 PR 제목/설명과 일치하는가
- [ ] 불필요한 변경이 섞여 있지 않은가
- [ ] 에러 처리가 적절한가
- [ ] 테스트가 충분한가
- [ ] 보안 취약점은 없는가 (하드코딩된 시크릿 등)
- [ ] 성능 문제는 없는가 (N+1 쿼리, 불필요한 루프 등)
```

**PR 크기:** 200-400줄 이하가 이상적. 500줄 이상이면 분할을 고려한다.

### 4. Merge Strategies

| 전략 | 히스토리 | 용도 |
|------|---------|------|
| **Squash Merge** | 깔끔 (1커밋) | 기능 브랜치의 WIP 커밋 정리 |
| **Rebase Merge** | 선형 | 깔끔한 선형 히스토리 선호 |
| **Merge Commit** | 브랜치 이력 보존 | 병합 시점 명확, 되돌리기 쉬움 |

```bash
# Squash Merge (GitHub에서 가장 많이 사용)
git checkout main
git merge --squash feature/add-login
git commit -m "feat(auth): add login feature"

# Rebase Merge
git checkout feature/add-login
git rebase main
git checkout main
git merge feature/add-login  # fast-forward

# Merge Commit
git checkout main
git merge --no-ff feature/add-login
```

**권장:** GitHub Flow에서는 Squash Merge를 기본으로, 큰 기능은 Merge Commit.

### 5. .gitignore Patterns

```gitignore
# === OS ===
.DS_Store
Thumbs.db
Desktop.ini

# === IDE ===
.vscode/
.idea/
*.swp
*.swo
*~

# === Language — Python ===
__pycache__/
*.py[cod]
*.egg-info/
.venv/
venv/
dist/
build/

# === Language — Node.js ===
node_modules/
dist/
build/
.next/

# === Language — C# ===
bin/
obj/
*.user
*.suo

# === Environment & Secrets ===
.env
.env.*
!.env.example
*.pem
*.key
credentials.json

# === Logs ===
*.log
logs/

# === Build / Coverage ===
coverage/
.nyc_output/
htmlcov/
```

### 6. Git Hooks

```bash
# .git/hooks/pre-commit (또는 husky/lint-staged)
#!/bin/sh
# 린트 실행
npm run lint --quiet
if [ $? -ne 0 ]; then
  echo "Lint failed. Fix errors before committing."
  exit 1
fi

# 시크릿 탐지
if git diff --cached --diff-filter=ACM | grep -qE "(password|secret|api_key)\s*=\s*['\"][^'\"]+['\"]"; then
  echo "Potential secret detected in staged files!"
  exit 1
fi
```

```bash
# .git/hooks/commit-msg — Conventional Commit 검증
#!/bin/sh
MSG=$(cat "$1")
PATTERN="^(feat|fix|refactor|docs|test|chore|style|perf|ci)(\(.+\))?!?: .{1,72}$"
if ! echo "$MSG" | head -1 | grep -qE "$PATTERN"; then
  echo "Invalid commit message format."
  echo "Expected: <type>(<scope>): <subject>"
  echo "Example: feat(auth): add OAuth2 login"
  exit 1
fi
```

**husky + lint-staged (Node.js 프로젝트):**
```json
// package.json
{
  "lint-staged": {
    "*.{ts,tsx}": ["eslint --fix", "prettier --write"],
    "*.{json,md}": ["prettier --write"]
  }
}
```

### 7. Cherry-Pick

특정 커밋만 다른 브랜치로 가져온다.

```bash
# main에 hotfix 커밋 하나만 가져오기
git checkout main
git cherry-pick abc1234

# 충돌 발생 시
git cherry-pick abc1234
# ... 충돌 해결 ...
git add .
git cherry-pick --continue

# cherry-pick 취소
git cherry-pick --abort
```

**사용 시점:** hotfix를 main과 develop 양쪽에 적용할 때, 특정 커밋만 릴리스에 포함할 때.

### 8. Stash Workflow

작업 중인 변경을 임시 저장한다.

```bash
# 기본 stash
git stash                           # 변경사항 저장
git stash -m "WIP: login form"      # 설명과 함께 저장
git stash -u                        # untracked 파일도 포함

# stash 목록 확인
git stash list
# stash@{0}: On feature/login: WIP: login form
# stash@{1}: WIP on main: abc1234 previous commit

# stash 적용
git stash pop                       # 적용 + stash 제거
git stash apply stash@{1}           # 적용만 (stash 유지)

# stash 삭제
git stash drop stash@{0}            # 특정 stash 삭제
git stash clear                     # 전체 삭제
```

### 9. Tag & Release Workflow

```bash
# Semantic Versioning: MAJOR.MINOR.PATCH
# MAJOR: 호환성 깨지는 변경
# MINOR: 하위 호환 기능 추가
# PATCH: 하위 호환 버그 수정

# 태그 생성
git tag -a v1.2.0 -m "Release v1.2.0: add payment module"
git push origin v1.2.0

# 특정 커밋에 태그
git tag -a v1.1.1 abc1234 -m "Hotfix: fix login crash"

# 태그 목록
git tag -l "v1.*"

# 태그 삭제
git tag -d v1.2.0                   # 로컬
git push origin --delete v1.2.0     # 원격
```

### 10. Useful Aliases

```bash
# ~/.gitconfig
[alias]
  st = status -sb
  co = checkout
  br = branch -v
  lg = log --oneline --graph --decorate -20
  last = log -1 --stat
  unstage = reset HEAD --
  amend = commit --amend --no-edit
  wip = !git add -A && git commit -m "chore: WIP"
  undo = reset --soft HEAD~1
  branches = branch -a --sort=-committerdate
  cleanup = !git branch --merged main | grep -v main | xargs git branch -d
```

---

## Anti-Patterns

### 1. Committing to main Directly
- PR 없이 main에 직접 커밋하면 리뷰, CI 검증을 우회
- **해결:** main 브랜치 보호 규칙 설정 (required reviews, status checks)

### 2. Giant Commits
- 3000줄짜리 커밋 하나에 여러 기능, 리팩토링, 포맷팅이 섞여 있음
- **해결:** 하나의 커밋 = 하나의 논리적 변경. 별도 작업은 별도 커밋

### 3. Meaningless Commit Messages
- `fix`, `update`, `WIP`, `asdf`, `...` — 나중에 변경 이유를 알 수 없음
- **해결:** Conventional Commits 형식 준수

### 4. Long-Lived Branches
- 2주 이상 머지되지 않는 브랜치 → 충돌 폭탄
- **해결:** 작은 단위로 나누어 자주 머지. Trunk-Based 고려

### 5. Force Push to Shared Branches
- `git push --force` on main/develop → 다른 팀원의 작업이 유실
- **해결:** `--force-with-lease` 사용 (다른 사람이 push한 경우 거부됨)

### 6. Committing Secrets
- `.env`, API 키, 비밀번호가 커밋 이력에 남으면 삭제해도 복구 가능
- **해결:** .gitignore 설정, pre-commit hook으로 시크릿 탐지, git-secrets 도구

### 7. No .gitignore
- `node_modules/`, `__pycache__/`, `.venv/` 등이 저장소에 포함
- **해결:** 프로젝트 시작 시 바로 .gitignore 설정
