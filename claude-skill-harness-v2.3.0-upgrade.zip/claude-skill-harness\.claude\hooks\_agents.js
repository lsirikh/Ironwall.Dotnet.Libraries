// .claude/hooks/_agents.js
// Agent/Domain/Rules 로더 — FR-04, FR-07
//
// Agent 정의(.claude/agents/*.md)와 Domain Skills(.claude/domain-skills/*.md),
// Rules(.claude/rules/*/*.md)를 파싱하여 Phase 기반 매핑을 제공한다.
// session-gate.js와 advance-phase.js가 사용한다.
//
// 설계 원칙:
//   - Hook 코드에 프레임워크 특정 로직 금지 (NFR-03)
//   - .md 파일의 YAML frontmatter로만 매칭 (확장성 보장, NFR-04)
//   - 60초 캐시 (_config.js 패턴 재활용)

const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

// ── 캐시 ─────────────────────────────────────────────────────────────
let _agentCache = null;
let _agentCacheTime = 0;
let _domainCache = null;
let _domainCacheTime = 0;
let _rulesCache = null;
let _rulesCacheTime = 0;
const CACHE_TTL = 60000; // 60초

// ── YAML Frontmatter 파서 ────────────────────────────────────────────
// 정규식 기반 경량 파서. 외부 의존성 없음.

function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return null;
  const yaml = match[1].trim();
  if (!yaml) return {};
  const result = {};

  // 단순 문자열 필드
  for (const field of ['name', 'description', 'model']) {
    const m = yaml.match(new RegExp(`^${field}:\\s*(.+)$`, 'm'));
    if (m) result[field] = m[1].trim().replace(/^["']|["']$/g, '');
  }

  // 배열 필드 (인라인: ["a", "b"] 또는 멀티라인: - "a")
  for (const field of ['tools', 'phases', 'languages', 'frameworks']) {
    // 인라인 배열: field: ["a", "b"]
    const inlineMatch = yaml.match(new RegExp(`^${field}:\\s*\\[([^\\]]*)]`, 'm'));
    if (inlineMatch) {
      result[field] = inlineMatch[1]
        .split(',')
        .map(s => s.trim().replace(/^["']|["']$/g, ''))
        .filter(Boolean);
      continue;
    }
    // 멀티라인 배열
    const multiMatch = yaml.match(new RegExp(`^${field}:\\s*\\n((?:\\s+-\\s+.+\\n?)+)`, 'm'));
    if (multiMatch) {
      result[field] = multiMatch[1]
        .split('\n')
        .map(line => line.replace(/^\s+-\s+/, '').trim().replace(/^["']|["']$/g, ''))
        .filter(Boolean);
    }
  }

  return result;
}

// ── Agent 로더 ──────────────────────────────────────────────────────

function loadAgents(fresh = false) {
  const now = Date.now();
  if (!fresh && _agentCache && (now - _agentCacheTime) < CACHE_TTL) {
    return _agentCache;
  }

  const agentsDir = path.join(PROJECT_ROOT, '.claude', 'agents');
  const agents = [];

  try {
    if (!fs.existsSync(agentsDir)) return [];
    const files = fs.readdirSync(agentsDir).filter(f => f.endsWith('.md') && f !== 'README.md');

    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(agentsDir, file), 'utf8');
        const fm = parseFrontmatter(content);
        if (fm && fm.name) {
          agents.push({
            name: fm.name,
            description: fm.description || '',
            tools: fm.tools || [],
            model: fm.model || 'sonnet',
            phases: fm.phases || [],
            file
          });
        }
      } catch { /* skip invalid files */ }
    }
  } catch { /* directory not found */ }

  _agentCache = agents;
  _agentCacheTime = now;
  return agents;
}

/**
 * 특정 Phase에서 활용 가능한 Agent 목록 반환
 * @param {string} phase - 현재 Phase (dev, test, analysis 등)
 * @returns {Array<{name, description, model}>}
 */
function getAgentsForPhase(phase) {
  const agents = loadAgents();
  return agents.filter(a => a.phases.includes(phase));
}

// ── Domain Skills 로더 ───────────────────────────────────────────────

function loadDomainSkills(fresh = false) {
  const now = Date.now();
  if (!fresh && _domainCache && (now - _domainCacheTime) < CACHE_TTL) {
    return _domainCache;
  }

  const skillsDir = path.join(PROJECT_ROOT, '.claude', 'domain-skills');
  const skills = [];

  try {
    if (!fs.existsSync(skillsDir)) return [];
    const files = fs.readdirSync(skillsDir).filter(f => f.endsWith('.md') && f !== 'README.md');

    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(skillsDir, file), 'utf8');
        const fm = parseFrontmatter(content);
        if (fm && fm.name) {
          skills.push({
            name: fm.name,
            description: fm.description || '',
            languages: (fm.languages || []).map(l => l.toLowerCase()),
            frameworks: (fm.frameworks || []).map(f => f.toLowerCase()),
            phases: fm.phases || [],
            file
          });
        }
      } catch { /* skip */ }
    }
  } catch { /* directory not found */ }

  _domainCache = skills;
  _domainCacheTime = now;
  return skills;
}

/**
 * CLAUDE.md의 language/framework 기반 Domain Skills 매칭
 * @param {string} language - CLAUDE.md의 language 값 (예: "C#")
 * @param {string} framework - CLAUDE.md의 framework 값 (예: "WPF")
 * @returns {Array<{name, file}>}
 */
function getDomainSkillsForProject(language, framework) {
  if (!language && !framework) return [];
  const skills = loadDomainSkills();
  const lang = (language || '').toLowerCase();
  const fw = (framework || '').toLowerCase();

  // framework은 쉼표/공백 구분 다중 값 지원 (예: "FrameworkA, FrameworkB")
  const fwTokens = fw.split(/[,\s]+/).map(s => s.trim()).filter(Boolean);

  return skills.filter(skill => {
    // 언어 매칭
    const langMatch = lang && skill.languages.some(sl =>
      sl.includes(lang) || lang.includes(sl)
    );
    // 프레임워크 매칭
    const fwMatch = fwTokens.length > 0 && fwTokens.some(token =>
      skill.frameworks.some(sf => sf.includes(token) || token.includes(sf))
    );
    // 와일드카드 매칭 (languages: ["*"])
    const wildcardMatch = skill.languages.includes('*');

    return langMatch || fwMatch || wildcardMatch;
  });
}

// ── Rules 로더 ──────────────────────────────────────────────────────

function loadRules(fresh = false) {
  const now = Date.now();
  if (!fresh && _rulesCache && (now - _rulesCacheTime) < CACHE_TTL) {
    return _rulesCache;
  }

  const rulesDir = path.join(PROJECT_ROOT, '.claude', 'rules');
  const rules = {};

  try {
    if (!fs.existsSync(rulesDir)) return {};
    const packs = fs.readdirSync(rulesDir).filter(d => {
      try { return fs.statSync(path.join(rulesDir, d)).isDirectory(); }
      catch { return false; }
    });

    for (const pack of packs) {
      const packDir = path.join(rulesDir, pack);
      const files = fs.readdirSync(packDir).filter(f => f.endsWith('.md'));
      if (files.length > 0) {
        rules[pack] = files.map(f => f.replace('.md', ''));
      }
    }
  } catch { /* directory not found */ }

  _rulesCache = rules;
  _rulesCacheTime = now;
  return rules;
}

/**
 * 현재 프로젝트에 활성화된 Rules 반환
 * @param {string} language - CLAUDE.md의 language 값
 * @returns {Array<{pack, rules}>} 예: [{pack:'common', rules:['security','testing']}, {pack:'csharp', ...}]
 */
function getActiveRules(language) {
  const allRules = loadRules();
  const active = [];

  // common은 항상 포함
  if (allRules['common']) {
    active.push({ pack: 'common', rules: allRules['common'] });
  }

  // 언어 매칭
  if (language) {
    const lang = language.toLowerCase();
    const langMap = {
      'c#': 'csharp', 'csharp': 'csharp',
      'python': 'python', 'py': 'python',
      'typescript': 'typescript', 'javascript': 'typescript', 'ts': 'typescript', 'js': 'typescript',
      'go': 'go', 'golang': 'go',
      'rust': 'rust', 'rs': 'rust',
      'java': 'java', 'kotlin': 'java'
    };
    const packName = langMap[lang];
    if (packName && allRules[packName]) {
      active.push({ pack: packName, rules: allRules[packName] });
    }
  }

  return active;
}

// ── 캐시 무효화 ─────────────────────────────────────────────────────

function clearCaches() {
  _agentCache = null;
  _agentCacheTime = 0;
  _domainCache = null;
  _domainCacheTime = 0;
  _rulesCache = null;
  _rulesCacheTime = 0;
}

module.exports = {
  parseFrontmatter,
  loadAgents,
  getAgentsForPhase,
  loadDomainSkills,
  getDomainSkillsForProject,
  loadRules,
  getActiveRules,
  clearCaches
};
