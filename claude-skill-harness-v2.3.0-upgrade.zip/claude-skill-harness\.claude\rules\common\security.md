# Security Rules (All Languages)

> Always-on coding guidelines for secure software development.
> Applies to every language and framework in this project.

---

## Must Always

### Input & Validation
- Validate all user inputs at system boundaries (API endpoints, CLI args, file uploads)
- Sanitize inputs before rendering in HTML to prevent XSS
- Use allowlists over denylists for input validation
- Validate file types, sizes, and paths before processing

### Database
- Use parameterized queries / prepared statements for all database access
- Apply principle of least privilege to database accounts
- Escape or parameterize dynamic table/column names separately

### Secrets & Credentials
- Store secrets in environment variables or a secrets manager, never in code
- Rotate secrets on a regular schedule
- Use separate credentials per environment (dev, staging, prod)

### Communication
- Use HTTPS/TLS for all external communications
- Verify SSL certificates in all environments including staging
- Set appropriate CORS policies -- never use `*` in production

### Authentication & Sessions
- Hash passwords with bcrypt or argon2; never store plaintext
- Set `Secure`, `HttpOnly`, `SameSite` flags on authentication cookies
- Implement rate limiting on authentication endpoints
- Use short-lived tokens; refresh via secure rotation

### Logging & Monitoring
- Log security events: auth failures, access denied, privilege changes
- Include request IDs for traceability
- Keep dependencies updated; run vulnerability scans regularly (Dependabot, Snyk, etc.)

---

## Must Never

### Secrets
- Commit `.env`, credentials, API keys, or tokens to version control
- Hard-code secrets in source code
- Log sensitive data: passwords, tokens, PII, credit card numbers

### Dangerous Patterns
- Use `eval()` or equivalent dynamic code execution with user input
- Disable SSL/TLS certificate verification
- Use MD5 or SHA1 for security-sensitive hashing (passwords, signatures)
- Deserialize untrusted data without validation

### Error Handling
- Expose stack traces or internal error details to end users
- Return different error messages that reveal whether a user account exists
- Catch and silently swallow security-related exceptions

---

## Quick Reference

| Category         | Do                                 | Don't                              |
|------------------|------------------------------------|------------------------------------|
| Passwords        | bcrypt/argon2 hash                 | Plaintext or MD5                   |
| DB queries       | Parameterized / ORM                | String concatenation               |
| Secrets          | Env vars / secrets manager         | Hard-coded in source               |
| User input       | Validate at boundary               | Trust blindly                      |
| Errors           | Generic message to user            | Stack trace to user                |
| Dependencies     | Regular updates + vuln scans       | Pin and forget                     |
| TLS              | Always verify                      | Disable verification               |
