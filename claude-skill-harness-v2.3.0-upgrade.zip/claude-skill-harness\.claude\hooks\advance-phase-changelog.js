// .claude/hooks/advance-phase-changelog.js
// 버전 관리 + CHANGELOG 자동화 — IMPL-01~06

const fs = require('fs');
const path = require('path');
const { readClaudeMdField, scanDocsDir } = require('./_common');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const PRDS_DIR = path.join(PROJECT_ROOT, 'docs', 'prds');
const REPORTS_DIR = path.join(PROJECT_ROOT, 'docs', 'reports');
const CHANGELOG_FILE = path.join(PROJECT_ROOT, 'CHANGELOG.md');
const CLAUDE_MD = path.join(PROJECT_ROOT, 'CLAUDE.md');

function incrementVersion(current, today, lastDate, mode) {
  const parts = (current || '0.1.0').split('.').map(n => parseInt(n, 10));
  const X = isNaN(parts[0]) ? 0 : parts[0];
  const Y = isNaN(parts[1]) ? 1 : parts[1];
  const Z = isNaN(parts[2]) ? 0 : parts[2];
  if (mode === 'major') return `${X + 1}.0.0`;
  if (!lastDate || today !== lastDate) return `${X}.${Y + 1}.0`;
  return `${X}.${Y}.${Z + 1}`;
}

function readClaudeMdVersion() {
  try {
    if (!fs.existsSync(CLAUDE_MD)) return '0.1.0';
    const content = fs.readFileSync(CLAUDE_MD, 'utf8');
    const m = content.match(/version:\s*"([^"]+)"/);
    return m ? m[1] : '0.1.0';
  } catch { return '0.1.0'; }
}

function writeClaudeMdVersion(newVersion, today) {
  try {
    if (!fs.existsSync(CLAUDE_MD)) return false;
    let content = fs.readFileSync(CLAUDE_MD, 'utf8');
    content = content.replace(/version:\s*"[^"]*"/, `version: "${newVersion}"`);
    content = content.replace(/last_updated:\s*"[^"]*"/, `last_updated: "${today}"`);
    fs.writeFileSync(CLAUDE_MD, content);
    return true;
  } catch { return false; }
}

function extractCycleTopic(state) {
  if (state && state.activePrd) return path.basename(state.activePrd).replace(/-prd\.md$/i, '');
  try {
    const prds = scanDocsDir('prds');
    if (prds.length > 0) return prds[0].name.replace(/-prd\.md$/i, '');
  } catch {}
  return null;
}

function extractCycleTitle(topic) {
  if (!topic) return '사이클 완료';
  for (const dir of ['reports', 'prds']) {
    const suffix = dir === 'reports' ? '-report.md' : '-prd.md';
    const fp = path.join(PROJECT_ROOT, 'docs', dir, `${topic}${suffix}`);
    try {
      if (fs.existsSync(fp)) {
        const m = fs.readFileSync(fp, 'utf8').match(/^#\s+(.+)/m);
        if (m) return m[1].trim().replace(/\s*[—-]\s*완료 리포트$/, '').trim();
      }
    } catch {}
  }
  return topic;
}

function ensureChangelogTemplate() {
  if (fs.existsSync(CHANGELOG_FILE)) return;
  const template = `# Changelog\n\n이 프로젝트의 모든 주요 변경사항은 이 파일에 기록됩니다.\n형식: [Keep a Changelog](https://keepachangelog.com/) + 작업 로그형 X.Y.Z 버전\n\n> X = 사람이 수동 bump (큰 이정표)\n> Y = 날짜 기반 자동 증가 (날이 바뀌면 +1, Z=0 리셋)\n> Z = 작업 단위 자동 증가 (Track C 사이클 완료마다 +1)\n\n<!-- changelog-entries-start -->\n\n`;
  try { fs.writeFileSync(CHANGELOG_FILE, template); } catch {}
}

function changelogContainsTopic(topic) {
  if (!fs.existsSync(CHANGELOG_FILE)) return false;
  try { return fs.readFileSync(CHANGELOG_FILE, 'utf8').includes(`docs/reports/${topic}-report.md`); } catch { return false; }
}

function extractPrdVersion(content) {
  const m = content.match(/^- \*\*버전\*\*:\s*v?(\d+\.\d+)/im);
  return m ? m[1] : '1.0';
}

function insertChangeHistoryRow(content, newRow) {
  if (/## 변경 이력/.test(content)) {
    const tableMatch = content.match(/(## 변경 이력[\s\S]*?\|[-|\s]+\|\n(?:\|[^\n]+\|\n)*)/);
    if (tableMatch) return content.replace(tableMatch[1], tableMatch[1] + newRow + '\n');
  }
  return content;
}

function completePrd(prdRelPath) {
  if (!prdRelPath) return { ok: false, error: 'no path' };
  const fp = prdRelPath.includes(':') || prdRelPath.startsWith('/') ? prdRelPath : path.join(PROJECT_ROOT, prdRelPath);
  if (!fs.existsSync(fp)) return { ok: false, error: 'file not found' };
  let c = fs.readFileSync(fp, 'utf8');
  if (!/^- \*\*상태\*\*:\s*Approved/im.test(c)) return { ok: false, error: 'not Approved' };
  c = c.replace(/^(- \*\*상태\*\*:\s*)Approved/im, '$1Completed');
  const today = new Date().toISOString().slice(0, 10);
  const version = extractPrdVersion(c);
  c = insertChangeHistoryRow(c, `| ${today} | ${version} | 사이클 종료 — 자동 Completed | advance-phase.js complete | 상태 Approved → Completed |`);
  fs.writeFileSync(fp, c);
  return { ok: true };
}

function executePrdApproval(prdFileName, comment) {
  const prdPath = path.join(PRDS_DIR, prdFileName);
  if (!fs.existsSync(prdPath)) return { ok: false, error: `PRD 파일 없음: ${prdPath}` };
  let content = fs.readFileSync(prdPath, 'utf8');
  if (!/^- \*\*상태\*\*:\s*Draft/im.test(content)) return { ok: false, error: '현재 상태가 Draft가 아님' };
  content = content.replace(/^(- \*\*상태\*\*:\s*)Draft/im, '$1Approved');
  const today = new Date().toISOString().slice(0, 10);
  const version = extractPrdVersion(content);
  content = insertChangeHistoryRow(content, `| ${today} | ${version} | 사용자 승인 | "${comment || '승인'}" | 상태 Draft → Approved |`);
  fs.writeFileSync(prdPath, content);
  return { ok: true, prdPath };
}

function updateChangelog(state, mode) {
  const today = new Date().toISOString().slice(0, 10);
  const currentVersion = readClaudeMdVersion();
  const lastDate = state.last_changelog_date || null;
  const newVersion = incrementVersion(currentVersion, today, lastDate, mode);
  ensureChangelogTemplate();

  let entryBody = '';
  if (mode === 'major') {
    entryBody = `### Major\n- 수동 메이저 버전 bump (X+1, Y=0, Z=0)\n`;
  } else {
    const topic = extractCycleTopic(state);
    if (topic && changelogContainsTopic(topic)) return { skipped: true, reason: 'already-logged', version: currentVersion };
    const title = extractCycleTitle(topic);
    const links = [];
    if (topic) {
      for (const [dir, suffix] of [['prds','-prd.md'],['plans','-prd-plan.md'],['reports','-report.md']]) {
        const p = `docs/${dir}/${topic}${suffix}`;
        if (fs.existsSync(path.join(PROJECT_ROOT, p))) links.push(`[${dir === 'prds' ? 'PRD' : dir === 'plans' ? 'Plan' : 'Report'}](${p})`);
      }
    }
    entryBody = `### Added\n- **${title}**${links.length > 0 ? ` (${links.join(' · ')})` : ''}\n`;
  }

  const newBlock = `## [${newVersion}] - ${today}\n\n${entryBody.trimEnd()}\n`;
  let content = fs.readFileSync(CHANGELOG_FILE, 'utf8');
  const marker = '<!-- changelog-entries-start -->';
  const idx = content.indexOf(marker);
  if (idx !== -1) {
    const before = content.substring(0, idx + marker.length);
    let after = content.substring(idx + marker.length).replace(/^\n+/, '');
    content = before + '\n\n' + newBlock + '\n' + after;
  } else {
    content = newBlock + '\n' + content;
  }
  fs.writeFileSync(CHANGELOG_FILE, content);
  writeClaudeMdVersion(newVersion, today);
  return { skipped: false, version: newVersion, prevVersion: currentVersion };
}

module.exports = {
  incrementVersion, readClaudeMdVersion, writeClaudeMdVersion,
  extractCycleTopic, extractCycleTitle, ensureChangelogTemplate,
  changelogContainsTopic, extractPrdVersion, insertChangeHistoryRow,
  completePrd, executePrdApproval, updateChangelog
};
