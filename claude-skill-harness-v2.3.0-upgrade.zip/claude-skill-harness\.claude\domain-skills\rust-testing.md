---
name: rust-testing
description: Rust testing patterns — unit tests, integration tests, doc tests, mocking, property testing, coverage, benchmarks
languages: ["Rust"]
frameworks: ["Rust", "cargo"]
phases: ["test"]
---

# Rust Testing

## When to Activate

- Rust 프로젝트에서 테스트 작성 또는 실행 시
- `#[test]` 또는 `#[cfg(test)]` 관련 코드 작업 시
- `cargo test` 실행 또는 테스트 전략 논의 시

## Core Patterns

### Unit Tests — Basic Assertions

```rust
pub fn divide(a: f64, b: f64) -> Result<f64, String> {
    if b == 0.0 { Err("division by zero".into()) } else { Ok(a / b) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_divide_ok() {
        let r = divide(10.0, 3.0).unwrap();
        assert!((r - 3.333).abs() < 0.01, "expected ~3.333, got {r}");
    }

    #[test]
    fn test_divide_zero() -> Result<(), String> {
        let err = divide(1.0, 0.0).unwrap_err();
        assert_eq!(err, "division by zero");
        Ok(())
    }

    #[test]
    #[should_panic(expected = "index out of bounds")]
    fn test_out_of_bounds() { let _ = vec![1, 2][99]; }
}
```

### Test Organization

```rust
pub struct User { pub name: String, pub age: u32, active: bool }
impl User {
    pub fn new(name: &str, age: u32) -> Self { Self { name: name.into(), age, active: true } }
    pub fn deactivate(&mut self) { self.active = false; }
    pub fn is_active(&self) -> bool { self.active }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn make_test_user() -> User { User::new("test", 25) } // test-only helper

    #[test]
    fn new_user_is_active() { assert!(make_test_user().is_active()); }

    #[test]
    fn deactivate_works() {
        let mut u = make_test_user();
        u.deactivate();
        assert!(!u.is_active());
    }

    #[test]
    #[ignore = "requires database"]  // run with --ignored
    fn slow_integration() { std::thread::sleep(std::time::Duration::from_secs(10)); }
}
```

### Integration Tests (tests/ Directory)

```rust
// tests/api_integration.rs — compiled as separate crate, public API only
use my_crate::{Config, Server};
mod common; // tests/common/mod.rs for shared utilities

#[test]
fn test_full_cycle() {
    let server = common::setup_test_server();
    let resp = server.handle_request("/api/health");
    assert_eq!(resp.status(), 200);
}
```

```rust
// tests/common/mod.rs
use my_crate::{Config, Server};
pub fn setup_test_server() -> Server {
    Server::new(Config::new("localhost", 0))
}
```

### Doc Tests

```rust
/// Adds two numbers.
///
/// ```
/// assert_eq!(my_crate::add(2, 3), 5);
/// ```
///
/// ```should_panic
/// panic!("expected");
/// ```
///
/// ```no_run
/// my_crate::start_server(); // compiles but won't execute
/// ```
pub fn add(a: i32, b: i32) -> i32 { a + b }
```

### Test Fixtures — Setup and Drop Cleanup

```rust
use std::fs;
use std::path::{Path, PathBuf};

struct TempDir { path: PathBuf }
impl TempDir {
    fn new(name: &str) -> Self {
        let p = std::env::temp_dir().join(format!("test_{name}_{}", std::process::id()));
        fs::create_dir_all(&p).unwrap();
        Self { path: p }
    }
    fn path(&self) -> &Path { &self.path }
}
impl Drop for TempDir {
    fn drop(&mut self) { let _ = fs::remove_dir_all(&self.path); }
}

#[test]
fn test_file_ops() {
    let dir = TempDir::new("ops");   // auto-cleaned on drop
    let f = dir.path().join("test.txt");
    fs::write(&f, "hello").unwrap();
    assert_eq!(fs::read_to_string(&f).unwrap(), "hello");
}
```

### Cargo Test Flags

```bash
cargo test                     # all tests (unit + integration + doc)
cargo test --lib               # unit tests only
cargo test --test api_test     # specific integration test file
cargo test --doc               # doc tests only
cargo test test_user           # name pattern match
cargo test -- --ignored        # ignored tests only
cargo test -- --include-ignored
cargo test -- --nocapture      # show stdout from passing tests
cargo test --release           # optimized mode
cargo test -p my_crate         # specific workspace package
cargo test -- --test-threads=1 # sequential execution
```

### Mocking with mockall

```rust
use mockall::{automock, predicate::*};

#[automock]
trait Database {
    fn get_user(&self, id: i64) -> Result<User, DbError>;
    fn save_user(&self, user: &User) -> Result<(), DbError>;
}

struct UserService<D: Database> { db: D }
impl<D: Database> UserService<D> {
    fn find_user(&self, id: i64) -> Result<User, DbError> { self.db.get_user(id) }
}

#[test]
fn test_find_user() {
    let mut mock = MockDatabase::new();
    mock.expect_get_user()
        .with(eq(42))
        .times(1)
        .returning(|_| Ok(User { id: 42, name: "Alice".into() }));

    let svc = UserService { db: mock };
    assert_eq!(svc.find_user(42).unwrap().name, "Alice");
}

#[test]
fn test_not_found() {
    let mut mock = MockDatabase::new();
    mock.expect_get_user()
        .with(eq(999))
        .returning(|id| Err(DbError::NotFound(id)));
    assert!(UserService { db: mock }.find_user(999).is_err());
}
```

### Property-Based Testing with proptest

```rust
use proptest::prelude::*;

fn reverse<T: Clone>(v: &[T]) -> Vec<T> { v.iter().rev().cloned().collect() }
fn encode(s: &str) -> String { s.chars().map(|c| (c as u8 + 1) as char).collect() }
fn decode(s: &str) -> String { s.chars().map(|c| (c as u8 - 1) as char).collect() }

proptest! {
    #[test]
    fn double_reverse_identity(ref v in prop::collection::vec(any::<i32>(), 0..100)) {
        assert_eq!(reverse(&reverse(v)), *v);
    }
    #[test]
    fn encode_decode_roundtrip(s in "[a-zA-Z0-9 ]{0,50}") {
        assert_eq!(decode(&encode(&s)), s);
    }
    #[test]
    fn add_commutative(a in any::<i32>(), b in any::<i32>()) {
        assert_eq!(a.wrapping_add(b), b.wrapping_add(a));
    }
}
```

### Code Coverage

```bash
# cargo-tarpaulin (Linux-focused)
cargo install cargo-tarpaulin
cargo tarpaulin --out html --output-dir coverage/
cargo tarpaulin --ignore-tests --packages my_crate

# cargo-llvm-cov (cross-platform, recommended)
cargo install cargo-llvm-cov
cargo llvm-cov --html                  # HTML report
cargo llvm-cov --open                  # open in browser
cargo llvm-cov --lcov --output-path lcov.info  # CI integration
cargo llvm-cov --fail-under-lines 80  # fail below threshold
```

### Benchmarks with Criterion

```rust
// Cargo.toml: criterion = { version = "0.5", features = ["html_reports"] }
// [[bench]] name = "sorting", harness = false

use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId};

fn bench_sorting(c: &mut Criterion) {
    let mut group = c.benchmark_group("sorting");
    for size in [100, 1000, 10000] {
        let data: Vec<i32> = (0..size).rev().collect();
        group.bench_with_input(BenchmarkId::new("std_sort", size), &data, |b, d| {
            b.iter(|| { let mut v = d.clone(); v.sort(); black_box(&v); });
        });
    }
    group.finish();
}
criterion_group!(benches, bench_sorting);
criterion_main!(benches);
```

```bash
cargo bench                      # run all benchmarks
cargo bench -- sorting           # specific benchmark
cargo bench -- --save-baseline main  # save baseline for comparison
```

## Anti-Patterns

| Bad | Good | Why |
|-----|------|-----|
| No `#[cfg(test)]` on test module | `#[cfg(test)] mod tests` | Test code must not compile in release |
| Tests with no assertions | `assert_eq!`, `assert!`, `?` return | Test that cannot fail is useless |
| Hardcoded file paths in tests | `TempDir` or `env::temp_dir()` | Tests must run on any machine |
| `#[ignore]` without comment | `#[ignore = "requires database"]` | Document why test is skipped |
| Testing only private internals | Test public API behavior | Refactoring should not break tests |
| Giant monolithic test functions | Small focused tests with clear names | Easier to diagnose failures |
| `unwrap()` in test setup | `.expect("setup: create file")` | Better failure messages |
| Shared mutable state between tests | Each test creates own state | Tests run in parallel by default |
| Skipping doc tests | `///` examples on public API | Doc tests verify docs stay correct |
| No CI coverage tracking | `cargo llvm-cov --fail-under-lines 80` | Prevent coverage regression |
