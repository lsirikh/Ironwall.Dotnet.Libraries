# Java Coding Patterns

## Must Always
- Use records for immutable data carriers (Java 16+)
- Use sealed interfaces for restricted type hierarchies (Java 17+)
- Use switch expressions with pattern matching (Java 21+)
- Use `Optional.map()`, `.orElse()`, `.ifPresent()` — never `.get()` without `.isPresent()`
- Use try-with-resources for `AutoCloseable` resources
- Use `@Override` annotation on all overridden methods
- Prefer constructor injection over field injection for DI
- Use `Stream` API for collection transformations, not manual loops
- Use `CompletableFuture` for async operations, virtual threads for blocking I/O (Java 21+)
- Validate inputs at public API boundaries with `Objects.requireNonNull()`

## Must Never
- Catch `Exception` or `Throwable` broadly — catch specific types
- Use raw types (always parameterize generics: `List<String>` not `List`)
- Return `null` from collection methods — return empty collection
- Use `synchronized` on public methods — use private lock objects
- Mutate method parameters
- Swallow exceptions with empty catch blocks
