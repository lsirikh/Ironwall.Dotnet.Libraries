---
name: prd
description: |
  기능 구현, 아키텍처 설계, 신규 모듈에 대한 요구사항 정의서(PRD)를 작성하는 스킬.
  "PRD 만들어줘", "요구사항 정리해줘", "기능 명세 작성해줘",
  "이 기능 어떻게 만들지 설계해줘", "뭘 만들어야 하는지 정리해줘",
  "기능 스펙 뽑아줘", "개발 중 요구사항 바뀌었어" 등에서 반드시 사용한다.
  암묵적 요청: "성능이 너무 느려" → 성능 개선 PRD 필요,
  "보안 취약점 발견했어" → 보안 강화 PRD, "API 버전 올려야 해" → 마이그레이션 PRD,
  "이 모듈 복잡 리팩토링 필요해" → 리팩토링 PRD, "버그 패턴이 계속 반복돼" → 구조 개선 PRD.
  복잡한 개발 요청이 들어오면 process 스킬 판단에 따라 이 스킬이 먼저 실행된다.
  결과물은 docs/prds/{topic}-prd.md에 저장한다.
---

# PRD 스킬 — 요구사항 정의서 작성

## 역할

개발 착수 전 "무엇을 왜 만드는가"를 명확히 정의한다.
PRD 없이 개발하면 방향이 흔들리고 완료 기준이 모호해진다.
이 문서가 plan → 개발 → test → report 전체의 기준이 된다.
특히 FR ID는 plan의 IMPL 태스크와 1:N으로 연결되어 report의 달성 현황 추적을 가능하게 한다.

---

## PRD 상태 관리

PRD는 아래 상태를 거친다. 파일의 **상태** 필드를 항상 최신으로 갱신한다.

| 상태 | 의미 | 전환 트리거 |
|------|------|-----------|
| Draft | 작성 중 | 초기 생성 시 |
| Review | 검토 요청 | 초안 완성 후 사용자에게 제출 |
| Approved | 승인됨 → plan 진행 가능 | 사용자 명시적 승인 확인 |
| Rejected | 거부됨 → 재작성 필요 | 사용자 거부 + 피드백 수집 |
| Superseded | 신버전으로 대체됨 | 대규모 요구사항 변경 시 |

Approved가 되어야 plan 스킬 실행이 허용된다.

### Superseded PRD 처리 절차

기존 PRD가 신버전으로 대체될 때:
1. 기존 PRD 상태를 `Superseded`로 변경
2. 기존 PRD 상단에 `- **대체됨**: docs/prds/{new-topic}-prd.md` 참조 추가
3. 신규 PRD 상단에 `- **이전 PRD**: docs/prds/{old-topic}-prd.md` 참조 추가
4. INDEX.md에서 기존 PRD 행 상태를 `Superseded`로 변경

---

## 실행 전 확인

1. CLAUDE.md를 읽어 프로젝트 언어/프레임워크를 파악한다
2. `docs/analysis/` 폴더에 관련 분석 파일이 있으면 반드시 읽는다:
   - analysis에서 전달받은 파일 경로 우선 사용
   - "7. PRD 필요 항목" 테이블을 FR 초안의 출발점으로 활용
   - analysis의 prd 연결 매핑 가이드에 따라 각 섹션을 prd에 매핑
   - analysis 없으면 요구사항 인터뷰로 직접 파악
3. 같은 topic의 PRD가 이미 있으면:
   "기존 PRD({상태})가 있습니다. 덮어쓸까요, 새로 만들까요, 수정할까요?"

---

## 요구사항 인터뷰

analysis 결과가 있으면 이미 파악된 항목은 건너뛰고 불명확한 부분만 확인한다.
analysis 없으면 아래 항목을 자연스러운 대화 흐름에 맞게 순서대로 묻는다.

```
1. 이 기능/모듈의 목적은? (왜 필요한가)
2. 어떻게 동작해야 하는가? (사용자/시스템 관점)
3. 입력과 출력은 무엇인가?
4. 성능, 보안, 확장성 제약이 있나?
5. 기존 코드와 연동되는 지점은?
6. 이번에 하지 않을 것 (Out of Scope)은?
```

---

## FR 복잡도 가이드

각 FR의 "예상 태스크 수"를 기입할 때 아래 기준을 참조한다:

| 복잡도 | 예상 태스크 수 | 판단 기준 |
|--------|------------|---------|
| 단순 | ~2개 | 단일 함수·클래스 추가, 설정 변경 |
| 보통 | ~4개 | 여러 파일 수정, 새 서브모듈 추가 |
| 복잡 | ~7개 | 여러 레이어 수정, 외부 연동 포함 |
| 대규모 | 10개↑ | 아키텍처 변경, 전체 모듈 재설계 |

복잡도 "대규모" FR이 2개 이상이면 PRD 분할을 검토한다.

## NFR 검증 방법 가이드

NFR 항목 작성 시 "검증 방법" 컬럼을 아래 기준으로 채운다:

| NFR 항목 | 권장 검증 방법 |
|---------|------------|
| 응답 시간 (예: 3초 이내) | 부하 테스트 + 응답 시간 측정 |
| 처리량 (예: 초당 100건) | 부하 테스트 (동시 요청) |
| 메모리 사용량 | 프로파일러 + 메모리 스냅샷 |
| 보안 — 인증/권한 | 단위 테스트 + 수동 취약점 검증 |
| 보안 — 입력 검증 | 퍼징 + SQL 인젝션/XSS 시나리오 |
| 가용성 / 복구 | 장애 시뮬레이션 + 복구 시간 측정 |
| 데이터 무결성 | 트랜잭션 롤백 시나리오 |

---

## 출력 파일

**경로**: `docs/prds/{topic}-prd.md`

```markdown
# {topic} PRD

- **작성일**: {날짜}
- **상태**: Draft
- **버전**: 1.0
- **언어/프레임워크**: {CLAUDE.md 값}
- **연관 분석**: docs/analysis/{관련파일}.md (있는 경우)

---

## 변경 이력

| 날짜 | 버전 | 변경 항목 | 변경 이유 | 영향 범위 |
|------|------|---------|---------|---------|
| {날짜} | 1.0 | 초안 작성 | — | — |

---

## 1. 개요

### 목적
### 배경 및 동기

---

## 2. 요구사항

### 기능 요구사항 (Functional Requirements)

각 FR에 예상 태스크 수를 명시한다 — plan 스킬이 태스크 분해 시 참조한다.

| ID | 요구사항 | 우선순위 | 예상 태스크 수 |
|----|---------|---------|--------------|
| FR-01 | | High/Mid/Low | ~N개 |

### 비기능 요구사항 (Non-Functional Requirements)

검증 방법을 명시한다 — test 스킬이 이 컬럼을 수신해 테스트 케이스 설계에 사용한다.

| ID | 항목 | 요구사항 | 검증 방법 |
|----|------|---------|---------|
| NFR-01 | 성능 | | 부하 테스트 / 응답 시간 측정 |
| NFR-02 | 보안 | | 취약점 스캔 / 인증 테스트 |

---

## 3. 기술 설계

### 아키텍처 결정 및 이유
### 주요 컴포넌트
### 데이터 모델
### API/인터페이스 설계 (해당 시)

---

## 4. 범위

### In Scope
### Out of Scope

---

## 5. 의존성 및 전제 조건

---

## 6. 리스크

가능성 "높음" 리스크는 plan 스킬이 RISK 태스크로 변환한다.

| 리스크 | 가능성 | 영향 | 대응 방안 |
|--------|--------|------|---------|

---

## 7. 완료 기준 (Definition of Done)

아래 체크리스트는 plan 스킬의 "완료 기준 체크리스트"와 자동으로 동기화된다.

- [ ] 모든 FR 구현 완료 (FR-01 ~ FR-N)
- [ ] NFR 검증 통과 (test 스킬에서 검증)
- [ ] 단위 테스트 작성 및 통과
- [ ] 문서 업데이트
```

---

## PRD 상태 ↔ pipeline-state.json 동기화

PRD 상태가 변경될 때마다 pipeline-state.json과 동기화한다:

| PRD 상태 변경 | pipeline-state.json 처리 |
|-------------|----------------------|
| Draft 생성 | `artifacts.prd.path` 갱신 (Hook 자동) |
| Draft → Review | 변경 없음 |
| Review → Approved | `activePrd` 갱신 확인 + `advance-phase.js plan` 실행 준비 |
| Approved → Completed | `activePrd` → null (report 완료 후 처리에서) |
| Superseded | `activePrd`가 이 PRD를 가리키면 → null로 갱신 |

### PRD 버전 관리 규칙

```
버전 형식: v{major}.{minor}  (예: v1.0, v1.1, v2.0)

초기 작성:        v1.0
사소한 수정:       v1.1, v1.2, ...  (FR 변경 없이 문구 수정)
FR 추가/삭제:     v2.0              (major 증가)
Superseded 시:    새 PRD 파일 생성 (기존 PRD 상단에 "대체됨: {새 PRD 경로}" 표시)

PRD 파일 상단에 버전 필드 추가:
- **버전**: v1.0
- **변경 이력**: v1.0 ({날짜}) 초기 작성
```

---

## 완료 후 처리

> ⚠ **CRITICAL — Claude 자동 승인 금지** (FR-01, FR-04 by user-approval-gates-prd v1.1)
> - PRD 신규 작성 시 상태는 **반드시 `Draft`**
> - Claude가 직접 `Approved` / `Completed`로 변경 시 `pre-tool-gate.js`가 차단
> - 승인은 오직 사용자 명시 명령으로:
>   `node .claude/hooks/advance-phase.js approve prd "코멘트"`

1. `docs/prds/{topic}-prd.md` 저장 확인 (**상태: Draft**)

2. 사용자에게 PRD 핵심 내용 요약 후 검토 요청:
   ```
   📋 PRD 초안이 완성되었습니다 (Draft).
   FR: {N}개 | NFR: {N}개 | 리스크: {N}건
   
   검토 후 다음 중 하나로 응답해주세요:
   - 수정 요청: "FR-XX 수정해줘" 등
   - 승인: node .claude/hooks/advance-phase.js approve prd "코멘트"
   ```

3. 사용자 승인 (위 명령) 시 → advance-phase.js가 상태를 자동으로 Approved 전환 + 변경 이력 자동 추가

4. **사이클 종료 시 자동 Completed 전환** (FR-01 by process-cleanup-prd):
   `advance-phase.js complete` 트리거가 active PRD 상태를 자동으로 `Approved` → `Completed`로 변경.
   변경 이력에 "사이클 종료 — 자동 Completed" 행 자동 추가. Claude의 수동 변경 불필요.

## 수정 후 처리 (사용자 피드백 시)

사용자가 PRD 수정 요청 시:
1. 해당 FR/섹션 Edit
2. **즉시 변경 이력 테이블에 행 추가**:
   ```
   | {날짜} | {버전} | {수정 내용} | 사용자 요청 — "{피드백 요약}" | {영향 범위} |
   ```
3. 사용자에게 재검토 요청:
   ```
   ✏ PRD가 v{N}로 수정되었습니다. 재검토 부탁드립니다.
   ```
4. 변경 이력 누락 시 `post-write-sync.js`가 stderr 경고로 안내

4. **pipeline-state.json 동기화 확인**
   `docs/memory/pipeline-state.json`의 `activePrd` 값이 이 PRD 경로와 일치하는지 확인
   불일치 시 수동으로 갱신 (Hook이 이미 처리했을 수 있으므로 확인만)

5. **INDEX.md 갱신**
   `.claude/skills/index/SKILL.md`를 읽고 `docs/INDEX.md`의 PRD 섹션을 갱신한다
   - 신규 PRD: 행 추가 (상태: Draft)
   - Approved 전환 시: 해당 행 상태 컬럼 `Approved`로 변경

6. **session-context.md 갱신**
   `.claude/skills/memory/SKILL.md`를 읽고 `docs/memory/session-context.md`를 갱신한다:
   - "활성 PRD": `docs/prds/{topic}-prd.md`
   - "현재 Phase": `prd`
   - "다음 할 일": `plan 스킬로 구현 계획 작성`
   - "중요 기술 결정 사항"에 PRD 핵심 기술 결정 추가 (있는 경우)
   - 추가: FR 목록 요약을 "완료된 작업 이력"에 기록:
     `{날짜} | {topic} PRD Approved | FR {N}개 (예상 태스크 ~{합산}개) | docs/prds/{topic}-prd.md`

7. **README Unreleased 갱신**
   `.claude/skills/readme/SKILL.md`를 읽고 Unreleased 섹션에 기능 추가

---

## process 연동

이 스킬 완료 직후:
1. 위의 "완료 후 처리" 섹션을 모두 수행한다
2. 사용자에게 승인 여부를 확인한다:
   - 승인 → 상태 Approved 저장 → `.claude/skills/process/SKILL.md`의 "prd 승인" 완료 신호 처리에 따라 plan 즉시 실행
   - 거부 → `.claude/skills/process/SKILL.md`의 "prd 거부" 예외 복구 라우팅 실행 (피드백 수집 → 재작성)
3. plan 실행 시 아래 컨텍스트를 전달한다:
   - FR 테이블 (ID·요구사항·예상 태스크 수)
   - 리스크 테이블 (가능성 높음 항목 강조)
   - DoD 체크리스트 (plan의 완료 기준으로 그대로 사용)
   - NFR 테이블 (test 스킬 전달용)
