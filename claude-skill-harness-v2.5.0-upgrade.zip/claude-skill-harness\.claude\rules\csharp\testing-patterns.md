# C# Testing Patterns

> Always-on testing guidelines for C# / xUnit codebases.
> Covers DB fixtures, time abstraction, test isolation, and naming.

---

## DB 통합 테스트 픽스처 (I-01)

### Must Always
- `IAsyncLifetime` 라이프사이클 메서드(`InitializeAsync`, `DisposeAsync`)에 **`[Fact]` 절대 금지**
  - xUnit이 라이프사이클 메서드 + 독립 테스트 두 번 실행 → "Duplicate entry", "Table doesn't exist" 오류
- DB INSERT 후 반드시 `try/finally` 또는 `WithCleanup` 헬퍼로 cleanup 보장
- 동시성 테스트에서 공유 `DbConnection` 단일 인스턴스 **절대 사용 금지** — 각 Task에 독립 연결 생성

### 표준 픽스처 패턴

```csharp
public class DbTestFixture : IAsyncLifetime
{
    // [Fact] 절대 금지 — IAsyncLifetime 메서드에 테스트 어트리뷰트 불가
    public async Task InitializeAsync() { /* 시드 데이터 삽입 */ }
    public async Task DisposeAsync()   { /* 테이블 정리 */ }

    // INSERT 후 cleanup 보장 헬퍼
    public async Task<T> WithCleanup<T>(Func<Task<T>> action, Func<T, Task> cleanup)
    {
        var result = await action();
        try { await cleanup(result); } catch { /* cleanup 실패 무시 */ }
        return result;
    }
}
```

### INSERT / cleanup 패턴

```csharp
[Fact]
public async Task should_insert_record_when_valid_input()
{
    // Arrange
    var entity = BuildEntity();

    // Act
    var inserted = await _fx.Svc.InsertAsync(entity);

    try
    {
        // Assert
        inserted.Should().NotBeNull();
    }
    finally
    {
        // Cleanup — 시드 카운트 오염 방지
        await _fx.Svc.DeleteAsync(inserted);
    }
}
```

### 동시성 테스트 패턴

```csharp
// 잘못된 패턴 — 공유 연결에 병렬 Task
// [Fact(Skip = "MySqlConnection non-thread-safe")]
// public async Task concurrent_insert_shared_connection() { ... }

// 올바른 패턴 — Task마다 독립 연결
[Fact]
public async Task should_insert_concurrently_when_independent_connections()
{
    var tasks = Enumerable.Range(0, 5).Select(async i =>
    {
        await using var conn = new MySqlConnection(_connStr);
        await conn.OpenAsync();
        // 각 Task에서 독립 연결 사용
    });
    await Task.WhenAll(tasks);
}
```

---

## 시간 의존 코드 — IClock 추상화 (I-02)

시간에 의존하는 컴포넌트는 처음부터 `IClock`으로 분리한다.

```csharp
public interface IClock
{
    DateTime Now    { get; }
    DateTime UtcNow { get; }
}

// 프로덕션
public class SystemClock : IClock
{
    public DateTime Now    => DateTime.Now;
    public DateTime UtcNow => DateTime.UtcNow;
}

// 테스트용
public class FakeClock : IClock
{
    public DateTime Now    { get; set; } = DateTime.Now;
    public DateTime UtcNow { get; set; } = DateTime.UtcNow;
}
```

### DI 등록 (Program.cs / Startup.cs)

```csharp
services.AddSingleton<IClock, SystemClock>();
```

### Must Never
- `DateTime.Now` / `DateTime.UtcNow` 를 서비스/컨트롤러 내에서 직접 호출
  → 환경에 따라 불안정한 테스트 발생
- 타이머(`Timer`, `DispatcherTimer`)의 콜백 내 시간 계산에 `DateTime.Now` 직접 사용

---

## 테스트 명명 규칙 (I-03)

### Must Always
- 모든 테스트 메서드는 `should_{expected_behavior}_when_{condition}` 패턴 준수
- 완료 기준(DoD)에 명명 패턴 준수 포함

```csharp
// 올바른 예시
[Fact]
public async Task should_return_null_when_entity_not_found() { }

[Fact]
public async Task should_throw_when_connection_is_closed() { }

// 잘못된 예시
[Fact]
public async Task TestInsert() { }       // 패턴 미준수

[Fact]
public async Task Insert_Works() { }    // 패턴 미준수
```

### code-reviewer 체크 항목
- `[Fact]` / `[Theory]` 메서드명이 `should_` 로 시작하는가
- `IAsyncLifetime` 구현 클래스의 메서드에 `[Fact]`/`[Theory]` 가 없는가
- DB INSERT 후 `finally` cleanup 또는 `WithCleanup` 헬퍼가 있는가

---

## Quick Reference

| 항목 | Do | Don't |
|------|-----|-------|
| 픽스처 라이프사이클 | `InitializeAsync()` — 어트리뷰트 없음 | `[Fact] InitializeAsync()` |
| INSERT cleanup | `try/finally` + Delete | cleanup 없이 Assert 후 종료 |
| 동시성 DB | Task마다 독립 연결 | 공유 `_conn` 병렬 호출 |
| 시간 의존 | `IClock` 주입 | `DateTime.Now` 직접 호출 |
| 테스트 명명 | `should_X_when_Y` | `TestMethod`, `MethodName_Works` |
