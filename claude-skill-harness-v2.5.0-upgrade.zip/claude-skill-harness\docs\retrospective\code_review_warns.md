# 미해결 code-reviewer WARN 항목 (I-13)

> 릴리스 전 일괄 해소 대상. code-reviewer가 WARN을 발행하면 이 파일에 추가한다.
> 기능 동작은 정상이나 품질·안전성 기준 미달 항목만 기록한다.

---

## 추적 테이블

| # | 항목 | 파일 | 발견 주기 | 우선순위 | 상태 |
|---|------|------|---------|---------|------|
| W-01 | 테스트 명명 `should_X_when_Y` 미준수 | `SoundAlarmControllerTests.cs` | v2.5.1 | Low | 미해결 |
| W-02 | `DateTime.Now` 직접 사용 (IClock Mock 미적용) | `SoundAlarmController.cs` | v2.5.1 | Medium | 미해결 |
| W-03 | `ProcessDetectionMode` L373 `ProcessDeviceEvent` 직접 호출 잔존 | `NatsDomainService.cs` | v2.5.1 | Medium | 미해결 |

---

## 운영 규칙

- **추가**: code-reviewer 실행 후 WARN 항목은 즉시 이 파일에 행 추가
- **해소**: 수정 완료 시 상태 → `해결` + 해결 날짜 기록 후 다음 릴리스에서 행 삭제
- **우선순위 기준**:
  - `Critical` — 잠재적 런타임 오류, 스레드 안전성 문제
  - `Medium` — 테스트 불안정, 아키텍처 원칙 위반
  - `Low` — 명명 규칙, 스타일

---

## 해결 이력

| # | 항목 | 해결 날짜 | 방법 |
|---|------|---------|------|
| — | — | — | — |
