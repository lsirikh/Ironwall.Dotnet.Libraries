---
name: process
description: |
  마스터 오케스트레이터. 모든 개발 관련 요청의 첫 번째 진입점이자
  각 스킬 완료 후 다음 단계를 결정하는 허브.
  기능 추가, 버그 수정, 코드 작성, 리팩토링, 아키텍처 변경, 모듈 신설 등
  어떤 개발 요청이든 이 스킬을 읽어 복잡도와 경로를 먼저 판단한다.
  "프로젝트 설정", "지금 뭐부터 해야 해?", "현재 상태 알려줘",
  "스킬 운영 확인", "이어서 하자", "다음 단계 뭐야" 등에서도 반드시 사용한다.
  analysis, prd, plan, monitoring, test, report 중 어느 스킬이 완료된 직후에도
  이 스킬을 읽어 완료 신호 처리 테이블에 따라 다음 행동을 결정한다.
  "배포해도 돼?", "지금까지 뭐가 됐어?", "얼마나 걸릴 것 같아?" 등
  현황·판단·일정 관련 질문에서도 이 스킬이 session-context를 읽어 답한다.
  "성능이 너무 느려", "보안 취약점 발견했어" 등 기술 이슈도
  즉답인지 PRD가 필요한지 이 스킬이 먼저 판단한다.
  판단이 애매하면 프로세스 쪽으로 기울이는 것이 품질에 유리하다.
---

# Process 스킬 — 마스터 오케스트레이터

## 역할

두 가지 역할을 동시에 수행한다:
1. 요청 라우터 — 새 요청이 들어왔을 때 A/B/C 경로를 결정
2. 완료 허브 — 각 스킬이 완료된 후 다음 단계를 결정하고 컨텍스트를 브리징

규칙을 기계적으로 집행하는 게 아니라, 팀 리드처럼 작업의 흐름 전체를 조율한다.

---

## 매 호출 시 필수 실행 루틴

이 스킬을 읽으면 반드시 아래 순서를 먼저 실행한다. 건너뛰지 않는다.

1. `CLAUDE.md`를 읽어 프로젝트 설정과 처리 규칙을 확인한다
2. `docs/memory/session-context.md`를 읽는다 (파일이 있는 경우)
3. "현재 Phase" 값에 따라 상황을 판단한다:

| 현재 Phase | 판단 및 행동 |
|-----------|-----------|
| 없음 / 완료 | 새 요청에 대해 A/B/C 경로 판단 (아래 라우팅 섹션 실행) |
| prd / plan / dev / test / report | "진행 중인 작업이 있습니다: {활성 PRD/Plan}. 이어서 진행할까요?" |
| 블로킹 [!] 존재 | "이전 작업이 블로킹 상태입니다: {이슈 내용}. 이 문제를 먼저 해결할까요?" |

---

## 라우팅 후 Track 설정 + session-context 갱신

요청 분류 직후 반드시 두 가지를 수행한다:

### 1) Track 설정 (필수)

```bash
node .claude/hooks/advance-phase.js set-track <A|B|C>
```

| Track | 결정 시점 | 사용 예 |
|-------|---------|---------|
| **A** | 코드 수정이 전혀 없는 질의/설명 | "이 함수 뭐 하는 거야?", "구조 파악해줘" |
| **B** | 1~3 파일 소규모 수정 | "변수명 바꿔", "플래그 토글" |
| **C** | 새 기능, 아키텍처 변경, 4파일+ | "기능 만들어줘", "리팩토링하자" |

Track을 설정하지 않으면 Hook이 가장 엄격한 Track C로 폴백한다.

### 2) session-context.md 갱신

| 결정 경로 | 갱신할 "현재 Phase" | 갱신할 "다음 할 일" |
|---------|-----------------|-----------------|
| Track A | `analysis` | `질문에 답변 후 complete 전환` |
| Track B | `analysis` | `dev-journal 엔트리 작성 → dev 전환` |
| Track C | `prd` | `{topic} PRD 작성` |
| 사이클 완료 | `완료` | `다음 작업 대기` |

이 갱신이 이루어져야 새 세션에서 "어떤 Track/Phase였지?"를 정확히 복구할 수 있다.

---

## 요청 라우팅 판단

CLAUDE.md의 A/B/C 판단 기준을 따르되, 이 스킬의 예시 테이블로 보완한다.

### Track C TDD 흐름

Track C의 plan은 TDD 패턴(Red → Green → Refactor)으로 분해된다. plan/SKILL.md "TDD 분해 패턴" 참조.

```
PRD Approved
 → Plan 분해: TEST-XX (Red) → IMPL-XX (Green) → REFAC-XX (Refactor 선택)
   → dev에서 TEST 작성 → test로 가서 fail 확인 (Red)
   → test → dev 백워드 (--reason "[Green] TEST-XX 통과")
   → IMPL 구현 → test로 가서 pass 확인
   → (선택) test → dev 백워드 (--reason "[Refactor] 정리")
 → 모든 IMPL 완료 → test → report → complete
   → complete가 자동으로 PRD를 Completed로 전환 (BUG-1 by process-cleanup-prd)
   → CHANGELOG 자동 갱신
```

### Track별 처리 예시

| 요청 | Track | 처리 |
|------|-------|------|
| "이 함수 어떻게 동작해?" | A | analysis 후 답변 |
| "이 코드 구조 파악해줘" | A | analysis 결과 답변만 (코드 수정 없음) |
| "기술 부채 찾아줘" | A | analysis 결과 답변 |
| "이 변수명 바꿔줘" | B | analysis → dev-journal → dev → test |
| "DEBUG 플래그 끄기" | B | dev-journal 엔트리 후 수정 |
| "이 함수 시그니처 변경" | B | 호출부 1~3개면 B, 많으면 C |
| "로그인 기능 만들어줘" | C | analysis → prd → plan → dev → test → report |
| "MVVM으로 리팩토링하자" | C | analysis → prd → plan → 개발 |
| "이 모듈 성능 개선해줘" | B 또는 C | 범위에 따라 — 사용자 확인 |

### 수치 기반 복잡도 점수 계산 (A/B/C 결정 트리)

주관적 판단을 줄이기 위해 아래 5가지 축으로 점수를 매긴다:

```
축 1: 파일 범위 — 몇 개 파일을 변경하는가?
  1개          → 0점
  2~3개        → 1점
  4개 이상     → 2점

축 2: 아키텍처 영향 — 기존 구조에 영향이 있는가?
  없음          → 0점
  기존 패턴 내  → 1점
  새 패턴/구조  → 2점

축 3: 모듈 연동 — 다른 모듈과 인터페이스가 바뀌는가?
  없음          → 0점
  1개 모듈 연동 → 1점
  2개+ 연동     → 2점

축 4: 테스트 필요성 — 테스트가 필요한가?
  불필요        → 0점
  기존 테스트 수정 → 1점
  새 테스트 작성  → 2점

축 5: 예상 공수
  1시간 이내    → 0점
  1~4시간      → 1점
  4시간 초과    → 2점
```

**점수 합산 → 경로 결정:**

| 합계 | 경로 | 근거 |
|------|------|------|
| 0~2점 | **A. 즉답** | 단순 수정, 단일 파일, 영향 없음 |
| 3~5점 | **B. Analysis** | 코드 파악 필요, 중간 복잡도 |
| 6~10점 | **C. PRD → 프로세스** | 다중 파일, 아키텍처 영향, 테스트 필수 |

**경계선 (합계 3 또는 6):** 사용자에게 확인
"복잡도 점수 {N}점입니다. {A/B} 중 어느 경로로 진행할까요?"

### 판단이 애매한 경우

수치 점수가 경계선이거나 요청이 모호할 때:
"이 작업은 복잡도 {N}점으로 [{경로}] 경로가 적합해 보입니다. 진행할까요?"
라고 제안하고 사용자가 결정하도록 한다.
사용자가 "그냥 바로 해줘"라고 하면 즉답으로 처리해도 된다.

---

## Agent 활용 가이드

각 Phase에서 활용할 수 있는 전문 Agent 목록. Agent는 Soft Recommendation이다 — 강제가 아닌 권장.

| Phase | 추천 Agent | 역할 | 호출 시점 | 필수/선택 |
|-------|-----------|------|---------|---------|
| analysis | architect | 아키텍처 분석, 패턴 식별 | 구조 분석 시 | 선택 |
| plan | planner | 계획 검증, 의존성 분석 | 플랜 리뷰 시 | 선택 |
| dev | code-reviewer | 코드 품질 리뷰 (수정 안 함) | 코드 작성 후 | **권장** |
| dev | tdd-guide | TDD Red→Green→Refactor | 테스트 작성 시 | 선택 |
| dev | build-error-resolver | 빌드 오류 해결 | 빌드 실패 시 | 선택 |
| test | security-reviewer | 보안 취약점 탐지 | 보안 리뷰 시 | 선택 |
| test | tdd-guide | 테스트 실행 가이드 | 테스트 시 | 선택 |
| report | doc-updater | 문서 갱신 (haiku) | 문서 업데이트 시 | 선택 |

### Agent 호출 방법

Agent는 Claude Code의 내장 Agent 도구로 호출한다:
```
"code-reviewer agent를 호출해서 방금 수정한 파일을 리뷰해줘"
```

session-gate.js가 매 턴 PIPELINE STATE에 현재 Phase의 추천 Agent를 표시한다.
Agent 정의는 `.claude/agents/*.md`에 있다.

### Domain Skills 참조

CLAUDE.md의 `language`/`framework` 필드에 따라 session-gate가 자동으로 관련 Domain Skills를 표시한다.
Domain Skills는 `.claude/domain-skills/*.md`에 있다. 새 스킬 추가 시 Hook 수정 불필요.

---

## 완료 신호 처리 (스킬 완료 후 다음 단계 결정)

각 스킬이 완료되면 아래 표에 따라 다음 단계를 즉시 결정하고 제안한다.
사용자가 별도로 다음 단계를 요청하지 않아도 이 표를 따른다.

| 완료 스킬 | 결과 | process의 다음 행동 |
|---------|------|-------------------|
| analysis | 정상 | "분석 완료. 권고된 개선 항목 중 PRD가 필요한 게 있습니다. 어떤 항목부터 시작할까요?" → prd로 컨텍스트 브리징 |
| analysis | 복잡성 과다 (권고 3개↑) | "여러 기능이 필요합니다. 우선순위를 정해 PRD를 하나씩 작성할까요?" |
| prd | 승인 | 즉시 `.claude/skills/plan/SKILL.md` 읽고 plan 실행. analysis 결과 경로 함께 전달 |
| prd | 거부 | "어떤 부분을 수정할까요?" → 피드백 수집 → prd 재작성 모드 재진입 |
| plan | 완료 | "플랜 완성 ({N}개 태스크). [SETUP-01]부터 시작할까요?" → 개발 안내 |
| monitoring | 전체 완료 | plan에 TEST 태스크 있으면 → `.claude/skills/test/SKILL.md` 읽고 test 제안 / 없으면 → report 제안 |
| monitoring | [!] 블로킹 | "블로킹 이슈가 발생했습니다: {내용}. 해결 방법을 찾아볼까요?" |
| test | 전체 통과 | 즉시 `.claude/skills/report/SKILL.md` 읽고 report 실행 |
| test | 실패 있음 | 예외 복구 라우팅 실행 (아래 참조) |
| report | 완료 | "개발 사이클 완료. README 버전을 올리고 다음 기능 개발을 시작할까요?" |

---

## 컨텍스트 브리징 규칙

스킬 간 라우팅 시 아래 컨텍스트를 명시적으로 전달한다.
"A 스킬을 실행하세요"가 아니라 "A 스킬을 이 컨텍스트와 함께 실행하세요"다.

| 라우팅 | 전달할 컨텍스트 |
|--------|--------------|
| analysis → prd | 분석 파일 경로 `docs/analyses/{topic}-analysis.md` 전달. "섹션 7의 다음 단계 제안을 PRD 인터뷰 출발점으로 사용할 것" 명시 |
| prd → plan | PRD 파일 경로 전달. "FR-01~FR-N 목록을 태스크 분해 기반으로 사용할 것. DoD를 plan의 완료 기준에 연결할 것" 명시 |
| plan → 개발 | plan 파일의 첫 번째 `[ ]` 태스크 ID와 파일 경로를 명시. monitoring 스킬이 이 태스크를 `[~]`로 즉시 변경 |
| monitoring 완료 → test | plan 파일 경로와 TEST 태스크 목록 전달. CLAUDE.md의 test_framework 값 함께 전달 |
| test 실패 → monitoring | 실패한 TEST-ID 목록 전달. 연관 IMPL-ID 목록 전달. "해당 태스크를 [!]로 변경할 것" 명시 |
| test 통과 → report | plan 파일 경로, 테스트 결과 파일 경로, PRD 파일 경로를 모두 전달 |
| report → readme | 버전 증가 유형(major/minor/patch) 결정 후 전달. CLAUDE.md의 현재 version 값 전달 |

---

## 예외 복구 라우팅

정상 흐름에서 벗어난 상황에서 복구 경로를 결정한다.

| 예외 상황 | 감지 방법 | 복구 경로 |
|---------|---------|---------|
| test 실패 | test 결과에 실패 항목 존재 | 컨텍스트 브리징 → monitoring 복귀 → 실패 IMPL 태스크 [!] → 수정 후 재테스트. **dev-journal에 실패 원인 기록** |
| prd 거부 | 사용자 "수정 필요" 응답 | 피드백 메모 → prd 재작성. **dev-journal에 거부 사유 + 변경 내용 기록** |
| plan [!] 블로킹 | monitoring이 [!] 태스크 감지 | 사용자에게 블로킹 내용 보고 → 해결 방안 협의 → 해결 후 [~] 재개. **dev-journal에 블로킹→해소 과정 기록** |
| analysis 복잡성 과다 | 권고사항 3개 이상 | "여러 PRD로 분할 권장. 우선순위를 정하면 순서대로 진행합니다." |
| 사이클 완료 후 후속 이슈 | report의 "알려진 이슈" 섹션 | "후속 작업 {N}건이 발견됐습니다. 새 PRD 사이클을 시작할까요?" |
| 세션 중단 후 재개 | session-context.md Phase가 진행 중 | "이전 작업을 이어서 진행합니다. 현재 단계: {Phase}, 다음 할 일: {내용}" |

---

## 복수 작업 우선순위 처리

여러 PRD가 동시에 Approved 상태이거나, report 이후 후속 PRD가 생기거나,
여러 기능 요청이 동시에 들어올 때 아래 순서로 우선순위를 결정한다:

1. 사용자가 명시한 순서 → 사용자 지시 최우선
2. 다른 작업의 선행 조건인 PRD → 먼저 진행
3. 블로킹 이슈가 있는 작업 → 블로킹 해소 우선
4. High 우선순위 FR이 더 많은 PRD → 먼저 진행
5. 모두 동등하면 → 먼저 작성된 PRD 먼저

결정 후 사용자에게 제안: "이 순서로 진행할까요? {PRD1} → {PRD2} → {PRD3}"

---

## 프로세스 단계별 실행

복잡 개발로 판단되면 아래 순서를 안내하고 첫 단계를 시작한다.
각 스킬은 해당 SKILL.md 파일을 직접 읽고 실행한다.

```
0단계: (선택) .claude/skills/analysis/SKILL.md → docs/analyses/{topic}-analysis.md
       ↓ 컨텍스트 브리징 (분석 파일 경로 전달)
1단계: .claude/skills/prd/SKILL.md → docs/prds/{topic}-prd.md
       ↓ 컨텍스트 브리징 (FR/NFR 목록 전달)
2단계: .claude/skills/plan/SKILL.md → docs/plans/{topic}-prd-plan.md
       ↓ 컨텍스트 브리징 (첫 태스크 ID 전달)
3단계: 코드 구현 + .claude/skills/monitoring/SKILL.md로 체크박스 실시간 갱신
       ↓ 완료 신호 → process가 다음 단계 결정
4단계: .claude/skills/test/SKILL.md → docs/tests/{topic}-test-result.md
       ↓ 통과: report 진행 / 실패: 예외 복구 라우팅
5단계: .claude/skills/report/SKILL.md → docs/reports/{topic}-report.md
       ↓ 완료: readme 갱신 + 사이클 종료 선언
```

---

## 단계 전환 게이트 검사

단순 파일 존재 여부를 넘어 내용도 확인한다.

| 전환 | 확인 항목 |
|------|---------|
| analysis → prd | `docs/analyses/{topic}-analysis.md` 존재 + "7. 다음 단계 제안" 섹션 있는지 확인 |
| prd → plan | `docs/prds/{topic}-prd.md` 존재 + 상태가 Draft인지 Approved인지 확인. Draft면 사용자 승인 요청 |
| plan → 개발 | `docs/plans/{topic}-prd-plan.md` 존재 + `[ ]` 태스크가 하나 이상 있는지 확인 |
| 개발 → test | plan에 TEST- 태스크 존재 여부 확인 |
| test → report | 모든 테스트 통과 여부 확인. 실패 있으면 예외 복구 라우팅 실행 |
| → report | 미완료 `[ ]`, `[~]` 태스크 없는지 확인 |

게이트 실패 시 이유와 해결 방법을 설명하고 선행 단계 실행을 제안한다.
단, 사용자가 명시적으로 "그냥 넘어가자"고 하면 따른다.

### dev Phase 재개 상세 절차

session-context.md의 "현재 Phase"가 `dev`인 경우, 아래 순서로 재개 지점을 파악한다:

```
1. 활성 Plan 파일을 읽는다
2. [!] 블로킹 태스크가 있으면 → 블로킹 내용 먼저 보고, 해결 방안 제시
3. [~] 진행 중 태스크가 있으면 → 해당 태스크를 이어서 진행
4. [~]도 [!]도 없으면 → monitoring 의존성 로직으로 "시작 가능" 태스크 중 첫 번째 안내
5. 모든 태스크가 [x]이면 → test 또는 report 단계 제안
```

"이어서 진행합니다. [{태스크 ID}] {태스크명}부터 시작할까요?" 형식으로 제안한다.

---

## Phase 전환 방법 (Hard Gate 시스템)

### pipeline-state.json vs session-context.md 역할 분리

| 파일 | 역할 | 읽는 주체 |
|------|------|---------|
| `docs/memory/pipeline-state.json` | **기계적 상태** — Phase, activePrd, activePlan | pre-tool-gate.js (Hook), advance-phase.js (CLI) |
| `docs/memory/session-context.md` | **인간 맥락** — 작업 이력, 기술 결정, 진행 중 태스크 | Claude (세션 복구 시) |

pipeline-state.json은 Hook이 읽어 Write/Edit 차단 여부를 결정한다.
session-context.md는 Claude가 읽어 맥락을 복구한다.
두 파일의 Phase 값은 항상 동기화되어야 한다.

### Phase 전환 CLI

```bash
node .claude/hooks/advance-phase.js <phase>
node .claude/hooks/advance-phase.js status    # 현재 상태 조회
```

가능한 phase: `setup → analysis → prd → plan → dev → test → report → complete`

게이트 조건 미충족 시 자동으로 에러를 출력하고 전환을 거부한다:
- `plan` 전환: PRD Approved 필수
- `dev` 전환: Plan 파일 + `[ ]` 태스크 존재 필수

### Hard Gate 동작 원리

`pre-tool-gate.js`가 `PreToolUse` Hook으로 등록되어 있다.
Write/Edit/Bash 툴이 실행되기 전에 OS 레벨에서 가로채어:
- Phase가 setup/analysis/prd/plan일 때 **src/ 소스 코드 쓰기를 물리적으로 차단**
- docs/, .claude/, config/, tests/ 등 문서/설정 파일은 **모든 Phase에서 허용**
- pipeline-state.json 누락/파손 시 **안전하게 허용 폴백** (작업 중단 방지)

### Phase 전환 시 process가 해야 할 일

1. `node .claude/hooks/advance-phase.js <phase>` 실행 (pipeline-state.json 갱신)
2. session-context.md의 "현재 Phase" 필드도 동일하게 갱신 (동기화)
3. 두 파일이 불일치하면 pipeline-state.json을 기준으로 session-context.md를 수정

---

## 스킬 의존 관계 참조표

각 스킬 실행 시 입력 조건과 산출물을 명확히 알고 라우팅한다.

| 스킬 | 필요 입력 | 산출물 | 경로 |
|------|---------|--------|------|
| analysis | 프로젝트 코드 | {topic}-analysis.md | `.claude/skills/analysis/SKILL.md` |
| prd | (analysis 결과 또는 사용자 요구사항) | {topic}-prd.md | `.claude/skills/prd/SKILL.md` |
| plan | prd.md | {topic}-prd-plan.md | `.claude/skills/plan/SKILL.md` |
| monitoring | plan.md | plan 파일 인플레이스 수정 | `.claude/skills/monitoring/SKILL.md` |
| test | plan의 TEST 태스크 + 구현 코드 | {topic}-test-result.md | `.claude/skills/test/SKILL.md` |
| report | plan 완료 + (test 결과) | {topic}-report.md | `.claude/skills/report/SKILL.md` |
| memory | (항상 사용 가능) | session-context.md + dev-journal.md | `.claude/skills/memory/SKILL.md` |
| index | (항상 사용 가능) | INDEX.md | `.claude/skills/index/SKILL.md` |
| readme | report.md + CLAUDE.md version | README.md | `.claude/skills/readme/SKILL.md` |
