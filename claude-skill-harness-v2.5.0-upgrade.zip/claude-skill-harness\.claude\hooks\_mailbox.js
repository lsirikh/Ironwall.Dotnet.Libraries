// .claude/hooks/_mailbox.js
// 세션 간 메시지 전달 모듈 — FR-05 (multi-session-coordination)
//
// 메시지 파일: .claude/mailbox/{sessionId}.json
// 각 세션별 독립 파일 — 파일 단위 충돌 없음, lock 불필요
//
// 설계 원칙:
//   - CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS 환경변수 미설정 시 모든 함수는 no-op
//   - 메시징 실패가 전체 훅을 중단시켜선 안 됨 (try/catch, 빈 값 반환)
//   - sessionId에 경로 순회 문자 포함 시 throw (보안 체크)

'use strict';

const fs   = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const MAILBOX_DIR  = path.join(PROJECT_ROOT, '.claude', 'mailbox');

// ── isMultiSession guard ────────────────────────────────────────────

/**
 * AGENT_TEAMS 모드 활성화 여부 확인
 * @returns {boolean}
 */
function isMultiSession() {
  const v = process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS;
  return v === '1' || v === 'true';
}

// ── 보안 체크 ──────────────────────────────────────────────────────

/**
 * sessionId 유효성 검증 — 경로 순회 공격 방지
 * @param {string} sessionId
 * @throws {Error} 위험 문자 포함 시
 */
function validateSessionId(sessionId) {
  if (typeof sessionId !== 'string' || !sessionId) {
    throw new Error(`[_mailbox] Invalid sessionId: ${String(sessionId)}`);
  }
  // 경로 순회 문자 금지: "..", "/", "\", null byte
  if (/\.\.|[/\\]|\x00/.test(sessionId)) {
    throw new Error(`[_mailbox] sessionId contains unsafe characters: ${sessionId}`);
  }
  // 최종 경로가 MAILBOX_DIR 내부인지 검증
  const resolved = path.resolve(MAILBOX_DIR, `${sessionId}.json`);
  if (!resolved.startsWith(path.resolve(MAILBOX_DIR) + path.sep) &&
      resolved !== path.resolve(MAILBOX_DIR, `${sessionId}.json`)) {
    throw new Error(`[_mailbox] sessionId resolves outside mailbox dir: ${sessionId}`);
  }
}

// ── 내부 유틸리티 ─────────────────────────────────────────────────

/**
 * mailbox 디렉토리 존재 확인 및 생성 (방어 코드)
 */
function ensureMailboxDir() {
  try {
    if (!fs.existsSync(MAILBOX_DIR)) {
      fs.mkdirSync(MAILBOX_DIR, { recursive: true });
    }
  } catch { /* 생성 실패는 무시 — 이후 읽기/쓰기에서 오류 처리 */ }
}

/**
 * 세션 파일 경로 반환
 * @param {string} sessionId
 * @returns {string}
 */
function mailboxPath(sessionId) {
  return path.join(MAILBOX_DIR, `${sessionId}.json`);
}

/**
 * 세션 파일 읽기 — 없으면 빈 배열 반환
 * @param {string} sessionId
 * @returns {Array}
 */
function readMailboxFile(sessionId) {
  const filePath = mailboxPath(sessionId);
  try {
    if (!fs.existsSync(filePath)) return [];
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/**
 * 세션 파일 쓰기
 * @param {string} sessionId
 * @param {Array} messages
 */
function writeMailboxFile(sessionId, messages) {
  const filePath = mailboxPath(sessionId);
  fs.writeFileSync(filePath, JSON.stringify(messages, null, 2), 'utf8');
}

/**
 * 간단한 UUID-like ID 생성
 * Date.now()의 base-36 + 랜덤 suffix
 * @returns {string}
 */
function generateId() {
  return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

// ── Public API ──────────────────────────────────────────────────────

/**
 * 대상 세션에 메시지 전송
 *
 * @param {string} toSessionId   - 수신 세션 ID
 * @param {string} type          - 메시지 타입 (phase-change|lead-failover|file-lock|phase-advance-request|info)
 * @param {object} payload       - 메시지 페이로드
 * @param {string} fromSessionId - 발신 세션 ID
 * @returns {object|null} 전송된 메시지 객체, isMultiSession 비활성 또는 오류 시 null
 */
function sendMessage(toSessionId, type, payload, fromSessionId) {
  if (!isMultiSession()) return null;

  // 보안 체크 — 경로 순회 위반은 호출자에게 throw
  validateSessionId(toSessionId);
  if (fromSessionId) validateSessionId(fromSessionId);

  try {
    ensureMailboxDir();

    const messages = readMailboxFile(toSessionId);

    const message = {
      id:        generateId(),
      from:      fromSessionId || 'unknown',
      to:        toSessionId,
      type:      type || 'info',
      payload:   payload || {},
      origin:    'harness',
      timestamp: new Date().toISOString(),
      read:      false
    };

    messages.push(message);
    writeMailboxFile(toSessionId, messages);

    return message;
  } catch (err) {
    // I/O 오류는 훅 전체를 중단시키지 않음
    process.stderr.write(`[_mailbox] sendMessage error: ${err.message}\n`);
    return null;
  }
}

/**
 * 세션의 미읽음 메시지 조회 (read: false)
 * 반환 후 해당 메시지들을 read: true 로 마킹하여 파일에 저장
 *
 * @param {string} sessionId
 * @returns {Array} 미읽음 메시지 배열, isMultiSession 비활성 또는 오류 시 []
 */
function readMessages(sessionId) {
  if (!isMultiSession()) return [];

  // 보안 체크 — 경로 순회 위반은 호출자에게 throw
  validateSessionId(sessionId);

  try {
    ensureMailboxDir();

    const messages = readMailboxFile(sessionId);
    const unread   = messages.filter(m => m.read === false);

    if (unread.length === 0) return [];

    // 미읽음 메시지를 read: true 로 마킹
    const updated = messages.map(m =>
      m.read === false ? { ...m, read: true } : m
    );
    writeMailboxFile(sessionId, updated);

    return unread;
  } catch (err) {
    process.stderr.write(`[_mailbox] readMessages error: ${err.message}\n`);
    return [];
  }
}

/**
 * 세션 파일에서 read: true 항목 제거
 * 최근 50개는 히스토리 디버깅용으로 보관
 *
 * @param {string} sessionId
 * @returns {number} 제거된 메시지 수, isMultiSession 비활성 시 0
 */
function purgeRead(sessionId) {
  if (!isMultiSession()) return 0;

  // 보안 체크 — 경로 순회 위반은 호출자에게 throw
  validateSessionId(sessionId);

  try {
    ensureMailboxDir();

    const messages = readMailboxFile(sessionId);

    // read: false 메시지 (미읽음) 보존
    const unread = messages.filter(m => m.read === false);
    // read: true 메시지 (읽음) — 최근 50개만 보관
    const readMessages = messages.filter(m => m.read === true);
    const keepRead     = readMessages.slice(-50);

    // 최종: 미읽음 전체 + 읽음 최근 50개
    const retained = [...keepRead, ...unread];
    const removed  = messages.length - retained.length;

    if (removed > 0) {
      writeMailboxFile(sessionId, retained);
    }

    return removed;
  } catch (err) {
    process.stderr.write(`[_mailbox] purgeRead error: ${err.message}\n`);
    return 0;
  }
}

/**
 * 활성 세션 전체에 메시지 브로드캐스트
 * 발신자 자신은 제외
 *
 * @param {string}   type           - 메시지 타입
 * @param {object}   payload        - 메시지 페이로드
 * @param {string}   fromSessionId  - 발신 세션 ID
 * @param {string[]} activeSessions - 대상 세션 ID 목록
 * @returns {number} 전송된 메시지 수, isMultiSession 비활성 시 0
 */
function broadcastToAll(type, payload, fromSessionId, activeSessions) {
  if (!isMultiSession()) return 0;

  if (!Array.isArray(activeSessions)) return 0;

  let sent = 0;
  for (const sessionId of activeSessions) {
    // 발신자 자신은 제외
    if (sessionId === fromSessionId) continue;

    const result = sendMessage(sessionId, type, payload, fromSessionId);
    if (result !== null) sent++;
  }

  return sent;
}

// ── exports ────────────────────────────────────────────────────────

module.exports = {
  isMultiSession,
  sendMessage,
  readMessages,
  purgeRead,
  broadcastToAll,
  MAILBOX_DIR
};
