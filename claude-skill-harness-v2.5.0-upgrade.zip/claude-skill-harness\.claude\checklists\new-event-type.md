# 신규 EventType 추가 체크리스트 (I-04)

> 새 `EnumEventType` 값을 추가할 때 반드시 아래 위치를 전수 검토한다.
> 누락 시 특정 이벤트만 심볼/상태가 갱신되지 않는 죽은 코드(P-06) 발생.

---

## 필수 검토 위치

```
[ ] DeviceSymbolLookupModel.ProcessEvent()
    — switch/if 분기에 새 EventType 케이스 추가

[ ] DeviceSymbolLookupModel.ProcessEventReport()
    — 복원 로직에 새 EventType 분기 추가

[ ] SymbolEventManager.SetGroupDetecting / SetDeviceDetecting
    — 상태 매핑 테이블에 새 타입 반영

[ ] EventQueueManager
    — 필터/분기가 있으면 새 타입 포함 여부 확인

[ ] PidsGroupMarkerStyle.xaml
    — DataTrigger 추가 여부 (심볼 색상/모양 변경 필요 시)

[ ] EventCardListPanelViewModel.HandleAsync
    — 카드 생성 분기에 새 타입 케이스 추가

[ ] NatsDomainService
    — NATS 핸들러 분기에 새 타입 처리 추가
```

---

## PRD/Plan 연동

- 신규 EventType PRD 작성 시 위 체크리스트를 **"5. 의존성 및 전제 조건"** 섹션에 포함
- Plan의 IMPL 태스크에 각 검토 위치를 개별 태스크로 분해

---

## 배경

- **P-06**: `DeviceSymbolLookupModel.ProcessEvent(Fault)` 죽은 코드 — Fault 분기 누락으로
  Malfunction 발생 시 FenceGroup 심볼이 Orange로 표시되지 않음
- **발견 시점**: 기능 개발 수개월 후 별도 PRD 분석 중 발견
- **교훈**: 새 EventType 추가 시 모든 switch/if 분기 전수 검토 필수
