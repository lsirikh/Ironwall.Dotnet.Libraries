// .claude/hooks/_git.js
// git 명령 래퍼 + git 초기화 위저드 모듈
//
// IMPL-22: gitRun() + detectGit()                 (FR-26-D)
// IMPL-23: runWizard() — 5단계 git init 시퀀스    (FR-26-B)
// IMPL-24: snapshotPipelineState() + restoreFromSnapshot() (FR-26-A-4)
// IMPL-27: validatePostWizard()                   (사전 구현)
//
// 설계 원칙:
//   - gitRun 인수는 반드시 배열 (injection 방지)
//   - wizard 재진입 지원 (wizard-state.json step 기반 재개)
//   - 스냅샷 없이 wizard 진입 불가 (pre-wizard snapshot required)
//   - 모든 주요 이벤트는 audit-log.jsonl에 기록

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const WIZARD_STATE_PATH = path.join(PROJECT_ROOT, '.claude', 'wizard-state.json');
const AUDIT_LOG = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');
const STATE_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'pipeline-state.json');

// ── Windows PATH 보강 ────────────────────────────────────────────────

/**
 * Windows에서 git.exe 경로가 PATH에 없으면 보강
 * (다른 OS에서는 no-op)
 */
function ensureGitInPath() {
  const commonPaths = [
    'C:\\Program Files\\Git\\cmd',
    'C:\\Program Files (x86)\\Git\\cmd',
  ];
  const pathEnv = process.env.PATH || '';
  for (const p of commonPaths) {
    if (fs.existsSync(p) && !pathEnv.includes(p)) {
      process.env.PATH = p + path.delimiter + pathEnv;
      break;
    }
  }
}
ensureGitInPath();

// ── audit-log 헬퍼 ──────────────────────────────────────────────────

/**
 * audit-log.jsonl에 이벤트 추가 (silent — 실패해도 진행)
 * @param {Object} event
 */
function appendAudit(event) {
  try {
    const entry = JSON.stringify({
      timestamp: new Date().toISOString(),
      ...event
    }) + '\n';
    fs.appendFileSync(AUDIT_LOG, entry);
  } catch { /* silent */ }
}

// ── IMPL-22: gitRun() ────────────────────────────────────────────────

/**
 * git 명령 실행 래퍼
 *
 * 보안: args는 반드시 배열이어야 함 (문자열 interpolation/shell injection 방지).
 * 커밋 메시지 등 사용자 입력이 포함될 경우에도 배열 인수로만 전달할 것.
 *
 * @param {string[]} args — git 서브커맨드 + 인수 배열
 * @param {string} [cwd] — 작업 디렉토리 (기본: PROJECT_ROOT)
 * @returns {string} stdout (trim 적용)
 * @throws {Error} git exit code !== 0 또는 args 타입 오류
 */
function gitRun(args, cwd) {
  if (!Array.isArray(args)) {
    throw new Error('gitRun: args must be an array — never pass a string (injection risk)');
  }
  const result = spawnSync('git', args, {
    cwd: cwd || PROJECT_ROOT,
    encoding: 'utf8',
    env: { ...process.env, GIT_TERMINAL_PROMPT: '0' }
  });
  if (result.status !== 0) {
    const stderr = (result.stderr || '').trim();
    throw new Error(`git ${args[0]} failed: ${stderr}`);
  }
  return (result.stdout || '').trim();
}

// ── IMPL-22: detectGit() ─────────────────────────────────────────────

/**
 * 현재 PROJECT_ROOT가 git 레포 안에 있는지 확인
 * @returns {boolean}
 */
function detectGit() {
  try {
    const result = gitRun(['rev-parse', '--is-inside-work-tree']);
    return result === 'true';
  } catch {
    return false;
  }
}

// ── wizard-state 헬퍼 ────────────────────────────────────────────────

/**
 * wizard-state.json 로드 (파일 없거나 파손 시 기본값 반환)
 * @returns {{ initialized: boolean, step: number|null, started_at: string|null }}
 */
function loadWizardState(wizardStatePath) {
  try {
    if (!fs.existsSync(wizardStatePath)) {
      return { initialized: false, step: null, started_at: null };
    }
    const raw = fs.readFileSync(wizardStatePath, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      initialized: parsed.initialized === true,
      step: typeof parsed.step === 'number' ? parsed.step : null,
      started_at: parsed.started_at || null
    };
  } catch {
    return { initialized: false, step: null, started_at: null };
  }
}

/**
 * wizard-state.json 저장
 * @param {string} wizardStatePath
 * @param {Object} data
 */
function saveWizardState(wizardStatePath, data) {
  fs.writeFileSync(
    wizardStatePath,
    JSON.stringify({ ...data, updated_at: new Date().toISOString() }, null, 2) + '\n'
  );
}

// ── IMPL-23: runWizard() ─────────────────────────────────────────────

/**
 * 5단계 git init 시퀀스
 *
 * 재진입 지원: wizard-state.json의 step을 읽어 해당 단계부터 재개.
 *
 * 단계:
 *   1. git init
 *   2. git config user.name + user.email (설정 없으면 기본값 적용)
 *   3. CHANGELOG.md + README.md 없으면 최소 내용으로 생성
 *   4. git add .
 *   5. git commit -m "chore: initial commit (claude-skill-harness)"
 *
 * 완료 시 wizard-state.json에 initialized: true 저장.
 *
 * @param {string} [wizardStatePath] — wizard-state.json 경로 (기본: WIZARD_STATE_PATH)
 * @returns {void}
 */
function runWizard(wizardStatePath) {
  const wsPath = wizardStatePath || WIZARD_STATE_PATH;
  let state = loadWizardState(wsPath);

  // 이미 완료된 경우 skip
  if (state.initialized) {
    appendAudit({ event: 'wizard-skip', reason: 'already initialized' });
    return;
  }

  // 시작 시각 기록 (최초 진입 시)
  if (state.step === null || state.step === undefined) {
    state.started_at = new Date().toISOString();
    saveWizardState(wsPath, { initialized: false, step: 0, started_at: state.started_at });
    state.step = 0;
  }

  appendAudit({
    event: 'wizard-start',
    resume_from_step: state.step,
    started_at: state.started_at
  });

  // ── 단계 1: git init ────────────────────────────────────────────
  if (state.step < 1) {
    try {
      gitRun(['init']);
      saveWizardState(wsPath, { initialized: false, step: 1, started_at: state.started_at });
      state.step = 1;
      appendAudit({ event: 'wizard-step', step: 1, action: 'git init', status: 'ok' });
    } catch (err) {
      appendAudit({ event: 'wizard-step', step: 1, action: 'git init', status: 'error', error: err.message });
      throw new Error(`Wizard step 1 (git init) failed: ${err.message}`);
    }
  }

  // ── 단계 2: git config user.name + user.email ───────────────────
  if (state.step < 2) {
    try {
      // user.name 확인 — 없으면 기본값 설정
      let userName = '';
      try {
        userName = gitRun(['config', 'user.name']);
      } catch { /* 미설정 상태 */ }
      if (!userName) {
        gitRun(['config', 'user.name', 'Claude Skill Harness']);
        appendAudit({ event: 'wizard-step', step: 2, action: 'set user.name', value: 'Claude Skill Harness' });
      }

      // user.email 확인 — 없으면 기본값 설정
      let userEmail = '';
      try {
        userEmail = gitRun(['config', 'user.email']);
      } catch { /* 미설정 상태 */ }
      if (!userEmail) {
        gitRun(['config', 'user.email', 'skill-harness@localhost']);
        appendAudit({ event: 'wizard-step', step: 2, action: 'set user.email', value: 'skill-harness@localhost' });
      }

      saveWizardState(wsPath, { initialized: false, step: 2, started_at: state.started_at });
      state.step = 2;
      appendAudit({ event: 'wizard-step', step: 2, action: 'git config', status: 'ok' });
    } catch (err) {
      appendAudit({ event: 'wizard-step', step: 2, action: 'git config', status: 'error', error: err.message });
      throw new Error(`Wizard step 2 (git config) failed: ${err.message}`);
    }
  }

  // ── 단계 3: CHANGELOG.md + README.md 생성 (없으면) ──────────────
  if (state.step < 3) {
    try {
      const changelogPath = path.join(PROJECT_ROOT, 'CHANGELOG.md');
      if (!fs.existsSync(changelogPath)) {
        fs.writeFileSync(
          changelogPath,
          '# Changelog\n\nAll notable changes to this project will be documented in this file.\n'
        );
        appendAudit({ event: 'wizard-step', step: 3, action: 'create CHANGELOG.md' });
      }

      const readmePath = path.join(PROJECT_ROOT, 'README.md');
      if (!fs.existsSync(readmePath)) {
        fs.writeFileSync(
          readmePath,
          '# skill-set\n\nClaude Code Hook System (Node.js)\n'
        );
        appendAudit({ event: 'wizard-step', step: 3, action: 'create README.md' });
      }

      saveWizardState(wsPath, { initialized: false, step: 3, started_at: state.started_at });
      state.step = 3;
      appendAudit({ event: 'wizard-step', step: 3, action: 'ensure docs', status: 'ok' });
    } catch (err) {
      appendAudit({ event: 'wizard-step', step: 3, action: 'ensure docs', status: 'error', error: err.message });
      throw new Error(`Wizard step 3 (ensure docs) failed: ${err.message}`);
    }
  }

  // ── 단계 4: git add . ───────────────────────────────────────────
  if (state.step < 4) {
    try {
      gitRun(['add', '.']);
      saveWizardState(wsPath, { initialized: false, step: 4, started_at: state.started_at });
      state.step = 4;
      appendAudit({ event: 'wizard-step', step: 4, action: 'git add .', status: 'ok' });
    } catch (err) {
      appendAudit({ event: 'wizard-step', step: 4, action: 'git add .', status: 'error', error: err.message });
      throw new Error(`Wizard step 4 (git add .) failed: ${err.message}`);
    }
  }

  // ── 단계 5: git commit ──────────────────────────────────────────
  if (state.step < 5) {
    try {
      // 커밋 메시지는 고정 상수 배열로 전달 (사용자 입력 없음 — injection 위험 없음)
      gitRun(['commit', '-m', 'chore: initial commit (claude-skill-harness)']);
      saveWizardState(wsPath, { initialized: true, step: 5, started_at: state.started_at });
      state.step = 5;
      appendAudit({ event: 'wizard-step', step: 5, action: 'git commit', status: 'ok' });
    } catch (err) {
      // 커밋할 변경사항이 없는 경우도 성공으로 처리 (이미 커밋된 상태)
      const msg = (err.message || '').toLowerCase();
      if (msg.includes('nothing to commit') || msg.includes('nothing added')) {
        saveWizardState(wsPath, { initialized: true, step: 5, started_at: state.started_at });
        appendAudit({ event: 'wizard-step', step: 5, action: 'git commit', status: 'nothing-to-commit' });
      } else {
        appendAudit({ event: 'wizard-step', step: 5, action: 'git commit', status: 'error', error: err.message });
        throw new Error(`Wizard step 5 (git commit) failed: ${err.message}`);
      }
    }
  }

  appendAudit({ event: 'wizard-complete', initialized: true });
}

// ── IMPL-24: snapshotPipelineState() ────────────────────────────────

/**
 * wizard 진입 전 pipeline-state.json 스냅샷 생성
 *
 * 파일명 패턴: pipeline-state.{timestamp}.{pid}.bak
 * 스냅샷 실패 시 throw (wizard 진입 차단).
 *
 * @param {string} [stateFilePath] — pipeline-state.json 경로 (기본: STATE_FILE)
 * @returns {string} 생성된 스냅샷 파일 경로
 * @throws {Error} 스냅샷 실패 시
 */
function snapshotPipelineState(stateFilePath) {
  const srcPath = stateFilePath || STATE_FILE;

  if (!fs.existsSync(srcPath)) {
    throw new Error('Pre-wizard snapshot required before git init — pipeline-state.json not found');
  }

  const timestamp = Date.now();
  const bkPath = srcPath.replace(/\.json$/, '') + '.' + timestamp + '.' + process.pid + '.bak';

  try {
    fs.copyFileSync(srcPath, bkPath);
  } catch (err) {
    throw new Error('Pre-wizard snapshot required before git init — copy failed: ' + err.message);
  }

  appendAudit({
    event: 'wizard-snapshot',
    action: 'snapshotPipelineState',
    source: srcPath,
    snapshot: bkPath
  });

  return bkPath;
}

// ── IMPL-24: restoreFromSnapshot() ──────────────────────────────────

/**
 * 스냅샷에서 pipeline-state.json 복원
 * wizard-state.json도 리셋 (initialized: false, step: null).
 *
 * @param {string} bkPath — .bak 파일 경로
 * @returns {void}
 * @throws {Error} bak 파일 없거나 복원 실패 시
 */
function restoreFromSnapshot(bkPath) {
  if (!bkPath || !fs.existsSync(bkPath)) {
    throw new Error('restoreFromSnapshot: snapshot file not found — ' + bkPath);
  }

  // bak → pipeline-state.json 복사
  // bak 파일명에서 원래 경로 추론: *.{timestamp}.{pid}.bak → *.json
  const stateFilePath = bkPath.replace(/\.\d+\.\d+\.bak$/, '.json');
  try {
    fs.copyFileSync(bkPath, stateFilePath);
  } catch (err) {
    throw new Error('restoreFromSnapshot: copy failed: ' + err.message);
  }

  // wizard-state.json 리셋
  try {
    saveWizardState(WIZARD_STATE_PATH, {
      initialized: false,
      step: null,
      started_at: null
    });
  } catch { /* wizard-state 리셋 실패는 non-fatal */ }

  appendAudit({
    event: 'wizard-restore',
    action: 'restoreFromSnapshot',
    snapshot: bkPath,
    restored_to: stateFilePath
  });
}

// ── IMPL-27: validatePostWizard() ────────────────────────────────────

/**
 * wizard 완료 후 검증
 *
 * 검사 항목:
 *   1. detectGit() — git 레포 초기화 확인
 *   2. git config user.name — 설정 확인
 *   3. git config user.email — 설정 확인
 *   4. CHANGELOG.md 존재 확인
 *   5. README.md 존재 확인
 *
 * 결과를 audit-log.jsonl에 { event: 'wizard-validation', checks: [...], passed: N, failed: N } 기록.
 *
 * @returns {string[]} 실패 항목 배열 (모두 통과 시 빈 배열)
 */
function validatePostWizard() {
  const checks = [];
  const failures = [];

  // 1. git 레포 확인
  const isGit = detectGit();
  checks.push({ name: 'detectGit', passed: isGit });
  if (!isGit) failures.push('detectGit: not inside a git work tree');

  // 2. user.name 확인
  let userName = '';
  try { userName = gitRun(['config', 'user.name']); } catch { /* 미설정 */ }
  const hasUserName = userName.length > 0;
  checks.push({ name: 'git.user.name', passed: hasUserName, value: userName || null });
  if (!hasUserName) failures.push('git.user.name: not configured');

  // 3. user.email 확인
  let userEmail = '';
  try { userEmail = gitRun(['config', 'user.email']); } catch { /* 미설정 */ }
  const hasUserEmail = userEmail.length > 0;
  checks.push({ name: 'git.user.email', passed: hasUserEmail, value: userEmail || null });
  if (!hasUserEmail) failures.push('git.user.email: not configured');

  // 4. CHANGELOG.md 확인
  const changelogExists = fs.existsSync(path.join(PROJECT_ROOT, 'CHANGELOG.md'));
  checks.push({ name: 'CHANGELOG.md', passed: changelogExists });
  if (!changelogExists) failures.push('CHANGELOG.md: file not found');

  // 5. README.md 확인
  const readmeExists = fs.existsSync(path.join(PROJECT_ROOT, 'README.md'));
  checks.push({ name: 'README.md', passed: readmeExists });
  if (!readmeExists) failures.push('README.md: file not found');

  appendAudit({
    event: 'wizard-validation',
    checks,
    passed: checks.filter(c => c.passed).length,
    failed: failures.length
  });

  return failures;
}

// ── exports ──────────────────────────────────────────────────────────

module.exports = {
  gitRun,
  detectGit,
  runWizard,
  snapshotPipelineState,
  restoreFromSnapshot,
  validatePostWizard,
  WIZARD_STATE_PATH
};
