# settings.json 설정 가이드

이 파일은 `.claude/settings.json`의 각 설정 항목을 설명합니다.

## 환경변수 (env 섹션)

| 키 | 기본값 | 설명 | 활성화 방법 |
|---|--------|------|-----------|
| `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` | `"0"` | 멀티세션(Agent Teams) 활성화 여부. "1"로 변경 시 Lead/Teammate 역할 분리 및 세션 레지스트리 활성화. | `settings.json`의 `env` 섹션 수정 후 Claude Code 재시작 |
| `max_parallel_sessions` | `"8"` | 동시에 허용되는 최대 세션 수. 초과 시 대기 큐에 진입. | `settings.json` 수정 |
| `file_conflict_policy` | `"warn"` | 파일 충돌 정책. `"warn"` = 경고만 출력 / `"block"` = 완전 차단 | `settings.json` 수정 |
| `session_heartbeat_timeout_s` | `"60"` | 세션 heartbeat 만료 기준(초). 이 시간 이상 heartbeat 없으면 dead 세션으로 판단하고 Failover 발동. | `settings.json` 수정 |

## 상세 설명

### CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS

**목적**: 여러 Claude Code 세션이 동시에 같은 프로젝트에 접근할 수 있게 함.

**활성화 절차**:
1. `.claude/settings.json` 열기
2. `"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "0"` → `"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"`로 변경
3. Claude Code 완전히 종료 후 다시 시작
4. 팀 생성 UI에서 세션 역할 확인

**활성화 후 동작**:
- 첫 세션 자동 Lead 등록 (Phase 전환 권한)
- 이후 세션 자동 Teammate 등록 (파일 작업만 가능)
- Lead 크래시 감지 → 가장 오래된 Teammate 자동 승격

### max_parallel_sessions

**목적**: 과도한 병렬 세션이 시스템에 부하를 주지 않도록 제한.

**기본값**: 8

**조정 시점**:
- 로컬 개발: 기본값 유지
- CI/CD 서버: 4~6으로 낮춈
- 고성능 머신: 12~16으로 높임

### file_conflict_policy

**목적**: 다른 세션이 소유한 파일을 현재 세션이 수정할 때의 동작 정의.

**값별 동작**:

| 값 | 동작 | 사용 시기 |
|----|------|---------|
| `"warn"` | 경고 표시 후 계속 진행 (파일 소유권 무시) | 협업 개발, 자유로운 편집 필요 |
| `"block"` | 완전 차단 (파일 편집 거부) | 엄격한 세션 격리 필요 |

**파일 소유권 추적**:
- 파일을 생성/수정한 세션이 "소유자"
- `post-write-sync.js`가 자동 기록
- `pipeline-state.json`의 `fileOwnership` 섹션 관리

### session_heartbeat_timeout_s

**목적**: 응답 불가 상태의 세션을 자동 감지하고 Failover 실행.

**기본값**: 60초

**동작 흐름**:
1. 각 세션은 10초마다 heartbeat를 `.claude/_sessions.js` 레지스트리에 기록
2. 60초 이상 heartbeat 없으면 "dead" 판정
3. session-gate.js가 자동 감지 → audit-log에 기록
4. Lead가 dead 상태 → 가장 오래된 Teammate 자동 승격
5. session-context.md에 "Failover 발생" 주석 추가

**조정 시점**:
- 매우 느린 네트워크: 120초 이상
- 로컬 개발: 기본값 유지
- 매우 빠른 환경: 30초로 낮춤 (불필요한 failover 주의)

---

## 실전 예시

### 예시 1: 멀티세션으로 협업 개발

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
    "max_parallel_sessions": "8",
    "file_conflict_policy": "warn",
    "session_heartbeat_timeout_s": "60"
  }
}
```

**시나리오**:
- Alice (세션 1, Lead): 사용자 인증 기능 작업 중
- Bob (세션 2, Teammate): API 엔드포인트 작업 중
- 둘 다 `src/utils.py` 수정 필요 → 경고만 표시, 병렬 진행 가능

### 예시 2: 엄격한 세션 격리

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
    "max_parallel_sessions": "4",
    "file_conflict_policy": "block",
    "session_heartbeat_timeout_s": "60"
  }
}
```

**시나리오**:
- 자동화 테스트 환경
- 각 세션이 명확히 다른 폴더 담당
- 파일 충돌 절대 방지

### 예시 3: 로컬 빠른 응답 환경

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
    "max_parallel_sessions": "8",
    "file_conflict_policy": "warn",
    "session_heartbeat_timeout_s": "30"
  }
}
```

**시나리오**:
- 로컬 머신에서 빠른 개발
- 응답이 빠르므로 heartbeat 타임아웃을 30초로 단축
- 응답 불가 상태를 빨리 감지

---

## 트러블슈팅

### "멀티세션이 활성화되지 않음"
- `settings.json`을 수정했나? → 재확인
- Claude Code를 재시작했나? → 재시작 필수 (설정은 세션 시작 시에만 로드됨)

### "TEAMMATE가 Phase 전환을 할 수 없음"
- 정상 동작. Teammate는 파일 작업만 가능.
- Lead에게 Phase 전환 요청 필요 (또는 Lead가 명령 공유)

### "파일 충돌 경고가 계속 나타남"
- `file_conflict_policy`를 `"warn"`으로 설정했기 때문
- 다른 세션의 파일 수정이 필요 없으면 `"block"`으로 변경

### "Failover가 자주 발생"
- `session_heartbeat_timeout_s`가 너무 짧을 수 있음
- 60초 이상으로 조정 시도

---

## 참고

- 더 자세한 멀티세션 운영 방법은 `docs/Manual.md` 9장 참조
- 세션 레지스트리 상세: `.claude/hooks/_sessions.js`
- Heartbeat/Failover 로직: `.claude/hooks/session-gate.js`
