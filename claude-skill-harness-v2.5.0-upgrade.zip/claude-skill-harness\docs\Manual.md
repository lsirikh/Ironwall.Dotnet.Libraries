# Skill Set Manual — Claude Code 개발 프로세스 강제 시스템

> **버전**: 2.5.0
> **대상**: Claude Code를 사용해 소프트웨어를 개발하는 모든 사용자
> **목적**: 이 시스템을 처음 접한 사람도 30분 안에 설치하고 실전에 적용할 수 있게 한다

---

## 0. TL;DR (1분 이해)

이 시스템은 **Claude Code가 "코드부터 짜고 보자"는 충동을 OS 레벨에서 차단**하고, 요청 복잡도에 맞는 적절한 개발 프로세스를 강제한다.

```
사용자 요청 → 복잡도 판단 → 3-Track 중 하나로 라우팅
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        ▼                          ▼                          ▼
   Track A (단순답변)         Track B (간단작업)         Track C (복합작업)
   질문/설명만                1~3 파일 수정             새 기능/아키텍처
                                                                  
   analysis → complete       analysis → dev-journal    analysis → prd → plan
                              → dev → test → complete  → dev → test → report
                                                       → complete

   ★ 코드 수정 없음          ★ dev-journal 필수        ★ PRD/Plan 필수
```

**핵심 약속**:
- Track A: 코드 수정이 **OS 레벨에서 차단**된다
- Track B: dev-journal 엔트리 없이 코드 수정 **���가**
- Track C: PRD가 Approved 상���가 아니면 plan/dev 진입 **불가**
- 모든 단계 전환은 `advance-phase.js`만 가능 (`pipeline-state.json` 직접 편집 차단)
- `test_command` 설정 시: 테스트 실패하면 **자동으로 dev 복귀** (최대 3회)
- `lint_command` 설정 시: src/ 코드 작성 후 **자동 린트 실행** + 결과 주입

---

## 1. 개요

### 1.1 이 시스템이 해결하는 문제

LLM 기반 개발 도구의 가장 큰 약점은 **"규칙을 읽고도 무시할 수 있다"**는 것이다. 프롬프트로 "PRD부터 작성해야 한다"고 지시해도, Claude는 컨텍스트가 길어지거나 사용자가 급박해 보이면 그 규칙을 건너뛴다.

이 시스템은 그 문제를 **"규칙을 읽고 무시하는 구조"가 아닌 "OS가 먼저 차단하고 Claude에게 통보하는 구조"**로 전환한다.

### 1.2 핵심 아이디어 — Hard Gate vs Soft Gate

```
Soft Gate (전통적 방식)              Hard Gate (이 시스템)
─────────────────────                ─────────────────────
프롬프트로 규칙 지시                  Hook이 OS 레벨에서 차단
"Plan을 먼저 작성하세요"              Plan 없으면 src/ Write 도구 자체가 거부됨
↓                                    ↓
Claude가 읽고 따를지 선택              Claude는 선택권 없음
↓                                    ↓
이탈 가능                            물리적 차단
```

### 1.3 시스템 구조 (3계층)

```
┌─────────────────────────────────────────────────────────────┐
│  사용자 요청 (User Request)                                   │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
╔═══════════════════════════════════════════════════════════════╗
║  Layer 1. 강제 계층 (Hooks — OS 레벨 차단)                    ║
║  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐         ║
║  │ session-gate │ │ pre-tool-gate│ │post-write-   │         ║
║  │ (UserPrompt) │ │ (PreToolUse) │ │sync(PostTool)│         ║
║  │ 상태 주입     │ │ Write/Bash   │ │ 자동 갱신     │         ║
║  │              │ │ 차단         │ │              │         ║
║  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘         ║
║         │                │                │                  ║
║         └────────────────┼────────────────┘                  ║
║                          ▼                                   ║
║          ┌─────────────────────────────┐                     ║
║          │  pipeline-state.json (상태)  │                     ║
║          │  { phase, track, artifacts } │                     ║
║          └─────────────────────────────┘                     ║
╚═══════════════════════════════════════════════════════════════╝
                              │
                              ▼
╔═══════════════════════════════════════════════════════════════╗
║  Layer 2. 오케스트레이션 (CLAUDE.md + process 스킬)            ║
║  Track 판단, 스킬 라우팅, 컨텍스트 브리징                     ║
╚═══════════════════════════════════════════════════════════════╝
                              │
                              ▼
╔═══════════════════════════════════════════════════════════════╗
║  Layer 3. 실행 계층 (12개 SKILL.md)                           ║
║  analysis · prd · plan · monitoring · test · report ·         ║
║  memory · index · readme · changelog · process                ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 2. 설치 방법

### 2.1 사전 요구사항

| 항목 | 버전 | 비고 |
|------|------|------|
| **Claude Code** | 최신 | https://claude.com/claude-code |
| **Node.js** | v16+ | Hook 실행에 필요 |
| **Git** (선택) | 최신 | 버전 관리용 |

OS는 Windows / macOS / Linux 모두 지원한다 (경로 정규화 포함).

### 2.2 설치 단계

#### Step 1 — 압축 해제

```bash
# 프로젝트 루트로 이동
cd /path/to/your/project

# 압축 해제 — claude-skill-harness/ 폴더가 생성됨
# Windows PowerShell:
Expand-Archive -Path claude-skill-harness-v2.2.0.zip -DestinationPath . -Force

# macOS/Linux:
unzip claude-skill-harness-v2.2.0.zip
```

#### Step 2 — 인스톨러 실행

```bash
cd claude-skill-harness
node install.js
```

인스톨러가 자동으로 처리하는 항목:
- `.claude/hooks/`, `.claude/skills/`, `.claude/agents/` 등 복사
- `settings.json` Hook 등록 (기존 사용자 Hook 보존하며 병합)
- `.gitignore` 하네스 섹션 생성/병합 (기존 .gitignore 보존)
- `CLAUDE.md` 템플릿 설치 (기존 yaml 설정이 있으면 보존+마이그레이션)
- `pipeline-state.json`, `session-context.md` 등 상태 파일 초기화

기존 하네스가 설치된 프로젝트라면 `--upgrade` 플래그를 사용한다:

```bash
node install.js --upgrade    # 상태/학습 데이터 보존하며 업그레이드
node install.js --rollback   # 직전 백업에서 복원
node install.js --target /other/project  # 다른 경로에 설치
```

#### Step 3 — 설치 검증

```bash
node .claude/hooks/advance-phase.js status
```

기대 출력:
```
[STATUS] phase: setup
  track:      (미설정 -> C 폴백)
  activePrd:  없음
  activePlan: 없음
  허용 경로:  setup -> analysis -> prd -> plan -> dev -> test -> report -> complete
```

#### Step 4 — 정리 (선택)

설치 완료 후 추출 폴더를 삭제할 수 있다:

```bash
cd ..
rm -rf claude-skill-harness
```

### 2.3 첫 실행 — CLAUDE.md 프로젝트 설정

Claude Code 세션을 시작하면 CLAUDE.md의 "세션 시작 루틴"이 자동으로 발동되어 6개 항목을 묻는다:

```
1. 프로젝트 이름
2. 주 개발 언어 (C#, Python, TypeScript, ...)
3. 프레임워크/플랫폼 (FastAPI, React, .NET, ...)
4. 테스트 프레임워크 (pytest, Jest, xUnit, ...)
5. 패키지 매니저 (pip, npm, NuGet, ...)
6. 코딩 컨벤션 특이사항 (없으면 "언어 기본값")
```

답변하면 CLAUDE.md의 yaml 블록이 자동 갱신된다. 이 인터뷰가 끝나야 본격적인 작업이 시작된다.

### 2.4 Harness Loop 설정 (선택)

CLAUDE.md yaml 블록에 아래 필드를 추가하면 **자동 교정 루프**와 **코드 품질 게이트**가 활성화된다:

```yaml
test_command: "pytest tests/ -x --tb=short"   # 테스트 실행 명령 (빈 문자열 = 비활성화)
lint_command: "ruff check src/"                # 린트 실행 명령 (빈 문자열 = 비활성화)
max_auto_fix: 3                                # 자동 수정 시도 횟수 (기본 3)
```

| 필드 | 동작 | 미설정 시 |
|------|------|---------|
| `test_command` | `advance-phase.js test` 실행 시 자동 테스트. 실패 → dev 자동 복귀 | 기존 수동 모드 |
| `lint_command` | src/ 파일 Write/Edit 후 자동 린트. 결과를 다음 메시지에 주입 | 린트 없음 |
| `max_auto_fix` | test→dev 자동 복귀 최대 횟수. 초과 시 사용자 개입 요청 | 3회 |

**예시 설정 (프로젝트별)**:

| 프로젝트 | test_command | lint_command |
|---------|-------------|-------------|
| Python (pytest) | `pytest tests/ -x --tb=short` | `ruff check src/` |
| Node.js (jest) | `npx jest --bail` | `npx eslint src/` |
| .NET (xUnit) | `dotnet test --no-build` | `dotnet format --verify-no-changes` |
| Go | `go test ./...` | `golangci-lint run` |

### 2.5 설치 검증 체크리스트

```
□ node .claude/hooks/advance-phase.js status 가 정상 출력
□ Claude Code에서 새 메시지 작성 시 PIPELINE STATE 박스가 자동 주입됨
□ docs/memory/pipeline-state.json 파일이 자동 생성됨
□ .gitignore에 Claude Skill Harness 섹션이 포함됨
□ Track 미설정 상태에서 src/ Write 시도 시 차단 메시지 출력
```

---

## 3. 핵심 개념

### 3.1 3-Track 파이프라인

이 시스템의 가장 중요한 결정은 **요청 복잡도에 맞는 경로를 선택**하는 것이다.

#### Track A — 단순답변

```
Phase: setup → analysis → complete
산출물: (없음, 답변 자체)
```

**언제 사용?** 코드를 수정하지 않는 모든 요청.

| 예시 |
|------|
| "이 함수 뭐 하는 거야?" |
| "이 모듈 구조 파악해줘" |
| "기술 부채 어디 있어?" |
| "이 라이브러리 어떻게 동작해?" |

**Hook 동작**: dev Phase 자체가 허용되지 않음. src/ 쓰기 시도 시 즉시 차단.

#### Track B — 간단작업

```
Phase: setup → analysis → dev → test → complete
                          ↑ dev-journal 필수
산출물: dev-journal 엔트리
```

**언제 사용?** 1~3 파일 소규모 수정. 새 기능 추가가 아닌 변경.

| 예시 |
|------|
| "변수명을 snake_case로 바꿔" |
| "DEBUG 플래그를 False로" |
| "이 함수에 None 체크 추가" |
| "import 정렬해줘" |

**Hook 동작**:
- dev Phase 진입 시 `docs/memory/dev-journal.md` 에 작업 엔트리가 있어야 함
- 엔트리 없으면 src/ Write 차단

**dev-journal 엔트리 형식 (Hook이 검증)**:
```markdown
### [2026-04-10 14:30] DEBUG 플래그 비활성화
- **Track**: B
- **대상**: src/config.py — `DEBUG = True` → `DEBUG = False`
- **이유**: 프로덕션 배포 전 디버그 모드 끄기 (보안 정책)
- **영향**: 로깅 레벨 변경. 테스트 1건 영향
- **테스트**: pytest tests/test_config.py 통과
- **완료**: ✅
```

#### Track C — 복합작업

```
Phase: setup → analysis → prd → plan → dev → test → report → complete
                          ↑              ↑              ↑
                       PRD 필수      Plan 필수     test-result 필수
산출물: PRD + Plan + 코드 + 테스트 결과 + 리포트
```

**언제 사용?** 새 기능, 아키텍처 변경, 4파일 이상 수정.

| 예시 |
|------|
| "로그인 기능 만들어줘" |
| "MVVM으로 리팩토링" |
| "API v2 마이그레이션" |
| "결제 모듈 추가" |

**Hook 동작 (Phase별)**:
- `prd → plan`: PRD 상태가 `Approved`여야 함
- `plan → dev`: Plan 파일에 `[ ]` 태스크가 존재해야 함
- `dev → test`: IMPL 태스크의 80% 이상이 `[x]` 완료되어야 함
- `test → report`: `docs/tests/` 에 결과 파일이 존재해야 함
- `report → complete`: Plan에 미완료 태스크 0개

### 3.2 Track 판단 기준 (5축 점수)

복잡도를 5개 축으로 0~2점씩 점수화하여 합산한다.

| 축 | 0점 | 1점 | 2점 |
|----|-----|-----|-----|
| 파일 범위 | 0개 (읽기만) | 1~3개 | 4개+ |
| 아키텍처 영향 | 없음 | 기존 패턴 내 | 새 패턴/구조 |
| 모듈 연동 | 없음 | 1개 | 2개+ |
| 테스트 필요 | 불필요 | 기존 수정 | 새 작성 |
| 예상 공수 | 즉시 | 1h 이내 | 1h+ |

```
합계 → Track:
  0~2점  →  Track A (단순답변)
  3~5점  →  Track B (간단작업)
  6~10점 →  Track C (복합작업)
```

경계선(3, 6)에서는 Claude가 "Track [A/B/C]로 진행하는 게 적합해 보입니다. 진행할까요?"라고 사용자에게 확인한다.

### 3.3 Phase 진행 단계

```
                              Phase 흐름

  setup           analysis        prd           plan          
   │               │              │             │             
   ▼               ▼              ▼             ▼             
┌─────────┐   ┌──────────┐   ┌───────┐   ┌────────┐         
│프로젝트  │   │코드베이스 │   │요구사항│   │태스크  │         
│설정     │   │분석      │   │정의   │   │분해    │         
│         │   │          │   │       │   │        │         
│CLAUDE   │   │{topic}-  │   │{topic}│   │{topic} │         
│.md yaml │   │analysis  │   │-prd   │   │-prd-   │         
│         │   │.md       │   │.md    │   │plan.md │         
└─────────┘   └──────────┘   └───────┘   └────────┘         

           dev          test          report        complete
            │            │             │             │      
            ▼            ▼             ▼             ▼      
       ┌────────┐   ┌────────┐   ┌────────┐   ┌────────┐
       │코드    │   │테스트  │   │완료    │   │사이클  │
       │구현    │   │실행    │   │정리    │   │종료    │
       │        │   │        │   │        │   │        │
       │src/    │   │tests/  │   │{topic} │   │PRD →   │
       │작성    │   │실행    │   │-report │   │Comple- │
       │        │   │결과    │   │.md     │   │ted    │
       └────────┘   └────────┘   └────────┘   └────────┘
```

### 3.4 dev-journal의 역할

`docs/memory/dev-journal.md`는 두 가지 다른 역할을 한다:

#### 역할 1 — Track B의 핵심 산출물 (필수)

Track B에서는 PRD/Plan을 작성하지 않으므로 dev-journal이 **유일한 변경 추적 수단**이다. Hook이 엔트리 존재를 강제한다.

#### 역할 2 — Track C 개발 중 시행착오 기록 (권장)

Track C 개발 중 만나는 에러, 우회, 기술 결정 변경을 기록한다. 이 내용은 나중에 report 스킬이 자동으로 읽어 "시행착오 및 기술 결정 과정" 섹션을 생성한다.

#### 두 형식의 차이

```markdown
# Track B 형식 (간결, Hook 강제)
### [2026-04-10 14:30] 작업 제목
- **Track**: B
- **대상**: src/...
- **이유**: ...
- **영향**: ...
- **완료**: ✅

# Track C 시행착오 형식 (상세, 권장)
### 2026-04-10 14:30 — 작업 제목
- **상황**: 무엇을 하려고 했는가
- **시도**: 어떤 방법을 시도했는가
- **결과**: 성공/실패, 에러 메시지
- **원인**: 왜 실패했는가
- **해결**: 최종 해결 방법
- **영향**: 다른 코드/설계에 미친 영향
- **관련**: 태스크 ID, 파일 경로
```

---

## 4. 사용법 — 일상 워크플로우

### 4.1 새 작업 시작 시

매번 Claude Code 메시지를 보낼 때마다 **PIPELINE STATE 박스가 자동으로 주입**된다:

```
╔══════════════════════════════════════════════════════════════╗
║  PIPELINE STATE (Hook 강제 주입 — 무시 불가)                  ║
╠══════════════════════════════════════════════════════════════╣
║  Phase: dev        Track: C           Project: my-app  v0.1.0
║  Active PRD:  docs/prds/login-prd.md
║  Active Plan: docs/plans/login-prd-plan.md
║  Progress:    8/12(67%) [진행:1 블로킹:0 대기:3]
╠══════════════════════════════════════════════════════════════╣
║  ▶ ACTION REQUIRED:
║    1. Resume: IMPL-09 비밀번호 해시 함수 구현
╠══════════════════════════════════════════════════════════════╣
║  ▶ 매 응답 전: CLAUDE.md A/B/C 복잡도 점수 판단 필수
║  ▶ 매 응답 후: session-context.md(Rule1) + INDEX.md(Rule2)
╚══════════════════════════════════════════════════════════════╝
```

이 박스가 있으면 Claude는 "지금 어떤 상태인지 모르겠다"고 할 수 없다.

### 4.2 Track 결정 가이드

```
사용자 요청 도착
    │
    ▼
┌───────────────────────────┐
│ 코드 수정이 필요한가?       │
└──────┬─────────┬──────────┘
       │         │
      No        Yes
       │         │
       ▼         ▼
   Track A   ┌─────────────────────────┐
             │ 4파일 이상 수정인가?      │
             │ 새 기능/아키텍처 변경?   │
             └────┬─────────┬──────────┘
                  │         │
                 No        Yes
                  │         │
                  ▼         ▼
              Track B   Track C
```

### 4.3 Track A 실전 예시

```
사용자: "이 utils.py 파일이 어떤 역할을 하는지 설명해줘"

Claude: [복잡도 판단: 코드 수정 없음 → Track A]
        → set-track A 실행 (또는 이미 A면 생략)
        → utils.py를 Read로 읽음
        → 답변
        → analysis 완료, complete으로 전환

산출물: 답변 텍스트 (파일 생성 없음)
```

### 4.4 Track B 실전 예시

```
사용자: "config.py에서 DEBUG 플래그를 False로 바꿔"

Claude: [복잡도 판단: 단일 파일 수정 → Track B]
        → set-track B 실행
        → config.py 읽기
        → dev-journal.md에 엔트리 작성:
          ### [2026-04-10 14:30] DEBUG 플래그 비활성화
          - Track: B
          - 대상: src/config.py
          - 이유: 프로덕션 배포 준비
          - 영향: 로깅 레벨 변경
        → advance-phase.js dev → 통과 (dev-journal 게이트 충족)
        → Edit src/config.py
        → test 실행
        → dev-journal에 "완료: ✅" 추가
        → complete 전환

산출물: dev-journal 엔트리 + 수정된 src/config.py
```

### 4.5 Track C 실전 예시

```
사용자: "사용자 로그인 기능을 만들어줘"

Claude: [복잡도 판단: 새 기능, 다중 파일 → Track C]
        → set-track C 실행
        → analysis 단계: 기존 코드 분석
        → docs/analyses/login-analysis.md 작성
        → advance-phase.js prd
        → docs/prds/login-prd.md 작성 (FR/NFR/리스크/DoD)
        → 사용자 승인 대기

사용자: "OK, 진행해"

Claude: → PRD 상태를 Approved로 변경
        → advance-phase.js plan (PRD Approved 게이트 통과)
        → docs/plans/login-prd-plan.md 작성 (12개 태스크)
        → advance-phase.js dev (Plan + [ ] 태스크 게이트 통과)
        → src/auth/login.py 등 작성
        → 태스크 완료마다 [x] 표시
        → advance-phase.js test (IMPL 80%+ 게이트 통과)
        → tests/auth/test_login.py 작성 + 실행
        → docs/tests/login-test-result.md 작성
        → advance-phase.js report (test-result 게이트 통과)
        → docs/reports/login-report.md 작성 (ADR 포함)
        → advance-phase.js complete (미완료 태스크 0개 게이트 통과)

산출물: analysis + PRD + Plan + 코드 + 테스트 + 리포트 = 5개 문서 + 코드
```

---

## 5. 명령어 레퍼런스

### 4.6 Feedback Loop — 백워드 전환

현실의 개발은 직선이 아니다. 테스트에서 버그가 발견되면 dev로 돌아가고, 개발 중 계획을 수정한다.

**허용되는 백워드 전환** (whitelist):

| 전환 | 의미 |
|------|------|
| `test → dev` | 테스트 실패로 코드 수정 |
| `test → plan` | 테스트 결과로 태스크 추가 |
| `dev → plan` | 개발 중 계획 수정 |
| `plan → prd` | 계획 중 요구사항 변경 |
| `report → dev` | 리포트 중 추가 수정 |
| `report → test` | 추가 테스트 필요 |
| `complete → analysis` | 새 사이클 시작 |

**사용법**:

```bash
# 백워드 전환 시 --reason 필수
node .claude/hooks/advance-phase.js dev --reason "FR-05 비동기 race condition"
```

`--reason` 없이 백워드 시도 → 차단됨.

**자동 처리**:
1. `iterations` 카운터 자동 증가 (`pipeline-state.json`)
2. `dev-journal.md`에 자동 엔트리 추가:
   ```markdown
   ### [2026-04-10 14:30] 🔁 test → dev (2회차)
   - 이유: ...
   ```
3. `audit-log.jsonl`에 `backward-transition` 이벤트 기록
4. 동일 백워드 5회 초과 시 경고 (차단은 아님)

### 5.0 CHANGELOG vs README — 책임 분리

이 시스템은 두 파일을 **완전히 다른 메커니즘**으로 관리한다:

| 항목 | CHANGELOG.md | README.md |
|------|------------|---------|
| 갱신 시점 | Track C complete 자동 | 사용자 요청 시만 |
| 갱신 방식 | 추가만 (append-only) | 전체 재작성 |
| 답하는 질문 | "언제 무엇이 바뀌었나?" | "이 프로젝트가 뭐야?" |
| 관리 주체 | `advance-phase.js` + changelog 스킬 | readme 스킬 |
| 자동 트리거 | ✅ 있음 | ❌ 없음 |
| 사용자 요청 | "변경 이력 보여줘" | "README 갱신해줘" |

**버전 체계**: X.Y.Z 작업 로그형
- **X**: 사람 수동 (`bump-major`)
- **Y**: 날짜 변경 시 +1 (Z=0 리셋)
- **Z**: Track C 사이클 완료마다 +1

CHANGELOG는 `Track C` 사이클이 종료될 때만 기록된다. Track A/B는 기록되지 않는다.

### 5.1 advance-phase.js

이 시스템에서 **유일하게 허용된 Phase 전환 도구**이다. `pipeline-state.json` 직접 편집은 차단된다.

#### 5.1.1 status — 현재 상태 조회

```bash
node .claude/hooks/advance-phase.js status
```

출력 예:
```
[STATUS] phase: dev
  track:      C
  activePrd:  docs/prds/login-prd.md
  activePlan: docs/plans/login-prd-plan.md
  허용 경로:  setup → analysis → prd → plan → dev → test → report → complete
```

#### 5.1.2 set-track — Track 설정

```bash
node .claude/hooks/advance-phase.js set-track A    # 단순답변
node .claude/hooks/advance-phase.js set-track B    # 간단작업
node .claude/hooks/advance-phase.js set-track C    # 복합작업
```

#### 5.1.3 Phase 전환

```bash
node .claude/hooks/advance-phase.js setup
node .claude/hooks/advance-phase.js analysis
node .claude/hooks/advance-phase.js prd
node .claude/hooks/advance-phase.js plan
node .claude/hooks/advance-phase.js dev
node .claude/hooks/advance-phase.js test
node .claude/hooks/advance-phase.js report
node .claude/hooks/advance-phase.js complete
```

각 전환은 게이트 조건을 검증하고, 미충족 시 차단 메시지를 출력한다.

#### 5.1.4 new-cycle — 정식 사이클 재시작

```bash
node .claude/hooks/advance-phase.js new-cycle "결제 모듈 추가"
```

`complete` 단계에서 새 사이클을 시작할 때 사용. 자동으로:
- `complete → analysis` 전환
- `activePrd`, `activePlan`, `iterations` 리셋
- session-context "다음 할 일" 갱신
- audit-log에 `new-cycle` 이벤트 기록

`complete`이 아닌 phase에서는 `--force` 필요 (작업 중단 방지).

#### 5.1.5 bump-major — 메이저 버전 수동 증가

```bash
node .claude/hooks/advance-phase.js bump-major
```

`X.Y.Z` → `(X+1).0.0`. CHANGELOG.md에 메이저 마커 추가 + CLAUDE.md version 갱신 + audit-log 기록.

큰 이정표(외부 공개, 호환성 깨짐) 시 사용한다.

#### 5.1.5 approve — PRD 사용자 명시 승인 (필수)

```bash
node .claude/hooks/advance-phase.js approve prd "코멘트"
```

PRD가 `Draft` 상태일 때 사용자가 승인하는 유일한 방법. 자동으로:
- PRD 상태 `Draft` → `Approved`
- 변경 이력 테이블에 사용자 승인 행 추가 (PRD 본문의 실제 버전 자동 추출)
- audit-log에 `user-approval` 이벤트 기록
- session-context "다음 할 일" 갱신

**중요**: Claude는 PRD를 직접 `Approved`로 변경할 수 없다. `pre-tool-gate.js`가 OS 레벨에서 차단한다 (신규 파일 + Draft 작성은 예외).

#### 5.1.6 사이클 종료 자동 처리

`advance-phase.js complete` 트리거 시 (Track C) 자동 수행:
1. **artifacts 갱신**: 가장 최근 PRD/Plan으로 강제 교체
2. **PRD 자동 Completed**: active PRD를 `Approved` → `Completed` 전환 + 변경 이력 자동 추가
3. **CHANGELOG 갱신**: 새 X.Y.Z 엔트리 자동 추가 (멱등성 보장)
4. **CLAUDE.md version**: 자동 갱신
5. **INDEX.md**: 자동 재구축

#### 5.1.7 --force — 긴급 우회

```bash
node .claude/hooks/advance-phase.js dev --force
```

모든 게이트 검증을 스킵한다. 단:
- `audit-log.jsonl`에 `force-phase-override` 이벤트가 자동 기록됨
- 다음 세션에서 session-gate.js가 "force-override 발생" 리마인더를 주입할 수 있음
- 핫픽스/오탐 회피 외에는 사용 금지

### 5.2 차단 메시지 해석

```
[GATE BLOCKED] Track C 경로 검증 실패
이유: Track A는 'dev' Phase를 허용하지 않음. 허용 경로: setup → analysis → complete
긴급 우회: node .claude/hooks/advance-phase.js dev --force
Track 변경: node .claude/hooks/advance-phase.js set-track <A|B|C>
```

차단 메시지는 항상 **이유 + 해결 방법 + 긴급 우회 옵션**을 포함한다.

---

## 6. Hook 동작 상세

### 6.1 session-gate.js (UserPromptSubmit)

**언제 실행?** 사용자가 메시지를 보낼 때마다.

**무엇을 하나?**
1. `pipeline-state.json` 읽기 → Phase, Track, lastFailure, lastLintResult 추출
2. CLAUDE.md 읽기 → project_name, version
3. session-context.md 읽기 → 진행 중인 작업, 다음 할 일
4. Plan 파일에서 진행률 계산 (`[x]/[~]/[!]/[ ]` 카운트)
5. **[v1.1.0] 에러 피드백 주입**: lastFailure가 있으면 테스트/린트 에러 메시지 표시
6. **[v1.1.0] 린트 결과 주입**: lastLintResult에 경고/에러가 있으면 표시
7. **[v1.1.0] Phase별 SKILL 경로 주입**: 현재 Phase에서 참조할 SKILL.md 경로 표시
8. **[v1.1.0] 키워드 기반 Track 추천**: 사용자 메시지를 분석하여 A/B/C 추천 (참고용)
9. **[v1.1.0] 모호성 자동 감지**: 메시지가 짧고 동사가 없으면 "구체적 설명 권장" 표시
10. 모든 정보를 PIPELINE STATE 박스로 조립하여 stdout 출력
11. ACTION REQUIRED 항목 체크:
    - 프로젝트 미설정
    - Phase 불일치
    - 블로킹 태스크
    - Track B + dev-journal 미작성
    - 최근 차단 후 dev-journal 미기록

**우회 가능?** 불가. UserPromptSubmit는 사용자 입력을 받기 전에 무조건 실행된다.

### 6.2 pre-tool-gate.js (PreToolUse)

**언제 실행?** Claude가 Write/Edit/Bash 도구를 호출하기 전.

**무엇을 차단하나?**

| 대상 | 차단 조건 |
|------|---------|
| Write/Edit `pipeline-state.json` | 항상 차단 (advance-phase.js 사용 강제) |
| Write/Edit `src/*` | non-dev Phase에서 차단 |
| Write/Edit `src/*` Track A | dev Phase에서도 차단 |
| Write/Edit `src/*` Track B | dev-journal 엔트리 없으면 차단 |
| Write/Edit `src/*` Track C | PRD Approved + Plan + [ ] 태스크 없으면 차단 |
| Bash `sed -i ... src/` | non-dev Phase에서 차단 |
| Bash `echo ... > src/` | non-dev Phase에서 차단 |
| Bash `cp/mv ... src/` | non-dev Phase에서 차단 |
| Bash `gcc/tsc/dotnet build` | non-dev Phase에서 차단 |
| Bash `rm -rf /` 등 | 항상 차단 |

**경로 정규화**: Windows 백슬래시(`\`) → 슬래시(`/`)로 변환 후 매칭.

**폴백 방향**: 모든 검증 catch는 **block** 방향. 안전 우선.

### 6.3 post-write-sync.js (PostToolUse)

**언제 실행?** Write/Edit 도구 실행 후.

**무엇을 갱신하나?**
1. **`pipeline-state.json` 자동 갱신**:
   - `docs/prds/*.md` 저장 → `artifacts.prd` + `activePrd`
   - `docs/plans/*.md` 저장 → `artifacts.plan` + `activePlan`
2. **`docs/INDEX.md` 자동 갱신**:
   - 새 PRD/Plan/test/report 파일 → 해당 섹션에 행 자동 삽입
   - 기존 파일 수정 → 진행률, 상태 컬럼 자동 업데이트
3. **`session-context.md` 자동 갱신**:
   - "마지막으로 수정한 파일" 섹션에 추가 (최신 5개 유지)
   - "마지막 업데이트" 타임스탬프 갱신
4. **`audit-log.jsonl` 추가**:
   - 모든 Write/Edit 이벤트 + 도구명 + 파일 + 현재 phase
5. **Plan FR-IMPL 검증** (Track C, Plan 저장 시):
   - PRD의 FR ↔ Plan의 IMPL "관련 FR" 매핑 검증
   - 미연결/고아 시 stderr 경고 + audit-log 기록
6. **Plan 순환 의존 감지** (Plan 저장 시):
   - 태스크 의존 그래프 구성 → DFS로 순환 탐지
   - 무효 참조(존재하지 않는 ID) 감지
   - 발견 시 stderr 경고 + audit-log 기록

7. **[v1.1.0] src/ 린트 자동 실행** (`lint_command` 설정 시):
   - src/ 파일 Write/Edit 후 린트 명령 실행 (타임아웃 10초)
   - 결과를 `pipeline-state.json`의 `lastLintResult`에 저장
   - 다음 메시지에서 session-gate.js가 자동 주입

**차단 여부**: 차단하지 않음. 모든 오류 silent skip (부가 기능이므로).

### 6.4 advance-phase.js (CLI)

**언제 실행?** 사용자/Claude가 명시적으로 호출.

**Phase별 게이트 조건**:

| Phase | Track A | Track B | Track C |
|-------|:-------:|:-------:|:-------:|
| analysis | 자유 | 자유 | 자유 |
| prd | ❌ 차단 | ❌ 차단 | 자유 |
| plan | ❌ 차단 | ❌ 차단 | PRD Approved 필수 |
| dev | ❌ 차단 | dev-journal 엔트리 | PRD + Plan + [ ] 태스크 |
| test | ❌ 차단 | 자유 | IMPL 80%+ 완료 |
| report | ❌ 차단 | ❌ 차단 | test-result.md 존재 |
| complete | dev-journal 완료 마커 | dev-journal 완료 마커 | 모든 태스크 [x] |

**[v1.1.0] Harness Loop — 자동 교정 루프**:

`test_command`가 설정된 상태에서 `advance-phase.js test` 실행 시:

```
advance-phase test
  │
  ├─ test_command 미설정 → "수동 테스트 모드" (기존 동작 유지)
  │
  ├─ test_command 실행 → 통과 ✅
  │   → lastFailure = null, autoFixCount = 0
  │   → test Phase 정상 진입
  │
  └─ test_command 실행 → 실패 ❌
      → lastFailure에 에러 메시지 저장
      → autoFixCount++
      │
      ├─ count < max_auto_fix(3) → dev Phase 자동 복귀
      │   → 다음 메시지에서 session-gate가 에러 주입
      │   → Claude가 에러를 보고 수정 → 재시도
      │
      └─ count >= max_auto_fix(3) → 루프 중단
          → test Phase 진입하되 사용자 개입 요청
```

**부가 동작**:
- session-context.md의 Phase 필드 자동 동기화
- 감사 로그에 `phase-transition` 또는 `force-phase-override` 이벤트 기록

---

## 7. 스킬 시스템

### 7.1 10개 스킬 개요

| 스킬 | 역할 | Track |
|------|------|:-----:|
| **process** | 마스터 오케스트레이터, A/B/C 라우팅 | All |
| **analysis** | 코드베이스 분석, FR 초안 생성 | All |
| **prd** | 요구사항 정의서 작성 | C |
| **plan** | 태스크 분해, FR 연결, 의존성 명시 | C |
| **monitoring** | 체크박스 갱신, 진행률 추적 | C |
| **test** | 테스트 작성/실행, NFR 검증 | B,C |
| **report** | 완료 리포트, ADR 기록 | C |
| **memory** | session-context.md 포맷 정의 | All |
| **index** | INDEX.md 갱신 방법 정의 | All |
| **readme** | 버전 이력, CHANGELOG 관리 | C |

### 7.2 스킬 호출 방식

스킬은 **함수 호출이 아니라 "파일을 읽고 따른다"**. Claude는 SKILL.md 파일을 Read 도구로 읽고, 그 안의 지침에 따라 동작한다.

```
Claude가 "PRD를 작성해야겠다"고 판단
    │
    ▼
.claude/skills/prd/SKILL.md 를 Read로 읽음
    │
    ▼
SKILL.md의 "출력 파일" 섹션 템플릿대로 docs/prds/{topic}-prd.md 작성
    │
    ▼
SKILL.md의 "완료 후 처리" 섹션 6단계 수행
```

### 7.3 스킬 간 데이터 흐름

```
analysis ──FR 초안──→ prd ──FR/NFR──→ plan ──태스크 ID──→ monitoring
                                       │                       │
                                       │                       │
                                  TEST 태스크              [x]/[~]/[!]
                                       │                  체크박스 갱신
                                       ▼                       │
                                    test ────테스트 결과───────┘
                                     │
                                     ▼
                                  report ──버전 증가──→ readme
```

---

## 8. 산출물 구조

### 8.1 docs/ 폴더 전체 구조

```
docs/
├── INDEX.md                           ← 모든 산출물 인덱스 (Hook 자동 갱신)
├── Manual.md                          ← 본 매뉴얼
├── memory/
│   ├── pipeline-state.json            ← 기계적 상태 (Hook이 읽음)
│   ├── session-context.md             ← 인간 맥락 (Claude가 읽음)
│   ├── dev-journal.md                 ← 시행착오 기록
│   └── audit-log.jsonl                ← 감사 로그 (Hook이 추가)
├── analyses/
│   └── {topic}-analysis.md            ← analysis 스킬 산출물
├── prds/
│   └── {topic}-prd.md                 ← prd 스킬 산출물
├── plans/
│   └── {topic}-prd-plan.md            ← plan 스킬 산출물
├── tests/
│   └── {topic}-test-result.md         ← test 스킬 산출물
└── reports/
    └── {topic}-report.md              ← report 스킬 산출물
```

### 8.2 pipeline-state.json 스키마

```json
{
  "phase": "dev",
  "track": "C",
  "activePrd": "docs/prds/login-prd.md",
  "activePlan": "docs/plans/login-prd-plan.md",
  "artifacts": {
    "prd": { "path": "docs/prds/login-prd.md", "recorded_at": "..." },
    "plan": { "path": "docs/plans/login-prd-plan.md", "recorded_at": "..." }
  },
  "updated_at": "2026-04-10T14:35:00.000Z",
  "last_changelog_date": "2026-04-10",
  "iterations": { "test→dev": 1, "total_backwards": 1 },
  "lastFailure": {
    "type": "test",
    "message": "AssertionError: expected 3, got 5",
    "file": "tests/test_calc.py:42",
    "timestamp": "..."
  },
  "lastLintResult": {
    "errors": 0, "warnings": 2,
    "summary": "src/foo.js:12 unused-var",
    "timestamp": "..."
  },
  "autoFixCount": 1
}
```

**중요**: 이 파일을 수동으로 편집하면 차단된다. 항상 `advance-phase.js` 또는 `post-write-sync.js`를 통해 갱신한다.

### 8.3 session-context.md 구조

```markdown
# 세션 컨텍스트

- **마지막 업데이트**: {YYYY-MM-DD HH:mm}

## 프로젝트 상태
- **활성 PRD**: ...
- **활성 Plan**: ...
- **현재 Phase**: ...

## 진행 중인 작업
{한 줄 요약}

## 마지막으로 수정한 파일
- ...

## 다음 할 일
{Resume 지점}

## 완료된 작업 이력
| 날짜 | 작업 | 결과물 |

## 중요 기술 결정 사항
| 날짜 | 결정 | 이유 |

## 완료된 개발 사이클
| 사이클 | PRD | Plan | 상태 |
```

---

## 9. 실전 시나리오

### 9.1 새 기능 추가 (Track C 풀 사이클)

```
1. 사용자: "결제 모듈 추가해줘"
2. Claude: 복잡도 점수 판단 → 7점 → Track C
3. node advance-phase.js set-track C
4. node advance-phase.js analysis
5. analysis 스킬 → docs/analyses/payment-analysis.md
6. node advance-phase.js prd
7. prd 스킬 → docs/prds/payment-prd.md (Draft)
8. 사용자 검토 → 승인
9. PRD 상태를 Approved로 변경 (Edit)
10. node advance-phase.js plan
11. plan 스킬 → docs/plans/payment-prd-plan.md (15 태스크)
12. node advance-phase.js dev
13. 태스크별 src/ 코드 작성, monitoring으로 체크박스 갱신
14. node advance-phase.js test (IMPL 80%+ 검증 통과)
15. test 스킬 → docs/tests/payment-test-result.md
16. node advance-phase.js report (test-result 검증 통과)
17. report 스킬 → docs/reports/payment-report.md
18. node advance-phase.js complete (미완료 0건 검증 통과)
```

### 9.2 변수명 변경 (Track B)

```
1. 사용자: "src/utils.py의 calcTotal을 calculate_total로 바꿔"
2. Claude: 복잡도 점수 → 3점 → Track B
3. node advance-phase.js set-track B
4. dev-journal.md에 엔트리 작성:
   ### [2026-04-10 15:00] calcTotal → calculate_total 리네임
   - Track: B
   - 대상: src/utils.py
   - 이유: PEP 8 컨벤션 준수
   - 영향: 호출부 src/main.py, src/api.py, tests/test_utils.py
5. node advance-phase.js analysis (자유 통과)
6. node advance-phase.js dev (dev-journal 게이트 통과)
7. Edit src/utils.py + 호출부 3개
8. pytest 실행
9. dev-journal 엔트리에 "완료: ✅" 추가
10. node advance-phase.js test → complete
```

### 9.3 코드 설명 요청 (Track A)

```
1. 사용자: "이 함수가 왜 필요해?"
2. Claude: 복잡도 점수 → 0점 → Track A
3. node advance-phase.js set-track A
4. 함수 파일 Read
5. 답변
6. node advance-phase.js complete (Track A는 직접 complete 가능)
```

### 9.4 긴급 핫픽스 (--force 사용)

```
1. 사용자: "프로덕션 장애! 지금 src/server.py 바로 고쳐야 해"
2. Claude: 정상 절차로는 PRD/Plan 필요 → 시간 부족
3. node advance-phase.js set-track B  # B로 빠르게
4. dev-journal에 핫픽스 엔트리 작성 (필수)
5. node advance-phase.js dev  # dev-journal 게이트 통과
6. Edit src/server.py
7. (테스트 후) complete
8. 사후: docs/prds/hotfix-{date}-prd.md 작성하여 정상 문서화
```

만약 dev-journal 작성도 시간이 없다면:
```
node advance-phase.js dev --force
```
(audit-log에 force-override 기록됨)

### 9.5 작업 중단 후 재개

새 Claude Code 세션을 시작하면:

```
1. session-gate.js가 PIPELINE STATE 박스 자동 주입
2. Phase, Track, Active PRD/Plan, Progress, Resume 지점 모두 표시
3. Claude는 즉시 "이전 작업 이어서 진행할까요?" 물음
4. 사용자: "응"
5. Claude는 다음 [ ] 태스크부터 재개
```

session-context.md만 잘 갱신되어 있으면 컨텍스트 손실 0%.

---

## 10. 트러블슈팅

### 10.1 Hook이 동작하지 않음

**증상**: PIPELINE STATE 박스가 주입되지 않음, 차단이 작동하지 않음.

**확인**:
```bash
# 1. settings.json에 hooks 등록 확인
cat .claude/settings.json

# 2. Node.js 설치 확인
node --version

# 3. Hook 직접 실행 (구문 오류 확인)
node .claude/hooks/session-gate.js
node .claude/hooks/pre-tool-gate.js
```

**해결**: Claude Code를 재시작. settings.json은 세션 시작 시 한 번만 로드된다.

### 10.2 Phase 전환 차단됨

**증상**: `[GATE BLOCKED] {phase} 전환 거부`

**확인**: 차단 메시지의 "이유" 줄을 읽는다. 게이트 조건을 충족시키거나 `--force`로 우회.

### 10.3 src/ 쓰기가 차단됨

**증상**: `[HARD GATE] 소스 코드 작성 차단`

**확인**:
```bash
node .claude/hooks/advance-phase.js status
```

**해결**:
- Phase가 `dev`가 아닌가? → 적절한 Phase로 전환
- Track 미설정? → `set-track <A|B|C>`
- Track B인데 dev-journal 없음? → 엔트리 작성
- Track C인데 PRD/Plan 없음? → 작성 또는 Track 변경

### 10.4 dev-journal 게이트 통과 안 됨

**증상**: Track B에서 `[HARD GATE] dev-journal 엔트리가 없음`

**해결**: `### [YYYY-MM-DD HH:mm]` 패턴으로 시작하는 엔트리를 `docs/memory/dev-journal.md`에 추가.

### 10.5 Track 잘못 설정함

**증상**: Track C로 설정했는데 사실 Track B 작업이었음.

**해결**:
```bash
node .claude/hooks/advance-phase.js set-track B
```

언제든지 변경 가능.

### 10.6 pipeline-state.json 손상

**증상**: `[STATUS] pipeline-state.json 없음` 또는 JSON 파싱 에러.

**해결**:
```bash
# 백업
mv docs/memory/pipeline-state.json docs/memory/pipeline-state.json.bad

# 다음 Claude Code 메시지 시 session-gate.js가 자동 재생성
# 또는 수동:
echo '{"phase":"setup","track":null,"activePrd":null,"activePlan":null,"artifacts":{},"updated_at":"2026-04-10T00:00:00.000Z"}' > docs/memory/pipeline-state.json
```

---

## 11. 커스터마이징

### 11.1 새 스킬 추가

```
.claude/skills/{새스킬명}/SKILL.md
```

YAML frontmatter로 시작:
```markdown
---
name: 새스킬명
description: |
  언제 사용하는지...
---

# 스킬 본문
```

CLAUDE.md의 "스킬 경로 참조표"에 행 추가.

### 11.2 게이트 조건 변경

`.claude/hooks/advance-phase.js`의 `GATES` 객체를 수정.

```javascript
const GATES = {
  test: () => {
    const { track } = getCurrentState();
    if (track === 'C') {
      // 80% → 90%로 변경
      if (pct < 90) return `IMPL 90% 미달`;
    }
    return null;
  }
};
```

### 11.3 새 Track 추가

`.claude/hooks/advance-phase.js`의 `TRACK_ROUTES`에 추가:

```javascript
const TRACK_ROUTES = {
  A: ['setup', 'analysis', 'complete'],
  B: ['setup', 'analysis', 'dev', 'test', 'complete'],
  C: ['setup', 'analysis', 'prd', 'plan', 'dev', 'test', 'report', 'complete'],
  D: ['setup', 'analysis', 'spike', 'dev', 'complete']  // 새 Track 예시
};
```

`pre-tool-gate.js`의 dev Phase 검증 로직에 새 Track 처리 추가.

---

## 12. 부록

### Y. Approval Authentication (approval-authentication-prd 추가 사항)

#### 4 레이어 보호 메커니즘

PRD 검토 게이트 우회를 막기 위해 마커 파일 기반 메커니즘:

| 레이어 | 메커니즘 | 위치 |
|--------|---------|------|
| 1. 상태 명시 | `.claude/.pending-prd-review` 마커 파일 | 파일 시스템 |
| 2. 시간 강제 | PRD가 최소 한 메시지 턴 동안 Draft 유지 | post-write-sync + session-gate |
| 3. OS 차단 | Bash로 `advance-phase.js approve prd` 호출 차단 | pre-tool-gate |
| 4. 의미 검증 | 사용자 명시 키워드만 마커 해제 | session-gate (stdin) |

#### 키워드 패턴

```regex
\b(approve|승인|OK|진행시켜|진행해|진행하자|좋아|good|승인해)\b
```

case-insensitive. 사용자가 다음 메시지에 위 단어를 포함하면 마커 자동 해제.

#### 마커 형식

```json
{
  "prd": "docs/prds/foo-prd.md",
  "version": "1.0",
  "created_at": "2026-04-10T...",
  "updated_at": "2026-04-10T..."
}
```

#### 마커 만료

3일(72시간) 초과 시 session-gate가 자동 삭제 + audit-log `prd-review-expired` 이벤트.

#### 사용자 직접 명령은 영향 없음

`!` 접두사로 사용자가 직접 명령 입력 시 Bash 도구를 거치지 않으므로 차단되지 않음. Claude가 Bash 도구로 호출할 때만 차단.

---

### Z. System Optimization (system-optimization-prd 추가 사항)

#### 시나리오 테스트 격리

`tests/manual/_helpers.sh`의 `isolate_test` 함수가 시나리오 시작 시 상태 백업 + EXIT trap으로 자동 복원. pipeline-state, audit-log, dev-journal, session-context 4개 파일 모두 격리.

```bash
source "$(dirname "$0")/_helpers.sh"
isolate_test  # backup + trap restore_state EXIT
# ... 시나리오 본문 (실제 advance-phase 호출 OK)
print_summary
```

#### Memory 자동 GC

| 파일 | 임계 | 동작 | 트리거 |
|------|------|------|------|
| dev-journal.md | 200줄 | 가장 오래된 1/3 → `dev-journal-archive/{YYYY-Q}.md` | complete |
| audit-log.jsonl | 1000줄 | 가장 오래된 1/2 → `audit-log-archive/{date}.jsonl` | complete |

#### Hook 성능 자동 측정

각 Hook 종료 시 100ms 초과 시 audit-log에 `hook-perf` 이벤트 자동 기록.

#### 사이클 무결성 검증

`new-cycle` 실행 시 이전 사이클 PRD가 모두 Completed인지 검사. Approved 발견 시 자동 backfill + audit-log `cycle-integrity-backfill` 이벤트.

#### Track 추천

`track`이 미설정이면 session-gate가 ACTION REQUIRED에 안내 (강제 X).

#### 공통 헬퍼 모듈

`.claude/hooks/_common.js` — `loadState`, `saveState`, `scanDocsDir`, `normalizePathForRegex`, `resolveFilePath`, `appendAudit`. 점진적 마이그레이션 중 (현재 pre-tool-gate.js만 require).

---

### A. 파일 구조 전체 트리

```
{project-root}/
├── .claude/
│   ├── settings.json                  ← Hook 등록
│   ├── hooks/
│   │   ├── advance-phase.js           ← Phase/Track 전환 CLI
│   │   ├── pre-tool-gate.js           ← Write/Bash 차단
│   │   ├── post-write-sync.js         ← 자동 갱신
│   │   └── session-gate.js            ← 상태 주입
│   └── skills/
│       ├── analysis/SKILL.md
│       ├── index/SKILL.md
│       ├── memory/SKILL.md
│       ├── monitoring/SKILL.md
│       ├── plan/SKILL.md
│       ├── prd/SKILL.md
│       ├── process/SKILL.md
│       ├── readme/SKILL.md
│       ├── report/SKILL.md
│       └── test/SKILL.md
├── CLAUDE.md                          ← 마스터 컨텍스트
└── docs/
    ├── INDEX.md
    ├── Manual.md                      ← 본 파일
    ├── memory/
    │   ├── pipeline-state.json
    │   ├── session-context.md
    │   ├── dev-journal.md
    │   └── audit-log.jsonl
    ├── analyses/
    ├── prds/
    ├── plans/
    ├── tests/
    └── reports/
```

### B. audit-log.jsonl 이벤트 종류

| 이벤트 | 발생 시점 |
|--------|---------|
| `phase-transition` | 정상 Phase 전환 |
| `force-phase-override` | --force 플래그 사용 |
| `track-set` | set-track 명령 |
| `circular-dependency` | Plan 저장 시 순환 의존 발견 |
| `invalid-dep-reference` | Plan 저장 시 무효 ID 참조 |
| `fr-impl-mismatch` | Plan 저장 시 FR-IMPL 매핑 불일치 |
| `untested-nfr-in-report` | report 저장 시 미테스트 NFR 발견 |

각 이벤트는 timestamp + 상세 정보를 포함한다.

### C. 자주 묻는 질문

**Q1. Track을 매번 설정해야 하나?**

아니다. 한 번 설정하면 새 Track으로 변경하기 전까지 유지된다. Track 미설정 시 가장 엄격한 C로 폴백된다.

**Q2. 기존 프로젝트에 설치해도 안전한가?**

안전하다. `install.js`가 기존 CLAUDE.md yaml을 보존하고, settings.json Hook을 병합하며, .gitignore에 하네스 섹션만 추가한다. 기존 src/ 코드는 그대로 보존된다.

**Q3. Hook이 너무 빡빡해서 작업이 느려진다.**

`set-track A`로 단순 작업은 빠르게 처리하고, 정말 필요할 때만 Track B/C를 사용하라. 또는 `--force`로 일시 우회 (감사 로그에는 남음).

**Q4. dev-journal과 session-context의 차이는?**

- session-context: "지금 어디에 있는가" (현재 상태)
- dev-journal: "왜 여기에 왔는가" (과정과 시행착오)

**Q5. 다른 LLM으로도 동작하나?**

이 시스템은 **Claude Code의 Hook 메커니즘**을 사용한다. Claude Code 외 환경에서는 동작하지 않는다.

**Q6. 멀티 프로젝트(monorepo)에서는?**

각 프로젝트 루트에 별도로 설치한다. pipeline-state.json은 프로젝트별로 독립적이다.

### D. 주요 정규식 패턴 참조

| 패턴 | 매칭 대상 |
|------|---------|
| `/\/src\//i` | src/ 폴더 내 파일 |
| `/\.(py\|js\|ts\|jsx\|tsx\|cs\|cpp\|java\|go\|rs)$/i` | 소스 파일 확장자 |
| `/^### \[\d{4}-\d{2}-\d{2}/m` | dev-journal 엔트리 |
| `/^- \*\*상태\*\*:\s*Approved/im` | PRD Approved 상태 |
| `/^- \[[ x~!\-]\] \*\*\[([A-Z]+-\d+)\]\*\*/gm` | Plan 태스크 ID |

---

## 9장. 멀티세션 운영 (Multi-Session Coordination)

### 9.1 멀티세션 활성화

`settings.json`의 `env` 섹션에서 다음 값을 `"1"`로 변경:

```json
"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
```

Claude Code 재시작 후 팀 생성 UI 또는 `_HARNESS_SESSION_ROLE` 환경변수로 역할 확인.

### 9.2 Lead / Teammate 역할

| 역할 | 설명 |
|------|------|
| **Lead** | 세션 레지스트리에 가장 먼저 등록된 세션. Phase 전환 권한 보유. |
| **Teammate** | 이후 등록된 세션. 파일 작업 가능. Phase 전환 불가 (Lead 권한 필요). |

Lead 크래시 시: Heartbeat 60초 초과 감지 → 가장 오래된 Teammate 자동 승격 (FR-14 Failover).

### 9.3 파일 충돌 정책

`settings.json`의 `file_conflict_policy`:
- `"warn"` (기본): 다른 세션 소유 파일 접근 시 경고 후 계속 진행
- `"block"`: 다른 세션 소유 파일 접근 시 완전 차단

### 9.4 git 초기화 위저드 (FR-26)

git 레포지토리가 없는 프로젝트에서 하네스 첫 실행 시 자동으로 5단계 위저드가 실행됩니다:

1. `git init`
2. `git config user.name / user.email` 설정
3. `CHANGELOG.md` / `README.md` 생성
4. `git add .`
5. `git commit -m "chore: initial commit"`

위저드가 중단되면 `.claude/wizard-state.json`의 `step` 필드에서 이어서 재개.
수동 리셋: `wizard-state.json`의 `initialized`를 `false`로 변경.

### 9.5 Worktree 사용

`advance-phase.js --worktree <name>`으로 격리된 작업 트리 생성:

```bash
node .claude/hooks/advance-phase.js dev --worktree feature-branch
```

정리: `.claude/worktrees/` 내 디렉토리 수동 삭제 후 `git worktree remove --force <path>`.

### 9.6 설정 항목 참조

| 키 | 기본값 | 설명 |
|----|--------|------|
| `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` | `"0"` | 멀티세션 활성화 (`"1"` = ON) |
| `max_parallel_sessions` | `"8"` | 최대 병렬 세션 수 |
| `file_conflict_policy` | `"warn"` | 파일 충돌 정책 |
| `session_heartbeat_timeout_s` | `"60"` | 세션 dead 판정 기준 (초) |

---

## 13. 라이선스 / 기여

- **버전**: 0.2.0
- **변경 이력**: docs/reports/hook-hardening-report.md 참조
- **이슈/제안**: 프로젝트 저장소에 등록

이 매뉴얼이 도움이 되었기를 바란다. 잘못된 내용이나 누락된 항목을 발견하면 PR을 환영한다.
