#!/usr/bin/env node
// install.js — claude-skill-harness 인스톨러
//
// zip을 프로젝트 루트에 풀면 하위 폴더가 생김:
//   my-project/claude-skill-harness-v2.x.x/
//
// 그 폴더 안에서 실행:
//   cd claude-skill-harness-v2.x.x
//   node install.js              → 부모 폴더(my-project/)에 신규 설치
//   node install.js --upgrade    → 부모 폴더 기존 상태 보존하며 업그레이드
//   node install.js --rollback   → 직전 백업에서 복원
//   node install.js --target /path/to/project  → 지정 경로에 설치

const fs = require('fs');
const path = require('path');

// ── 하네스 버전 (빌드 시 build-package.js가 갱신) ─────────────────────
const HARNESS_VERSION = '2.5.0';

// ── CLAUDE.md v2.1.1 compact 템플릿 ─────────────────────────────────
function generateClaudeMd(yaml) {
  return `# CLAUDE.md — 프로젝트 마스터 컨텍스트

> 이 파일은 최소 런타임 설정이다. 상세 지침은 참조 경로를 읽는다.
> 시스템 전체 설명: [\`docs/Manual.md\`](docs/Manual.md)

---

## 세션 시작 루틴

\`project_name\`이 비어있으면 프로젝트 설정 인터뷰를 실행한다
(이름, 언어, 프레임워크, 테스트, 패키지 매니저, 컨벤션 → yaml에 기록).

\`docs/memory/session-context.md\`가 있으면 읽고 이전 작업 현황을 요약한 뒤
"이어서 진행할까요?"라고 묻는다. 없으면 "준비 완료."

---

## 프로젝트 정보

\`\`\`yaml
${yaml}
\`\`\`

---

## 매 응답 전 — 복잡도 판단 (필수)

| Track | 조건 | 경로 |
|-------|------|------|
| **A** | 코드 수정 없음 | analysis → complete |
| **B** | 1~3파일 수정 | analysis → dev-journal → dev → test → complete |
| **C** | 4파일+ / 새 기능 | analysis → prd → plan → dev → test → report → complete |

**5축 점수** (각 0~2점): 파일 범위 · 아키텍처 영향 · 모듈 연동 · 테스트 필요 · 예상 공수
합계 0~2=A / 3~5=B / 6~10=C. 경계선은 사용자에게 확인.

Phase 전환: \`node .claude/hooks/advance-phase.js <phase|set-track|status|approve>\`
상세: \`.claude/skills/process/SKILL.md\` 및 [\`docs/Manual.md\`](docs/Manual.md) 3~5장.

---

## 매 응답 후 — 필수 처리

1. **Memory**: 파일 변경/기술 결정/Phase 변경 시 \`docs/memory/session-context.md\` 갱신
   (포맷: \`.claude/skills/memory/SKILL.md\`)
2. **Index**: \`docs/\` 파일 생성·수정 시 \`docs/INDEX.md\` 갱신 (대부분 Hook 자동)

---

## 참조 경로

| 필요할 때 | 읽을 파일 |
|----------|---------|
| Track/Phase 상세 규칙 | \`.claude/skills/process/SKILL.md\` |
| 해당 Phase의 작업 지침 | \`.claude/skills/{phase별 스킬}/SKILL.md\` |
| Hook·명령어·설치·전체 설명 | [\`docs/Manual.md\`](docs/Manual.md) |
| 현재 세션 상태 | \`docs/memory/session-context.md\` |
| 기계적 파이프라인 상태 | \`docs/memory/pipeline-state.json\` |
`;
}

// ── 기존 CLAUDE.md에서 yaml 블록 추출 ────────────────────────────────
function extractYamlFromClaudeMd(content) {
  const m = content.match(/```yaml\n([\s\S]*?)```/);
  return m ? m[1].trim() : null;
}

// ── yaml 블록에서 version/last_updated 갱신 ──────────────────────────
function updateYamlVersion(yaml, newVersion) {
  const today = new Date().toISOString().slice(0, 10);
  return yaml
    .replace(/version:\s*"[^"]*"/, `version: "${newVersion}"`)
    .replace(/last_updated:\s*"[^"]*"/, `last_updated: "${today}"`);
}

// ── 빈 yaml 템플릿 ──────────────────────────────────────────────────
function emptyYaml() {
  const today = new Date().toISOString().slice(0, 10);
  return `project_name: ""
language: ""
framework: ""
test_framework: ""
package_manager: ""
coding_convention: "언어 기본값"
version: "${HARNESS_VERSION}"
created_at: "${today}"
last_updated: "${today}"
test_command: ""
lint_command: ""
max_auto_fix: 3`;
}

// ── 경로 결정 ────────────────────────────────────────────────────────
const SCRIPT_DIR = __dirname;  // zip 풀린 폴더 (소스)

// --target 옵션이 있으면 그 경로, 없으면 부모 폴더
function resolveTarget() {
  const idx = process.argv.indexOf('--target');
  if (idx !== -1 && process.argv[idx + 1]) {
    return path.resolve(process.argv[idx + 1]);
  }
  return path.resolve(SCRIPT_DIR, '..');  // 부모 폴더
}

const TARGET = resolveTarget();
const BACKUP_DIR = path.join(TARGET, '.skill-set-backup');
const UPGRADE = process.argv.includes('--upgrade');
const ROLLBACK = process.argv.includes('--rollback');

// ── 유틸리티 ────────────────────────────────────────────────────────
function rmRecursive(p) {
  if (!fs.existsSync(p)) return;
  if (fs.statSync(p).isDirectory()) {
    for (const f of fs.readdirSync(p)) rmRecursive(path.join(p, f));
    fs.rmdirSync(p);
  } else {
    fs.unlinkSync(p);
  }
}

function copyRecursive(src, dest) {
  if (!fs.existsSync(src)) return 0;
  let count = 0;
  if (fs.statSync(src).isDirectory()) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    for (const f of fs.readdirSync(src)) {
      count += copyRecursive(path.join(src, f), path.join(dest, f));
    }
  } else {
    const dir = path.dirname(dest);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.copyFileSync(src, dest);
    count = 1;
  }
  return count;
}

// ── 사전 검증 ───────────────────────────────────────────────────────
const nodeVersion = parseInt(process.version.slice(1));
if (nodeVersion < 16) {
  console.error(`[ERROR] Node.js v16+ 필요 (현재: ${process.version})`);
  process.exit(1);
}

// 소스와 타겟이 같은 폴더인지 확인
if (path.resolve(SCRIPT_DIR) === path.resolve(TARGET)) {
  console.error('[ERROR] install.js를 프로젝트 루트에서 직접 실행하고 있습니다.');
  console.error('  zip을 프로젝트 루트에 풀면 하위 폴더가 생깁니다.');
  console.error('  그 폴더 안에서 실행하세요:');
  console.error('    cd claude-skill-harness-v2.x.x');
  console.error('    node install.js');
  process.exit(1);
}

console.log(`\n  소스: ${SCRIPT_DIR}`);
console.log(`  대상: ${TARGET}\n`);

// ══════════════════════════════════════════════════════════════════════
// 롤백 모드
// ══════════════════════════════════════════════════════════════════════
if (ROLLBACK) {
  console.log('╔══════════════════════════════════════╗');
  console.log('║  Rollback Mode                       ║');
  console.log('╚══════════════════════════════════════╝\n');

  if (!fs.existsSync(BACKUP_DIR)) {
    console.error('[ERROR] 백업 없음: ' + BACKUP_DIR);
    process.exit(1);
  }
  const restored = copyRecursive(BACKUP_DIR, TARGET);
  console.log(`[OK] ${restored}개 파일 복원됨`);
  process.exit(0);
}

// ── 공통: Hook/Skills/Agents/Domain/Rules 복사 ──────────────────────
function installComponents() {
  let total = 0;

  // .claude/hooks/
  const srcHooks = path.join(SCRIPT_DIR, '.claude', 'hooks');
  if (fs.existsSync(srcHooks)) {
    const n = copyRecursive(srcHooks, path.join(TARGET, '.claude', 'hooks'));
    console.log(`  Hook 설치: ${n}개 파일`);
    total += n;
  }

  // .claude/skills/
  const srcSkills = path.join(SCRIPT_DIR, '.claude', 'skills');
  if (fs.existsSync(srcSkills)) {
    const n = copyRecursive(srcSkills, path.join(TARGET, '.claude', 'skills'));
    console.log(`  Skills 설치: ${n}개 파일`);
    total += n;
  }

  // .claude/agents/
  const srcAgents = path.join(SCRIPT_DIR, '.claude', 'agents');
  if (fs.existsSync(srcAgents)) {
    const n = copyRecursive(srcAgents, path.join(TARGET, '.claude', 'agents'));
    console.log(`  Agents 설치: ${n}개 파일`);
    total += n;
  }

  // .claude/domain-skills/
  const srcDomain = path.join(SCRIPT_DIR, '.claude', 'domain-skills');
  if (fs.existsSync(srcDomain)) {
    const n = copyRecursive(srcDomain, path.join(TARGET, '.claude', 'domain-skills'));
    console.log(`  Domain Skills 설치: ${n}개 파일`);
    total += n;
  }

  // .claude/rules/
  const srcRules = path.join(SCRIPT_DIR, '.claude', 'rules');
  if (fs.existsSync(srcRules)) {
    const n = copyRecursive(srcRules, path.join(TARGET, '.claude', 'rules'));
    console.log(`  Rules 설치: ${n}개 파일`);
    total += n;
  }

  // tests/
  const srcTests = path.join(SCRIPT_DIR, 'tests');
  if (fs.existsSync(srcTests)) {
    const n = copyRecursive(srcTests, path.join(TARGET, 'tests'));
    console.log(`  Tests 설치: ${n}개 파일`);
    total += n;
  }

  // 유틸리티 파일
  for (const f of ['docs/Manual.md']) {
    const src = path.join(SCRIPT_DIR, f);
    if (fs.existsSync(src)) {
      const dest = path.join(TARGET, f);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(src, dest);
      total++;
    }
  }

  return total;
}

// ── 공통: .gitignore 생성/병합 ──────────────────────────────────
const GITIGNORE_SECTION_START = '# ── Claude Skill Harness ──';
const GITIGNORE_SECTION_END = '# ── /Claude Skill Harness ──';
const GITIGNORE_CONTENT = `${GITIGNORE_SECTION_START}
# 이 섹션은 claude-skill-harness install.js가 자동 생성합니다.
# 하네스/스킬/MCP 관련 파일을 git 추적에서 제외합니다.

# Harness core
.claude/
CLAUDE.md
CHANGELOG.md
UPGRADE.md

# Harness documents
docs/memory/
docs/analyses/
docs/prds/
docs/plans/
docs/tests/
docs/reports/
docs/INDEX.md
docs/Manual.md

# Harness installer / backup
install.js
claude-skill-harness*/
.skill-set-backup*
${GITIGNORE_SECTION_END}`;

function setupGitignore() {
  const gitignorePath = path.join(TARGET, '.gitignore');
  if (fs.existsSync(gitignorePath)) {
    const existing = fs.readFileSync(gitignorePath, 'utf8');
    if (existing.includes(GITIGNORE_SECTION_START)) {
      // 기존 하네스 섹션 교체
      const re = new RegExp(
        GITIGNORE_SECTION_START.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
        + '[\\s\\S]*?'
        + GITIGNORE_SECTION_END.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
      );
      fs.writeFileSync(gitignorePath, existing.replace(re, GITIGNORE_CONTENT));
      console.log('  .gitignore: 하네스 섹션 갱신');
    } else {
      // 기존 파일 끝에 하네스 섹션 추가
      const sep = existing.endsWith('\n') ? '\n' : '\n\n';
      fs.writeFileSync(gitignorePath, existing + sep + GITIGNORE_CONTENT + '\n');
      console.log('  .gitignore: 하네스 섹션 추가');
    }
  } else {
    fs.writeFileSync(gitignorePath, GITIGNORE_CONTENT + '\n');
    console.log('  .gitignore: 신규 생성');
  }
}

// ── 공통: settings.json Hook 등록/병합 ──────────────────────────────
function setupSettings() {
  const settingsPath = path.join(TARGET, '.claude', 'settings.json');
  let settings = {};
  if (fs.existsSync(settingsPath)) {
    try { settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8')); } catch {}
  }
  if (!settings.hooks) settings.hooks = {};

  const hookDefs = {
    UserPromptSubmit: { command: 'node .claude/hooks/session-gate.js', timeout: 5 },
    PreToolUse: { command: 'node .claude/hooks/pre-tool-gate.js', timeout: 8,
                  matcher: 'Write|Edit|Bash|mcp__filesystem__write_file|mcp__filesystem__edit_file|mcp__filesystem__move_file' },
    PreCompact: { command: 'node .claude/hooks/pre-compact.js', timeout: 5 },
    Stop: { command: 'node .claude/hooks/stop-observation.js', timeout: 10 },
    PostToolUse: { command: 'node .claude/hooks/post-write-sync.js', timeout: 10, matcher: 'Write|Edit' }
  };

  const isHarness = (entry) => {
    const hooks = entry.hooks || [];
    return hooks.some(h => h.command && h.command.includes('.claude/hooks/'));
  };

  for (const [event, def] of Object.entries(hookDefs)) {
    const existing = settings.hooks[event] || [];
    const userHooks = existing.filter(e => !isHarness(e));
    const entry = { hooks: [{ type: 'command', command: def.command, timeout: def.timeout }] };
    if (def.matcher) entry.matcher = def.matcher;
    settings.hooks[event] = [entry, ...userHooks];
    const preserved = userHooks.length > 0 ? ` (+사용자 Hook ${userHooks.length}개 보존)` : '';
    console.log(`  Hook: ${event}${preserved}`);
  }

  fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2) + '\n');
}

// ══════════════════════════════════════════════════════════════════════
// 업그레이드 모드
// ══════════════════════════════════════════════════════════════════════
if (UPGRADE) {
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║  Upgrade Mode — 기존 상태/학습/문서 보존       ║');
  console.log('╚══════════════════════════════════════════════╝\n');

  // 1. 백업
  const ts = new Date().toISOString().slice(0, 10);
  const upgBackup = path.join(TARGET, `.skill-set-backup-${ts}`);
  console.log(`[BACKUP] ${upgBackup}/`);
  for (const d of ['.claude/hooks', '.claude/skills', '.claude/agents', '.claude/domain-skills', '.claude/rules']) {
    const src = path.join(TARGET, d);
    if (fs.existsSync(src)) copyRecursive(src, path.join(upgBackup, d));
  }
  const settingsFile = path.join(TARGET, '.claude', 'settings.json');
  if (fs.existsSync(settingsFile)) {
    fs.mkdirSync(path.join(upgBackup, '.claude'), { recursive: true });
    fs.copyFileSync(settingsFile, path.join(upgBackup, '.claude', 'settings.json'));
  }
  console.log('  ✅ 백업 완료\n');

  // 2. 기존 Hook/Skills/Agents/Domain/Rules 삭제
  for (const d of ['.claude/hooks', '.claude/skills', '.claude/agents', '.claude/domain-skills', '.claude/rules']) {
    const dir = path.join(TARGET, d);
    if (fs.existsSync(dir)) rmRecursive(dir);
  }
  console.log('  기존 컴포넌트 삭제 완료');

  // 3. 새 컴포넌트 설치
  const total = installComponents();

  // 4. settings.json 병합
  console.log('\n── Hook 등록 ──');
  setupSettings();

  // 4b. .gitignore 설정
  console.log('\n── .gitignore ──');
  setupGitignore();

  // 5. CLAUDE.md 마이그레이션 (yaml 보존 + v2.1.1 compact 구조)
  const claudeMd = path.join(TARGET, 'CLAUDE.md');
  if (fs.existsSync(claudeMd)) {
    const oldContent = fs.readFileSync(claudeMd, 'utf8');
    const oldYaml = extractYamlFromClaudeMd(oldContent);
    const oldV = oldContent.match(/version:\s*"([^"]+)"/);
    if (oldYaml) {
      const newYaml = updateYamlVersion(oldYaml, HARNESS_VERSION);
      fs.writeFileSync(claudeMd, generateClaudeMd(newYaml));
      console.log(`\n  CLAUDE.md: ${oldV ? oldV[1] : '?'} → ${HARNESS_VERSION} (yaml 보존 + v2.1.1 구조 마이그레이션)`);
    } else {
      console.log('\n  CLAUDE.md: yaml 블록 없음 — 변경 없이 보존');
    }
  } else {
    fs.writeFileSync(claudeMd, generateClaudeMd(emptyYaml()));
    console.log(`\n  CLAUDE.md: 신규 생성 (v${HARNESS_VERSION} 템플릿)`);
  }

  // 6. 보존 확인
  console.log('\n── 보존된 파일 ──');
  for (const f of ['CLAUDE.md', 'docs/memory/pipeline-state.json', 'docs/memory/session-context.md',
                     'docs/memory/feedback-rules.json', 'docs/memory/instincts.jsonl',
                     'docs/memory/dev-journal.md', 'docs/INDEX.md', 'CHANGELOG.md']) {
    const fp = path.join(TARGET, f);
    console.log(`  ${fs.existsSync(fp) ? '✅' : '⬜'} ${f}`);
  }

  console.log(`\n╔══════════════════════════════════════════════╗`);
  console.log(`║  업그레이드 완료! (${total}개 파일 설치)         ║`);
  console.log(`║  롤백: node install.js --rollback             ║`);
  console.log(`╚══════════════════════════════════════════════╝`);
  process.exit(0);
}

// ══════════════════════════════════════════════════════════════════════
// 신규 설치 모드 (기본)
// ══════════════════════════════════════════════════════════════════════
console.log('╔══════════════════════════════════════════════╗');
console.log('║  claude-skill-harness Installer              ║');
console.log('╚══════════════════════════════════════════════╝\n');

// 기존 하네스 감지
const existingHarness = fs.existsSync(path.join(TARGET, '.claude', 'hooks', 'session-gate.js'));
if (existingHarness) {
  console.log('[INFO] 기존 하네스 감지됨. --upgrade 모드를 권장합니다.');
  console.log('  node install.js --upgrade\n');
  console.log('  계속하면 기존 상태가 초기화됩니다.');
  console.log('  (Ctrl+C로 취소 가능)\n');
}

// 1. 디렉토리 생성
for (const d of ['.claude', 'docs/memory', 'docs/analyses', 'docs/prds', 'docs/plans', 'docs/tests', 'docs/reports']) {
  const full = path.join(TARGET, d);
  if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
}

// 2. 컴포넌트 설치
console.log('── 컴포넌트 설치 ──');
const total = installComponents();

// 3. settings.json 설정
console.log('\n── Hook 등록 ──');
setupSettings();

// 3b. .gitignore 설정
console.log('\n── .gitignore ──');
setupGitignore();

// 4. CLAUDE.md 설치/마이그레이션
const targetClaude = path.join(TARGET, 'CLAUDE.md');
if (fs.existsSync(targetClaude)) {
  const oldContent = fs.readFileSync(targetClaude, 'utf8');
  const oldYaml = extractYamlFromClaudeMd(oldContent);
  if (oldYaml) {
    const newYaml = updateYamlVersion(oldYaml, HARNESS_VERSION);
    fs.writeFileSync(targetClaude, generateClaudeMd(newYaml));
    console.log('\n  CLAUDE.md: 기존 yaml 보존 + v2.1.1 구조 마이그레이션');
  } else {
    fs.writeFileSync(targetClaude, generateClaudeMd(emptyYaml()));
    console.log('\n  CLAUDE.md: 신규 템플릿 설치 (Claude Code 시작 시 설정 인터뷰)');
  }
} else {
  fs.writeFileSync(targetClaude, generateClaudeMd(emptyYaml()));
  console.log('\n  CLAUDE.md: 신규 템플릿 설치 (Claude Code 시작 시 설정 인터뷰)');
}

// 5. 상태 파일 초기화 (없는 것만)
const stateFile = path.join(TARGET, 'docs', 'memory', 'pipeline-state.json');
if (!fs.existsSync(stateFile)) {
  fs.writeFileSync(stateFile, JSON.stringify({
    phase: 'setup', track: null, activePrd: null, activePlan: null,
    artifacts: {}, updated_at: new Date().toISOString(),
    iterations: {}, lastFailure: null, autoFixCount: 0
  }, null, 2) + '\n');
}
for (const [file, content] of [
  ['docs/memory/feedback-rules.json', '[]\n'],
  ['docs/memory/session-context.md', '# 세션 컨텍스트\n\n- **마지막 업데이트**: (신규)\n\n---\n\n## 프로젝트 상태\n\n- **현재 Phase**: setup\n'],
  ['docs/memory/instincts.jsonl', ''],
  ['docs/INDEX.md', '<!-- auto-section-start -->\n# 프로젝트 문서 인덱스\n\n- **총 문서 수**: 0개\n<!-- auto-section-end -->\n'],
  ['CHANGELOG.md', '# Changelog\n\n<!-- changelog-entries-start -->\n'],
]) {
  const fp = path.join(TARGET, file);
  if (!fs.existsSync(fp)) {
    fs.mkdirSync(path.dirname(fp), { recursive: true });
    fs.writeFileSync(fp, content);
  }
}

// 6. 검증
console.log('\n── 설치 검증 ──');
const hookFiles = ['session-gate.js', 'pre-tool-gate.js', 'post-write-sync.js',
  'advance-phase.js', '_common.js', '_state.js', '_config.js', '_gates.js',
  '_agents.js', '_learning.js', 'stop-observation.js', 'pre-compact.js'];
let ok = 0;
for (const f of hookFiles) {
  if (fs.existsSync(path.join(TARGET, '.claude', 'hooks', f))) ok++;
  else console.warn(`  ⚠ 누락: .claude/hooks/${f}`);
}
console.log(`  Hook: ${ok}/${hookFiles.length}`);

const agentCount = fs.existsSync(path.join(TARGET, '.claude', 'agents'))
  ? fs.readdirSync(path.join(TARGET, '.claude', 'agents')).filter(f => f.endsWith('.md') && f !== 'README.md').length : 0;
const domainCount = fs.existsSync(path.join(TARGET, '.claude', 'domain-skills'))
  ? fs.readdirSync(path.join(TARGET, '.claude', 'domain-skills')).filter(f => f.endsWith('.md') && f !== 'README.md').length : 0;
const ruleCount = fs.existsSync(path.join(TARGET, '.claude', 'rules'))
  ? fs.readdirSync(path.join(TARGET, '.claude', 'rules')).reduce((sum, d) => {
      const dir = path.join(TARGET, '.claude', 'rules', d);
      try { return sum + (fs.statSync(dir).isDirectory() ? fs.readdirSync(dir).filter(f => f.endsWith('.md')).length : 0); }
      catch { return sum; }
    }, 0) : 0;

console.log(`  Agents: ${agentCount} | Domain Skills: ${domainCount} | Rules: ${ruleCount}`);

console.log(`\n╔══════════════════════════════════════════════╗`);
console.log(`║  설치 완료! (${total}개 파일)                   ║`);
console.log(`║                                              ║`);
console.log(`║  시작: cd ${path.basename(TARGET)}                              ║`);
console.log(`║        Claude Code 실행                      ║`);
console.log(`╚══════════════════════════════════════════════╝`);
