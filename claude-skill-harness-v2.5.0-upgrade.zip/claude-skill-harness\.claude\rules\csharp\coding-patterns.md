# C# Coding Patterns

> Always-on coding pattern rules for C# codebases.
> Covers async, nullability, SOLID, disposal, and exception handling.

---

## Async / Await

### Do
- Use `ConfigureAwait(false)` in library code (non-UI)
- Prefer `ValueTask<T>` for hot paths that often complete synchronously
- Always accept and forward `CancellationToken` parameters
- Use `Task.WhenAll` for independent concurrent operations
- Name async methods with `Async` suffix

### Don't
- Use `.Result` or `.Wait()` -- causes deadlocks
- Use `async void` except for event handlers
- Ignore the returned `Task` (fire-and-forget without error handling)
- Mix sync and async code in the same call chain

---

## Thread Safety (I-05)

신규 서비스/매니저 설계 시 스레드 안전성을 초기 설계에 명시한다.

### Design Checklist
```
[ ] 이 컴포넌트를 호출하는 스레드는? (UI / NATS callback / background timer)
[ ] 내부 상태(Dictionary, List 등)를 여러 스레드가 공유하는가?
[ ] lock 전략: _gate lock / ConcurrentDictionary / Dispatcher 직렬화 중 선택
[ ] 이벤트 발화는 lock 밖에서 수행 (재진입 데드락 방지)
```

### Do
- Use `lock (_gate)` for shared mutable collections accessed from multiple threads
- Use `ConcurrentDictionary<K,V>` for read-heavy concurrent maps
- Fire events outside of locks to prevent re-entrant deadlocks
- Use `Dispatcher.InvokeAsync` to serialize UI-thread-only state from background threads
- Document the expected calling thread in XML doc or inline comment

### Don't
- Share a single `DbConnection` / `MySqlConnection` instance across parallel Tasks
  — these are not thread-safe; create one connection per Task
- Use plain `Dictionary<K,V>` or `List<T>` from multiple threads without `lock`
- Acquire a lock and then raise an event or call an external callback inside it

```csharp
// Do
private readonly object _gate = new();
private readonly Dictionary<int, State> _states = new();

public void Enqueue(Event e)
{
    lock (_gate) { _states[e.Id] = e.State; }
    // 이벤트 발화는 lock 밖에서
    StateChanged?.Invoke(this, e);
}

// Don't
public void Enqueue(Event e)
{
    lock (_gate)
    {
        _states[e.Id] = e.State;
        StateChanged?.Invoke(this, e); // lock 안에서 이벤트 발화 → 재진입 위험
    }
}
```

```csharp
// Do
public async Task<User> GetUserAsync(int id, CancellationToken ct = default)
{
    var data = await _repo.FindAsync(id, ct).ConfigureAwait(false);
    return Map(data);
}

// Don't
var user = _repo.FindAsync(id).Result; // deadlock risk
```

---

## Nullable Reference Types

### Do
- Enable `<Nullable>enable</Nullable>` in `.csproj`
- Use `?` to explicitly mark nullable types: `string? name`
- Prefer null-conditional (`?.`) and null-coalescing (`??`) operators
- Use `?? throw` for mandatory values: `name ?? throw new ArgumentNullException()`
- Validate nullable parameters at public API boundaries

### Don't
- Use `!` (null-forgiving) unless null is provably impossible
- Ignore nullable warnings -- fix or document them
- Return `null` from methods when an empty collection is appropriate

---

## SOLID Principles

### Do
- **Single Responsibility**: one reason to change per class
- **Dependency Injection**: inject dependencies via constructor, not `new`
- **Program to interfaces**: depend on `IService`, not `ServiceImpl`
- **Open/Closed**: extend via abstractions, not by modifying existing code
- Favor composition over inheritance

### Don't
- Create god classes with multiple unrelated responsibilities
- Use `static` classes for anything with state or dependencies
- Tightly couple modules -- use interfaces or events for cross-cutting

---

## IDisposable & Resource Management

### Do
- Use `using` statement or `using` declaration for disposable objects
- Use `await using` for `IAsyncDisposable`
- Implement dispose pattern for classes owning unmanaged resources
- Call `Dispose` on injected disposables only if the class owns their lifetime

### Don't
- Forget to dispose `HttpClient`, `DbConnection`, `Stream`, etc.
- Dispose objects you don't own (injected via DI container)
- Suppress `Dispose` exceptions silently

```csharp
// Do
await using var connection = new SqlConnection(connStr);
using var reader = await command.ExecuteReaderAsync(ct);

// Don't
var stream = new FileStream(path, FileMode.Open); // never disposed
```

---

## Exception Handling

### Do
- Throw specific exceptions: `ArgumentNullException`, `InvalidOperationException`
- Catch specific exceptions, not `Exception` broadly
- Use exception filters with `when`: `catch (HttpRequestException ex) when (ex.StatusCode == 404)`
- Include context in exception messages
- Let unexpected exceptions propagate to global handlers

### Don't
- Catch `Exception` and silently swallow it
- Use exceptions for flow control (use return values or `TryX` pattern)
- Throw from `finally` blocks
- Lose stack trace by `throw ex` instead of `throw`

```csharp
// Do
catch (HttpRequestException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
{
    _logger.LogWarning("Resource {Id} not found", id);
    return null;
}

// Don't
catch (Exception) { } // silent swallow
catch (Exception ex) { throw ex; } // stack trace lost
```

---

## Quick Reference

| Pattern            | Do                                  | Don't                             |
|--------------------|-------------------------------------|-----------------------------------|
| Async              | `await` + `ConfigureAwait(false)`   | `.Result`, `.Wait()`              |
| Cancellation       | Pass `CancellationToken`            | Ignore cancellation               |
| Nullable           | `?`, `?.`, `??`                     | `!` everywhere                    |
| DI                 | Constructor injection               | `new Service()` inside classes    |
| Disposal           | `using` / `await using`             | Forget to dispose                 |
| Exceptions         | Catch specific + `throw`            | `catch (Exception) { }`          |
| Return types       | `Task<T>` / `ValueTask<T>`         | `async void`                      |
