// .claude/hooks/_sessions.js
// Multi-session coordination — 세션 레지스트리 모듈
//
// 기능:
//   - 세션 등록/해제 (IMPL-01)
//   - CAS 기반 Lead 선출 (FR-01, FR-11)
//   - 파일 소유권 + Heartbeat + 복구 (FR-12, FR-15)
//   - Lead Failover (FR-14)
//
// 활성화 조건: CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1 또는 =true
// 비활성화 시: 모든 함수 no-op 반환 (싱글세션 폴백)

'use strict';

const fs = require('fs');
const path = require('path');

// ── 경로 상수 ────────────────────────────────────────────────────────

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const SESSIONS_FILE = path.join(PROJECT_ROOT, 'docs', 'memory', 'sessions.json');
const SESSIONS_LOCK = SESSIONS_FILE + '.lock';
const SESSIONS_BACKUP = SESSIONS_FILE + '.bak';
const AUDIT_LOG = path.join(PROJECT_ROOT, 'docs', 'memory', 'audit-log.jsonl');

// Heartbeat 만료 기준 (ms)
const HEARTBEAT_TTL_MS = 60_000;

// ── 빈 세션 구조 ─────────────────────────────────────────────────────

const EMPTY_REGISTRY = () => ({ lead: null, sessions: {} });

// ── 멀티세션 Guard ───────────────────────────────────────────────────

/**
 * CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS 환경 변수로 멀티세션 기능 활성화 여부 확인
 * @returns {boolean}
 */
function isMultiSession() {
  return process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS === '1' ||
         process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS === 'true';
}

// ── audit-log 연동 ───────────────────────────────────────────────────

/**
 * audit-log.jsonl에 이벤트 기록 (silent)
 * @param {string} event - 이벤트 이름
 * @param {string} sessionId - 세션 ID
 * @param {Object} [extra] - 추가 메타데이터
 */
function appendAudit(event, sessionId, extra = {}) {
  try {
    const entry = { event, sessionId, timestamp: new Date().toISOString(), ...extra };
    fs.appendFileSync(AUDIT_LOG, JSON.stringify(entry) + '\n');
  } catch { /* silent */ }
}

// ── 파일 잠금 ────────────────────────────────────────────────────────

// LOCK ORDER: acquire _state.lock before _sessions.lock — never reverse
// (교착 방지를 위해 항상 pipeline-state.json.lock → sessions.json.lock 순서로 획득)

/**
 * sessions.json.lock 획득 (busy-wait, 최대 timeoutMs)
 * - wx 플래그로 배타 잠금 시도
 * - 잠금 보유 프로세스 PID를 kill(0)으로 생존 확인
 * - Dead 프로세스의 잠금은 즉시 해제
 * @param {number} [timeoutMs=3000]
 * @returns {boolean} 획득 성공 여부
 */
function acquireLock(timeoutMs = 3000) {
  const start = Date.now();
  while (true) {
    try {
      fs.writeFileSync(SESSIONS_LOCK, JSON.stringify({
        pid: process.pid,
        acquired_at: Date.now()
      }), { flag: 'wx' });
      return true;
    } catch {
      if (Date.now() - start > timeoutMs) {
        // 타임아웃: 잠금 보유 PID 생존 확인
        try {
          const lockData = JSON.parse(fs.readFileSync(SESSIONS_LOCK, 'utf8'));
          const ownerPid = lockData.pid;
          let ownerAlive = true;
          try {
            process.kill(ownerPid, 0);
          } catch {
            ownerAlive = false;
          }
          if (!ownerAlive || Date.now() - lockData.acquired_at > 10_000) {
            // Dead 프로세스 또는 10초 초과 → 강제 해제
            try { fs.unlinkSync(SESSIONS_LOCK); } catch {}
            continue;
          }
        } catch {
          // 잠금 파일 읽기 실패 → 삭제 후 재시도
          try { fs.unlinkSync(SESSIONS_LOCK); } catch {}
          continue;
        }
        return false; // 진짜 타임아웃
      }
      // 10ms spin-wait 후 재시도
      const until = Date.now() + 10;
      while (Date.now() < until) { /* spin */ }
    }
  }
}

/**
 * sessions.json.lock 해제
 */
function releaseLock() {
  try { fs.unlinkSync(SESSIONS_LOCK); } catch { /* silent */ }
}

// ── I/O 헬퍼 ────────────────────────────────────────────────────────

/**
 * sessions.json 로드 — 파싱 실패 시 .bak 복원, 그래도 실패하면 빈 구조 반환
 * @returns {{ lead: string|null, sessions: Object }}
 */
function loadWithRecovery() {
  // 1차: 정상 파일 시도
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const raw = fs.readFileSync(SESSIONS_FILE, 'utf8');
      return JSON.parse(raw);
    }
  } catch { /* 파싱 실패 → 백업 시도 */ }

  // 2차: 백업 파일 복원 시도
  try {
    if (fs.existsSync(SESSIONS_BACKUP)) {
      const raw = fs.readFileSync(SESSIONS_BACKUP, 'utf8');
      const data = JSON.parse(raw);
      // 복원 후 정상 파일로 기록
      try { fs.writeFileSync(SESSIONS_FILE, JSON.stringify(data, null, 2) + '\n'); } catch {}
      appendAudit('sessions-recovered-from-backup', 'system');
      return data;
    }
  } catch { /* 백업도 실패 */ }

  // 3차: 빈 구조 반환
  return EMPTY_REGISTRY();
}

/**
 * sessions.json 저장 (atomic: temp → rename + .bak 갱신)
 * @param {{ lead: string|null, sessions: Object }} data
 */
function saveRegistry(data) {
  // .bak 먼저 갱신 (기존 파일 기반)
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      fs.copyFileSync(SESSIONS_FILE, SESSIONS_BACKUP);
    }
  } catch { /* .bak 실패해도 저장 진행 */ }

  // 부모 디렉토리 보장
  const dir = path.dirname(SESSIONS_FILE);
  if (!fs.existsSync(dir)) {
    try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  }

  // 원자적 쓰기: temp → rename
  const tmpFile = SESSIONS_FILE + '.tmp.' + process.pid;
  try {
    fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2) + '\n');
    fs.renameSync(tmpFile, SESSIONS_FILE);
  } catch (err) {
    try { fs.unlinkSync(tmpFile); } catch {}
    throw err;
  }
}

// ── 경로 보안 검증 ───────────────────────────────────────────────────

/**
 * filePath가 PROJECT_ROOT 내부인지 검증
 * @param {string} filePath - 검증할 경로
 * @returns {string} 정규화된 절대 경로
 * @throws {Error} PROJECT_ROOT 외부 경로인 경우
 */
function validateFilePath(filePath) {
  const resolved = path.resolve(PROJECT_ROOT, filePath);
  const rootWithSep = PROJECT_ROOT.endsWith(path.sep)
    ? PROJECT_ROOT
    : PROJECT_ROOT + path.sep;
  if (!resolved.startsWith(rootWithSep) && resolved !== PROJECT_ROOT) {
    throw new Error(`Security: filePath "${filePath}" is outside PROJECT_ROOT`);
  }
  return resolved;
}

// ── IMPL-01: 기본 CRUD + CAS Lead 선출 ─────────────────────────────

/**
 * 세션 등록 + CAS Lead 선출
 * - lock 획득 → sessions.json 읽기 → lead null이면 lead, 아니면 teammate → 저장
 * @param {string} sessionId
 * @param {number} pid
 * @returns {{ role: 'lead'|'teammate', session: Object }|null} 싱글세션이면 null
 */
function registerSession(sessionId, pid) {
  if (!isMultiSession()) return null;

  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();

    const now = new Date().toISOString();
    const session = {
      role: 'teammate',
      pid: pid || process.pid,
      started_at: now,
      last_heartbeat: now,
      task_status: 'idle',
      owned_files: [],
      worktree: null
    };

    // CAS: lead double-check
    if (data.lead === null) {
      session.role = 'lead';
      data.lead = sessionId;
    }

    data.sessions[sessionId] = session;
    saveRegistry(data);

    appendAudit('session-registered', sessionId, { role: session.role, pid: session.pid });
    return { role: session.role, session };
  } finally {
    if (locked) releaseLock();
  }
}

/**
 * 세션 해제
 * - 소유 파일 해제 + lead이면 failover 트리거
 * @param {string} sessionId
 * @returns {boolean} 성공 여부, 싱글세션이면 false
 */
function unregisterSession(sessionId) {
  if (!isMultiSession()) return false;

  const locked = acquireLock(3000);
  let wasLead = false;
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    wasLead = data.lead === sessionId;
    delete data.sessions[sessionId];

    if (wasLead) {
      data.lead = null;
    }

    saveRegistry(data);
    appendAudit('session-unregistered', sessionId, { wasLead });
    return true;
  } finally {
    if (locked) releaseLock();
  }

  // lead였으면 failover (lock 해제 후 별도 호출)
  // Note: finally 블록 실행 후 wasLead 체크
}

// Note: wasLead 기반 failover를 finally 밖에서 수행하기 위해
// unregisterSession은 내부적으로 _unregisterAndFailover를 사용
(function patchUnregisterSession() {
  // unregisterSession 재정의 — wasLead 추적 후 failover 분리
  const _orig = module.exports ? undefined : undefined; // placeholder
})();

// 올바른 구현: wasLead를 추적한 뒤 lock 해제 후 failover 실행
function _unregisterSessionImpl(sessionId) {
  if (!isMultiSession()) return false;

  let wasLead = false;
  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    wasLead = data.lead === sessionId;
    delete data.sessions[sessionId];
    if (wasLead) data.lead = null;

    saveRegistry(data);
    appendAudit('session-unregistered', sessionId, { wasLead });
    return true;
  } finally {
    if (locked) releaseLock();
  }
}

// ── IMPL-02: 파일 소유권 + Heartbeat + 복구 ─────────────────────────

/**
 * 파일 소유권 등록
 * owned_files에 추가, task_status = 'working'
 * @param {string} sessionId
 * @param {string} filePath - PROJECT_ROOT 기준 상대경로 또는 절대경로
 * @param {string} [taskId]
 * @returns {boolean} 성공 여부
 */
function claimFile(sessionId, filePath, taskId) {
  if (!isMultiSession()) return false;

  // 보안: filePath 검증
  let safePath;
  try {
    safePath = path.relative(PROJECT_ROOT, validateFilePath(filePath)).replace(/\\/g, '/');
  } catch (err) {
    appendAudit('claim-file-rejected', sessionId, { filePath, reason: err.message });
    return false;
  }

  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    if (!session.owned_files.includes(safePath)) {
      session.owned_files.push(safePath);
    }
    session.task_status = 'working';
    if (taskId) session.current_task_id = taskId;

    saveRegistry(data);
    appendAudit('file-claimed', sessionId, { filePath: safePath, taskId });
    return true;
  } finally {
    if (locked) releaseLock();
  }
}

/**
 * 파일 소유권 해제
 * owned_files에서 제거, 빈 배열이면 task_status = 'idle'
 * @param {string} sessionId
 * @param {string} filePath
 * @returns {boolean} 성공 여부
 */
function releaseFile(sessionId, filePath) {
  if (!isMultiSession()) return false;

  let safePath;
  try {
    safePath = path.relative(PROJECT_ROOT, validateFilePath(filePath)).replace(/\\/g, '/');
  } catch (err) {
    appendAudit('release-file-rejected', sessionId, { filePath, reason: err.message });
    return false;
  }

  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    session.owned_files = session.owned_files.filter(f => f !== safePath);
    if (session.owned_files.length === 0) {
      session.task_status = 'idle';
      delete session.current_task_id;
    }

    saveRegistry(data);
    appendAudit('file-released', sessionId, { filePath: safePath });
    return true;
  } finally {
    if (locked) releaseLock();
  }
}

/**
 * Heartbeat 갱신
 * @param {string} sessionId
 * @returns {boolean} 성공 여부 (세션 없으면 false)
 */
function updateHeartbeat(sessionId) {
  if (!isMultiSession()) return false;

  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    session.last_heartbeat = new Date().toISOString();
    saveRegistry(data);
    return true;
  } finally {
    if (locked) releaseLock();
  }
}

/**
 * Dead 세션 정리 (heartbeat > 60s)
 * lead가 dead이면 checkLeadFailover() 호출
 * @returns {{ removed: string[] }} 제거된 세션 ID 목록
 */
function cleanDeadSessions() {
  if (!isMultiSession()) return { removed: [] };

  const locked = acquireLock(3000);
  const removed = [];
  let leadWasDead = false;

  try {
    const data = loadWithRecovery();
    const now = Date.now();

    for (const [sid, session] of Object.entries(data.sessions)) {
      const lastHb = new Date(session.last_heartbeat).getTime();
      if (isNaN(lastHb) || now - lastHb > HEARTBEAT_TTL_MS) {
        removed.push(sid);
        if (data.lead === sid) {
          leadWasDead = true;
          data.lead = null;
        }
        delete data.sessions[sid];
        appendAudit('session-dead-cleaned', sid, { last_heartbeat: session.last_heartbeat });
      }
    }

    if (removed.length > 0) {
      saveRegistry(data);
    }
  } finally {
    if (locked) releaseLock();
  }

  if (leadWasDead) {
    checkLeadFailover();
  }

  return { removed };
}

// ── IMPL-03: Lead Failover ───────────────────────────────────────────

/**
 * Lead Failover 확인 및 실행
 * Lead heartbeat > 60s → started_at 가장 이른 teammate를 lead로 승격
 */
function checkLeadFailover() {
  if (!isMultiSession()) return;

  const data = loadWithRecovery();
  const now = Date.now();

  // 현재 lead 생존 확인
  const leadId = data.lead;
  if (leadId) {
    const leadSession = data.sessions[leadId];
    if (leadSession) {
      const lastHb = new Date(leadSession.last_heartbeat).getTime();
      if (!isNaN(lastHb) && now - lastHb <= HEARTBEAT_TTL_MS) {
        // lead 생존 중 — failover 불필요
        return;
      }
    }
  }

  // Teammate 중 started_at 가장 이른 세션 선택
  const candidates = Object.entries(data.sessions)
    .filter(([sid, s]) => s.role === 'teammate')
    .sort(([, a], [, b]) => new Date(a.started_at) - new Date(b.started_at));

  if (candidates.length === 0) {
    appendAudit('failover-no-candidates', 'system', { previous_lead: leadId });
    return;
  }

  const [newLeadId] = candidates[0];
  const promoted = promoteToLead(newLeadId);
  if (promoted) {
    appendAudit('failover-completed', newLeadId, {
      previous_lead: leadId,
      promoted_at: new Date().toISOString()
    });
  }
}

/**
 * 세션을 Lead로 승격 (CAS 패턴)
 * lock 획득 → lead 필드 확인 → null 또는 dead이면 갱신
 * @param {string} sessionId
 * @returns {boolean} 승격 성공 여부
 */
function promoteToLead(sessionId) {
  if (!isMultiSession()) return false;

  const locked = acquireLock(3000);
  try {
    const data = loadWithRecovery();
    const session = data.sessions[sessionId];
    if (!session) return false;

    const now = Date.now();
    const currentLeadId = data.lead;
    let canPromote = false;

    if (currentLeadId === null) {
      canPromote = true;
    } else if (currentLeadId === sessionId) {
      // 이미 lead
      return true;
    } else {
      // 현재 lead dead 확인
      const currentLeadSession = data.sessions[currentLeadId];
      if (!currentLeadSession) {
        canPromote = true;
      } else {
        const lastHb = new Date(currentLeadSession.last_heartbeat).getTime();
        canPromote = isNaN(lastHb) || now - lastHb > HEARTBEAT_TTL_MS;
      }
    }

    if (!canPromote) return false;

    // 이전 lead의 role을 teammate로 변경
    if (currentLeadId && data.sessions[currentLeadId]) {
      data.sessions[currentLeadId].role = 'teammate';
    }

    // 승격 적용
    data.lead = sessionId;
    session.role = 'lead';
    session.last_heartbeat = new Date().toISOString();

    saveRegistry(data);
    appendAudit('session-promoted-to-lead', sessionId, {
      previous_lead: currentLeadId
    });
    return true;
  } finally {
    if (locked) releaseLock();
  }
}

// ── 조회 API ─────────────────────────────────────────────────────────

/**
 * 전체 세션 객체 반환
 * @returns {Object} sessions 맵 (비활성 시 빈 객체)
 */
function getSessions() {
  if (!isMultiSession()) return {};
  return loadWithRecovery().sessions;
}

/**
 * 현재 Lead 세션 ID 반환
 * @returns {string|null}
 */
function getLeadSession() {
  if (!isMultiSession()) return null;
  return loadWithRecovery().lead;
}

/**
 * 지정 세션이 lead인지 확인
 * @param {string} sessionId
 * @returns {boolean}
 */
function isLead(sessionId) {
  if (!isMultiSession()) return false;
  return loadWithRecovery().lead === sessionId;
}

// ── unregisterSession 최종 구현 (wasLead 추적 + 외부 failover) ──────

// 위의 _unregisterSessionImpl을 래핑하여 failover를 lock 해제 후 실행
function _unregisterSessionFinal(sessionId) {
  if (!isMultiSession()) return false;

  // 먼저 unregister 수행 (내부 lock)
  const result = _unregisterSessionImpl(sessionId);

  // lead였는지 사후 확인 (이미 삭제됐으므로 registry 재조회)
  const data = loadWithRecovery();
  if (result && data.lead === null && Object.keys(data.sessions).length > 0) {
    checkLeadFailover();
  }

  return result;
}

// ── exports ──────────────────────────────────────────────────────────

module.exports = {
  isMultiSession,
  registerSession,
  unregisterSession: _unregisterSessionFinal,
  getSessions,
  getLeadSession,
  isLead,
  claimFile,
  releaseFile,
  updateHeartbeat,
  cleanDeadSessions,
  loadWithRecovery,
  checkLeadFailover,
  promoteToLead,
  SESSIONS_FILE,
  SESSIONS_LOCK
};
