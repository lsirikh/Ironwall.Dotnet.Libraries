// .claude/hooks/_merge-advisor.js
// 세션별 owned_files 교집합 분석 — 수렴 충돌 감지 모듈 (FR-08)
//
// 기능:
//   - analyzeConflicts : 세션 간 owned_files 교집합으로 충돌 감지
//   - suggestMergeOrder: dependency 기반 병합 순서 제안
//   - reportToLead     : Lead mailbox에 충돌/순서 info 메시지 전송
//
// 활성화 조건: CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1 또는 =true
// 비활성화 시: 모든 함수 no-op 반환 (싱글세션 폴백)

'use strict';

const path = require('path');

// ── 경로 상수 ────────────────────────────────────────────────────────

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

// ── 의존 모듈 ────────────────────────────────────────────────────────

const { getSessions }  = require('./_sessions');
const { sendMessage }  = require('./_mailbox');

// ── isMultiSession guard ─────────────────────────────────────────────

/**
 * CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS 환경 변수로 멀티세션 활성화 여부 확인
 * @returns {boolean}
 */
function isMultiSession() {
  return process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS === '1' ||
         process.env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS === 'true';
}

// ── FR-08: 충돌 분석 ─────────────────────────────────────────────────

/**
 * 세션별 owned_files 교집합 분석 — 수렴 충돌 감지
 *
 * sessions 맵의 모든 쌍(sessionA, sessionB)을 순회하며
 * owned_files 교집합이 1개 이상이면 충돌로 간주한다.
 *
 * @param {Object} sessions — _sessions.js getSessions() 반환값
 *   { [sessionId]: { owned_files: string[], ... }, ... }
 * @returns {Array} conflicts [{sessionA, sessionB, files:[...]}]
 *   isMultiSession false → 빈 배열 반환
 */
function analyzeConflicts(sessions) {
  if (!isMultiSession()) return [];

  if (!sessions || typeof sessions !== 'object') return [];

  const entries = Object.entries(sessions);
  const conflicts = [];

  for (let i = 0; i < entries.length; i++) {
    const [idA, sessA] = entries[i];
    const filesA = Array.isArray(sessA.owned_files) ? sessA.owned_files : [];

    for (let j = i + 1; j < entries.length; j++) {
      const [idB, sessB] = entries[j];
      const filesB = Array.isArray(sessB.owned_files) ? sessB.owned_files : [];

      // 교집합 계산
      const setB = new Set(filesB);
      const shared = filesA.filter(f => setB.has(f));

      if (shared.length > 0) {
        conflicts.push({ sessionA: idA, sessionB: idB, files: shared });
      }
    }
  }

  return conflicts;
}

// ── FR-08: 병합 순서 제안 ────────────────────────────────────────────

/**
 * dependency 기반 병합 순서 제안
 *
 * 충돌 파일 수가 적은 세션(다른 세션과 겹침이 적은 세션)을 먼저 병합하도록
 * 오름차순 정렬한다. 충돌이 없으면 started_at 기준(이른 순서) 정렬을 사용한다.
 *
 * @param {Object} sessions — _sessions.js getSessions() 반환값
 * @returns {string[]} sessionId 배열 (병합 권장 순서)
 *   isMultiSession false → 빈 배열 반환
 */
function suggestMergeOrder(sessions) {
  if (!isMultiSession()) return [];

  if (!sessions || typeof sessions !== 'object') return [];

  const entries = Object.entries(sessions);
  if (entries.length === 0) return [];

  // 세션별 충돌 파일 누적 수 계산
  const conflictCount = {};
  for (const [id] of entries) {
    conflictCount[id] = 0;
  }

  const conflicts = analyzeConflicts(sessions);
  for (const { sessionA, sessionB, files } of conflicts) {
    conflictCount[sessionA] = (conflictCount[sessionA] || 0) + files.length;
    conflictCount[sessionB] = (conflictCount[sessionB] || 0) + files.length;
  }

  // 충돌 수 오름차순 → 충돌 수 동일 시 started_at 오름차순
  const sorted = entries
    .map(([id, sess]) => ({
      id,
      conflictScore: conflictCount[id] || 0,
      startedAt: sess.started_at ? new Date(sess.started_at).getTime() : 0
    }))
    .sort((a, b) => {
      if (a.conflictScore !== b.conflictScore) {
        return a.conflictScore - b.conflictScore;
      }
      return a.startedAt - b.startedAt;
    });

  return sorted.map(s => s.id);
}

// ── FR-08: Lead mailbox 보고 ─────────────────────────────────────────

/**
 * Lead mailbox에 충돌 분석 결과를 info 메시지로 전송
 *
 * _mailbox.js sendMessage()를 사용하며,
 * I/O 오류는 stderr에 기록하고 함수를 조용히 종료한다.
 *
 * @param {Array}    conflicts     - analyzeConflicts() 반환값
 * @param {string[]} order         - suggestMergeOrder() 반환값
 * @param {string}   leadSessionId - 수신 Lead 세션 ID
 * @returns {Promise<void>}
 *   isMultiSession false → 즉시 resolve (no-op)
 */
async function reportToLead(conflicts, order, leadSessionId) {
  if (!isMultiSession()) return;

  if (!leadSessionId) {
    process.stderr.write('[_merge-advisor] reportToLead: leadSessionId is required\n');
    return;
  }

  try {
    sendMessage(
      leadSessionId,
      'info',
      { conflicts, mergeOrder: order },
      'harness'
    );
  } catch (err) {
    process.stderr.write(`[_merge-advisor] reportToLead error: ${err.message}\n`);
  }
}

// ── exports ──────────────────────────────────────────────────────────

module.exports = { analyzeConflicts, suggestMergeOrder, reportToLead };
